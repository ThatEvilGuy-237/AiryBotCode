# Airy UI changes

Since the last hand-over (base commit ec2dd9a), up to ec2dd9a. Base 0.1.0, company package 0.1.11.

No changes to the base or to your layer in this range.
0 commit(s) in range.
