<script setup lang="ts">
/**
 * ConfirmDialog — yes/no confirmation built on Modal. Replaces native confirm().
 *
 * @prop open / title / message / confirmText / cancelText
 * @prop danger - render the confirm action as destructive (red)
 * @event confirm / cancel
 *
 * Status: new
 */
import Button from '../Button/Button.vue'
import Modal from '../Modal/Modal.vue'

withDefaults(defineProps<{
  open: boolean
  title?: string
  message?: string
  confirmText?: string
  cancelText?: string
  danger?: boolean
}>(), { title: 'Are you sure?', confirmText: 'Confirm', cancelText: 'Cancel', danger: false })

const emit = defineEmits<{ confirm: []; cancel: [] }>()
</script>

<template>
  <Modal data-ui="confirm-dialog" :open="open" :title="title" size="sm" @close="emit('cancel')">
    <p :class="$style.msg"><slot>{{ message }}</slot></p>
    <template #footer>
      <Button variant="ghost" size="sm" @click="emit('cancel')">{{ cancelText }}</Button>
      <Button :variant="danger ? 'danger' : 'solid'" size="sm" @click="emit('confirm')">{{ confirmText }}</Button>
    </template>
  </Modal>
</template>

<style module>
.msg { font-size: var(--font-size-sm); color: var(--color-text-dim, var(--color-fg)); line-height: 1.5; margin: 0; }
</style>
