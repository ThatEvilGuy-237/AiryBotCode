<script setup lang="ts">
/**
 * EmptyState
 * Dashed-border block for empty lists / "nothing here yet" moments.
 *
 * @prop title - the main message (bold)
 * @prop sub   - optional muted second line
 *
 * Slots:
 *   glyph   - the icon/symbol inside the round badge (default: "+")
 *   default - actions row beneath the text (Button, etc.)
 *
 * Status: stable | Consumers: Patterns
 */
defineProps<{ title: string; sub?: string }>()
</script>

<template>
  <div data-ui="empty-state" :class="$style.empty">
    <div :class="$style.glyph">
      <slot name="glyph">+</slot>
    </div>
    <div :class="$style.title">{{ title }}</div>
    <div v-if="sub" :class="$style.sub">{{ sub }}</div>
    <div v-if="$slots.default" :class="$style.actions"><slot /></div>
  </div>
</template>

<style module>
.empty {
  display: flex;
  flex-direction: column;
  align-items: center;
  gap: var(--space-3);
  padding: calc(var(--space-4) * 2) var(--space-4);
  border: 1px dashed var(--color-border, var(--color-muted));
  border-radius: var(--radius);
  background: var(--color-bg-2, var(--color-bg));
  text-align: center;
  width: 100%;
}
.glyph {
  width: 44px;
  height: 44px;
  border-radius: 50%;
  border: var(--border);
  background: var(--color-surface);
  color: var(--color-accent);
  display: inline-flex;
  align-items: center;
  justify-content: center;
  font-family: var(--font-mono);
  font-size: 22px;
}
.title {
  font-size: var(--font-size-base);
  font-weight: 600;
  color: var(--color-fg);
}
.sub {
  font-size: var(--font-size-sm);
  color: var(--color-text-dim, var(--color-muted));
  max-width: 360px;
}
.actions {
  display: flex;
  gap: var(--space-2);
  margin-top: var(--space-2);
}
</style>
