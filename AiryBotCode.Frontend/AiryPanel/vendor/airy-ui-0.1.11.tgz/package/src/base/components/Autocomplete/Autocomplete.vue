<script setup lang="ts">
/**
 * Autocomplete
 * One value, picked from a list you do not have. You give it an async
 * `fetchOptions(query, signal)` and it asks the server as the user types:
 * debounced, deduplicated, cached, and cancelled — a slow answer to an old
 * keystroke can never overwrite a fast answer to a new one.
 *
 * It is the third rung of the picker ladder and the rungs are not
 * interchangeable:
 *   Select        — a short list you already have, one value.
 *   MultiSelect   — a list you already have, many values (filter turns itself
 *                   on past `searchAfter`).
 *   Autocomplete  — a list only the server has, one value.
 *   TagInput      — values the user invents, no list at all.
 *   SearchField   — not a picker: it filters a view you are already looking at
 *                   and commits nothing.
 * MultiSelect drew the line between *offered* and *invented* values. This draws
 * the second line, inside "offered": Select and MultiSelect take options you can
 * hand over, Autocomplete takes options you can only ask for. If you can pass an
 * array, do — a component that round-trips the network for eight fixed rooms is
 * slower and less accessible than a listbox. If you cannot, do not paginate a
 * MultiSelect; use this.
 *
 * What it commits: `modelValue` is the chosen option's `value` — an id, not a
 * label — or `null`. The full option comes back on `v-model:selected` so you can
 * render it without a second lookup, and `commit` fires a discriminated
 * `{ kind: 'option' | 'text' }` payload. With `allowFreeText` the user may commit
 * words that match nothing; that is the *only* case where `kind` is `'text'`, so
 * `commit.kind === 'text'` is the whole answer to "did they pick concept-42 or
 * type some words". The control says so on screen too: a committed option shows
 * its id as a mono badge inside the field, free text shows `text`.
 *
 * Typing over a committed value detaches it — `modelValue` goes `null` at the
 * first keystroke, because a half-typed field is not a value and a form must
 * never submit the id the user was busy replacing.
 *
 * @prop modelValue     - the committed value (v-model), or null.
 * @prop selected       - the committed option (`v-model:selected`). Optional, but
 *                        passing it saves the `resolveOption` round-trip on load.
 * @prop fetchOptions   - `(query, signal) => Promise<AutocompleteOption[]>`. Pass
 *                        `signal` to `fetch` so an abandoned request is really
 *                        aborted; ignoring it is safe, stale answers are dropped
 *                        either way.
 * @prop resolveOption  - `(value) => Promise<AutocompleteOption | null>`. Turns an
 *                        incoming id into a label. Without it an unknown incoming
 *                        id is shown verbatim in mono rather than guessed at.
 * @prop placeholder    - shown while the field is empty.
 * @prop minChars       - queries shorter than this never reach the server (2).
 * @prop debounce       - ms of quiet before a query is sent (200). A cache hit
 *                        skips it entirely.
 * @prop cache          - remember each query's results for the field's lifetime.
 * @prop cacheSize      - how many queries to keep (24, oldest dropped).
 * @prop allowFreeText  - Enter may commit unmatched text as the value.
 * @prop commitOnTab    - Tab commits the active option instead of just leaving.
 * @prop openOnFocus    - re-open the last result set on focus.
 * @prop clearable      - show the clear button once something is committed.
 * @prop highlight      - mark the matched substring in each option (default true).
 * @prop status         - show the mono `//` state line (default true).
 * @prop size           - 'sm' | 'md' control height.
 * @prop disabled       - dim and lock the control.
 * @prop noMatch        - headline when the server returned nothing.
 * @prop errorTitle     - headline when the fetch rejected.
 * @prop listMaxHeight  - height at which the list scrolls.
 * @prop badgeShows     - what the committed badge shows: the option's 'value' (default), its 'meta', or 'none'.
 * @prop ariaLabel      - accessible name when not inside a <Field>.
 *
 * @event update:modelValue - (string | null) commit, detach or clear.
 * @event update:selected   - (AutocompleteOption | null) the option behind it.
 * @event commit            - (AutocompleteCommit) an option or free text was chosen.
 * @event clear             - the value was cleared.
 * @event query             - (string) the query the user has typed, after trimming.
 * @event error             - (Error) a fetch rejected; the popover shows it.
 * @event open / close      - popover visibility.
 *
 * @slot option  - one row. Slot props: { option, active, selected, labelParts, metaParts }.
 * @slot empty   - replaces the no-matches state. Slot props: { query }.
 * @slot error   - replaces the error state. Slot props: { error, retry }.
 * @slot status  - replaces the `//` line text. Slot props: { state, text, count }.
 *
 * Status: new | Consumers: catalog, memory portal search + concept pickers
 */
import { computed, nextTick, onBeforeUnmount, ref, watch } from 'vue'
import Icon from '../Icon/Icon.vue'

export interface AutocompleteOption {
  label: string
  value: string
  meta?: string
  hint?: string
  group?: string
  disabled?: boolean
}

export type AutocompleteFetch = (query: string, signal: AbortSignal) => Promise<AutocompleteOption[]>

export type AutocompleteCommit =
  | { kind: 'option', value: string, option: AutocompleteOption }
  | { kind: 'text', value: string }

export type AutocompleteState = 'short' | 'searching' | 'results' | 'empty' | 'error'

export interface AutocompletePart { text: string, match: boolean }

const props = withDefaults(defineProps<{
  modelValue: string | null
  fetchOptions: AutocompleteFetch
  selected?: AutocompleteOption | null
  resolveOption?: (value: string) => Promise<AutocompleteOption | null>
  placeholder?: string
  minChars?: number
  debounce?: number
  cache?: boolean
  cacheSize?: number
  allowFreeText?: boolean
  commitOnTab?: boolean
  openOnFocus?: boolean
  clearable?: boolean
  highlight?: boolean
  status?: boolean
  size?: 'sm' | 'md'
  disabled?: boolean
  noMatch?: string
  errorTitle?: string
  listMaxHeight?: string
  ariaLabel?: string
  badgeShows?: 'value' | 'meta' | 'none'
}>(), {
  selected: null,
  placeholder: 'Search…',
  minChars: 2,
  debounce: 200,
  cache: true,
  cacheSize: 24,
  allowFreeText: false,
  commitOnTab: true,
  openOnFocus: false,
  clearable: true,
  highlight: true,
  status: true,
  size: 'md',
  disabled: false,
  noMatch: 'No matches',
  errorTitle: 'Search failed',
  listMaxHeight: '280px',
})

const emit = defineEmits<{
  'update:modelValue': [v: string | null]
  'update:selected': [option: AutocompleteOption | null]
  commit: [payload: AutocompleteCommit]
  clear: []
  query: [q: string]
  error: [err: Error]
  open: []
  close: []
}>()

defineSlots<{
  option?: (p: {
    option: AutocompleteOption
    active: boolean
    selected: boolean
    labelParts: AutocompletePart[]
    metaParts: AutocompletePart[]
  }) => any
  empty?: (p: { query: string }) => any
  error?: (p: { error: Error, retry: () => void }) => any
  status?: (p: { state: AutocompleteState, text: string, count: number }) => any
}>()

const uid = `hive-ac-${Math.random().toString(36).slice(2, 9)}`
const listId = `${uid}-list`
const statusId = `${uid}-status`
const optionId = (i: number) => `${uid}-opt-${i}`

const root = ref<HTMLElement>()
const inputEl = ref<HTMLInputElement>()
const listEl = ref<HTMLElement>()

const open = ref(false)
const query = ref('')
const options = ref<AutocompleteOption[]>([])
const activeIndex = ref(-1)
const loading = ref(false)
const failure = ref<Error | null>(null)
const fromCache = ref(false)
const matched = ref('')
const dropUp = ref(false)
const chosen = ref<AutocompleteOption | null>(null)

const cache = new Map<string, AutocompleteOption[]>()

let seq = 0
let resolveSeq = 0
let controller: AbortController | undefined
let timer: ReturnType<typeof setTimeout> | undefined
let echo: string | null | undefined
let pending = ''

const trimmed = computed(() => query.value.trim())
const tooShort = computed(() => trimmed.value.length < props.minChars)
const committed = computed(() => props.modelValue !== null && props.modelValue !== '')

const state = computed<AutocompleteState>(() => {
  if (failure.value) return 'error'
  if (tooShort.value) return 'short'
  if (loading.value && !options.value.length) return 'searching'
  if (!options.value.length) return 'empty'
  return 'results'
})

const badge = computed(() => {
  if (!committed.value || props.badgeShows === 'none') return ''
  if (chosen.value) return props.badgeShows === 'meta' ? chosen.value.meta ?? '' : chosen.value.value
  return 'text'
})

const statusText = computed(() => {
  const n = options.value.length
  if (failure.value) return failure.value.message || 'the search endpoint did not answer'
  if (tooShort.value) {
    const left = props.minChars - trimmed.value.length
    if (!trimmed.value) return `type ${props.minChars} character${props.minChars === 1 ? '' : 's'} to search`
    return `type ${left} more character${left === 1 ? '' : 's'}`
  }
  if (loading.value) {
    return n ? `searching… still showing ${n} for “${matched.value}”` : 'searching…'
  }
  if (!n) return `nothing matches “${trimmed.value}”`
  const tail = fromCache.value ? ' · cached' : ''
  const free = props.allowFreeText && !committed.value ? ' · enter keeps what you typed' : ''
  return `${n} match${n === 1 ? '' : 'es'}${tail}${free}`
})

const groups = computed(() => {
  const out: { label: string, options: AutocompleteOption[] }[] = []
  for (const o of options.value) {
    const label = o.group ?? ''
    const last = out[out.length - 1]
    if (last && last.label === label) last.options.push(o)
    else out.push({ label, options: [o] })
  }
  return out
})

const indexOf = computed(() => {
  const map = new Map<string, number>()
  options.value.forEach((o, i) => map.set(o.value, i))
  return map
})

function idx(option: AutocompleteOption) {
  return indexOf.value.get(option.value) ?? -1
}

function parts(text: string | undefined): AutocompletePart[] {
  if (!text) return []
  const q = matched.value.trim().toLowerCase()
  if (!props.highlight || !q) return [{ text, match: false }]
  const lower = text.toLowerCase()
  let needles = [q]
  if (!lower.includes(q)) needles = q.split(/\s+/).filter(w => w.length > 1)
  if (!needles.length) return [{ text, match: false }]

  const out: AutocompletePart[] = []
  let i = 0
  while (i < text.length) {
    let at = -1
    let len = 0
    for (const needle of needles) {
      const found = lower.indexOf(needle, i)
      if (found < 0) continue
      if (at < 0 || found < at || (found === at && needle.length > len)) {
        at = found
        len = needle.length
      }
    }
    if (at < 0) {
      out.push({ text: text.slice(i), match: false })
      break
    }
    if (at > i) out.push({ text: text.slice(i, at), match: false })
    out.push({ text: text.slice(at, at + len), match: true })
    i = at + len
  }
  return out
}

function remember(key: string, value: AutocompleteOption[]) {
  if (!props.cache) return
  cache.delete(key)
  cache.set(key, value)
  while (cache.size > Math.max(1, props.cacheSize)) {
    const oldest = cache.keys().next().value
    if (oldest === undefined) break
    cache.delete(oldest)
  }
}

function abandon() {
  seq++
  controller?.abort()
  controller = undefined
  if (timer) {
    clearTimeout(timer)
    timer = undefined
  }
}

function firstEnabled(list: AutocompleteOption[]) {
  return list.findIndex(o => !o.disabled)
}

function adopt(list: AutocompleteOption[], q: string, cached: boolean) {
  options.value = list
  activeIndex.value = firstEnabled(list)
  matched.value = q
  fromCache.value = cached
  loading.value = false
  failure.value = null
  nextTick(scrollActiveIntoView)
}

async function run(q: string) {
  const id = ++seq
  controller?.abort()
  const ctl = new AbortController()
  controller = ctl
  loading.value = true
  failure.value = null
  try {
    const result = await props.fetchOptions(q, ctl.signal)
    if (id !== seq) return
    remember(q.toLowerCase(), result ?? [])
    adopt(result ?? [], q, false)
  } catch (error) {
    if (id !== seq) return
    if (ctl.signal.aborted) return
    const err = error instanceof Error ? error : new Error(String(error))
    if (err.name === 'AbortError') return
    failure.value = err
    options.value = []
    activeIndex.value = -1
    loading.value = false
    emit('error', err)
  }
}

function schedule(force = false) {
  if (timer) {
    clearTimeout(timer)
    timer = undefined
  }
  const q = trimmed.value
  pending = q
  emit('query', q)

  if (q.length < props.minChars) {
    abandon()
    options.value = []
    activeIndex.value = -1
    loading.value = false
    failure.value = null
    fromCache.value = false
    matched.value = ''
    return
  }

  const key = q.toLowerCase()
  const hit = force ? undefined : cache.get(key)
  if (hit) {
    abandon()
    remember(key, hit)
    adopt(hit, q, true)
    return
  }

  loading.value = true
  failure.value = null
  timer = setTimeout(() => run(q), props.debounce)
}

function openList() {
  if (props.disabled || open.value) return
  open.value = true
  emit('open')
  measure()
  nextTick(scrollActiveIntoView)
}

function closeList(refocus = true) {
  if (!open.value) return
  open.value = false
  emit('close')
  if (refocus) inputEl.value?.focus()
}

function measure() {
  const el = root.value
  if (!el || typeof window === 'undefined') return
  const rect = el.getBoundingClientRect()
  const need = parseInt(props.listMaxHeight, 10) || 280
  dropUp.value = window.innerHeight - rect.bottom < need + 24 && rect.top > window.innerHeight - rect.bottom
}

function scrollActiveIntoView() {
  if (activeIndex.value < 0) return
  listEl.value?.querySelector<HTMLElement>(`#${optionId(activeIndex.value)}`)?.scrollIntoView({ block: 'nearest' })
}

function move(step: number) {
  const list = options.value
  if (!list.length) return
  let i = activeIndex.value
  for (let n = 0; n < list.length; n++) {
    i += step
    if (i < 0) i = list.length - 1
    if (i >= list.length) i = 0
    if (!list[i].disabled) break
  }
  activeIndex.value = i
  nextTick(scrollActiveIntoView)
}

function edge(to: 'first' | 'last') {
  const list = options.value
  const order = to === 'first' ? list.map((_, i) => i) : list.map((_, i) => list.length - 1 - i)
  const found = order.find(i => !list[i].disabled)
  if (found !== undefined) {
    activeIndex.value = found
    nextTick(scrollActiveIntoView)
  }
}

function hover(option: AutocompleteOption) {
  if (option.disabled) return
  activeIndex.value = idx(option)
}

function publish(value: string | null, option: AutocompleteOption | null) {
  echo = props.modelValue === value ? undefined : value
  chosen.value = option
  emit('update:modelValue', value)
  emit('update:selected', option)
}

function pick(option: AutocompleteOption) {
  if (props.disabled || option.disabled) return
  abandon()
  query.value = option.label
  matched.value = ''
  publish(option.value, option)
  emit('commit', { kind: 'option', value: option.value, option })
  closeList()
}

function commitText() {
  const value = trimmed.value
  if (!value) return false
  abandon()
  loading.value = false
  publish(value, null)
  emit('commit', { kind: 'text', value })
  closeList()
  return true
}

function detach() {
  if (props.modelValue === null) return
  publish(null, null)
}

function clear() {
  if (props.disabled) return
  abandon()
  query.value = ''
  options.value = []
  activeIndex.value = -1
  matched.value = ''
  loading.value = false
  failure.value = null
  publish(null, null)
  emit('clear')
  closeList(false)
  inputEl.value?.focus()
}

function retry() {
  failure.value = null
  schedule(true)
  openList()
}

function refresh() {
  schedule(true)
}

function clearCache() {
  cache.clear()
}

function onInput(event: Event) {
  query.value = (event.target as HTMLInputElement).value
  detach()
  schedule()
  openList()
}

function onFocus() {
  if (!props.openOnFocus) return
  if (!options.value.length && !failure.value && !tooShort.value) schedule()
  openList()
}

function onKeydown(event: KeyboardEvent) {
  const key = event.key

  if (key === 'ArrowDown' || key === 'ArrowUp') {
    event.preventDefault()
    if (!open.value) {
      openList()
      if (!options.value.length && !tooShort.value) schedule()
      return
    }
    move(key === 'ArrowDown' ? 1 : -1)
    return
  }
  if (key === 'Home' || key === 'End') {
    if (!open.value || !options.value.length) return
    event.preventDefault()
    edge(key === 'Home' ? 'first' : 'last')
    return
  }
  if (key === 'Enter') {
    const option = open.value ? options.value[activeIndex.value] : undefined
    if (option) {
      event.preventDefault()
      pick(option)
      return
    }
    if (props.allowFreeText && !committed.value && commitText()) event.preventDefault()
    return
  }
  if (key === 'Tab') {
    if (props.commitOnTab && open.value) {
      const option = options.value[activeIndex.value]
      if (option) {
        pick(option)
        closeList(false)
        return
      }
    }
    if (open.value) closeList(false)
    restore()
    return
  }
  if (key === 'Escape') {
    if (open.value) {
      event.preventDefault()
      event.stopPropagation()
      closeList()
      return
    }
    if (!query.value) return
    event.preventDefault()
    event.stopPropagation()
    if (committed.value) restore()
    else clear()
  }
}

function restore() {
  if (committed.value) {
    query.value = chosen.value?.label ?? props.modelValue ?? ''
    matched.value = ''
    return
  }
  if (props.allowFreeText) return
  query.value = ''
  options.value = []
  activeIndex.value = -1
  matched.value = ''
  loading.value = false
  abandon()
}

function onDocumentPointer(event: PointerEvent) {
  if (root.value?.contains(event.target as Node)) return
  closeList(false)
  restore()
}

watch(open, (isOpen) => {
  if (typeof document === 'undefined') return
  if (isOpen) {
    document.addEventListener('pointerdown', onDocumentPointer, true)
    window.addEventListener('resize', measure)
  } else {
    document.removeEventListener('pointerdown', onDocumentPointer, true)
    window.removeEventListener('resize', measure)
  }
})

watch(() => props.selected, (option) => {
  if (!option) return
  if (option.value !== props.modelValue) return
  chosen.value = option
  if (typeof document === 'undefined' || document.activeElement !== inputEl.value) query.value = option.label
})

watch(() => props.modelValue, async (value) => {
  if (value === echo) {
    echo = undefined
    return
  }
  echo = undefined

  if (value === null || value === '') {
    chosen.value = null
    query.value = ''
    return
  }
  if (chosen.value?.value === value) {
    query.value = chosen.value.label
    return
  }
  if (props.selected && props.selected.value === value) {
    chosen.value = props.selected
    query.value = props.selected.label
    return
  }
  const known = options.value.find(o => o.value === value)
  if (known) {
    chosen.value = known
    query.value = known.label
    emit('update:selected', known)
    return
  }
  if (!props.resolveOption) {
    chosen.value = { label: value, value, meta: value }
    query.value = value
    return
  }
  const id = ++resolveSeq
  let option: AutocompleteOption | null = null
  try {
    option = await props.resolveOption(value)
  } catch {
    option = null
  }
  if (id !== resolveSeq) return
  chosen.value = option ?? { label: value, value, meta: value }
  query.value = chosen.value.label
  emit('update:selected', chosen.value)
}, { immediate: true })

onBeforeUnmount(() => {
  abandon()
  if (typeof document === 'undefined') return
  document.removeEventListener('pointerdown', onDocumentPointer, true)
  window.removeEventListener('resize', measure)
})

function focus() {
  inputEl.value?.focus()
}

defineExpose({ focus, clear, refresh, clearCache, openList, closeList })
</script>

<template>
  <div data-ui="autocomplete" ref="root" :class="[$style.root, $style[size], disabled && $style.disabled]">
    <div :class="[$style.control, open && $style.controlOpen, committed && $style.controlSet]">
      <span :class="$style.lead" aria-hidden="true">
        <Icon name="search" :size="14" />
      </span>

      <input
        ref="inputEl"
        :class="$style.input"
        type="text"
        role="combobox"
        autocomplete="off"
        spellcheck="false"
        aria-haspopup="listbox"
        aria-autocomplete="list"
        :aria-expanded="open"
        :aria-controls="listId"
        :aria-activedescendant="open && activeIndex >= 0 ? optionId(activeIndex) : undefined"
        :aria-label="ariaLabel"
        :aria-describedby="status ? statusId : undefined"
        :disabled="disabled"
        :placeholder="placeholder"
        :value="query"
        @input="onInput"
        @focus="onFocus"
        @keydown="onKeydown"
      />

      <span v-if="badge" :class="[$style.badge, !chosen && $style.badgeText]">{{ badge }}</span>

      <button
        v-if="clearable && (committed || query)"
        type="button"
        :class="$style.clear"
        aria-label="Clear"
        :disabled="disabled"
        @click="clear"
      >
        <Icon name="close" :size="12" />
      </button>
    </div>

    <div v-if="open" :class="[$style.popover, dropUp && $style.popoverUp]">
      <ul
        :id="listId"
        ref="listEl"
        :class="[$style.list, loading && options.length && $style.stale]"
        role="listbox"
        :aria-busy="loading || undefined"
        :style="{ maxHeight: listMaxHeight }"
      >
        <template v-for="group in groups" :key="group.label || '_'">
          <li v-if="group.label" :class="$style.group" role="presentation">{{ group.label }}</li>
          <li
            v-for="option in group.options"
            :id="optionId(idx(option))"
            :key="option.value"
            :class="[
              $style.option,
              activeIndex === idx(option) && $style.active,
              option.value === modelValue && $style.on,
              option.disabled && $style.blocked,
            ]"
            role="option"
            :aria-selected="option.value === modelValue"
            :aria-disabled="option.disabled || undefined"
            @click="pick(option)"
            @mousemove="hover(option)"
          >
            <slot
              name="option"
              :option="option"
              :active="activeIndex === idx(option)"
              :selected="option.value === modelValue"
              :label-parts="parts(option.label)"
              :meta-parts="parts(option.meta)"
            >
              <span :class="$style.body">
                <span :class="$style.label">
                  <template v-for="(part, i) in parts(option.label)" :key="i">
                    <mark v-if="part.match" :class="$style.mark">{{ part.text }}</mark>
                    <template v-else>{{ part.text }}</template>
                  </template>
                </span>
                <span v-if="option.hint" :class="$style.hint">{{ option.hint }}</span>
              </span>
              <span v-if="option.meta" :class="$style.meta">
                <template v-for="(part, i) in parts(option.meta)" :key="i">
                  <mark v-if="part.match" :class="$style.mark">{{ part.text }}</mark>
                  <template v-else>{{ part.text }}</template>
                </template>
              </span>
            </slot>
          </li>
        </template>

        <li v-if="state === 'searching'" :class="$style.ghosts" role="presentation">
          <span v-for="n in 3" :key="n" :class="$style.ghost" :style="{ width: `${74 - n * 14}%` }" />
        </li>

        <li v-else-if="state === 'error'" :class="[$style.block, $style.blockError]" role="presentation">
          <slot name="error" :error="(failure as Error)" :retry="retry">
            <span :class="$style.blockTitle">{{ errorTitle }}</span>
            <span :class="$style.blockLine">
              <span :class="$style.slashes">//</span>
              {{ failure?.message || 'the search endpoint did not answer' }}
            </span>
            <button type="button" :class="$style.action" @click="retry">retry</button>
          </slot>
        </li>

        <li v-else-if="state === 'empty'" :class="$style.block" role="presentation">
          <slot name="empty" :query="trimmed">
            <span :class="$style.blockTitle">{{ noMatch }}</span>
            <span :class="$style.blockLine">
              <span :class="$style.slashes">//</span>
              {{ allowFreeText ? `nothing matches “${trimmed}” — enter keeps it as text anyway` : `nothing matches “${trimmed}” — try fewer words` }}
            </span>
          </slot>
        </li>

        <li v-else-if="state === 'short'" :class="$style.block" role="presentation">
          <span :class="$style.blockLine">
            <span :class="$style.slashes">//</span>
            {{ statusText }}
          </span>
        </li>
      </ul>
    </div>

    <p
      v-if="status"
      :id="statusId"
      :class="[$style.status, state === 'error' && $style.statusError]"
      role="status"
    >
      <slot name="status" :state="state" :text="statusText" :count="options.length">
        <span :class="$style.slashes" aria-hidden="true">//</span>
        <span>{{ statusText }}</span>
      </slot>
    </p>
  </div>
</template>

<style module>
/* Shell */
.root {
  position: relative;
  display: flex;
  flex-direction: column;
  gap: var(--space-1);
  min-width: 0;
  width: 100%;
}

/* Control */
.control {
  display: flex;
  align-items: center;
  gap: var(--space-2);
  padding: 0 var(--space-2);
  background: var(--color-bg);
  border: 1px solid var(--color-border);
  border-radius: var(--radius);
  cursor: text;
  transition: border-color 0.12s ease;
}
.sm .control { height: 28px; }
.md .control { height: 34px; }
.control:hover { border-color: var(--color-border-hi); }
.controlOpen,
.control:focus-within { border-color: var(--color-accent); }
.disabled .control { opacity: 0.5; cursor: not-allowed; }

.lead {
  display: inline-flex;
  flex-shrink: 0;
  color: var(--color-text-ghost);
}
.control:focus-within .lead { color: var(--color-muted); }

.input {
  flex: 1 1 auto;
  min-width: 0;
  height: 100%;
  border: 0;
  background: transparent;
  color: var(--color-fg);
  font-family: var(--font-family);
  font-size: var(--font-size-sm);
}
.input:focus { outline: none; }
.input::placeholder { color: var(--color-text-ghost); }

/* The committed value, visible as itself: the id in mono, or the word `text`
   when free text was accepted. This is the on-screen half of the
   option-vs-free-text answer. */
.badge {
  flex-shrink: 0;
  max-width: 42%;
  padding: 1px var(--space-1);
  border: 1px solid var(--color-border);
  border-radius: var(--r-1);
  background: var(--color-surface-mute);
  font-family: var(--font-mono);
  font-size: var(--font-size-xs);
  color: var(--color-text-dim);
  overflow: hidden;
  text-overflow: ellipsis;
  white-space: nowrap;
}
.badgeText {
  border-style: dashed;
  color: var(--color-muted);
}

.clear {
  display: inline-flex;
  flex-shrink: 0;
  padding: 1px;
  border: 0;
  border-radius: var(--r-1);
  background: none;
  color: var(--color-text-ghost);
  cursor: pointer;
}
.clear:hover { color: var(--color-fg); }
.clear:focus-visible {
  outline: 1px solid var(--color-accent);
  outline-offset: 1px;
  color: var(--color-fg);
}

/* Popover — bordered surface, no shadow */
.popover {
  position: absolute;
  z-index: 20;
  top: calc(100% + var(--space-1));
  left: 0;
  right: 0;
  background: var(--color-surface);
  border: 1px solid var(--color-border-hi);
  border-radius: var(--radius);
  overflow: hidden;
  animation: hive-ac-pop 0.12s ease-out;
}
.popoverUp {
  top: auto;
  bottom: calc(100% + var(--space-1));
}
@keyframes hive-ac-pop {
  from { opacity: 0; transform: translateY(-3px); }
  to   { opacity: 1; transform: none; }
}

.list {
  margin: 0;
  padding: var(--space-1);
  list-style: none;
  overflow-y: auto;
}
/* Old answers stay readable while a newer one is in flight — nothing jumps. */
.stale .option { opacity: 0.5; }

.group {
  padding: var(--space-2) var(--space-2) var(--space-1);
  font-family: var(--font-mono);
  font-size: var(--font-size-xs);
  letter-spacing: 0.08em;
  text-transform: uppercase;
  color: var(--color-text-ghost);
}

.option {
  display: flex;
  align-items: baseline;
  gap: var(--space-3);
  padding: var(--space-1) var(--space-2);
  border: 1px solid transparent;
  border-radius: var(--r-1);
  cursor: pointer;
}
.active {
  border-color: var(--color-accent-edge);
  background: var(--color-surface-hi);
}
.on .label { color: var(--color-fg); }
.blocked { opacity: 0.45; cursor: not-allowed; }

.body {
  display: flex;
  flex-direction: column;
  gap: 1px;
  min-width: 0;
  flex: 1 1 auto;
}
.label {
  font-family: var(--font-family);
  font-size: var(--font-size-sm);
  color: var(--color-text-dim);
  overflow: hidden;
  text-overflow: ellipsis;
  white-space: nowrap;
}
.hint {
  font-family: var(--font-family);
  font-size: var(--font-size-xs);
  color: var(--color-text-ghost);
  overflow: hidden;
  text-overflow: ellipsis;
  white-space: nowrap;
}
.meta {
  flex-shrink: 0;
  max-width: 40%;
  font-family: var(--font-mono);
  font-size: var(--font-size-xs);
  color: var(--color-muted);
  overflow: hidden;
  text-overflow: ellipsis;
  white-space: nowrap;
}

/* The match — weight and contrast, never a highlighter fill and never the
   accent, which belongs to the active row's hairline alone. */
.mark {
  background: none;
  color: var(--color-fg);
  font-weight: 600;
  box-shadow: inset 0 -1px 0 var(--color-border-hi);
}

/* Loading — outlined bars hold the row height so nothing reflows on arrival */
.ghosts {
  display: flex;
  flex-direction: column;
  gap: var(--space-2);
  padding: var(--space-3) var(--space-2);
}
.ghost {
  height: 9px;
  border: 1px solid var(--color-border-soft);
  border-radius: var(--r-1);
  animation: hive-ac-breathe 1.4s ease-in-out infinite;
}

@keyframes hive-ac-breathe {
  0%, 100% { opacity: 0.35; }
  50%      { opacity: 0.9; }
}

/* Empty / error / too-short — real states, each visibly a different one */
.block {
  display: flex;
  flex-direction: column;
  align-items: flex-start;
  gap: 2px;
  padding: var(--space-3) var(--space-2);
}
.blockError {
  margin: var(--space-1);
  padding-left: var(--space-2);
  border-left: 1px solid var(--color-danger);
}
.blockTitle {
  font-family: var(--font-family);
  font-size: var(--font-size-sm);
  color: var(--color-text-dim);
}
.blockError .blockTitle { color: var(--color-danger); }
.blockLine {
  display: flex;
  gap: var(--space-2);
  font-family: var(--font-mono);
  font-size: var(--font-size-xs);
  line-height: 1.5;
  color: var(--color-muted);
}

.action {
  margin-top: var(--space-1);
  padding: 0;
  border: 0;
  background: none;
  font-family: var(--font-mono);
  font-size: var(--font-size-xs);
  color: var(--color-muted);
  cursor: pointer;
}
.action:hover { color: var(--color-accent); }
.action:focus-visible { outline: 1px solid var(--color-accent); outline-offset: 2px; }

/* The `//` engineer line */
.status {
  display: flex;
  gap: var(--space-2);
  margin: 0;
  font-family: var(--font-mono);
  font-size: var(--font-size-xs);
  line-height: 1.5;
  color: var(--color-muted);
}
.statusError { color: var(--color-danger); }
.slashes { color: var(--color-text-ghost); flex-shrink: 0; }

@media (prefers-reduced-motion: reduce) {
  .popover { animation: none; }
  .ghost { animation: none; opacity: 0.6; }
  .control, .lead { transition: none; }
}
</style>
