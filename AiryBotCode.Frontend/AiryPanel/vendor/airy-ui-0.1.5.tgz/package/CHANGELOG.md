# Airy UI changes

Since the last hand-over (base commit 52899c9), up to 52899c9. Base 0.1.0, company package 0.1.5.

No changes to the base or to your layer in this range.
0 commit(s) in range.
