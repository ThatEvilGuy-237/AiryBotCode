# Airy UI changes

Since the last hand-over (base commit 516777b), up to 516777b. Base 0.1.0, company package 0.1.9.

No changes to the base or to your layer in this range.
0 commit(s) in range.
