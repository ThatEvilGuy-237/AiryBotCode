import { build } from 'vite'
import vue from '@vitejs/plugin-vue'
import { resolve, dirname } from 'node:path'
import { fileURLToPath } from 'node:url'
import { mkdtempSync, readdirSync, readFileSync, rmSync, writeFileSync } from 'node:fs'
import { tmpdir } from 'node:os'

const root = resolve(dirname(fileURLToPath(import.meta.url)), '..')
const work = mkdtempSync(resolve(tmpdir(), 'site-css-'))
await build({
  configFile: false,
  logLevel: 'error',
  plugins: [vue()],
  resolve: {
    alias: [
      { find: /^@evil-ui\/base\/site$/, replacement: resolve(root, 'src/base/site-kit.ts') },
      { find: /^@evil-ui\/base\/portal$/, replacement: resolve(root, 'src/base/portal-kit.ts') },
      { find: /^@evil-ui\/base\/flow$/, replacement: resolve(root, 'src/base/flow-kit.ts') },
      { find: /^@evil-ui\/base$/, replacement: resolve(root, 'src/base/index.ts') },
    ],
  },
  build: {
    outDir: work,
    emptyOutDir: true,
    lib: { entry: resolve(root, 'src/airy/site.ts'), formats: ['es'], fileName: () => 'site-only.js' },
    rollupOptions: { external: ['vue', 'vue-router'] },
    cssCodeSplit: false,
    minify: false,
  },
})
const css = readdirSync(work).find(f => f.endsWith('.css'))
if (!css) throw new Error('site-only build emitted no stylesheet')
writeFileSync(resolve(root, 'dist/site.css'), readFileSync(resolve(work, css), 'utf8'))
rmSync(work, { recursive: true, force: true })
console.log('dist/site.css written')
