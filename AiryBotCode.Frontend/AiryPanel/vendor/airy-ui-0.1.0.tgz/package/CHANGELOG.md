# Airy UI changes

Since the last hand-over (base commit 5749175), up to 5749175. Base 0.1.0, company package 0.1.0.

No changes to the base or to your layer in this range.
0 commit(s) in range.
