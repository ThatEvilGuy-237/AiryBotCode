<script setup lang="ts">
withDefaults(defineProps<{ name?: string; tagline?: string; size?: number }>(), {
  name: 'Airy',
  tagline: '',
  size: 24,
})
</script>

<template>
  <div class="mark" data-company="brand-mark">
    <svg class="mark-cloud" :width="size" :height="size" viewBox="96 64 320 384" fill="none" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">
      <path class="mark-body" d="M156 406 A64 64 0 0 1 146 282 A96 96 0 0 1 336 248 A80 80 0 0 1 356 406 Z" stroke-width="26" />
      <path class="mark-body" d="M256 169 V128" stroke-width="26" />
      <circle class="mark-face" cx="214" cy="336" r="24" />
      <circle class="mark-face" cx="298" cy="336" r="24" />
      <path class="mark-smile" d="M232 380 Q256 394 280 380" stroke-width="18" />
      <circle class="mark-antenna" cx="256" cy="108" r="26" />
    </svg>
    <span v-if="name" class="mark-name">{{ name }}</span>
    <span v-if="tagline" class="mark-tag">{{ tagline }}</span>
  </div>
</template>

<style scoped>
.mark {
  display: inline-flex;
  align-items: center;
  gap: var(--space-2);
  font-family: var(--font-family);
}
.mark-cloud {
  flex: none;
}
.mark-body {
  stroke: var(--color-accent);
}
.mark-face,
.mark-antenna {
  fill: var(--color-fg);
}
.mark-antenna {
  fill: var(--color-accent);
}
.mark-smile {
  stroke: var(--color-fg);
}
.mark-name {
  font-weight: 700;
  letter-spacing: -0.01em;
  color: var(--color-fg);
}
.mark-tag {
  font-family: var(--font-mono);
  font-size: var(--font-size-xs);
  letter-spacing: 0.06em;
  text-transform: uppercase;
  color: var(--color-muted);
}
</style>
