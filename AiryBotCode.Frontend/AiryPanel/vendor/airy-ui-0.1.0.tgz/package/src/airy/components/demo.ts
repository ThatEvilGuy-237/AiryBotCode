import type { Component } from 'vue'
import BrandMark from './BrandMark/BrandMark.vue'

export interface CompanyDemo { name: string; component: Component; props: Record<string, unknown>; note?: string }

export const demos: CompanyDemo[] = [
  { name: 'BrandMark', component: BrandMark, props: { name: 'Airy', tagline: 'control panel' } },
]
