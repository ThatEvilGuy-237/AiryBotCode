export { default as BrandMark } from './BrandMark/BrandMark.vue'
export { demos } from './demo'
export type { CompanyDemo } from './demo'
