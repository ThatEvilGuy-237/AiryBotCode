<script setup lang="ts">
/**
 * PortalEmptyState
 * Compatibility adapter for ~/ThatEvilGuyMemory's Nuxt portal. Wraps the core
 * @hive/ui EmptyState with the prop-shape the portal grew up on: `description`
 * maps to the core `sub`, `icon` (a lucide kebab name, optionally 'lucide:'-
 * prefixed) renders an <Icon> inside the core `#glyph` badge, and `variant` is
 * absorbed as a no-op so the sites still passing variant="empty" need no edit.
 *
 * @prop title       - required main message, forwarded to core `title`
 * @prop description - optional muted second line, mapped to core `sub`
 * @prop icon        - lucide icon name from the curated set; unmapped names fall
 *                     back to the core glyph (the mono "+")
 * @prop variant     - accepted for source-compat, deliberately ignored (dead in the shim)
 *
 * Slots:
 *   default - actions row beneath the text, forwarded to core
 *
 * Status: adapter | Consumers: portal (retires the portal-kit EmptyState shim)
 */
import { computed } from 'vue'
import EmptyState from '../components/EmptyState/EmptyState.vue'
import Icon from '../components/Icon/Icon.vue'
import { ICONS, type IconName } from '../components/Icon/icons'

const props = defineProps<{
  title: string
  description?: string
  icon?: string
  variant?: string
}>()

const iconName = computed<IconName | null>(() => {
  if (!props.icon) return null
  const key = props.icon.replace(/^lucide:/, '')
  return key in ICONS ? (key as IconName) : null
})
</script>

<template>
  <EmptyState :title="title" :sub="description">
    <template v-if="iconName" #glyph>
      <Icon :name="iconName" :size="24" />
    </template>
    <template v-if="$slots.default" #default><slot /></template>
  </EmptyState>
</template>
