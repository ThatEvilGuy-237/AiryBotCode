<script setup lang="ts">
/**
 * PortalSwitch — the `@hive/ui/portal` Switch: a labelled on/off row.
 *
 * Core `Toggle` is a bare `<button role="switch">` with no label (a button is
 * not a labelable element, so you can't just wrap it in a <label>). The portal
 * always pairs the switch with a caption and wants the caption clickable, so
 * this adapter renders the Toggle plus a `<span>` label associated by id, and
 * forwards clicks on the label to the toggle. Same shim signature the portal
 * already uses: modelValue / label / disabled.
 *
 * Status: new | Consumers: ThatEvilGuyMemory portal (settings, night-shift)
 */
import Toggle from '../components/Toggle/Toggle.vue'
import { nextFieldId } from '../components/Field/keys'

const props = withDefaults(defineProps<{
  modelValue: boolean
  label?: string
  disabled?: boolean
}>(), { disabled: false })

const emit = defineEmits<{ 'update:modelValue': [value: boolean] }>()

const labelId = nextFieldId()

function toggle() {
  if (!props.disabled) emit('update:modelValue', !props.modelValue)
}
</script>

<template>
  <span :class="[$style.row, disabled && $style.off]">
    <Toggle
      :model-value="modelValue"
      :disabled="disabled"
      :aria-labelledby="label ? labelId : undefined"
      @update:model-value="emit('update:modelValue', $event)"
    />
    <span v-if="label" :id="labelId" :class="$style.label" @click="toggle">{{ label }}</span>
  </span>
</template>

<style module>
.row {
  display: inline-flex;
  align-items: center;
  gap: var(--space-2);
}
.label {
  color: var(--color-text-dim);
  font-size: var(--font-size-sm);
  cursor: pointer;
}
.off { opacity: 0.5; }
.off .label { cursor: not-allowed; }
</style>
