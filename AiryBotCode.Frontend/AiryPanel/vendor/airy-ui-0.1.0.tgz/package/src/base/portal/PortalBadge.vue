<script setup lang="ts">
/**
 * PortalBadge
 * Compatibility adapter that renders the portal shim's Badge API
 * (`label` / `tone` / `fill`) on top of the core <Badge>. Lets
 * ~/ThatEvilGuyMemory's Nuxt portal keep every call site unchanged while the
 * hand-rolled portal-kit Badge shim is retired.
 *
 * @prop label - text content; used when no default slot is given
 * @prop tone  - portal tone: neutral | muted | brand | plan | info | success | warning | danger
 * @prop fill  - 'outline' renders the transparent (borders-only) chip
 *
 * Status: new | Consumers: @hive/ui/portal (portal-kit re-export)
 */
import { computed } from 'vue'
import Badge from '../components/Badge/Badge.vue'

type PortalTone = 'neutral' | 'muted' | 'brand' | 'plan' | 'info' | 'success' | 'warning' | 'danger'
type CoreTone = 'neutral' | 'accent' | 'ok' | 'warn' | 'danger' | 'muted'

const props = withDefaults(defineProps<{
  label?: string | number
  tone?: PortalTone
  fill?: string
}>(), { tone: 'neutral' })

const TONE_MAP: Record<PortalTone, CoreTone> = {
  neutral: 'neutral',
  muted: 'muted',
  brand: 'accent',
  plan: 'accent',
  info: 'accent',
  success: 'ok',
  warning: 'warn',
  danger: 'danger',
}

const tone = computed<CoreTone>(() => TONE_MAP[props.tone] ?? 'neutral')
const outline = computed(() => props.fill === 'outline')
</script>

<template>
  <Badge :tone="tone" :outline="outline">
    <slot>{{ label }}</slot>
  </Badge>
</template>
