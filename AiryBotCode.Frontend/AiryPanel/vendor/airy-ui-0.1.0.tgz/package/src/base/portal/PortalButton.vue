<script setup lang="ts">
/**
 * PortalButton
 * Compatibility adapter for ~/ThatEvilGuyMemory's Nuxt portal. Wraps the core
 * @hive/ui Button with the label/icon prop-shape the portal grew up on and the
 * portal's own variant vocabulary (primary | secondary | danger + the core set).
 *
 * @prop label   - text content when no default slot is given
 * @prop icon    - lucide icon name (optionally 'lucide:'-prefixed) from the curated set
 * @prop variant - primary | secondary | danger | solid | outline | ghost
 * @prop size    - sm | md | lg
 * @prop disabled - disables interaction
 * @prop loading  - shows an inline spinner + disables
 * @prop type     - native button type
 * @emits click   - forwards the core Button's MouseEvent
 *
 * Status: adapter | Consumers: portal (retires the portal-kit Button shim)
 */
import { computed } from 'vue'
import Button from '../components/Button/Button.vue'
import Icon from '../components/Icon/Icon.vue'
import { ICONS, type IconName } from '../components/Icon/icons'

type CoreVariant = 'solid' | 'outline' | 'ghost' | 'danger'
type PortalVariant = 'primary' | 'secondary' | CoreVariant

const props = withDefaults(defineProps<{
  label?: string
  icon?: string
  variant?: PortalVariant
  size?: 'sm' | 'md' | 'lg'
  disabled?: boolean
  loading?: boolean
  type?: 'button' | 'submit'
}>(), { variant: 'primary', size: 'md', disabled: false, loading: false, type: 'button' })

const emit = defineEmits<{ click: [MouseEvent] }>()

const VARIANT_MAP: Record<PortalVariant, CoreVariant> = {
  primary: 'solid',
  secondary: 'outline',
  danger: 'danger',
  solid: 'solid',
  outline: 'outline',
  ghost: 'ghost',
}

const coreVariant = computed<CoreVariant>(() => VARIANT_MAP[props.variant] ?? 'solid')

const iconName = computed<IconName | null>(() => {
  if (!props.icon) return null
  const key = props.icon.replace(/^lucide:/, '')
  return key in ICONS ? (key as IconName) : null
})
</script>

<template>
  <Button
    :variant="coreVariant"
    :size="size"
    :disabled="disabled"
    :loading="loading"
    :type="type"
    @click="emit('click', $event)"
  >
    <Icon v-if="iconName && !loading" :name="iconName" />
    <slot>{{ label }}</slot>
  </Button>
</template>
