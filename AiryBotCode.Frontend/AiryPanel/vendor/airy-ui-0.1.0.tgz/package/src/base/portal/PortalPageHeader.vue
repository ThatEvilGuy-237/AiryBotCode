<script setup lang="ts">
/**
 * PortalPageHeader
 * Compatibility adapter for ~/ThatEvilGuyMemory's Nuxt portal. Wraps the core
 * @hive/ui PageHeader with the prop-shape the portal grew up on — most notably
 * `description`, which core spells `subtitle`. Breadcrumbs and loading pass
 * straight through; the `actions` slot is forwarded.
 *
 * @prop title       - main heading text
 * @prop description - muted second line (mapped to core `subtitle`)
 * @prop loading     - toggles the bottom-edge loading line
 * @prop breadcrumbs - trail of { label, to? } forwarded to core
 *
 * Status: adapter | Consumers: portal (retires the portal-kit PageHeader shim)
 */
import PageHeader, { type PageHeaderCrumb } from '../components/PageHeader/PageHeader.vue'

withDefaults(defineProps<{
  title: string
  description?: string
  loading?: boolean
  breadcrumbs?: PageHeaderCrumb[]
}>(), { loading: false, breadcrumbs: () => [] })

defineSlots<{ actions?: () => unknown }>()
</script>

<template>
  <PageHeader
    :title="title"
    :subtitle="description"
    :loading="loading"
    :breadcrumbs="breadcrumbs"
  >
    <template v-if="$slots.actions" #actions>
      <slot name="actions" />
    </template>
  </PageHeader>
</template>
