<script setup lang="ts">
/**
 * PortalCard
 * Compatibility adapter that renders the portal shim's Card API (`title` +
 * `actions` slot) on top of the core <Card>. Reproduces the shim's stacked,
 * gapped body, 10px radius and clipped overflow so ~/ThatEvilGuyMemory's Nuxt
 * portal keeps every call site pixel-for-pixel while the hand-rolled portal-kit
 * Card shim is retired. `class` and other attrs fall through to the card root,
 * so `class="canvas"` / `class="stage-card"` / `class="signin"` (which lean on
 * overflow: hidden and their own layout) keep working unchanged.
 *
 * @prop title - optional header title; rendered as an <h2> matching the shim
 *
 * Slots:
 *   actions - right-aligned controls in the header (only shown with a header)
 *   default - body content, laid out as a gapped vertical stack
 *
 * Status: new | Consumers: @hive/ui/portal (portal-kit re-export)
 */
import Card from '../components/Card/Card.vue'

defineProps<{ title?: string }>()
</script>

<template>
  <Card stack :style="{ borderRadius: 'var(--r-3)', overflow: 'hidden' }">
    <template v-if="title || $slots.actions" #head>
      <div :class="$style.headRow">
        <h2 v-if="title" :class="$style.title">{{ title }}</h2>
        <div v-if="$slots.actions" :class="$style.actions"><slot name="actions" /></div>
      </div>
    </template>
    <slot />
  </Card>
</template>

<style module>
.headRow {
  display: flex;
  align-items: center;
  justify-content: space-between;
  gap: var(--space-3);
  width: 100%;
}
.title {
  margin: 0;
  font-size: var(--font-size-base);
  font-weight: 600;
  color: var(--color-fg);
}
.actions {
  display: flex;
  align-items: center;
  gap: var(--space-2);
  flex-shrink: 0;
}
</style>
