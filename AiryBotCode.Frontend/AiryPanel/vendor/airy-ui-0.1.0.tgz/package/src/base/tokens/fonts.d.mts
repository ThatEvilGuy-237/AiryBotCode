export type FontRole = 'sans' | 'serif' | 'mono'

export interface FontEntry {
  stack: string
  role: FontRole
  google?: string
}

export const FONTS: Record<string, FontEntry>
export function fontNames(role?: FontRole): string[]
export function stackFor(name: string): string
export function googleImport(names: string[]): string
export function buildFonts(s: { fontFamily: string; fontDisplay?: string; fontMono: string }): string
export function selfHostTemplate(s: { fontFamily: string; fontDisplay?: string; fontMono: string }): string
