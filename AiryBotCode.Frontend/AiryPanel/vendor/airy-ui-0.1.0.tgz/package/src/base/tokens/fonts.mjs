export const FONTS = {
  'Space Grotesk': { stack: "'Space Grotesk', system-ui, -apple-system, 'Segoe UI', Roboto, sans-serif", role: 'sans', google: 'Space+Grotesk:wght@400;500;600;700' },
  'Inter': { stack: "'Inter', system-ui, -apple-system, 'Segoe UI', Roboto, sans-serif", role: 'sans', google: 'Inter:wght@400;500;600;700' },
  'Hanken Grotesk': { stack: "'Hanken Grotesk', system-ui, sans-serif", role: 'sans', google: 'Hanken+Grotesk:wght@400;500;600;700' },
  'IBM Plex Sans': { stack: "'IBM Plex Sans', system-ui, sans-serif", role: 'sans', google: 'IBM+Plex+Sans:wght@400;500;600;700' },
  'Manrope': { stack: "'Manrope', system-ui, sans-serif", role: 'sans', google: 'Manrope:wght@400;500;600;700;800' },
  'Nunito': { stack: "'Nunito', system-ui, -apple-system, 'Segoe UI', Roboto, sans-serif", role: 'sans', google: 'Nunito:wght@400;600;700;800' },
  'DM Sans': { stack: "'DM Sans', system-ui, sans-serif", role: 'sans', google: 'DM+Sans:wght@400;500;600;700' },
  'Lora': { stack: "'Lora', Georgia, serif", role: 'serif', google: 'Lora:wght@400;500;600;700' },
  'Source Serif': { stack: "'Source Serif 4', Georgia, serif", role: 'serif', google: 'Source+Serif+4:wght@400;500;600;700' },
  'Playfair Display': { stack: "'Playfair Display', Georgia, serif", role: 'serif', google: 'Playfair+Display:wght@400;500;600;700' },
  'EB Garamond': { stack: "'EB Garamond', Georgia, serif", role: 'serif', google: 'EB+Garamond:ital,wght@0,400;0,500;0,600;1,400' },
  'Cinzel': { stack: "'Cinzel', Georgia, serif", role: 'serif', google: 'Cinzel:wght@500;600;700' },
  'Fraunces': { stack: "'Fraunces', Georgia, serif", role: 'serif', google: 'Fraunces:wght@400;500;600;700' },
  'Fira Code': { stack: "'Fira Code', 'Cascadia Code', 'JetBrains Mono', ui-monospace, Consolas, monospace", role: 'mono', google: 'Fira+Code:wght@400;500;600' },
  'Space Mono': { stack: "'Space Mono', ui-monospace, 'SFMono-Regular', Menlo, monospace", role: 'mono', google: 'Space+Mono:wght@400;700' },
  'JetBrains Mono': { stack: "'JetBrains Mono', ui-monospace, Consolas, monospace", role: 'mono', google: 'JetBrains+Mono:wght@400;500;600' },
  'IBM Plex Mono': { stack: "'IBM Plex Mono', ui-monospace, Consolas, monospace", role: 'mono', google: 'IBM+Plex+Mono:wght@400;500;600' },
  'System': { stack: "system-ui, -apple-system, 'Segoe UI', Roboto, sans-serif", role: 'sans' },
  'System serif': { stack: 'Georgia, "Times New Roman", serif', role: 'serif' },
  'System mono': { stack: 'ui-monospace, Menlo, Consolas, monospace', role: 'mono' },
}

export function fontNames(role) {
  return Object.keys(FONTS).filter(k => !role || FONTS[k].role === role)
}

export function stackFor(name) {
  return FONTS[name]?.stack ?? name
}

export function googleImport(names) {
  const families = [...new Set(names)].map(n => FONTS[n]?.google).filter(Boolean)
  if (!families.length) return ''
  return `@import url('https://fonts.googleapis.com/css2?${families.map(f => 'family=' + f).join('&')}&display=swap');\n`
}

export function buildFonts(s) {
  const names = [s.fontFamily, s.fontDisplay || s.fontFamily, s.fontMono]
  return googleImport(names)
}

export function selfHostTemplate(s) {
  const names = [...new Set([s.fontFamily, s.fontDisplay || s.fontFamily, s.fontMono])].filter(n => FONTS[n]?.google)
  return names.map(n => `@font-face {
  font-family: '${n}';
  font-style: normal;
  font-weight: 400 700;
  font-display: swap;
  src: url('./fonts/${n.toLowerCase().replace(/\s+/g, '-')}.woff2') format('woff2');
}
`).join('\n')
}
