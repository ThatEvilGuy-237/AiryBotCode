import { FONTS, stackFor } from './fonts.mjs'

export const FONT_STACKS = {
  'Space Grotesk': "'Space Grotesk', system-ui, -apple-system, 'Segoe UI', Roboto, sans-serif",
  'Inter': "'Inter', system-ui, -apple-system, 'Segoe UI', Roboto, sans-serif",
  'Hanken Grotesk': "'Hanken Grotesk', system-ui, sans-serif",
  'IBM Plex Sans': "'IBM Plex Sans', system-ui, sans-serif",
  'Lora': "'Lora', Georgia, serif",
  'Source Serif': "'Source Serif 4', Georgia, serif",
  'System': "system-ui, -apple-system, 'Segoe UI', Roboto, sans-serif",
}

export const MONO_STACKS = {
  'Fira Code': "'Fira Code', 'Cascadia Code', 'JetBrains Mono', ui-monospace, Consolas, monospace",
  'Space Mono': "'Space Mono', ui-monospace, 'SFMono-Regular', Menlo, monospace",
  'JetBrains Mono': "'JetBrains Mono', ui-monospace, Consolas, monospace",
  'System mono': 'ui-monospace, Menlo, Consolas, monospace',
}

export const DEFAULT_STATE = {
  id: 'acme',
  label: 'Acme',
  mode: 'dark',
  accent: '#7c5cff',
  surface: '#1c1b24',
  eyebrow: '',
  fontFamily: 'Space Grotesk',
  fontDisplay: '',
  fontMono: 'Fira Code',
  radius: 8,
  fontScale: 1,
  spaceScale: 1,
  ok: '',
  warn: '',
  danger: '',
}

function luminance(hex) {
  const m = /^#?([0-9a-f]{6})$/i.exec(hex.trim())
  if (!m) return 0
  const n = parseInt(m[1], 16)
  const c = [16, 8, 0].map(s => ((n >> s) & 255) / 255).map(v => (v <= 0.03928 ? v / 12.92 : ((v + 0.055) / 1.055) ** 2.4))
  return 0.2126 * c[0] + 0.7152 * c[1] + 0.0722 * c[2]
}

export function onAccentFor(accent) {
  return luminance(accent) > 0.4 ? '#161616' : '#ffffff'
}

function mix(a, pct, b, space = 'oklch') {
  return `color-mix(in ${space}, ${a} ${pct}%, ${b})`
}

function px(n) {
  return `${Math.round(n)}px`
}

export function buildTokens(s) {
  const dark = s.mode === 'dark'
  const surface = s.surface
  const accent = s.accent
  const eyebrow = (s.eyebrow || '').trim() || (dark ? 'var(--color-warn)' : 'var(--color-accent)')
  const fg = dark ? mix('white', 94, surface) : mix('black', 90, surface)
  const dim = dark ? mix('white', 80, surface) : mix('black', 78, surface)
  const muted = dark ? mix('white', 62, surface) : mix('black', 60, surface)
  const ghost = dark ? mix('white', 45, surface) : mix('black', 42, surface)
  const bg = dark ? mix(surface, 70, 'black') : mix(surface, 95, 'black')
  const bg2 = dark ? mix(surface, 85, 'black') : mix(surface, 91, 'black')
  const hi = dark ? mix(surface, 88, 'white') : 'white'
  const mute = dark ? mix(surface, 92, 'black') : mix(surface, 96, 'black')
  const border = dark ? mix(surface, 78, 'white') : mix(surface, 84, 'black')
  const borderSoft = dark ? mix(surface, 90, 'white') : mix(surface, 92, 'black')
  const borderHi = dark ? mix(surface, 65, 'white') : mix(surface, 72, 'black')
  const r = s.radius
  const fs = (base) => px(base * (s.fontScale ?? 1))
  const sp = (base) => px(base * (s.spaceScale ?? 1))
  const sem = (v, fallback) => (v || '').trim() || fallback
  return `:root {
  --color-bg: ${bg};
  --color-bg-2: ${bg2};
  --color-surface: ${surface};
  --color-surface-hi: ${hi};
  --color-surface-mute: ${mute};

  --color-border: ${border};
  --color-border-soft: ${borderSoft};
  --color-border-hi: ${borderHi};
  --border: 1px solid var(--color-border);

  --color-fg: ${fg};
  --color-text-dim: ${dim};
  --color-muted: ${muted};
  --color-text-ghost: ${ghost};

  --color-accent: ${accent};
  --color-accent-mute: ${mix('var(--color-accent)', 80, 'black')};
  --color-accent-soft: ${mix('var(--color-accent)', 16, 'transparent', 'srgb')};
  --color-accent-edge: ${mix('var(--color-accent)', 45, 'transparent', 'srgb')};
  --color-on-accent: ${onAccentFor(accent)};
  --color-ok: ${sem(s.ok, dark ? 'oklch(0.76 0.13 158)' : 'oklch(0.52 0.13 150)')};
  --color-warn: ${sem(s.warn, dark ? 'oklch(0.80 0.12 75)' : 'oklch(0.62 0.13 70)')};
  --color-danger: ${sem(s.danger, dark ? 'oklch(0.63 0.18 22)' : 'oklch(0.52 0.19 25)')};
  --color-plan: var(--color-text-ghost);
  --color-web: oklch(0.72 0.12 225);
  --color-mem: oklch(0.72 0.13 330);

  --font-family: ${stackFor(s.fontFamily)};
  --font-display: ${s.fontDisplay ? stackFor(s.fontDisplay) : 'var(--font-family)'};
  --font-ui: var(--font-family);
  --font-mono: ${stackFor(s.fontMono)};
  --font-size-xs: ${fs(12)};
  --font-size-sm: ${fs(13)};
  --font-size-base: ${fs(15)};
  --font-size-lg: ${fs(19)};
  --font-size-xl: ${fs(24)};

  --space-1: ${sp(4)};
  --space-2: ${sp(8)};
  --space-3: ${sp(12)};
  --space-4: ${sp(16)};
  --space-5: ${sp(20)};
  --space-6: ${sp(24)};

  --radius: ${px(r)};
  --r-1: ${px(Math.max(2, r / 2))};
  --r-2: ${px(r)};
  --r-3: ${px(r * 1.5 + 2)};
  --r-4: ${px(r * 2 + 4)};
  --shadow-1: 0 1px 0 oklch(1 0 0 / 0.04) inset, 0 1px 2px oklch(0 0 0 / ${dark ? 0.4 : 0.12});
  --shadow-2: 0 1px 0 oklch(1 0 0 / 0.05) inset, 0 8px 24px oklch(0 0 0 / ${dark ? 0.5 : 0.18});

  --site-lead: var(--color-accent);
  --site-eyebrow-color: ${eyebrow};
  --site-card-hover-edge: var(--site-eyebrow-color);
  --site-maxw: 1120px;
  --site-maxw-narrow: 820px;
  --site-gutter: clamp(20px, 5vw, 40px);
  --site-space-8: ${sp(32)};
  --site-space-12: ${sp(48)};
  --site-space-16: ${sp(64)};
  --site-space-20: ${sp(80)};
  --site-r-card: ${px(r * 2)};
}
`
}

export function scaffoldCommand(s) {
  const q = (v) => JSON.stringify(v)
  return `npm run new -- ${s.id} --label ${q(s.label)} --mode ${s.mode} --accent ${q(s.accent)} --surface ${q(s.surface)}${s.eyebrow ? ' --eyebrow ' + q(s.eyebrow) : ''} --font ${q(s.fontFamily)}${s.fontDisplay ? ' --display ' + q(s.fontDisplay) : ''} --mono ${q(s.fontMono)} --radius ${s.radius}`
}
