export type Mode = 'dark' | 'light'

export interface BuilderState {
  id: string
  label: string
  mode: Mode
  accent: string
  surface: string
  eyebrow: string
  fontFamily: string
  fontDisplay: string
  fontMono: string
  radius: number
  fontScale: number
  spaceScale: number
  ok: string
  warn: string
  danger: string
}

export const FONT_STACKS: Record<string, string>
export const MONO_STACKS: Record<string, string>
export const DEFAULT_STATE: BuilderState
export function onAccentFor(accent: string): string
export function buildTokens(s: BuilderState): string
export function scaffoldCommand(s: BuilderState): string
