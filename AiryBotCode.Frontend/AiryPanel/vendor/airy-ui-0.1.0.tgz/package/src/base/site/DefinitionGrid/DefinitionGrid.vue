<script setup lang="ts">
/**
 * DefinitionGrid
 * A grid of terms and what each one means — skills and how they were used,
 * features and what they do, jargon and its translation.
 *
 * Renders a real `<dl>` with `<dt>`/`<dd>` pairs. That is not pedantry: it is
 * the markup that says "these two things belong together", which a grid of
 * `<div>`s cannot, and it makes the pairing survive being read aloud.
 *
 * Prefer this over a row of chips with hover tooltips. A tooltip hides the
 * interesting half of the content from anyone who does not hover — which is
 * every touch user, every keyboard user who does not tab that far, and every
 * printed copy.
 *
 * @prop items    - the pairs; `note` is optional so a bare list still works
 * @prop numbered - prefix each term with its index
 * @prop columns  - minimum column width before wrapping (default 240px)
 *
 * Status: stable | Consumers: CV-Web
 */
export interface DefinitionItem {
  term: string
  note?: string
}

withDefaults(defineProps<{ items: DefinitionItem[]; numbered?: boolean; columns?: string }>(), {
  columns: '240px',
})
</script>

<template>
  <dl
    :class="$style.grid"
    :style="{ '--definition-col': columns }"
    data-site="definition-grid"
  >
    <div v-for="(item, i) in items" :key="item.term" :class="$style.cell" data-site="definition">
      <dt :class="$style.term">
        <span v-if="numbered" :class="$style.index" aria-hidden="true">
          {{ String(i + 1).padStart(2, '0') }}
        </span>
        {{ item.term }}
      </dt>
      <dd v-if="item.note" :class="$style.note">{{ item.note }}</dd>
    </div>
  </dl>
</template>

<style module>
.grid {
  display: grid;
  grid-template-columns: repeat(auto-fill, minmax(min(var(--definition-col, 240px), 100%), 1fr));
  gap: var(--site-space-4);
  margin: 0;
  padding: 0;
}
.cell {
  display: flex;
  flex-direction: column;
  gap: var(--site-space-1);
  padding: var(--site-space-4);
  border: 1px solid var(--site-line);
  border-radius: var(--site-r-card);
  background: var(--site-card);
  transition: border-color 150ms ease;
}
.cell:hover {
  border-color: var(--site-card-hover-edge);
}
.term {
  display: flex;
  align-items: baseline;
  gap: var(--site-space-2);
  margin: 0;
  color: var(--site-fg);
  font-weight: 600;
  font-size: 1.05rem;
}
.index {
  font-family: var(--font-mono);
  font-size: 0.7rem;
  color: var(--site-lead);
}
.note {
  margin: 0;
  color: var(--site-muted);
  font-size: 0.9rem;
  line-height: 1.5;
}
</style>
