<script setup lang="ts">
/**
 * ActionButton
 * The pill call-to-action of a content page. Renders an `<a>` when `href` is
 * given and a `<button>` otherwise, so a link stays a link — a div with a click
 * handler is not keyboard-reachable and not middle-clickable.
 *
 * External links (`http…`) get `target="_blank"` + `rel="noopener"` and are
 * announced as opening in a new tab, unless `external` says otherwise.
 *
 * @prop href     - makes it a link; omit for a button
 * @prop tone     - lead (the site's lead colour) | accent (the eyebrow colour) |
 *                  ghost (bordered, on-surface) | plain (text only)
 * @prop size     - md (default) | sm, for dense placements like a sidebar rail
 * @prop external - force the new-tab treatment on or off
 * @prop type     - button type when this is not a link
 *
 * Per-instance colours: a consumer that needs one specific brand colour (a
 * LinkedIn blue, say) sets `--action-bg`, `--action-bg-hover`, `--action-fg` or
 * `--action-fg-hover` on the element from its own stylesheet, rather than the
 * kit growing a tone per third party.
 *
 * Status: stable | Consumers: CV-Web
 */
import { computed } from 'vue'

const props = withDefaults(
  defineProps<{
    href?: string
    tone?: 'lead' | 'accent' | 'ghost' | 'plain'
    size?: 'md' | 'sm'
    external?: boolean
    type?: 'button' | 'submit'
  }>(),
  { tone: 'ghost', size: 'md', type: 'button' },
)

const isExternal = computed(() => props.external ?? /^https?:\/\//.test(props.href ?? ''))
</script>

<template>
  <component
    :is="href ? 'a' : 'button'"
    :class="[$style.action, $style[tone], $style[size]]"
    :href="href"
    :type="href ? undefined : type"
    :target="href && isExternal ? '_blank' : undefined"
    :rel="href && isExternal ? 'noopener' : undefined"
    data-site="action"
  >
    <slot />
    <span v-if="href && isExternal" :class="$style.sr">(opens in a new tab)</span>
  </component>
</template>

<style module>
.action {
  display: inline-flex;
  align-items: center;
  gap: var(--site-space-2);
  border: 1px solid transparent;
  border-radius: var(--site-r-pill);
  background: var(--action-bg, transparent);
  color: var(--action-fg, var(--site-fg));
  font: inherit;
  font-weight: 600;
  cursor: pointer;
  transition:
    transform 120ms ease,
    background 150ms ease,
    border-color 150ms ease,
    color 150ms ease;
}
.action:hover {
  transform: translateY(-1px);
  background: var(--action-bg-hover, var(--action-bg, transparent));
  color: var(--action-fg-hover, var(--action-fg, var(--site-fg)));
}

.md {
  padding: 12px 22px;
  font-size: 0.95rem;
}
.sm {
  padding: 6px 14px;
  font-size: 0.88rem;
}

/* Filled tones set --action-fg to a very dark ink rather than a token: they are
   filled with a light brand colour, so the label must be dark in every theme. */
.lead {
  --action-bg: var(--site-lead);
  --action-fg: oklch(0.15 0.02 var(--base-hue, 285));
}
.accent {
  --action-bg: var(--site-eyebrow-color);
  --action-fg: oklch(0.15 0.02 var(--base-hue, 285));
}
.lead:hover,
.accent:hover {
  --action-bg-hover: color-mix(in oklch, var(--action-bg) 82%, white);
}

.ghost {
  --action-bg: var(--site-card);
  border-color: var(--site-line);
}
.ghost:hover {
  border-color: var(--site-lead);
}

.plain {
  --action-bg: transparent;
  --action-fg: var(--site-muted);
  --action-fg-hover: var(--site-fg);
  padding-inline: 0;
}
.plain:hover {
  transform: none;
}

.sr {
  position: absolute;
  width: 1px;
  height: 1px;
  margin: -1px;
  padding: 0;
  overflow: hidden;
  clip-path: inset(50%);
  white-space: nowrap;
}
</style>
