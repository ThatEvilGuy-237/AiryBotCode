<script setup lang="ts">
/**
 * PricingTable
 * Good, better, best. Three (or two, or four) plans side by side, one of them
 * featured. The featured plan is the one to sell; put the anchor first.
 *
 * @prop plans    - { name, price, period?, tagline?, features, cta?, href?, featured? }[]
 * @prop currency - printed before the price (default "€")
 *
 * Emits: select(name) - a plan's action was pressed and it had no href
 *
 * Status: new | Consumers: showcase
 */
import Icon from '../../components/Icon/Icon.vue'
import ActionButton from '../ActionButton/ActionButton.vue'

export interface PricingPlan {
  name: string
  price: string
  period?: string
  tagline?: string
  features: string[]
  cta?: string
  href?: string
  featured?: boolean
}

withDefaults(defineProps<{
  plans: PricingPlan[]
  currency?: string
}>(), { currency: '€' })

const emit = defineEmits<{ select: [name: string] }>()
</script>

<template>
  <div :class="$style.table" data-site="pricing">
    <article
      v-for="p in plans"
      :key="p.name"
      :class="[$style.plan, p.featured && $style.featured]"
      :data-site="p.featured ? 'plan-featured' : 'plan'"
    >
      <header :class="$style.head">
        <h3 :class="$style.name">{{ p.name }}</h3>
        <p v-if="p.tagline" :class="$style.tagline">{{ p.tagline }}</p>
      </header>
      <div :class="$style.price">
        <span :class="$style.currency">{{ currency }}</span>
        <span :class="$style.amount">{{ p.price }}</span>
        <span v-if="p.period" :class="$style.period">/ {{ p.period }}</span>
      </div>
      <ul :class="$style.features">
        <li v-for="f in p.features" :key="f" :class="$style.feature">
          <Icon name="check" :size="16" :class="$style.check" />
          <span>{{ f }}</span>
        </li>
      </ul>
      <div :class="$style.cta">
        <ActionButton :href="p.href" :tone="p.featured ? 'lead' : 'ghost'" @click="!p.href && emit('select', p.name)">
          {{ p.cta ?? 'Choose ' + p.name }}
        </ActionButton>
      </div>
    </article>
  </div>
</template>

<style module>
.table {
  display: grid;
  grid-template-columns: repeat(auto-fit, minmax(240px, 1fr));
  gap: var(--site-space-4);
  align-items: stretch;
  max-width: var(--site-maxw);
  margin: 0 auto;
  padding: 0 var(--site-gutter);
}
.plan {
  display: flex;
  flex-direction: column;
  gap: var(--site-space-4);
  padding: var(--site-space-6);
  border: 1px solid var(--site-line);
  border-radius: var(--site-r-card, var(--r-3));
  background: var(--site-card);
}
.featured {
  border-color: var(--site-lead);
  box-shadow: inset 0 3px 0 0 var(--site-lead);
}
.head { display: flex; flex-direction: column; gap: 4px; }
.name { margin: 0; font-family: var(--font-mono); font-size: var(--site-eyebrow); letter-spacing: 0.12em; text-transform: uppercase; color: var(--site-eyebrow-color); }
.tagline { margin: 0; color: var(--site-muted); font-size: var(--site-body); }
.price { display: flex; align-items: baseline; gap: 4px; color: var(--site-fg); }
.currency { font-size: calc(var(--site-body) * 1.3); color: var(--site-muted); }
.amount { font-family: var(--site-display-font, var(--font-family)); font-size: calc(var(--site-heading) * 0.9); font-weight: 700; letter-spacing: -0.03em; line-height: 1; }
.period { font-family: var(--font-mono); font-size: var(--font-size-sm); color: var(--site-muted); }
.features { list-style: none; margin: 0; padding: 0; display: flex; flex-direction: column; gap: var(--site-space-2); flex: 1; }
.feature { display: flex; gap: var(--site-space-2); align-items: flex-start; font-size: var(--site-body); color: var(--site-fg); line-height: 1.4; }
.check { flex-shrink: 0; margin-top: 3px; color: var(--site-lead); }
.cta { margin-top: auto; }
</style>
