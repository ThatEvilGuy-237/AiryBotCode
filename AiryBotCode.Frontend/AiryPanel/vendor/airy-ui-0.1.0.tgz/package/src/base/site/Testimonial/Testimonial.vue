<script setup lang="ts">
/**
 * Testimonial
 * One quote, attributed. The quote is set in the display face because it is the
 * thing on the page a visitor is meant to read twice.
 *
 * @prop quote  - the words, without quotation marks
 * @prop name   - who said it
 * @prop role   - their role or company
 * @prop avatar - image URL; initials are drawn when it is missing
 *
 * Status: new | Consumers: showcase
 */
import { computed } from 'vue'

const props = defineProps<{
  quote: string
  name: string
  role?: string
  avatar?: string
}>()

const initials = computed(() => props.name.split(/\s+/).map(w => w[0]).slice(0, 2).join('').toUpperCase())
</script>

<template>
  <figure :class="$style.card" data-site="testimonial">
    <blockquote :class="$style.quote" data-site="testimonial-quote">{{ quote }}</blockquote>
    <figcaption :class="$style.who">
      <img v-if="avatar" :src="avatar" :alt="name" :class="$style.avatar" />
      <span v-else :class="[$style.avatar, $style.initials]" aria-hidden="true">{{ initials }}</span>
      <span :class="$style.meta">
        <span :class="$style.name">{{ name }}</span>
        <span v-if="role" :class="$style.role">{{ role }}</span>
      </span>
    </figcaption>
  </figure>
</template>

<style module>
.card {
  margin: 0;
  padding: var(--site-space-6);
  border: 1px solid var(--site-line);
  border-left: 3px solid var(--site-lead);
  border-radius: var(--site-r-card, var(--r-3));
  background: var(--site-card);
  max-width: var(--site-maxw-narrow);
}
.quote {
  margin: 0 0 var(--site-space-4);
  font-family: var(--site-display-font, var(--font-family));
  font-size: calc(var(--site-body) * 1.35);
  line-height: 1.4;
  letter-spacing: -0.01em;
  color: var(--site-fg);
}
.quote::before { content: '\201C'; color: var(--site-lead); margin-right: 2px; }
.quote::after { content: '\201D'; color: var(--site-lead); margin-left: 2px; }
.who { display: flex; align-items: center; gap: var(--site-space-3); }
.avatar { width: 40px; height: 40px; border-radius: 50%; object-fit: cover; border: 1px solid var(--site-line); }
.initials { display: inline-grid; place-items: center; font-family: var(--font-mono); font-size: var(--font-size-sm); background: var(--color-accent-soft); color: var(--site-lead); }
.meta { display: flex; flex-direction: column; }
.name { font-weight: 600; color: var(--site-fg); }
.role { font-family: var(--font-mono); font-size: var(--font-size-xs); color: var(--site-muted); }
</style>
