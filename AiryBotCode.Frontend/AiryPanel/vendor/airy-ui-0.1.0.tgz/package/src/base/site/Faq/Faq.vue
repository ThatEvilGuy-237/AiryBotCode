<script setup lang="ts">
/**
 * Faq
 * Questions that open one at a time. Uses native details/summary so every
 * answer is in the served HTML and printable, and the browser handles the
 * keyboard.
 *
 * @prop items - { q, a }[]
 * @prop title - optional heading above the list
 *
 * Status: new | Consumers: showcase
 */
import Icon from '../../components/Icon/Icon.vue'

export interface FaqItem { q: string; a: string }

defineProps<{
  items: FaqItem[]
  title?: string
}>()
</script>

<template>
  <section :class="$style.faq" data-site="faq">
    <h2 v-if="title" :class="$style.title">{{ title }}</h2>
    <details v-for="it in items" :key="it.q" :class="$style.item" data-site="faq-item">
      <summary :class="$style.q">
        <span>{{ it.q }}</span>
        <Icon name="chevron-down" :size="16" :class="$style.chev" />
      </summary>
      <p :class="$style.a">{{ it.a }}</p>
    </details>
  </section>
</template>

<style module>
.faq { max-width: var(--site-maxw-narrow); margin: 0 auto; padding: var(--site-space-8) var(--site-gutter); }
.title { margin: 0 0 var(--site-space-6); font-family: var(--site-display-font, var(--font-family)); font-size: var(--site-heading); font-weight: 700; letter-spacing: -0.03em; color: var(--site-fg); }
.item { border-top: 1px solid var(--site-line); }
.item:last-child { border-bottom: 1px solid var(--site-line); }
.q { display: flex; align-items: center; justify-content: space-between; gap: var(--site-space-4); padding: var(--site-space-4) 0; list-style: none; cursor: pointer; font-size: calc(var(--site-body) * 1.1); font-weight: 600; color: var(--site-fg); }
.q::-webkit-details-marker { display: none; }
.chev { flex-shrink: 0; color: var(--site-muted); transition: transform 0.15s; }
.item[open] .chev { transform: rotate(180deg); color: var(--site-lead); }
.a { margin: 0 0 var(--site-space-4); padding-right: var(--site-space-8); font-size: var(--site-body); line-height: 1.6; color: var(--site-muted); }
</style>
