<script setup lang="ts">
/**
 * ContactBlock
 * The closing ask of a marketing page: a title, a line, the ways to reach the
 * company, and a form slot for the site's own contact form.
 *
 * @prop eyebrow - mono label
 * @prop title   - display line
 * @prop lead    - the sentence under it
 * @prop methods - { label, value, href?, icon? }[]: phone, mail, address, hours
 *
 * Slots: default (the form or any call to action), aside (below the methods)
 *
 * Status: new | Consumers: showcase
 */
import Icon from '../../components/Icon/Icon.vue'
import type { IconName } from '../../components/Icon/icons'

export interface ContactMethod { label: string; value: string; href?: string; icon?: IconName }

withDefaults(defineProps<{
  eyebrow?: string
  title: string
  lead?: string
  methods?: ContactMethod[]
}>(), { methods: () => [] })
</script>

<template>
  <section :class="$style.block" data-site="contact">
    <div :class="$style.intro">
      <p v-if="eyebrow" :class="$style.eyebrow">{{ eyebrow }}</p>
      <h2 :class="$style.title" data-site="contact-title">{{ title }}</h2>
      <p v-if="lead" :class="$style.lead">{{ lead }}</p>
      <ul v-if="methods.length" :class="$style.methods" data-site="contact-methods">
        <li v-for="m in methods" :key="m.label" :class="$style.method">
          <span v-if="m.icon" :class="$style.icon"><Icon :name="m.icon" :size="16" /></span>
          <span :class="$style.methodBody">
            <span :class="$style.methodLabel">{{ m.label }}</span>
            <a v-if="m.href" :href="m.href" :class="$style.methodValue">{{ m.value }}</a>
            <span v-else :class="$style.methodValue">{{ m.value }}</span>
          </span>
        </li>
      </ul>
      <slot name="aside" />
    </div>
    <div v-if="$slots.default" :class="$style.form" data-site="contact-form"><slot /></div>
  </section>
</template>

<style module>
.block {
  display: grid;
  grid-template-columns: minmax(0, 1fr) minmax(0, 1.1fr);
  gap: var(--site-space-12);
  max-width: var(--site-maxw);
  margin: 0 auto;
  padding: var(--site-space-16) var(--site-gutter);
}
.eyebrow { margin: 0 0 var(--site-space-3); font-family: var(--font-mono); font-size: var(--site-eyebrow); letter-spacing: 0.12em; text-transform: uppercase; color: var(--site-eyebrow-color); }
.title { margin: 0; font-family: var(--site-display-font, var(--font-family)); font-size: var(--site-heading); font-weight: 700; letter-spacing: -0.03em; line-height: 1.05; color: var(--site-fg); }
.lead { margin: var(--site-space-3) 0 0; font-size: calc(var(--site-body) * 1.1); line-height: 1.5; color: var(--site-muted); }
.methods { list-style: none; margin: var(--site-space-6) 0 0; padding: 0; display: flex; flex-direction: column; gap: var(--site-space-3); }
.method { display: flex; gap: var(--site-space-3); align-items: flex-start; }
.icon { display: inline-grid; place-items: center; width: 32px; height: 32px; flex-shrink: 0; border-radius: var(--r-2); background: var(--color-accent-soft); color: var(--site-lead); }
.methodBody { display: flex; flex-direction: column; }
.methodLabel { font-family: var(--font-mono); font-size: var(--font-size-xs); letter-spacing: 0.08em; text-transform: uppercase; color: var(--site-muted); }
.methodValue { color: var(--site-fg); text-decoration: none; }
a.methodValue:hover { text-decoration: underline; text-underline-offset: 3px; }
.form { padding: var(--site-space-6); border: 1px solid var(--site-line); border-radius: var(--site-r-card, var(--r-3)); background: var(--site-card); }
@media (max-width: 800px) { .block { grid-template-columns: 1fr; padding-block: var(--site-space-12); } }
</style>
