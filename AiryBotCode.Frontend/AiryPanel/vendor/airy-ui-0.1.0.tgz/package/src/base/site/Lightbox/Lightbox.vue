<script setup lang="ts">
/**
 * Lightbox
 * Opens an image or video at full size over the page.
 *
 * A thumbnail in a grid is a preview; a screenshot of a UI is unreadable at
 * grid size, so a media wall that cannot be opened is a media wall you cannot
 * actually look at.
 *
 * Modal, with the same contract as `SlideOver` (both use `useDialog`): focus
 * moves in and back out, Tab is trapped, Escape closes, page scroll is locked.
 * Clicking the backdrop closes too, which is what everyone tries first.
 *
 * @prop open      - v-model:open
 * @prop src       - image or video URL
 * @prop type      - image | video
 * @prop alt       - alt text / accessible name
 * @prop caption   - shown under the media
 * @prop poster    - video poster
 * @prop closeLabel- accessible name for the close button
 *
 * Status: stable | Consumers: CV-Web
 */
import { ref, toRef } from 'vue'
import { useDialog } from '../../composables/useDialog'

const props = withDefaults(
  defineProps<{
    open: boolean
    src: string
    type?: 'image' | 'video'
    alt?: string
    caption?: string
    poster?: string
    closeLabel?: string
  }>(),
  { type: 'image', closeLabel: 'Close' },
)
const emit = defineEmits<{ 'update:open': [value: boolean] }>()

const frame = ref<HTMLElement | null>(null)
const closeButton = ref<HTMLElement | null>(null)

function close() {
  emit('update:open', false)
}

useDialog(toRef(props, 'open'), { container: frame, initialFocus: closeButton, onClose: close })
</script>

<template>
  <Teleport to="body">
    <Transition name="hui-lightbox">
      <div
        v-if="open"
        :class="$style.backdrop"
        data-site="lightbox-backdrop"
        @click.self="close"
      >
        <div
          ref="frame"
          :class="$style.frame"
          role="dialog"
          aria-modal="true"
          :aria-label="alt || caption"
          data-site="lightbox"
        >
          <button
            ref="closeButton"
            type="button"
            :class="$style.close"
            :aria-label="closeLabel"
            data-site="lightbox-close"
            @click="close"
          >
            <svg viewBox="0 0 16 16" width="16" height="16" aria-hidden="true" focusable="false">
              <path d="M2 2 L14 14 M14 2 L2 14" stroke="currentColor" stroke-width="2" stroke-linecap="round" />
            </svg>
          </button>

          <video
            v-if="type === 'video'"
            :class="$style.media"
            :src="src"
            :poster="poster"
            controls
            autoplay
          />
          <img v-else :class="$style.media" :src="src" :alt="alt ?? ''" />

          <p v-if="caption" :class="$style.caption" data-site="lightbox-caption">{{ caption }}</p>
        </div>
      </div>
    </Transition>
  </Teleport>
</template>

<style module>
.backdrop {
  position: fixed;
  inset: 0;
  z-index: 120;
  display: flex;
  align-items: center;
  justify-content: center;
  padding: var(--site-space-6);
  background: oklch(0 0 0 / 0.85);
  backdrop-filter: blur(6px);
}
.frame {
  position: relative;
  display: flex;
  flex-direction: column;
  gap: var(--site-space-3);
  /* the media, not the box, decides the size — up to what the viewport allows */
  max-width: min(1400px, 100%);
  max-height: 100%;
}
.media {
  display: block;
  /* subtract the caption's rough height so a tall image never pushes it off */
  max-height: calc(100vh - 8rem);
  max-width: 100%;
  width: auto;
  height: auto;
  margin-inline: auto;
  border-radius: var(--site-r-card);
  background: #000;
  object-fit: contain;
}
.caption {
  margin: 0;
  text-align: center;
  color: var(--site-muted);
  font-size: var(--font-size-sm, 13px);
}
.close {
  position: absolute;
  top: calc(-1 * var(--site-space-4) - 20px);
  right: 0;
  display: inline-flex;
  align-items: center;
  justify-content: center;
  width: 40px;
  height: 40px;
  border: 1px solid var(--site-line);
  border-radius: 50%;
  background: var(--site-card);
  color: var(--site-fg);
  font: inherit;
  cursor: pointer;
  transition:
    border-color 150ms ease,
    color 150ms ease;
}
.close:hover {
  border-color: var(--site-lead);
  color: var(--site-lead);
}

@media (max-width: 700px) {
  .close {
    top: 0;
    right: 0;
    /* on a small screen there is no room above the frame, so sit it on the media */
    background: oklch(0 0 0 / 0.7);
  }
}
</style>

<style>
.hui-lightbox-enter-active,
.hui-lightbox-leave-active {
  transition: opacity 180ms ease;
}
.hui-lightbox-enter-active [data-site='lightbox'],
.hui-lightbox-leave-active [data-site='lightbox'] {
  transition: scale 180ms ease;
}
.hui-lightbox-enter-from,
.hui-lightbox-leave-to {
  opacity: 0;
}
.hui-lightbox-enter-from [data-site='lightbox'],
.hui-lightbox-leave-to [data-site='lightbox'] {
  scale: 0.97;
}
@media (prefers-reduced-motion: reduce) {
  .hui-lightbox-enter-active,
  .hui-lightbox-leave-active,
  .hui-lightbox-enter-active [data-site='lightbox'],
  .hui-lightbox-leave-active [data-site='lightbox'] {
    transition: none;
  }
}
</style>
