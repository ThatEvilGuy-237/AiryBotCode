<script setup lang="ts">
/**
 * SectionHeading
 * A standalone heading block for content that sits inside a Section (or on a
 * page that has no numbered bands at all).
 *
 * @prop tone  - which identity role colours the title
 * @prop align - center (default) or left
 * @prop level - heading level to render; a page must not repeat h2 under an h2
 *
 * Slots:
 *   default - the title text
 *   sub     - one line of supporting copy under it
 *
 * Status: stable | Consumers: CV-Web
 */
withDefaults(
  defineProps<{
    tone?: 'lead' | 'eyebrow' | 'plain'
    align?: 'center' | 'left'
    level?: 2 | 3 | 4
  }>(),
  { tone: 'lead', align: 'center', level: 2 },
)
</script>

<template>
  <div :class="[$style.heading, align === 'center' && $style.center]">
    <component :is="`h${level}`" :class="[$style.title, $style[tone]]">
      <slot />
    </component>
    <p v-if="$slots.sub" :class="$style.sub"><slot name="sub" /></p>
  </div>
</template>

<style module>
.heading {
  margin-bottom: var(--site-space-12);
}
.center {
  text-align: center;
}
.title {
  font-family: var(--site-display-font, var(--font-family));
  font-size: var(--site-heading);
  text-transform: uppercase;
  letter-spacing: 0.02em;
}
.lead {
  color: var(--site-lead);
}
.eyebrow {
  color: var(--site-eyebrow-color);
}
.plain {
  color: var(--site-fg);
}
.sub {
  margin-top: var(--site-space-4);
  max-width: 60ch;
  color: var(--site-muted);
}
.center .sub {
  margin-inline: auto;
}
</style>
