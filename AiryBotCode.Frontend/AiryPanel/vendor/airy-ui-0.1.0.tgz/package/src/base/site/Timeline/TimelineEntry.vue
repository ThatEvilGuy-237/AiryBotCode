<script setup lang="ts">
/**
 * TimelineEntry
 * One node on a `Timeline`: a dot on the rail, an aside for the when/where, and
 * the body.
 *
 * @prop current - this entry is the one still going on. Marks it visually AND
 *                 with `aria-current="step"`, so "the job I have now" is not
 *                 information carried by a colour alone.
 * @prop accent  - override the dot's colour for this entry
 *
 * Slots:
 *   aside   - dates, place — the metadata column
 *   default - the entry itself
 *
 * Status: stable | Consumers: CV-Web
 */
withDefaults(defineProps<{ current?: boolean; accent?: string }>(), {})
</script>

<template>
  <li
    :class="[$style.entry, current && $style.current]"
    :style="accent ? { '--timeline-accent': accent } : undefined"
    :aria-current="current ? 'step' : undefined"
    data-site="timeline-entry"
  >
    <div :class="$style.rail" aria-hidden="true">
      <span :class="$style.dot" />
    </div>
    <div :class="$style.aside" data-site="timeline-aside"><slot name="aside" /></div>
    <div :class="$style.body"><slot /></div>
  </li>
</template>

<style module>
.entry {
  display: grid;
  grid-template-columns: auto minmax(0, 200px) minmax(0, 1fr);
  gap: var(--timeline-gutter, var(--site-space-6));
  padding-bottom: var(--site-space-8);
}
.entry:last-child {
  padding-bottom: 0;
}

/* The rail is drawn by the entry, not the list, so the last one can stop its
   line rather than trailing off past the final dot. */
.rail {
  position: relative;
  width: var(--timeline-dot, 11px);
}
.rail::before {
  content: '';
  position: absolute;
  top: 0;
  bottom: calc(-1 * var(--site-space-8));
  left: calc(50% - var(--timeline-rail, 2px) / 2);
  width: var(--timeline-rail, 2px);
  background: var(--site-line);
}
.entry:last-child .rail::before {
  bottom: auto;
  /* stop the line at the dot instead of running past the end of the list */
  height: calc(var(--timeline-dot, 11px) / 2 + 0.4em);
}
.dot {
  position: absolute;
  /* line the dot up with the first line of text rather than the top of the box */
  top: 0.4em;
  left: 0;
  width: var(--timeline-dot, 11px);
  height: var(--timeline-dot, 11px);
  border-radius: 50%;
  background: var(--site-bg);
  border: 2px solid var(--timeline-accent, var(--site-line-hi, var(--site-line)));
}
.current .dot {
  background: var(--timeline-accent, var(--site-lead));
  border-color: var(--timeline-accent, var(--site-lead));
  box-shadow: 0 0 0 4px color-mix(in oklch, var(--timeline-accent, var(--site-lead)) 25%, transparent);
}

.aside {
  display: flex;
  flex-direction: column;
  gap: var(--site-space-1);
  padding-top: 0.1em;
}
.body {
  min-width: 0;
  padding-bottom: var(--site-space-4);
}

@media (max-width: 720px) {
  .entry {
    grid-template-columns: auto minmax(0, 1fr);
    gap: var(--site-space-4);
  }
  /* the aside becomes a caption row above the body, still beside the rail */
  .aside {
    flex-direction: row;
    flex-wrap: wrap;
    gap: var(--site-space-4);
  }
  .body {
    grid-column: 2;
  }
}
</style>
