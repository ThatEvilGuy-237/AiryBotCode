<script setup lang="ts">
/**
 * MediaCard
 * An image or video with a caption and tags — the unit of a work/media grid.
 *
 * Videos are `preload="none"` and need a poster or they render as a black box
 * before play. Pass `poster` explicitly, or set `posterDir` to derive it from
 * the source by convention: `/clip.mp4` + `/posters` → `/posters/clip.jpg`.
 *
 * @prop title     - caption
 * @prop src       - image or video URL
 * @prop type      - image | video
 * @prop tags      - pills under the caption
 * @prop poster    - explicit video poster URL (wins over posterDir)
 * @prop posterDir - directory to derive the poster from, e.g. "/posters"
 * @prop alt       - image alt text; defaults to the title
 * @prop openable  - make the media a button that emits `open`. A screenshot of
 *                   a UI is unreadable at grid size, so a media wall you cannot
 *                   open is a media wall you cannot actually look at. Pair with
 *                   `Lightbox`.
 *
 * Emits: open - the visitor asked to see this at full size
 *
 * Status: stable | Consumers: CV-Web
 */
import { computed } from 'vue'
import TagList, { type TagItem } from '../TagList/TagList.vue'

const props = withDefaults(
  defineProps<{
    title: string
    src: string
    type?: 'image' | 'video'
    tags?: (string | TagItem)[]
    poster?: string
    posterDir?: string
    alt?: string
    openable?: boolean
  }>(),
  { type: 'image', tags: () => [] },
)

defineEmits<{ open: [] }>()

const posterSrc = computed(() => {
  if (props.type !== 'video') return undefined
  if (props.poster) return props.poster
  if (!props.posterDir) return undefined
  const file = props.src.split('/').pop()?.replace(/\.[^.]+$/, '')
  return file ? `${props.posterDir.replace(/\/$/, '')}/${file}.jpg` : undefined
})
</script>

<template>
  <figure :class="$style.card" data-site="media-card">
    <!-- A video keeps its own controls, so opening it is a separate affordance;
         an image becomes the button itself, which is what people click. -->
    <video
      v-if="type === 'video'"
      :class="$style.media"
      :src="src"
      :poster="posterSrc"
      controls
      preload="none"
    />
    <button
      v-else-if="openable"
      type="button"
      :class="[$style.media, $style.opener]"
      data-site="media-open"
      @click="$emit('open')"
    >
      <img :class="$style.media" :src="src" :alt="alt ?? title" loading="lazy" />
      <span :class="$style.zoom" aria-hidden="true">
        <svg viewBox="0 0 20 20" width="18" height="18">
          <circle cx="9" cy="9" r="6" fill="none" stroke="currentColor" stroke-width="2" />
          <path d="M13.5 13.5 L18 18 M6.5 9 h5 M9 6.5 v5" stroke="currentColor" stroke-width="2" stroke-linecap="round" />
        </svg>
      </span>
    </button>
    <img v-else :class="$style.media" :src="src" :alt="alt ?? title" loading="lazy" />
    <figcaption :class="$style.body">
      <p :class="$style.title">{{ title }}</p>
      <slot />
      <TagList v-if="tags.length" :items="tags" size="sm" />
    </figcaption>
  </figure>
</template>

<style module>
.card {
  margin: 0 0 var(--site-space-6);
  overflow: hidden;
  border: 1px solid var(--site-line);
  border-radius: var(--site-r-card);
  background: var(--site-card);
  transition: border-color 150ms ease;
  /* grid children are laid out by the parent; in a masonry column this keeps a
     card from being split across columns */
  break-inside: avoid;
}
.card:hover,
.card:focus-within {
  border-color: var(--site-card-hover-edge);
}
.media {
  display: block;
  width: 100%;
  height: auto;
  background: #000;
}
.opener {
  position: relative;
  padding: 0;
  border: 0;
  cursor: zoom-in;
}
.zoom {
  position: absolute;
  right: var(--site-space-2);
  bottom: var(--site-space-2);
  display: inline-flex;
  align-items: center;
  justify-content: center;
  width: 32px;
  height: 32px;
  border-radius: 50%;
  background: oklch(0 0 0 / 0.6);
  color: #fff;
  opacity: 0;
  transition: opacity 150ms ease;
}
.opener:hover .zoom,
.opener:focus-visible .zoom {
  opacity: 1;
}
.body {
  display: flex;
  flex-direction: column;
  gap: var(--site-space-2);
  padding: var(--site-space-4);
}
.title {
  margin: 0;
  font-weight: 600;
  color: var(--site-fg);
}
</style>
