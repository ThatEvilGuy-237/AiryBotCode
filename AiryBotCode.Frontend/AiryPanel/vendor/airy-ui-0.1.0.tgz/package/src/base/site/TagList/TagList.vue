<script setup lang="ts">
/**
 * TagList
 * A wrapping row of pill labels — tech stacks, skills, project keywords.
 * Presentational only; for interactive filtering use FilterPills instead.
 *
 * @prop items - plain strings, or objects carrying a hover/focus hint
 * @prop size  - sm (dense captions) or md (default)
 * @prop tone  - neutral (default) or lead (accent-tinted)
 *
 * Status: stable | Consumers: CV-Web
 */
import { computed } from 'vue'

export interface TagItem {
  label: string
  hint?: string
}

const props = withDefaults(
  defineProps<{
    items: (string | TagItem)[]
    size?: 'sm' | 'md'
    tone?: 'neutral' | 'lead'
  }>(),
  { size: 'md', tone: 'neutral' },
)

const tags = computed<TagItem[]>(() =>
  props.items.map((item) => (typeof item === 'string' ? { label: item } : item)),
)
</script>

<template>
  <ul :class="$style.list" data-site="taglist">
    <li
      v-for="tag in tags"
      :key="tag.label"
      :class="[$style.tag, $style[size], $style[tone], tag.hint && $style.hinted]"
      :title="tag.hint"
      :tabindex="tag.hint ? 0 : undefined"
    >
      {{ tag.label }}
      <span v-if="tag.hint" :class="$style.hint" role="tooltip">{{ tag.hint }}</span>
    </li>
  </ul>
</template>

<style module>
.list {
  display: flex;
  flex-wrap: wrap;
  gap: var(--site-space-2);
  margin: 0;
  padding: 0;
  list-style: none;
}
.tag {
  position: relative;
  border: 1px solid var(--site-line);
  border-radius: var(--site-r-pill);
  background: var(--site-card);
  color: var(--site-muted);
  font-weight: 500;
  white-space: nowrap;
}
.md {
  padding: 4px 10px;
  font-size: 0.78rem;
}
.sm {
  padding: 2px 8px;
  font-size: 0.72rem;
}
.lead {
  border-color: color-mix(in oklch, var(--site-lead) 45%, transparent);
  color: var(--site-fg);
}
.hinted {
  cursor: help;
}

/* The hint is a CSS-only tooltip: no JS, no portal, no layout thrash. It is
   clipped by an ancestor with overflow:hidden — keep tag rows unclipped. */
.hint {
  position: absolute;
  bottom: calc(100% + 8px);
  left: 50%;
  z-index: 5;
  translate: -50% 4px;
  padding: 6px 10px;
  max-width: 26ch;
  border: 1px solid var(--site-line);
  border-radius: var(--r-2, 6px);
  background: var(--site-bg-alt);
  box-shadow: var(--shadow-2);
  color: var(--site-fg);
  font-size: var(--font-size-xs, 12px);
  font-weight: 400;
  white-space: normal;
  text-align: center;
  opacity: 0;
  pointer-events: none;
  transition:
    opacity 140ms ease,
    translate 140ms ease;
}
.hinted:hover .hint,
.hinted:focus-visible .hint {
  opacity: 1;
  translate: -50% 0;
}
</style>
