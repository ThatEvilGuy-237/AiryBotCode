<script setup lang="ts">
/**
 * Timeline
 * A vertical rail of dated entries — a work history, a changelog, a roadmap.
 *
 * Renders an ordered list, because the order carries meaning: a screen reader
 * announcing "list, 7 items, item 1 of 7" is the point, and it is what a plain
 * stack of `<div>`s throws away.
 *
 * Put `TimelineEntry` children in the default slot; this only draws the rail and
 * owns the spacing between entries.
 *
 * @prop reversed - number the entries from the bottom up, for newest-first lists
 *
 * Status: stable | Consumers: CV-Web
 */
defineProps<{ reversed?: boolean }>()
</script>

<template>
  <ol :class="$style.timeline" :reversed="reversed || undefined" data-site="timeline">
    <slot />
  </ol>
</template>

<style module>
.timeline {
  --timeline-rail: 2px;
  --timeline-dot: 11px;
  --timeline-gutter: var(--site-space-6);
  list-style: none;
  margin: 0;
  padding: 0;
}
</style>
