<script setup lang="ts">
/**
 * SlideOver
 * A panel that slides in from the edge of the viewport for the long version of
 * something the page only summarised.
 *
 * It is a modal dialog, which is a contract rather than a look. Declaring
 * `aria-modal` and then leaving the page behind reachable is worse than not
 * declaring it, so this owns the whole set:
 *
 * - focus moves into the panel on open and returns to whatever opened it on close;
 * - **focus is trapped** — Tab and Shift+Tab cycle inside the panel;
 * - Escape closes, as does clicking the backdrop;
 * - page scroll is locked while it is open, and restored to whatever it was.
 *
 * Teleported to `<body>` so no ancestor's `overflow`, `transform` or stacking
 * context can clip it — a panel rendered inside a card is a panel inside a card.
 *
 * @prop open   - v-model:open
 * @prop label  - accessible name for the dialog; use when there is no visible title
 * @prop side   - which edge it comes from (default right)
 * @prop accent - colour of the edge stripe, e.g. to match whatever opened it.
 *                A prop rather than an inherited custom property: the panel is
 *                teleported to <body>, so a style bound on this component never
 *                reaches the element that needs it.
 *
 * Slots:
 *   header  - pinned to the top, beside the close button
 *   default - the body
 *   footer  - pinned under the body
 *
 * Status: stable | Consumers: CV-Web
 */
import { ref, toRef } from 'vue'
import { useDialog } from '../../composables/useDialog'

const props = withDefaults(
  defineProps<{
    open: boolean
    label?: string
    side?: 'right' | 'left'
    closeLabel?: string
    accent?: string
  }>(),
  { side: 'right', closeLabel: 'Close' },
)
const emit = defineEmits<{ 'update:open': [value: boolean] }>()

const sheet = ref<HTMLElement | null>(null)
const closeButton = ref<HTMLElement | null>(null)

function close() {
  emit('update:open', false)
}

// The whole modal contract — focus trap, focus restore, Escape, scroll lock —
// lives in useDialog so SlideOver and Lightbox cannot drift apart on it.
useDialog(toRef(props, 'open'), { container: sheet, initialFocus: closeButton, onClose: close })
</script>

<template>
  <Teleport to="body">
    <Transition name="hui-slideover">
      <div
        v-if="open"
        :class="[$style.backdrop, side === 'left' && $style.fromLeft]"
        data-site="slideover-backdrop"
        @click.self="close"
      >
        <aside
          ref="sheet"
          :class="$style.sheet"
          :style="accent ? { '--slideover-edge': accent } : undefined"
          role="dialog"
          aria-modal="true"
          :aria-label="label"
          data-site="slideover"
        >
          <header :class="$style.head" data-site="slideover-head">
            <slot name="header" />
            <button
              ref="closeButton"
              type="button"
              :class="$style.close"
              :aria-label="closeLabel"
              data-site="slideover-close"
              @click="close"
            >
              <svg viewBox="0 0 16 16" width="14" height="14" aria-hidden="true" focusable="false">
                <path
                  d="M2 2 L14 14 M14 2 L2 14"
                  stroke="currentColor"
                  stroke-width="2"
                  stroke-linecap="round"
                />
              </svg>
            </button>
          </header>

          <div :class="$style.body"><slot /></div>

          <footer v-if="$slots.footer" :class="$style.foot"><slot name="footer" /></footer>
        </aside>
      </div>
    </Transition>
  </Teleport>
</template>

<style module>
.backdrop {
  position: fixed;
  inset: 0;
  z-index: 100;
  display: flex;
  justify-content: flex-end;
  background: oklch(0 0 0 / 0.65);
  backdrop-filter: blur(4px);
}
.fromLeft {
  justify-content: flex-start;
}
.sheet {
  position: relative;
  display: flex;
  flex-direction: column;
  width: min(640px, 100%);
  height: 100%;
  overflow-y: auto;
  padding: var(--site-space-8);
  background: var(--site-bg-alt);
  /* the edge stripe takes the panel's accent; a consumer can set --slideover-edge
     per instance to colour-code what it opened from */
  border-inline-start: 3px solid var(--slideover-edge, var(--site-lead));
}
.head {
  display: flex;
  align-items: flex-start;
  justify-content: space-between;
  gap: var(--site-space-4);
  margin-bottom: var(--site-space-6);
}
.close {
  flex-shrink: 0;
  width: 40px;
  height: 40px;
  border: 1px solid var(--site-line);
  border-radius: 50%;
  display: inline-flex;
  align-items: center;
  justify-content: center;
  background: var(--site-card);
  color: var(--site-fg);
  font: inherit;
  cursor: pointer;
  transition:
    border-color 150ms ease,
    color 150ms ease;
}
.close:hover {
  border-color: var(--site-lead);
  color: var(--site-lead);
}
.body {
  flex: 1;
}
.foot {
  margin-top: var(--site-space-6);
  padding-top: var(--site-space-5);
  border-top: 1px solid var(--site-line);
}

@media (max-width: 560px) {
  .sheet {
    padding: var(--site-space-5);
  }
}
</style>

<style>
/* Transition classes cannot be CSS-module-scoped — Vue applies them by name to
   the element, so they have to exist as global class names. */
.hui-slideover-enter-active,
.hui-slideover-leave-active {
  transition: opacity 200ms ease;
}
.hui-slideover-enter-active [data-site='slideover'],
.hui-slideover-leave-active [data-site='slideover'] {
  transition: translate 250ms ease;
}
.hui-slideover-enter-from,
.hui-slideover-leave-to {
  opacity: 0;
}
.hui-slideover-enter-from [data-site='slideover'],
.hui-slideover-leave-to [data-site='slideover'] {
  translate: 40px 0;
}
@media (prefers-reduced-motion: reduce) {
  .hui-slideover-enter-active,
  .hui-slideover-leave-active,
  .hui-slideover-enter-active [data-site='slideover'],
  .hui-slideover-leave-active [data-site='slideover'] {
    transition: none;
  }
}
</style>
