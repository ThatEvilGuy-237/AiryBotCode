<script setup lang="ts">
/**
 * TabBar
 * The tab strip of a long-form page, with the parts of the tab pattern that are
 * easy to leave out and not optional:
 *
 * - **roving tabindex** — only the selected tab is in the tab order, so the
 *   strip is one stop rather than six;
 * - **arrow keys** — which is what makes the other five reachable at all once
 *   the tabindex is roving. Home/End jump to the ends;
 * - **`aria-controls` / `aria-labelledby`** wiring, so a screen reader can move
 *   between a tab and its panel.
 *
 * It is presentational and controlled: it renders no panels and owns no state.
 * The consumer decides where the selection lives — component state, or a URL,
 * which is usually the better answer for a page worth linking to.
 *
 * **Render every panel.** Whatever holds the content, do not mount only the
 * active one: an unmounted panel is not in the served HTML (invisible to search
 * engines, and a shared link lands on the default) and not in the DOM to print.
 * Hide the inactive ones instead; the bytes are the same either way.
 *
 * Ids follow `tab-<value>` and `panel-<value>`; give each panel the matching id.
 *
 * @prop modelValue - the selected tab's value
 * @prop items      - the tabs, in order
 *
 * Status: stable | Consumers: CV-Web
 */
import { nextTick, ref } from 'vue'

export interface TabBarItem {
  value: string
  label: string
}

const props = defineProps<{ modelValue: string; items: TabBarItem[] }>()
const emit = defineEmits<{ 'update:modelValue': [value: string] }>()

const buttons = ref<HTMLElement[]>([])

function move(from: number, delta: number) {
  const next = (from + delta + props.items.length) % props.items.length
  emit('update:modelValue', props.items[next].value)
  nextTick(() => buttons.value[next]?.focus())
}

function onKey(event: KeyboardEvent, index: number) {
  switch (event.key) {
    case 'ArrowRight':
      move(index, 1)
      break
    case 'ArrowLeft':
      move(index, -1)
      break
    case 'Home':
      move(0, 0)
      break
    case 'End':
      move(props.items.length - 1, 0)
      break
    default:
      return
  }
  event.preventDefault()
}
</script>

<template>
  <div :class="$style.bar" role="tablist" data-site="tabbar">
    <button
      v-for="(item, i) in items"
      :id="`tab-${item.value}`"
      :key="item.value"
      :ref="(el) => { if (el) buttons[i] = el as HTMLElement }"
      type="button"
      role="tab"
      :class="[$style.tab, modelValue === item.value && $style.active]"
      :aria-selected="modelValue === item.value"
      :aria-controls="`panel-${item.value}`"
      :tabindex="modelValue === item.value ? 0 : -1"
      data-site="tab"
      @click="emit('update:modelValue', item.value)"
      @keydown="onKey($event, i)"
    >
      {{ item.label }}
    </button>
  </div>
</template>

<style module>
.bar {
  display: flex;
  gap: var(--site-space-2);
  /* a narrow screen scrolls the strip rather than wrapping it — a tab row that
     wraps to two lines stops reading as one control */
  overflow-x: auto;
  scrollbar-width: none;
}
/* With the scrollbar hidden, nothing says "there is more" — so on widths where
   the strip is likely to overflow, fade the edges. The fade is the affordance. */
@media (max-width: 700px) {
  .bar {
    -webkit-mask-image: linear-gradient(90deg, transparent, #000 4%, #000 94%, transparent);
    mask-image: linear-gradient(90deg, transparent, #000 4%, #000 94%, transparent);
  }
}
.bar::-webkit-scrollbar {
  display: none;
}
.tab {
  border: 0;
  border-bottom: 2px solid transparent;
  background: none;
  color: var(--site-muted);
  font: inherit;
  font-weight: 600;
  padding: var(--site-space-4);
  white-space: nowrap;
  cursor: pointer;
  transition:
    color 150ms ease,
    border-color 150ms ease;
}
.tab:hover {
  color: var(--site-fg);
}
.active {
  color: var(--site-eyebrow-color);
  border-bottom-color: var(--site-eyebrow-color);
}
</style>
