<script setup lang="ts">
/**
 * StatsBand
 * A row of big numbers with a label each. Numbers are set in the display face
 * with tabular figures so a row of them lines up.
 *
 * @prop items - { value, label, hint? }[]
 * @prop tone  - plain (default) | lead: numbers in the lead colour
 *
 * Status: new | Consumers: showcase
 */
export interface StatItem { value: string; label: string; hint?: string }

withDefaults(defineProps<{
  items: StatItem[]
  tone?: 'plain' | 'lead'
}>(), { tone: 'plain' })
</script>

<template>
  <div :class="[$style.band, $style[tone]]" data-site="stats">
    <div v-for="s in items" :key="s.label" :class="$style.stat" data-site="stat">
      <span :class="$style.value">{{ s.value }}</span>
      <span :class="$style.label">{{ s.label }}</span>
      <span v-if="s.hint" :class="$style.hint">{{ s.hint }}</span>
    </div>
  </div>
</template>

<style module>
.band {
  display: grid;
  grid-template-columns: repeat(auto-fit, minmax(160px, 1fr));
  gap: var(--site-space-4);
  max-width: var(--site-maxw);
  margin: 0 auto;
  padding: var(--site-space-8) var(--site-gutter);
  border-top: 1px solid var(--site-line-soft);
  border-bottom: 1px solid var(--site-line-soft);
}
.stat { display: flex; flex-direction: column; gap: 4px; }
.value { font-family: var(--site-display-font, var(--font-family)); font-variant-numeric: tabular-nums; font-size: var(--site-heading); font-weight: 700; letter-spacing: -0.03em; line-height: 1; color: var(--site-fg); }
.lead .value { color: var(--site-lead); }
.label { font-size: var(--site-body); color: var(--site-fg); }
.hint { font-family: var(--font-mono); font-size: var(--font-size-xs); color: var(--site-muted); }
</style>
