<script setup lang="ts">
/**
 * SiteFooter
 * The last band: brand on the left, link columns, a note line underneath.
 *
 * @prop brand   - brand text (or use the brand slot)
 * @prop columns - { title, links: { label, href, external? }[] }[]
 * @prop note    - the small line at the bottom, usually the copyright
 *
 * Slots: brand, note
 *
 * Status: new | Consumers: showcase
 */
export interface FooterLink { label: string; href: string; external?: boolean }
export interface FooterColumn { title: string; links: FooterLink[] }

withDefaults(defineProps<{
  brand?: string
  columns?: FooterColumn[]
  note?: string
}>(), { columns: () => [] })
</script>

<template>
  <footer :class="$style.footer" data-site="footer" :style="{ '--footer-cols': columns.length }">
    <div :class="$style.inner">
      <div :class="$style.brand" data-site="footer-brand"><slot name="brand">{{ brand }}</slot></div>
      <nav v-for="c in columns" :key="c.title" :class="$style.column" data-site="footer-column" :aria-label="c.title">
        <h3 :class="$style.title">{{ c.title }}</h3>
        <a v-for="l in c.links" :key="l.label" :href="l.href" :class="$style.link" :target="l.external ? '_blank' : undefined" :rel="l.external ? 'noopener' : undefined">{{ l.label }}</a>
      </nav>
    </div>
    <div v-if="note || $slots.note" :class="$style.note" data-site="footer-note"><slot name="note">{{ note }}</slot></div>
  </footer>
</template>

<style module>
.footer {
  border-top: 1px solid var(--site-line);
  background: var(--site-bg-alt);
  color: var(--site-muted);
}
.inner {
  display: grid;
  grid-template-columns: minmax(160px, 1.4fr) repeat(var(--footer-cols, 3), minmax(120px, 1fr));
  gap: var(--site-space-8);
  max-width: var(--site-maxw);
  margin: 0 auto;
  padding: var(--site-space-12) var(--site-gutter) var(--site-space-8);
}
.brand { font-family: var(--site-display-font, var(--font-family)); font-size: calc(var(--site-body) * 1.3); font-weight: 700; letter-spacing: -0.02em; color: var(--site-fg); }
.column { display: flex; flex-direction: column; gap: var(--site-space-2); }
.title { margin: 0 0 var(--site-space-1); font-family: var(--font-mono); font-size: var(--site-eyebrow); letter-spacing: 0.12em; text-transform: uppercase; color: var(--site-eyebrow-color); }
.link { color: var(--site-muted); text-decoration: none; font-size: var(--site-body); }
.link:hover { color: var(--site-fg); text-decoration: underline; text-underline-offset: 3px; }
.note {
  max-width: var(--site-maxw);
  margin: 0 auto;
  padding: var(--site-space-4) var(--site-gutter) var(--site-space-8);
  border-top: 1px solid var(--site-line-soft);
  font-family: var(--font-mono);
  font-size: var(--font-size-xs);
  color: var(--site-muted);
}
@media (max-width: 700px) { .inner { grid-template-columns: 1fr 1fr; } }
</style>
