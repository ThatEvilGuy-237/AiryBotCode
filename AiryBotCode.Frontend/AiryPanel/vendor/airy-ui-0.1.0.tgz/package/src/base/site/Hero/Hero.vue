<script setup lang="ts">
/**
 * Hero
 * The opening band of a marketing page: eyebrow, display title, a lead paragraph,
 * a row of actions and an optional media column.
 *
 * @prop eyebrow - short mono label above the title
 * @prop title   - the display line; keep it to one sentence
 * @prop lead    - the paragraph under it
 * @prop align   - start (two columns when media is given) | center
 *
 * Slots: actions (buttons), media (image, video, illustration), default (extra content under the lead)
 *
 * Status: new | Consumers: showcase
 */
withDefaults(defineProps<{
  eyebrow?: string
  title: string
  lead?: string
  align?: 'start' | 'center'
}>(), { align: 'start' })
</script>

<template>
  <section :class="[$style.hero, $style[align], $slots.media && $style.withMedia]" data-site="hero">
    <div :class="$style.body">
      <p v-if="eyebrow" :class="$style.eyebrow" data-site="hero-eyebrow">{{ eyebrow }}</p>
      <h1 :class="$style.title" data-site="hero-title">{{ title }}</h1>
      <p v-if="lead" :class="$style.lead" data-site="hero-lead">{{ lead }}</p>
      <slot />
      <div v-if="$slots.actions" :class="$style.actions" data-site="hero-actions"><slot name="actions" /></div>
    </div>
    <div v-if="$slots.media" :class="$style.media" data-site="hero-media"><slot name="media" /></div>
  </section>
</template>

<style module>
.hero {
  display: grid;
  gap: var(--site-space-8);
  align-items: center;
  max-width: var(--site-maxw);
  margin: 0 auto;
  padding: var(--site-space-16) var(--site-gutter);
  color: var(--site-fg);
}
.withMedia.start { grid-template-columns: minmax(0, 1.1fr) minmax(0, 1fr); }
.center { text-align: center; }
.center .body { margin: 0 auto; }
.center .actions { justify-content: center; }
.body { max-width: 640px; }
.eyebrow {
  margin: 0 0 var(--site-space-3);
  font-family: var(--font-mono);
  font-size: var(--site-eyebrow);
  letter-spacing: 0.12em;
  text-transform: uppercase;
  color: var(--site-eyebrow-color);
}
.title {
  margin: 0;
  font-family: var(--site-display-font, var(--font-family));
  font-size: var(--site-display);
  font-weight: 700;
  letter-spacing: -0.03em;
  line-height: 1.02;
  color: var(--site-fg);
}
.lead {
  margin: var(--site-space-4) 0 0;
  font-size: calc(var(--site-body) * 1.2);
  line-height: 1.5;
  color: var(--site-muted);
}
.actions { display: flex; flex-wrap: wrap; gap: var(--site-space-3); margin-top: var(--site-space-6); }
.media { min-width: 0; }
.media > * { width: 100%; border-radius: var(--site-r-card, var(--r-4)); }
@media (max-width: 800px) {
  .withMedia.start { grid-template-columns: 1fr; }
  .hero { padding-block: var(--site-space-12); }
}
</style>
