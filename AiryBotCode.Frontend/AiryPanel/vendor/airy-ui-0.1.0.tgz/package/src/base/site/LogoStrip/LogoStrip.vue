<script setup lang="ts">
/**
 * LogoStrip
 * "Trusted by" in one quiet row. Logos are images or plain names; names are set
 * in the display face and muted so the strip never competes with the hero.
 *
 * @prop title - the small line above the row
 * @prop items - { name, src?, href? }[]
 *
 * Status: new | Consumers: showcase
 */
export interface LogoItem { name: string; src?: string; href?: string }

withDefaults(defineProps<{
  title?: string
  items: LogoItem[]
}>(), { title: 'Trusted by' })
</script>

<template>
  <div :class="$style.strip" data-site="logo-strip">
    <p v-if="title" :class="$style.title">{{ title }}</p>
    <ul :class="$style.row">
      <li v-for="it in items" :key="it.name" :class="$style.item" data-site="logo">
        <component :is="it.href ? 'a' : 'span'" :href="it.href" :class="$style.link">
          <img v-if="it.src" :src="it.src" :alt="it.name" :class="$style.img" />
          <span v-else :class="$style.name">{{ it.name }}</span>
        </component>
      </li>
    </ul>
  </div>
</template>

<style module>
.strip { max-width: var(--site-maxw); margin: 0 auto; padding: var(--site-space-8) var(--site-gutter); text-align: center; }
.title { margin: 0 0 var(--site-space-4); font-family: var(--font-mono); font-size: var(--site-eyebrow); letter-spacing: 0.12em; text-transform: uppercase; color: var(--site-muted); }
.row { list-style: none; margin: 0; padding: 0; display: flex; flex-wrap: wrap; justify-content: center; gap: var(--site-space-4) var(--site-space-8); }
.item { display: inline-flex; align-items: center; }
.link { color: inherit; text-decoration: none; opacity: 0.7; transition: opacity 0.15s; }
.link:hover { opacity: 1; }
.img { height: 28px; width: auto; filter: grayscale(1); }
.name { font-family: var(--site-display-font, var(--font-family)); font-size: calc(var(--site-body) * 1.25); font-weight: 700; letter-spacing: -0.02em; color: var(--site-muted); }
</style>
