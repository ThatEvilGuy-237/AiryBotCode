<script setup lang="ts">
/**
 * FeatureGrid
 * A grid of short feature cells: icon, title, one or two sentences.
 *
 * @prop items   - { icon?, title, body }[]
 * @prop columns - 2 | 3 | 4 (default 3); collapses on narrow screens
 *
 * Status: new | Consumers: showcase
 */
import Icon from '../../components/Icon/Icon.vue'
import type { IconName } from '../../components/Icon/icons'

export interface FeatureItem { icon?: IconName; title: string; body: string }

withDefaults(defineProps<{
  items: FeatureItem[]
  columns?: 2 | 3 | 4
}>(), { columns: 3 })
</script>

<template>
  <div :class="[$style.grid, $style[`c${columns}`]]" data-site="feature-grid">
    <article v-for="it in items" :key="it.title" :class="$style.cell" data-site="feature">
      <span v-if="it.icon" :class="$style.icon"><Icon :name="it.icon" :size="20" /></span>
      <h3 :class="$style.title">{{ it.title }}</h3>
      <p :class="$style.body">{{ it.body }}</p>
    </article>
  </div>
</template>

<style module>
.grid {
  display: grid;
  gap: var(--site-space-4);
  max-width: var(--site-maxw);
  margin: 0 auto;
  padding: 0 var(--site-gutter);
}
.c2 { grid-template-columns: repeat(2, minmax(0, 1fr)); }
.c3 { grid-template-columns: repeat(3, minmax(0, 1fr)); }
.c4 { grid-template-columns: repeat(4, minmax(0, 1fr)); }
.cell {
  padding: var(--site-space-5);
  border: 1px solid var(--site-line);
  border-radius: var(--site-r-card, var(--r-3));
  background: var(--site-card);
  transition: border-color 0.15s, transform 0.15s;
}
.cell:hover { border-color: var(--site-card-hover-edge); transform: translateY(-2px); }
.icon {
  display: inline-grid;
  place-items: center;
  width: 40px;
  height: 40px;
  margin-bottom: var(--site-space-3);
  border-radius: var(--r-2);
  background: var(--color-accent-soft);
  color: var(--site-lead);
}
.title { margin: 0 0 var(--site-space-2); font-size: calc(var(--site-body) * 1.1); font-weight: 600; color: var(--site-fg); }
.body { margin: 0; font-size: var(--site-body); line-height: 1.55; color: var(--site-muted); }
@media (max-width: 900px) { .c3, .c4 { grid-template-columns: repeat(2, minmax(0, 1fr)); } }
@media (max-width: 560px) { .c2, .c3, .c4 { grid-template-columns: 1fr; } }
</style>
