<script setup lang="ts">
/**
 * Section
 * One numbered band of a long-form page: a big outlined numeral, an eyebrow
 * label, a title, and the body. Head and body reveal on scroll, head first.
 *
 * @prop number  - the numeral shown in outline ("01"); also the scroll anchor's visual index
 * @prop id      - anchor id, for in-page nav / scrollspy
 * @prop label   - small uppercase eyebrow above the title
 * @prop title   - section title
 * @prop alt     - paint the alternating band background
 * @prop full    - stretch to at least one viewport height (default true)
 * @prop narrow  - use the narrow measure instead of the full one
 *
 * Every part carries a stable `data-site="…"` hook (section / section-head /
 * -numeral / -label / -title) so a consumer can restyle for print or override a
 * detail without reaching for a hashed CSS-module class.
 *
 * Slots:
 *   default - body content
 *   head    - replaces the whole default head (numeral + label + title)
 *   aside   - trailing content in the head row (e.g. a link or a count)
 *
 * Status: stable | Consumers: CV-Web
 */
import { useReveal } from '../../composables/useReveal'

withDefaults(
  defineProps<{
    number?: string
    id?: string
    label?: string
    title?: string
    alt?: boolean
    full?: boolean
    narrow?: boolean
  }>(),
  { full: true },
)

const { observe } = useReveal()
</script>

<template>
  <section
    :id="id"
    :class="[$style.section, alt && $style.alt, full && $style.full]"
    data-site="section"
    :data-alt="alt || undefined"
  >
    <div :class="[$style.container, narrow && $style.narrow]">
      <header :ref="observe" :class="[$style.head, $style.reveal]" data-site="section-head">
        <slot name="head">
          <span v-if="number" :class="$style.numeral" data-site="section-numeral" aria-hidden="true">
            {{ number }}
          </span>
          <div :class="$style.meta">
            <span v-if="label" :class="$style.label" data-site="section-label">{{ label }}</span>
            <h2 v-if="title" :class="$style.title" data-site="section-title">{{ title }}</h2>
          </div>
        </slot>
        <div v-if="$slots.aside" :class="$style.aside"><slot name="aside" /></div>
      </header>
      <div :ref="observe" :class="[$style.body, $style.reveal, $style.late]">
        <slot />
      </div>
    </div>
  </section>
</template>

<style module>
.section {
  padding-block: clamp(var(--site-space-16), 10vw, calc(var(--site-space-20) * 1.4));
  border-top: 1px solid var(--site-line-soft);
}
/* A full-height band suits a continuously scrolled page. Inside a tab panel or
   an accordion it just leaves a hole, and the section does not know where it
   has been placed — so the CONTAINER opts out by setting --site-section-min-h
   on any ancestor, without every section needing a prop threaded through it. */
.full {
  min-height: var(--site-section-min-h, 100svh);
  display: flex;
  flex-direction: column;
  justify-content: center;
}
.alt {
  background: var(--site-bg-alt);
}
.container {
  width: 100%;
  max-width: var(--site-maxw);
  margin-inline: auto;
  padding-inline: var(--site-gutter);
}
.narrow {
  max-width: var(--site-maxw-narrow);
}
.head {
  display: flex;
  align-items: flex-start;
  gap: var(--site-space-6);
  margin-bottom: var(--site-space-12);
}
.numeral {
  flex-shrink: 0;
  font-family: var(--font-mono);
  font-size: var(--site-numeral);
  line-height: 0.8;
  font-weight: 700;
  letter-spacing: -0.02em;
  color: transparent;
  -webkit-text-stroke: 1.5px var(--site-lead);
}
.meta {
  padding-top: 6px;
}
.label {
  display: block;
  margin-bottom: var(--site-space-2);
  font-family: var(--font-mono);
  font-size: var(--site-eyebrow);
  text-transform: uppercase;
  letter-spacing: 0.28em;
  color: var(--site-eyebrow-color);
}
.title {
  font-family: var(--site-display-font, var(--font-family));
  font-size: var(--site-display);
  line-height: 1.02;
  letter-spacing: -0.02em;
  font-weight: 600;
  color: var(--site-fg);
}
.aside {
  margin-left: auto;
  padding-top: 6px;
}

/* Reveal is opt-in via html.js so a no-JS render shows everything. */
:global(html.js) .reveal {
  opacity: 0;
  transform: translateY(18px);
  transition:
    opacity var(--site-reveal-ms) ease,
    transform var(--site-reveal-ms) ease;
}
:global(html.js) .late {
  transition-delay: 120ms;
}
:global(html.js) .reveal:global(.is-in) {
  opacity: 1;
  transform: none;
}

/* Paper never scrolls, so a not-yet-revealed section must not print blank. */
@media print {
  :global(html.js) .reveal {
    opacity: 1;
    transform: none;
  }
}

@media (max-width: 560px) {
  .head {
    gap: var(--site-space-4);
    margin-bottom: var(--site-space-8);
  }
}
</style>
