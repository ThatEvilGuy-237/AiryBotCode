import { nextTick, onBeforeUnmount, ref, watch, type Ref } from 'vue'

const FOCUSABLE =
  'a[href], button:not([disabled]), input, select, textarea, [tabindex]:not([tabindex="-1"])'

export interface DialogOptions {
  /** the element to trap focus inside */
  container: Ref<HTMLElement | null>
  /** focused when the dialog opens; falls back to the container itself */
  initialFocus?: Ref<HTMLElement | null>
  onClose: () => void
}

/**
 * The modal contract, in one place.
 *
 * `aria-modal="true"` is a promise about behaviour, not a styling hook. A dialog
 * that declares it and then lets Tab wander into the page behind tells assistive
 * tech something untrue — worse than never declaring it. So anything modal needs
 * the whole set, and the set is easy to half-implement:
 *
 * - focus moves in on open and returns to the opener on close, so a keyboard
 *   user carries on where they were instead of being dropped at the top;
 * - Tab and Shift+Tab wrap inside the container;
 * - Escape closes;
 * - page scroll is locked, and restored to whatever it was rather than to "".
 *
 * Shared by SlideOver and Lightbox so there is one implementation to get right.
 */
const openDialogs: { id: number; container: Ref<HTMLElement | null> }[] = []
let dialogSeq = 0
let layerSeq = 0

export function useDialog(open: Ref<boolean>, options: DialogOptions) {
  const { container, initialFocus, onClose } = options
  const id = ++dialogSeq
  const layer = ref(0)
  let opener: HTMLElement | null = null
  let previousOverflow = ''

  function leave() {
    const i = openDialogs.findIndex((d) => d.id === id)
    if (i >= 0) openDialogs.splice(i, 1)
  }

  function onKeydown(event: KeyboardEvent) {
    if (openDialogs[openDialogs.length - 1]?.id !== id) return
    if (event.key === 'Escape') {
      onClose()
      return
    }
    if (event.key !== 'Tab' || !container.value) return

    const items = [...container.value.querySelectorAll<HTMLElement>(FOCUSABLE)].filter(
      (el) => el.offsetParent !== null,
    )
    if (!items.length) return
    const first = items[0]
    const last = items[items.length - 1]
    if (event.shiftKey && document.activeElement === first) {
      event.preventDefault()
      last.focus()
    } else if (!event.shiftKey && document.activeElement === last) {
      event.preventDefault()
      first.focus()
    }
  }

  watch(open, (isOpen) => {
    if (typeof document === 'undefined') return
    if (isOpen) {
      openDialogs.push({ id, container })
      layer.value = ++layerSeq
      opener = document.activeElement as HTMLElement | null
      previousOverflow = document.body.style.overflow
      document.body.style.overflow = 'hidden'
      document.addEventListener('keydown', onKeydown)
      nextTick(() => (initialFocus?.value ?? container.value)?.focus())
    } else {
      leave()
      document.body.style.overflow = previousOverflow
      document.removeEventListener('keydown', onKeydown)
      const below = openDialogs[openDialogs.length - 1]?.container.value
      if (opener && opener.isConnected && !opener.matches(':disabled')) opener.focus()
      else below?.focus()
      opener = null
    }
  })

  onBeforeUnmount(() => {
    leave()
    if (typeof document === 'undefined') return
    document.removeEventListener('keydown', onKeydown)
    if (open.value) document.body.style.overflow = previousOverflow
  })

  return { layer }
}

/** Convenience for components that own their own container ref. */
export function useDialogRefs() {
  return {
    container: ref<HTMLElement | null>(null),
    initialFocus: ref<HTMLElement | null>(null),
  }
}
