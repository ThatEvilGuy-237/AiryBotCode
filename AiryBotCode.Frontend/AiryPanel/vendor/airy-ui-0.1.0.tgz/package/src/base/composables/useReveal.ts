import { onBeforeUnmount, onMounted, ref, type ComponentPublicInstance, type Ref } from 'vue'

export interface RevealOptions {
  threshold?: number
  /** class toggled on when the element first enters the viewport */
  activeClass?: string
}

/** what Vue hands a function `ref` — a DOM node, a component instance, or null */
export type RevealTarget = Element | ComponentPublicInstance | null | undefined

export interface RevealApi {
  /** attach to any element with `:ref`; observed once, then unobserved */
  observe: (el: RevealTarget) => void
  /** true once every observed element has revealed (useful for SSR-safe fallbacks) */
  done: Ref<boolean>
}

/**
 * Scroll-reveal — adds a class the first time an element scrolls into view.
 *
 * Server-rendered pages must be readable without JS, so the CONSUMER owns the
 * hidden state: gate the "before" styles behind `html.js` (set that class in a
 * head script) and the content stays visible when JS never runs.
 *
 * Non-reactive by design: it toggles a class rather than a bound prop so a page
 * with 50 revealed elements does not schedule 50 Vue re-renders while scrolling.
 */
export function useReveal(options: RevealOptions = {}): RevealApi {
  const { threshold = 0.12, activeClass = 'is-in' } = options
  const done = ref(false)
  const pending = new Set<Element>()
  let observer: IntersectionObserver | null = null

  const flush = (el: Element) => {
    el.classList.add(activeClass)
    pending.delete(el)
    if (pending.size === 0) done.value = true
  }

  onMounted(() => {
    if (typeof IntersectionObserver === 'undefined') {
      for (const el of [...pending]) flush(el)
      return
    }
    observer = new IntersectionObserver(
      (entries) => {
        for (const entry of entries) {
          if (!entry.isIntersecting) continue
          observer?.unobserve(entry.target)
          flush(entry.target)
        }
      },
      { threshold },
    )
    for (const el of pending) observer.observe(el)
  })

  onBeforeUnmount(() => {
    observer?.disconnect()
    observer = null
    pending.clear()
  })

  return {
    observe(target) {
      const el = target instanceof Element ? target : ((target?.$el as Element | undefined) ?? null)
      if (!el || el.classList.contains(activeClass)) return
      pending.add(el)
      done.value = false
      observer?.observe(el)
    },
    done,
  }
}
