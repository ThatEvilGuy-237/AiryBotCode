import { ref } from 'vue'

/**
 * useToast — app-wide transient notifications. Module-scoped state so any
 * component can push and the single <ToastHost> renders them.
 *
 *   const toast = useToast()
 *   toast.success('Saved')
 *   toast.error('Could not save')
 */
export type ToastTone = 'info' | 'success' | 'error' | 'warn'

export interface ToastAction {
  label: string
  run: () => void | Promise<void>
}
export interface Toast {
  id: number
  tone: ToastTone
  message: string
  action?: ToastAction
}

const toasts = ref<Toast[]>([])
let seq = 0

function push(message: string, tone: ToastTone = 'info', timeout = 4000, action?: ToastAction): number {
  const id = ++seq
  toasts.value = [...toasts.value, { id, tone, message, action }]
  if (timeout > 0) setTimeout(() => dismiss(id), timeout)
  return id
}

function dismiss(id: number) {
  toasts.value = toasts.value.filter(t => t.id !== id)
}

export function useToast() {
  return {
    toasts,
    push,
    dismiss,
    info:    (m: string, timeout?: number) => push(m, 'info', timeout),
    success: (m: string, timeout?: number) => push(m, 'success', timeout),
    warn:    (m: string, timeout?: number) => push(m, 'warn', timeout),
    error:   (m: string, timeout?: number) => push(m, 'error', timeout ?? 6000),
    action:  (m: string, action: ToastAction, tone: ToastTone = 'info', timeout = 6000) => push(m, tone, timeout, action),
  }
}
