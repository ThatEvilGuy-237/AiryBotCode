import { onBeforeUnmount, onMounted, ref } from 'vue'

export type AppUpdateOptions = {
  current: string
  url: string
  read?: (body: unknown) => string | undefined
  every?: number
  keepCaches?: string[]
}

const readId = (body: unknown) => {
  const b = body as { id?: string; build?: string } | null
  return b?.id ?? b?.build
}

export function useAppUpdate(options: AppUpdateOptions) {
  const available = ref(false)
  const updating = ref(false)
  let timer: ReturnType<typeof setInterval> | undefined

  async function check() {
    if (available.value || !options.current) return
    try {
      const r = await fetch(`${options.url}${options.url.includes('?') ? '&' : '?'}t=${Date.now()}`, { cache: 'no-store' })
      if (!r.ok) return
      const latest = (options.read ?? readId)(await r.json())
      if (latest && latest !== options.current) available.value = true
    } catch {
      return
    }
  }

  async function update() {
    updating.value = true
    try {
      const reg = await navigator.serviceWorker?.getRegistration()
      await reg?.update()
      if ('caches' in window) {
        const keys = await caches.keys()
        await Promise.all(keys.filter((k) => !(options.keepCaches ?? []).includes(k)).map((k) => caches.delete(k)))
      }
    } finally {
      location.reload()
    }
  }

  const onVisible = () => {
    if (document.visibilityState === 'visible') check()
  }

  onMounted(() => {
    check()
    timer = setInterval(check, options.every ?? 5 * 60 * 1000)
    document.addEventListener('visibilitychange', onVisible)
  })
  onBeforeUnmount(() => {
    clearInterval(timer)
    document.removeEventListener('visibilitychange', onVisible)
  })

  return { available, updating, update, check }
}
