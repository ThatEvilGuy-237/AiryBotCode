import { computed, ref } from 'vue'

type PromptEvent = Event & { prompt: () => Promise<void>; userChoice: Promise<{ outcome: 'accepted' | 'dismissed' }> }

const deferred = ref<PromptEvent | null>(null)
const installed = ref(false)
let wired = false

function wire() {
  if (wired || typeof window === 'undefined') return
  wired = true
  installed.value = window.matchMedia?.('(display-mode: standalone)').matches || (navigator as Navigator & { standalone?: boolean }).standalone === true
  window.addEventListener('beforeinstallprompt', (e) => {
    e.preventDefault()
    deferred.value = e as PromptEvent
  })
  window.addEventListener('appinstalled', () => {
    installed.value = true
    deferred.value = null
  })
}

export function useInstallPrompt() {
  wire()
  const canInstall = computed(() => !!deferred.value && !installed.value)

  async function install() {
    const e = deferred.value
    if (!e) return false
    await e.prompt()
    const { outcome } = await e.userChoice
    deferred.value = null
    return outcome === 'accepted'
  }

  return { canInstall, installed, install }
}
