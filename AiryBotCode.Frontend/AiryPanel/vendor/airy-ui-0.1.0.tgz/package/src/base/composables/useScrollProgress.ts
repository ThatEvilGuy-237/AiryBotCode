import { onBeforeUnmount, onMounted, ref, type Ref } from 'vue'

export interface ScrollProgressOptions {
  /**
   * How far the visitor must scroll for progress to reach 1. A number is
   * pixels; the default is one viewport height, re-measured on resize.
   */
  range?: number | (() => number)
}

export interface ScrollProgress {
  /** 0 → 1, clamped */
  progress: Ref<number>
  /** convenience: progress past a threshold (default 0.85) */
  past: (threshold?: number) => boolean
}

/**
 * Scroll position as a 0→1 number, for effects that must run in BOTH
 * directions.
 *
 * Drive the effect from the value as a CSS `calc()` on a custom property
 * (`width: calc(100vw * (1 - var(--p)) + 280px * var(--p))`) rather than
 * swapping classes at breakpoints: the result is continuous, reverses exactly,
 * and never snaps if the visitor stops mid-scroll.
 *
 * Reads are rAF-throttled and the listener is passive, so scrolling is never
 * blocked.
 */
export function useScrollProgress(options: ScrollProgressOptions = {}): ScrollProgress {
  const { range } = options
  const progress = ref(0)
  let frame = 0

  const measure = () => {
    if (typeof range === 'function') return Math.max(1, range())
    if (typeof range === 'number') return Math.max(1, range)
    return Math.max(1, window.innerHeight)
  }

  const read = () => {
    cancelAnimationFrame(frame)
    frame = requestAnimationFrame(() => {
      progress.value = Math.min(1, Math.max(0, window.scrollY / measure()))
    })
  }

  onMounted(() => {
    read()
    window.addEventListener('scroll', read, { passive: true })
    window.addEventListener('resize', read)
  })

  onBeforeUnmount(() => {
    cancelAnimationFrame(frame)
    window.removeEventListener('scroll', read)
    window.removeEventListener('resize', read)
  })

  return {
    progress,
    past: (threshold = 0.85) => progress.value > threshold,
  }
}
