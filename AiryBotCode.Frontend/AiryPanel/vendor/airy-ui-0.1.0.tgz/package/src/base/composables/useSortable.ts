import { computed, ref, type Ref } from 'vue'
import type { DragSource, DropTarget } from '../components/FlowCanvas/types'

/**
 * Pointer-based drag-and-sort primitive. Replaces HTML5 DnD for the flow
 * editor — gives us a custom ghost, live placeholder, and uniform touch/mouse
 * behaviour.
 *
 * Single module-scoped state because at most one drag is in flight across
 * the whole app.
 *
 * Lifecycle:
 *   1. Consumer calls `beginDrag(source, originPoint)` from `pointerdown`
 *      once the drag passes the movement threshold.
 *   2. The composable installs window-level `pointermove` + `pointerup`
 *      listeners. `cursor` updates reactively as the pointer moves.
 *   3. The consumer (FlowCanvas) sets `dropIndex` based on where the cursor
 *      falls in the chain.
 *   4. On `pointerup`, listeners fire `onDrop?.(dropIndex)` then clear.
 *
 * Threshold detection (the "is this a click or a drag?" decision) happens
 * in the consumer's `pointermove` handler — `beginDrag` is only called once
 * the consumer has decided.
 */

const THRESHOLD_PX = 5

interface DragContext {
  source: DragSource
  cursorX: number
  cursorY: number
  /** Pointer offset from the source element's top-left when drag began. */
  offsetX: number
  offsetY: number
}

const dragRef = ref<DragContext | null>(null)
const dropIndexRef = ref<number | null>(null)
let onDropCallback: ((dropIndex: number | null) => void) | null = null
let onCancelCallback: (() => void) | null = null

function onPointerMove(e: PointerEvent) {
  if (!dragRef.value) return
  dragRef.value = {
    ...dragRef.value,
    cursorX: e.clientX,
    cursorY: e.clientY,
  }
}

function onPointerUp() {
  const cb = onDropCallback
  const idx = dropIndexRef.value
  cleanup()
  cb?.(idx)
}

function onKeyDown(e: KeyboardEvent) {
  if (e.key === 'Escape') {
    const cb = onCancelCallback
    cleanup()
    cb?.()
  }
}

function cleanup() {
  window.removeEventListener('pointermove', onPointerMove)
  window.removeEventListener('pointerup', onPointerUp)
  window.removeEventListener('keydown', onKeyDown)
  dragRef.value = null
  dropIndexRef.value = null
  onDropCallback = null
  onCancelCallback = null
}

export interface BeginDragOptions {
  /** Where the cursor is when the drag begins (clientX/Y). */
  cursorX: number
  cursorY: number
  /** Bounding rect of the source element — used to position the ghost. */
  sourceRect?: { left: number; top: number }
  /** Called on successful pointerup. dropIndex may be null if cursor was
   *  outside any drop zone. */
  onDrop?: (dropIndex: number | null) => void
  /** Called when the user cancels via Escape. */
  onCancel?: () => void
}

export interface SortableApi {
  /** Module-shared drag context (or null when idle). Reactive. */
  drag: Ref<DragContext | null>
  /** True when a drag is in flight. */
  isDragging: Ref<boolean>
  /** Computed slot index where the dragged item will land. The consumer
   *  (FlowCanvas) writes this based on cursor-vs-slot math. */
  dropIndex: Ref<number | null>
  /** Start a drag. Installs window listeners. Called from the consumer's
   *  pointermove once it has confirmed the movement threshold. */
  beginDrag: (source: DragSource, opts: BeginDragOptions) => void
  /** Setter the consumer uses on pointermove to update where the cursor
   *  currently maps to in the chain. */
  setDropIndex: (idx: number | null) => void
  /** Movement threshold in px before a click becomes a drag. */
  THRESHOLD_PX: number
}

export function useSortable(): SortableApi {
  return {
    drag: dragRef,
    isDragging: computed(() => dragRef.value !== null),
    dropIndex: dropIndexRef,
    beginDrag(source, opts) {
      const rect = opts.sourceRect
      dragRef.value = {
        source,
        cursorX: opts.cursorX,
        cursorY: opts.cursorY,
        offsetX: rect ? opts.cursorX - rect.left : 0,
        offsetY: rect ? opts.cursorY - rect.top  : 0,
      }
      dropIndexRef.value = null
      onDropCallback   = opts.onDrop   ?? null
      onCancelCallback = opts.onCancel ?? null
      window.addEventListener('pointermove', onPointerMove, { passive: true })
      window.addEventListener('pointerup',   onPointerUp,   { passive: true })
      window.addEventListener('keydown',     onKeyDown)
    },
    setDropIndex(idx) {
      dropIndexRef.value = idx
    },
    THRESHOLD_PX,
  }
}

/** Returns true if (x, y) has moved at least THRESHOLD_PX from (origX, origY). */
export function exceedsThreshold(x: number, y: number, origX: number, origY: number): boolean {
  const dx = x - origX
  const dy = y - origY
  return dx * dx + dy * dy >= THRESHOLD_PX * THRESHOLD_PX
}

// Re-export types for convenience
export type { DragSource, DropTarget }
