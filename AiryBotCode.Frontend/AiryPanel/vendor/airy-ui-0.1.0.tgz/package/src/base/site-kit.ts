/**
 * @hive/ui/site — the SITE kit.
 *
 * The core barrel (`@hive/ui`) is a dense platform/dashboard kit. This entry is
 * the long-form counterpart: content-driven, full-width, scroll-revealed
 * components for portfolios, marketing pages and docs sites.
 *
 * It is a separate subpath (like `/portal`) so its Section/MediaCard/… never
 * collide with the canonical component names.
 *
 * Consumers must load the site-layer tokens once:
 *   import '@hive/ui/site-tokens.css'
 * Those tokens default off theme.css but can be driven from any identity — see
 * SITE-KIT.md for the bridge pattern.
 */
export { default as Section } from './site/Section/Section.vue'
export { default as SectionHeading } from './site/SectionHeading/SectionHeading.vue'
export { default as TagList } from './site/TagList/TagList.vue'
export type { TagItem } from './site/TagList/TagList.vue'
export { default as MediaCard } from './site/MediaCard/MediaCard.vue'
export { default as ActionButton } from './site/ActionButton/ActionButton.vue'
export { default as TabBar } from './site/TabBar/TabBar.vue'
export { default as SlideOver } from './site/SlideOver/SlideOver.vue'
export { default as Lightbox } from './site/Lightbox/Lightbox.vue'
export { default as DefinitionGrid } from './site/DefinitionGrid/DefinitionGrid.vue'
export type { DefinitionItem } from './site/DefinitionGrid/DefinitionGrid.vue'
export { default as Timeline } from './site/Timeline/Timeline.vue'
export { default as TimelineEntry } from './site/Timeline/TimelineEntry.vue'
export { default as Hero } from './site/Hero/Hero.vue'
export { default as FeatureGrid } from './site/FeatureGrid/FeatureGrid.vue'
export type { FeatureItem } from './site/FeatureGrid/FeatureGrid.vue'
export { default as PricingTable } from './site/PricingTable/PricingTable.vue'
export type { PricingPlan } from './site/PricingTable/PricingTable.vue'
export { default as Testimonial } from './site/Testimonial/Testimonial.vue'
export { default as SiteFooter } from './site/SiteFooter/SiteFooter.vue'
export type { FooterColumn, FooterLink } from './site/SiteFooter/SiteFooter.vue'
export { default as ContactBlock } from './site/ContactBlock/ContactBlock.vue'
export type { ContactMethod } from './site/ContactBlock/ContactBlock.vue'
export { default as StatsBand } from './site/StatsBand/StatsBand.vue'
export type { StatItem } from './site/StatsBand/StatsBand.vue'
export { default as LogoStrip } from './site/LogoStrip/LogoStrip.vue'
export type { LogoItem } from './site/LogoStrip/LogoStrip.vue'
export { default as Faq } from './site/Faq/Faq.vue'
export type { FaqItem } from './site/Faq/Faq.vue'

/**
 * The icon vocabulary is shared with the core kit rather than forked: one set of
 * names, one bundle. Re-exported here so a site consumer never has to import
 * from two entry points to draw an arrow.
 *
 * Use these instead of literal glyphs (★ ↗ ✕ 🎲). A site that self-hosts a
 * SUBSET webfont — which is the right call for performance — will not have those
 * codepoints, and they render as tofu boxes.
 */
export { default as Icon } from './components/Icon/Icon.vue'
export { iconNames } from './components/Icon/icons'
export type { IconName } from './components/Icon/icons'
export type { TabBarItem } from './site/TabBar/TabBar.vue'

export { useReveal } from './composables/useReveal'
export type { RevealApi, RevealOptions, RevealTarget } from './composables/useReveal'

export { useDialog } from './composables/useDialog'
export type { DialogOptions } from './composables/useDialog'

export { useScrollProgress } from './composables/useScrollProgress'
export type { ScrollProgress, ScrollProgressOptions } from './composables/useScrollProgress'
