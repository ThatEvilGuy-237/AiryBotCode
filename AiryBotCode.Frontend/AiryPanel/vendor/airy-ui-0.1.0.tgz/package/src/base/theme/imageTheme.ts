// Image → full-page theme.
//
// Derives a coherent @hive/ui theme from an image and applies it by setting a
// handful of CSS custom properties on a target element (default :root). Because
// every component reads the derived --color-* tokens (see theme.css), the WHOLE
// surface re-themes — accent, surfaces, borders, text — not just one hue. The
// accent is taken from the image's most vivid colour at its real lightness +
// chroma; the dark surfaces tint toward the image's dominant hue, with strength
// scaled to how saturated the image is. Semantic colours (ok/warn/danger) keep
// their fixed meaning and are intentionally left alone.
//
// Pure client-side, zero dependencies (Canvas + a little OKLab maths).

export interface DerivedTheme {
  accentHue: number;    // → --accent-hue (deg)
  accentL: number;      // → --accent-l   (oklch lightness 0..1)
  accentC: number;      // → --accent-c   (oklch chroma)
  baseHue: number;      // → --base-hue   (deg)
  baseChroma: number;   // → --base-chroma (tint-strength multiplier)
}

const DEFAULT_THEME: DerivedTheme = { accentHue: 287, accentL: 0.66, accentC: 0.17, baseHue: 285, baseChroma: 1 };

function srgbToLinear(c: number): number {
  c /= 255;
  return c <= 0.04045 ? c / 12.92 : Math.pow((c + 0.055) / 1.055, 2.4);
}

/** sRGB (0..255) → OKLCH { L: 0..1, C: ~0..0.4, H: 0..360 }. */
export function rgbToOklch(r: number, g: number, b: number): { L: number; C: number; H: number } {
  const lr = srgbToLinear(r), lg = srgbToLinear(g), lb = srgbToLinear(b);
  const l = 0.4122214708 * lr + 0.5363325363 * lg + 0.0514459929 * lb;
  const m = 0.2119034982 * lr + 0.6806995451 * lg + 0.1073969566 * lb;
  const s = 0.0883024619 * lr + 0.2817188376 * lg + 0.6299787005 * lb;
  const l_ = Math.cbrt(l), m_ = Math.cbrt(m), s_ = Math.cbrt(s);
  const L = 0.2104542553 * l_ + 0.7936177850 * m_ - 0.0040720468 * s_;
  const a = 1.9779984951 * l_ - 2.4285922050 * m_ + 0.4505937099 * s_;
  const bb = 0.0259040371 * l_ + 0.7827717662 * m_ - 0.8086757660 * s_;
  const C = Math.sqrt(a * a + bb * bb);
  let H = (Math.atan2(bb, a) * 180) / Math.PI;
  if (H < 0) H += 360;
  return { L, C, H };
}

const round = (n: number, p = 3) => Math.round(n * 10 ** p) / 10 ** p;
const clamp = (n: number, lo: number, hi: number) => Math.min(hi, Math.max(lo, n));

/** Derive a theme from a *loaded* image element (downsamples it to read pixels). */
export function deriveThemeFromImage(img: HTMLImageElement, sample = 48): DerivedTheme {
  const cv = document.createElement("canvas");
  cv.width = sample; cv.height = sample;
  const ctx = cv.getContext("2d", { willReadFrequently: true });
  if (!ctx) return { ...DEFAULT_THEME };
  try { ctx.drawImage(img, 0, 0, sample, sample); } catch { return { ...DEFAULT_THEME }; }

  let data: Uint8ClampedArray;
  try { data = ctx.getImageData(0, 0, sample, sample).data; }
  catch { return { ...DEFAULT_THEME }; }   // tainted canvas (cross-origin) → default

  let best = { C: -1, L: 0.66, H: 287 };   // most-vivid usable pixel → accent
  let hx = 0, hy = 0, cSum = 0, cCount = 0; // chroma-weighted circular mean → base hue + tint
  for (let i = 0; i < data.length; i += 4) {
    if (data[i + 3] < 128) continue;        // skip transparent
    const { L, C, H } = rgbToOklch(data[i], data[i + 1], data[i + 2]);
    if (C > best.C && L > 0.45 && L < 0.85) best = { C, L, H };   // vivid + usable lightness
    if (C > 0.02) {                          // only saturated pixels vote on the base tint
      const rad = (H * Math.PI) / 180;
      hx += Math.cos(rad) * C; hy += Math.sin(rad) * C; cSum += C; cCount++;
    }
  }

  const baseHue = cCount ? (((Math.atan2(hy, hx) * 180) / Math.PI) + 360) % 360 : DEFAULT_THEME.baseHue;
  const avgC = cCount ? cSum / cCount : 0.05;
  return {
    accentHue: round(best.C >= 0 ? best.H : DEFAULT_THEME.accentHue, 1),
    accentL: round(clamp(best.L, 0.58, 0.78)),     // keep it readable as an accent
    accentC: round(clamp(best.C, 0.10, 0.20)),     // vivid but not neon
    baseHue: round(baseHue, 1),
    baseChroma: round(clamp(avgC * 12, 0.4, 1.8), 2),  // saturated image → stronger surface tint
  };
}

const THEME_VARS: Record<keyof DerivedTheme, string> = {
  accentHue: "--accent-hue", accentL: "--accent-l", accentC: "--accent-c",
  baseHue: "--base-hue", baseChroma: "--base-chroma",
};

/** Apply a derived theme by setting the CSS custom properties. */
export function applyTheme(theme: DerivedTheme, el: HTMLElement = document.documentElement): void {
  (Object.keys(THEME_VARS) as (keyof DerivedTheme)[]).forEach(k => el.style.setProperty(THEME_VARS[k], String(theme[k])));
}

/** Clear an applied theme (revert to the stylesheet defaults). */
export function clearTheme(el: HTMLElement = document.documentElement): void {
  Object.values(THEME_VARS).forEach(v => el.style.removeProperty(v));
}

function loadImage(src: string): Promise<HTMLImageElement> {
  return new Promise((resolve, reject) => {
    const img = new Image();
    img.crossOrigin = "anonymous";   // best-effort, so getImageData isn't tainted for remote images
    img.onload = () => resolve(img);
    img.onerror = () => reject(new Error(`failed to load image: ${src}`));
    img.src = src;
  });
}

/** Convenience: load an image URL / data-URL, derive its theme, apply it, and return it. */
export async function applyThemeFromImageSrc(src: string, el?: HTMLElement): Promise<DerivedTheme> {
  const img = await loadImage(src);
  const theme = deriveThemeFromImage(img);
  applyTheme(theme, el);
  return theme;
}

export { DEFAULT_THEME };
