<script setup lang="ts">
withDefaults(defineProps<{
  modelValue: string
  label?: string
  placeholder?: string
  type?: 'text' | 'password' | 'email' | 'url' | 'date'
  autocomplete?: string
  disabled?: boolean
}>(), { type: 'text', disabled: false })

defineEmits<{ 'update:modelValue': [value: string] }>()
</script>

<template>
  <div data-ui="textfield" :class="$style.wrapper">
    <label v-if="label" :class="$style.label">{{ label }}</label>
    <input
      :type="type"
      :autocomplete="autocomplete"
      :disabled="disabled"
      :class="$style.input"
      :value="modelValue"
      :placeholder="placeholder"
      @input="$emit('update:modelValue', ($event.target as HTMLInputElement).value)"
    />
  </div>
</template>

<style module>
.wrapper { display: flex; flex-direction: column; gap: var(--space-1); }
.label { font-size: var(--font-size-sm); color: var(--color-muted); }
.input {
  border: var(--border);
  border-radius: var(--radius);
  padding: var(--space-2) var(--space-3);
  min-height: var(--input-h, auto);
  font-size: var(--font-size-base);
  background: var(--color-surface-mute, var(--color-bg));
  color: var(--color-fg);
  width: 100%;
  font-family: var(--font-family);
}
.input:disabled { opacity: .6; cursor: not-allowed; }
.input:focus {
  outline: 2px solid var(--color-accent, var(--color-fg));
  outline-offset: 1px;
  border-color: var(--color-accent, var(--color-border));
}
</style>
