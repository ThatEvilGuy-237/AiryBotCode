<script setup lang="ts">
/**
 * ToastHost — renders the toast stack from useToast(). Mount once near the app
 * root (it teleports to <body>). Click a toast to dismiss it early; a toast with an
 * action (useToast().action) shows one button, for example Undo.
 *
 * Status: new
 */
import { useToast } from '../../composables/useToast'

const { toasts, dismiss } = useToast()

async function act(id: number, run: () => void | Promise<void>) {
  dismiss(id)
  await run()
}
</script>

<template>
  <Teleport to="body">
    <div data-ui="toast-host" :class="$style.host">
      <div
        v-for="t in toasts"
        :key="t.id"
        data-ui="toast"
        :class="[$style.toast, $style[t.tone]]"
        role="status"
        @click="dismiss(t.id)"
      >
        <span :class="$style.message">{{ t.message }}</span>
        <button
          v-if="t.action"
          type="button"
          data-ui="toast-action"
          :class="$style.action"
          @click.stop="act(t.id, t.action.run)"
        >{{ t.action.label }}</button>
      </div>
    </div>
  </Teleport>
</template>

<style module>
.host { position: fixed; bottom: var(--space-4); right: var(--space-4); display: flex; flex-direction: column; gap: var(--space-2); z-index: 200; max-width: 360px; }
.toast { display: flex; align-items: center; gap: var(--space-3); padding: var(--space-3) var(--space-4); border-radius: var(--radius); background: var(--color-surface); border: var(--border); border-left-width: 3px; color: var(--color-fg); font-size: var(--font-size-sm); box-shadow: 0 8px 24px rgba(0,0,0,0.3); cursor: pointer; }
.message { flex: 1; min-width: 0; }
.action { flex: none; min-height: var(--tap, 36px); padding: 0 var(--space-3); border: var(--border); border-radius: var(--r-2); background: transparent; color: var(--color-accent); font: inherit; font-weight: 600; cursor: pointer; }
.action:hover { background: var(--color-surface-hi); }
.action:focus-visible { outline: 2px solid var(--color-accent); outline-offset: 2px; }
.info { border-left-color: var(--color-accent, var(--color-fg)); }
.success { border-left-color: var(--color-ok, #46c489); }
.error { border-left-color: var(--color-danger, #d64b46); }
.warn { border-left-color: var(--color-warn, #e0b24a); }
</style>
