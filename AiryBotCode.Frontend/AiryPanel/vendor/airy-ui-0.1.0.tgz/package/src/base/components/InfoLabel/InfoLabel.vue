<script setup lang="ts">
/**
 * InfoLabel
 * Key: value display row. Use to surface metadata.
 *
 * @prop label - the key (muted)
 * @prop value - the value
 *
 * Status: stable | Consumers: ToolboxesPage
 */
defineProps<{
  label: string
  value: string | number
}>()
</script>

<template>
  <div data-ui="info-label" :class="$style.row">
    <span :class="$style.label">{{ label }}</span>
    <span :class="$style.value">{{ value }}</span>
  </div>
</template>

<style module>
.row { display: flex; align-items: baseline; gap: var(--space-2); }
.label { color: var(--color-muted); font-size: var(--font-size-sm); font-family: var(--font-mono); flex-shrink: 0; }
.value { color: var(--color-fg); font-family: var(--font-mono); font-size: var(--font-size-sm); }
</style>
