<script setup lang="ts">
/**
 * LoadingState — centred spinner + label. Drop-in for "Loading…" text blocks.
 *
 * @prop label
 *
 * Status: new
 */
import Spinner from '../Spinner/Spinner.vue'

withDefaults(defineProps<{ label?: string }>(), { label: 'Loading…' })
</script>

<template>
  <div data-ui="loading-state" :class="$style.wrap">
    <Spinner :size="22" />
    <span :class="$style.label">{{ label }}</span>
  </div>
</template>

<style module>
.wrap { display: flex; flex-direction: column; align-items: center; justify-content: center; gap: var(--space-3); padding: var(--space-6); color: var(--color-text-dim, var(--color-muted)); }
.label { font-size: var(--font-size-sm); }
</style>
