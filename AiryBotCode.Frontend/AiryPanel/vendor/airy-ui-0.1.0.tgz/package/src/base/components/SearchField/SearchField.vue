<script setup lang="ts">
/**
 * SearchField — search input with a leading icon and a clear button. v-model.
 *
 * @prop modelValue / placeholder / size (sm | md | lg; lg is the 48 px touch size)
 * @prop label - accessible name of the input (defaults to the placeholder)
 * @prop inputAttrs - extra attributes for the input itself (role="combobox", aria-expanded, aria-controls, aria-activedescendant)
 * @expose focus() - puts the caret back in the input
 * @event update:modelValue / clear
 *
 * Status: new
 */
import { ref } from 'vue'
import Icon from '../Icon/Icon.vue'

withDefaults(defineProps<{
  modelValue: string
  placeholder?: string
  label?: string
  size?: 'sm' | 'md' | 'lg'
  inputAttrs?: Record<string, string | number | boolean | undefined>
}>(), { placeholder: 'Search…', size: 'md' })

const emit = defineEmits<{ 'update:modelValue': [v: string]; clear: [] }>()
const input = ref<HTMLInputElement | null>(null)

function clear() { emit('update:modelValue', ''); emit('clear') }
function focus() { input.value?.focus() }
defineExpose({ focus })
</script>

<template>
  <div data-ui="search-field" :class="[$style.wrap, $style[size]]">
    <Icon name="search" :size="15" :class="$style.icon" />
    <input
      ref="input"
      v-bind="inputAttrs"
      :class="$style.input"
      type="search"
      :value="modelValue"
      :placeholder="placeholder"
      :aria-label="label ?? placeholder"
      @input="emit('update:modelValue', ($event.target as HTMLInputElement).value)"
    />
    <button v-if="modelValue" type="button" :class="$style.clear" aria-label="Clear" @click="clear"><Icon name="x" :size="14" /></button>
  </div>
</template>

<style module>
.wrap { position: relative; display: inline-flex; align-items: center; width: 100%; }
.icon { position: absolute; left: 10px; color: var(--color-muted); pointer-events: none; }
.input { width: 100%; background: var(--color-bg); color: var(--color-fg); border: 1px solid var(--color-border); border-radius: var(--radius); padding: 0 28px 0 32px; font-family: var(--font-family); }
.sm .input { height: 28px; font-size: var(--font-size-sm); }
.md .input { height: 34px; font-size: var(--font-size-base); }
.lg .input { height: 48px; font-size: 16px; padding: 0 48px 0 40px; }
.lg .icon { left: 14px; }
.lg .clear { right: 2px; width: 44px; height: 44px; display: inline-flex; align-items: center; justify-content: center; border-radius: var(--radius); }
.clear:focus-visible { outline: 2px solid var(--color-accent); outline-offset: 1px; }
.input:focus { outline: none; border-color: var(--color-accent, var(--color-border)); }
.input::-webkit-search-cancel-button { display: none; }
.clear { position: absolute; right: 8px; background: none; border: 0; color: var(--color-muted); cursor: pointer; font-size: 16px; line-height: 1; }
.clear:hover { color: var(--color-fg); }
</style>
