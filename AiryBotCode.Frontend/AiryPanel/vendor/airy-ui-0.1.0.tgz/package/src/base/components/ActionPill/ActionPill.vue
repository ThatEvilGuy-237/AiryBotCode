<script setup lang="ts">
import Icon from '../Icon/Icon.vue'
import type { IconName } from '../Icon/icons'

defineProps<{ label: string; icon?: IconName; busy?: boolean; busyLabel?: string; dismissLabel?: string }>()
defineEmits<{ click: []; dismiss: [] }>()
</script>

<template>
  <div data-ui="action-pill" :class="$style.pill">
    <button type="button" :class="$style.main" :disabled="busy" @click="$emit('click')">
      <Icon v-if="busy" name="loader" :size="16" :class="$style.spin" />
      <Icon v-else-if="icon" :name="icon" :size="16" />
      <span>{{ busy && busyLabel ? busyLabel : label }}</span>
    </button>
    <button v-if="dismissLabel && !busy" type="button" :class="$style.close" :aria-label="dismissLabel" @click="$emit('dismiss')">
      <Icon name="x" :size="16" />
    </button>
  </div>
</template>

<style module>
.pill { display: inline-flex; align-items: stretch; border-radius: 999px; border: 1px solid var(--color-accent-edge, var(--color-accent)); background: var(--action-pill-bg, var(--color-surface)); color: var(--color-accent); box-shadow: var(--action-pill-shadow, none); overflow: hidden; }
.main { display: inline-flex; align-items: center; gap: 8px; min-height: var(--action-pill-h, 36px); padding: 0 16px; background: transparent; border: 0; color: inherit; font-family: var(--font-family); font-size: var(--font-size-sm); font-weight: 600; cursor: pointer; }
.main:disabled { cursor: progress; }
.close { display: inline-grid; place-items: center; min-width: var(--action-pill-h, 36px); padding: 0; border: 0; border-left: 1px solid var(--color-accent-edge, var(--color-accent)); background: transparent; color: inherit; cursor: pointer; }
.main:hover, .close:hover { background: var(--color-accent-soft, transparent); }
.main:focus-visible, .close:focus-visible { outline: 2px solid var(--color-accent); outline-offset: -3px; border-radius: 999px; }
.spin { animation: spin 1s linear infinite; }
@keyframes spin { to { transform: rotate(360deg); } }
@media (prefers-reduced-motion: reduce) { .spin { animation: none; } }
</style>
