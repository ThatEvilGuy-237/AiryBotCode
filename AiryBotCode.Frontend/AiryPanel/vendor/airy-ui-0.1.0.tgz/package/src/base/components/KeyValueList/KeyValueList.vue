<script setup lang="ts">
/**
 * KeyValueList — tidy label→value rows (a description list). Pass `items` or use
 * the default slot for custom rows. Replaces hand-rolled .kv grids.
 *
 * @prop items - { label, value }[]
 *
 * Status: new
 */
export interface KeyValueItem { label: string; value?: string | number | null }

withDefaults(defineProps<{ items?: KeyValueItem[] }>(), { items: () => [] })
</script>

<template>
  <dl data-ui="key-value-list" :class="$style.list">
    <template v-for="(it, i) in items" :key="i">
      <dt :class="$style.k">{{ it.label }}</dt>
      <dd :class="$style.v">{{ it.value ?? '—' }}</dd>
    </template>
    <slot />
  </dl>
</template>

<style module>
.list { display: grid; grid-template-columns: max-content 1fr; gap: 4px var(--space-3); margin: 0; align-items: baseline; }
.k { font-family: var(--kv-key-font, var(--font-mono)); font-size: var(--kv-key-size, var(--font-size-xs)); color: var(--color-muted); }
.v { font-size: var(--font-size-sm); color: var(--color-fg); margin: 0; word-break: break-word; }
</style>
