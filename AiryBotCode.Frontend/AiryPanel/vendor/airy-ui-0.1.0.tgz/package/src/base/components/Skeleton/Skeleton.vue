<script setup lang="ts">
/**
 * Skeleton — a shimmering placeholder shown while content loads.
 *
 * @prop variant - text (a line, or `lines` of them) | block | circle
 * @prop width   - CSS width (default: 100%, or the circle diameter)
 * @prop height  - CSS height (block/circle; text derives from line-height)
 * @prop lines   - number of text lines (text variant); last line is shorter
 * @prop radius  - CSS border-radius override
 *
 * Status: new
 */
withDefaults(defineProps<{
  variant?: 'text' | 'block' | 'circle'
  width?: string
  height?: string
  lines?: number
  radius?: string
}>(), { variant: 'text', lines: 1 })
</script>

<template>
  <!-- text: one or more shimmering lines -->
  <div v-if="variant === 'text'" data-ui="skeleton" :class="$style.stack" role="status" aria-label="Loading">
    <span
      v-for="n in lines"
      :key="n"
      :class="[$style.sk, $style.line]"
      :style="{ width: n === lines && lines > 1 ? '62%' : (width ?? '100%'), borderRadius: radius }"
    />
  </div>

  <!-- circle: avatars / icons -->
  <span
    v-else-if="variant === 'circle'"
    :class="[$style.sk, $style.circle]"
    :style="{ width: width ?? '40px', height: height ?? width ?? '40px' }"
    role="status"
    aria-label="Loading"
  />

  <!-- block: cards / media -->
  <span
    v-else
    :class="[$style.sk, $style.block]"
    :style="{ width: width ?? '100%', height: height ?? '80px', borderRadius: radius }"
    role="status"
    aria-label="Loading"
  />
</template>

<style module>
.stack { display: flex; flex-direction: column; gap: 8px; }

.sk {
  display: block;
  position: relative;
  overflow: hidden;
  background: var(--color-surface-mute, var(--color-surface));
}
/* The shimmer sweep */
.sk::after {
  content: '';
  position: absolute;
  inset: 0;
  transform: translateX(-100%);
  background: linear-gradient(
    90deg,
    transparent,
    var(--color-surface-hi, var(--color-surface)),
    transparent
  );
  animation: sk-shimmer 1.3s ease-in-out infinite;
}

.line { height: 0.72em; border-radius: 5px; }
.block { border-radius: var(--radius, 8px); }
.circle { border-radius: 50%; flex-shrink: 0; }

@keyframes sk-shimmer { 100% { transform: translateX(100%); } }
@media (prefers-reduced-motion: reduce) {
  .sk::after { animation: none; opacity: 0.5; }
}
</style>
