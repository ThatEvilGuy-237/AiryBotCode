import type { FlowNodeData } from '../FlowNode/FlowNode.vue'

/**
 * Flow shape this module needs. Loose enough that it matches Spine's
 * FlowDetailDto without importing it (Aether-Sight is consumer-agnostic).
 */
export interface ControlEdge {
  id: string
  fromNodeId: string
  toNodeId: string
  fromPort: string | null
}

export interface FlowGraph {
  nodes: FlowNodeData[]
  controlEdges: ControlEdge[]
}

export type ChainItem =
  | { kind: 'node'; key: string; node: FlowNodeData; orphan?: boolean; branchCount?: number }
  | { kind: 'edge'; key: string; port: string | null }

/**
 * Walks the flow's control graph and produces an interleaved
 * [node, edge, node, edge, ...] sequence suitable for rendering as a
 * horizontal chain.
 *
 * Rules (v1, linear only):
 *   - Start from the node with no incoming control edges.
 *   - At each step, follow the FIRST outgoing edge. If a node has multiple
 *     outgoing edges, the picked node is annotated with branchCount > 0 so
 *     the renderer can show a "+N more paths" hint.
 *   - Stop on cycles (already-seen node).
 *   - Append any nodes never visited at the end, marked orphan.
 */
export function linearize(flow: FlowGraph): ChainItem[] {
  const byId = new Map(flow.nodes.map(n => [n.id, n]))
  const outgoing = new Map<string, ControlEdge[]>()
  for (const e of flow.controlEdges) {
    const list = outgoing.get(e.fromNodeId)
    if (list) list.push(e)
    else outgoing.set(e.fromNodeId, [e])
  }

  const incoming = new Set(flow.controlEdges.map(e => e.toNodeId))
  const root = flow.nodes.find(n => !incoming.has(n.id))

  const out: ChainItem[] = []
  const seen = new Set<string>()

  let current = root
  while (current && !seen.has(current.id)) {
    seen.add(current.id)
    const outs = outgoing.get(current.id) ?? []
    out.push({
      kind: 'node',
      key: current.id,
      node: current,
      branchCount: outs.length > 1 ? outs.length - 1 : 0,
    })

    if (outs.length === 0) break
    const next = outs[0]
    out.push({ kind: 'edge', key: next.id, port: next.fromPort })
    current = byId.get(next.toNodeId)
  }

  // Any nodes never reached get appended visibly so broken graphs surface
  // instead of disappearing silently.
  for (const n of flow.nodes) {
    if (!seen.has(n.id)) out.push({ kind: 'node', key: n.id, node: n, orphan: true })
  }

  return out
}
