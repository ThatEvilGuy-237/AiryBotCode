<script setup lang="ts">
/**
 * Chart · line design
 * Trend over time. 2px strokes, a dash pattern per slot so the series stay apart
 * without a second hue, an end marker per series and a value label at the end —
 * dropped automatically when the ends converge, because nudged-apart labels lie
 * about which line they belong to.
 *
 * @prop ctx    - plot context handed down by Chart.vue
 * @prop active - hovered/focused point index, or null
 *
 * Status: new | Consumers: Chart
 */
import { computed } from 'vue'
import { bandPath, linePath, markPath } from '../geometry'
import type { ChartPlotCtx } from '../types'

const props = defineProps<{ ctx: ChartPlotCtx, active: number | null }>()

defineEmits<{ active: [index: number | null], point: [index: number, seriesIndex: number] }>()

const MARK = 8
const LABEL_GAP = 15

interface Drawn {
  name: string
  quiet: boolean
  band: string
  color: string
  dash: string
  shape: string
  path: string
  lone: { x: number, y: number } | null
  end: { x: number, y: number, text: string } | null
  activePoint: { x: number, y: number } | null
}

const drawn = computed<Drawn[]>(() => props.ctx.series.map((entry) => {
  const scale = props.ctx.scale
  const points = entry.values.map((value, index) => (value === null ? null : { x: scale.x(index), y: scale.y(value) }))
  const present = points.filter((point): point is { x: number, y: number } => point !== null)
  const lastIndex = entry.values.reduce<number>((found, value, index) => (value === null ? found : index), -1)
  const activeValue = props.active === null ? null : entry.values[props.active] ?? null
  const upper = entry.band ? entry.band.map((value, index) => (value === null || entry.values[index] === null ? null : { x: scale.x(index), y: scale.y(Math.max(value, entry.values[index]!)) })) : []
  return {
    name: entry.name,
    quiet: entry.quiet,
    band: entry.band ? bandPath(upper, points) : '',
    color: entry.color,
    dash: entry.dash,
    shape: entry.shape,
    path: linePath(points),
    lone: present.length === 1 ? present[0]! : null,
    end: lastIndex >= 0 && !props.ctx.sparkline && !entry.quiet
      ? { x: scale.x(lastIndex), y: scale.y(entry.values[lastIndex]!), text: props.ctx.fmt(entry.values[lastIndex]!) }
      : null,
    activePoint: activeValue === null ? null : { x: scale.x(props.active!), y: scale.y(activeValue) },
  }
}))

const endLabels = computed(() => {
  const ends = drawn.value.map(entry => entry.end).filter((end): end is { x: number, y: number, text: string } => end !== null)
  if (!props.ctx.endLabels || !ends.length || props.ctx.scale.plot.w < 150) return []
  const ys = ends.map(end => end.y).sort((a, b) => a - b)
  for (let index = 1; index < ys.length; index += 1) {
    if (ys[index]! - ys[index - 1]! < LABEL_GAP) return []
  }
  return ends
})
</script>

<template>
  <g :class="$style.marks">
    <g v-for="entry in drawn" :key="entry.name">
      <path v-if="entry.band" :class="$style.band" :d="entry.band" :fill="entry.color" />
      <path
        v-if="entry.path"
        :class="[$style.line, entry.quiet && $style.quiet]"
        :d="entry.path"
        :stroke="entry.color"
        :stroke-dasharray="entry.dash || undefined"
      />
      <line
        v-if="entry.lone"
        :class="$style.line"
        :x1="entry.lone.x - 12"
        :x2="entry.lone.x + 12"
        :y1="entry.lone.y"
        :y2="entry.lone.y"
        :stroke="entry.color"
        :stroke-dasharray="entry.dash || undefined"
      />
      <path
        v-if="entry.end"
        :class="$style.mark"
        :d="markPath(entry.shape, entry.end.x, entry.end.y, MARK)"
        :fill="entry.color"
      />
      <path
        v-if="entry.activePoint"
        :class="[$style.mark, $style.markActive]"
        :d="markPath(entry.shape, entry.activePoint.x, entry.activePoint.y, MARK + 3)"
        :fill="entry.color"
      />
    </g>

    <text
      v-for="label in endLabels"
      :key="`end-${label.text}-${label.y}`"
      :class="$style.endLabel"
      :x="label.x - MARK"
      :y="label.y - 9"
      text-anchor="end"
    >{{ label.text }}</text>
  </g>
</template>

<style module>
.line {
  fill: none;
  stroke-width: 2;
  stroke-linecap: round;
  stroke-linejoin: round;
}
.mark {
  stroke: var(--color-surface);
  stroke-width: 2;
  paint-order: stroke;
}
.markActive { stroke-width: 2.5; }
.quiet { stroke-width: 1; opacity: 0.45; }
.band { stroke: none; opacity: 0.2; }
.endLabel {
  font-family: var(--font-mono);
  font-size: var(--font-size-xs);
  font-variant-numeric: tabular-nums;
  fill: var(--color-text-dim, var(--color-fg));
}

/* The one motion: the series wipe in from the left on mount. */
.marks { animation: draw 420ms ease-out both; }
@keyframes draw {
  from { clip-path: inset(0 100% 0 0); }
  to { clip-path: inset(0 -4% 0 0); }
}
@media (prefers-reduced-motion: reduce) {
  .marks { animation: none; }
}
</style>
