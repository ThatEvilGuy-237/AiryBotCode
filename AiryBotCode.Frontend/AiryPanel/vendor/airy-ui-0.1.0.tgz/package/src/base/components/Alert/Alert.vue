<script setup lang="ts">
/**
 * Alert
 * Inline, in-flow message: "here's what happened" plus, optionally, "here's the fix".
 * A hairline box with a 2px semantic left bar — one colour per severity, no fills,
 * no glow. Title in sans, body prose in sans, any `<code>`/`<kbd>`/`<samp>` inside
 * the body switches to mono automatically, so IDs, ports and commands read as data.
 *
 * It is NOT a toast (that's ToastHost — transient, stacked, out of flow), NOT a
 * confirmation (ConfirmDialog), and NOT a field error (TextField's own error state).
 * If the message can be ignored forever, it's a `sub` line on a Card, not an Alert.
 *
 * @prop variant      - severity: 'info' | 'ok' | 'warn' | 'danger'. Legacy aliases
 *                      'success' | 'warning' | 'error' are accepted and normalised.
 * @prop title        - headline. Often the whole message; body is then optional.
 * @prop sub          - mono `// …` sub-line under the body (the house sub-caption).
 * @prop icon         - override the drawn icon (curated Icon name), or `null` for none.
 * @prop count        - mono `×n` chip next to the title, for a repeated/deduped event.
 * @prop dismissible  - render a close button; also enables Esc while focus is inside.
 * @prop dismissLabel - accessible label for that button.
 * @prop dense        - tighter padding, for alerts inside dialogs and cards.
 * @prop role         - force 'status' or 'alert'. Default derives from severity:
 *                      danger interrupts (role="alert"), everything else is polite.
 * @prop modelValue   - v-model visibility. Uncontrolled use works too: dismissing
 *                      hides it locally and emits, no binding required.
 *
 * Slots:
 *   default - body prose
 *   sub     - rich replacement for the `sub` prop (mono, prefixed with `//`)
 *   actions - the "and here's the fix" row (Button, links)
 *   icon    - replace the drawn glyph entirely
 *
 * Status: new | Consumers: portal-kit (Alert), memory portal pages
 */
import { computed, ref, watch } from 'vue'
import Icon from '../Icon/Icon.vue'
import type { IconName } from '../Icon/icons'

export type AlertVariant = 'info' | 'ok' | 'warn' | 'danger'
export type AlertVariantInput = AlertVariant | 'success' | 'warning' | 'error'

const props = withDefaults(defineProps<{
  variant?: AlertVariantInput
  title?: string
  sub?: string
  icon?: IconName | null
  count?: number
  dismissible?: boolean
  dismissLabel?: string
  dense?: boolean
  role?: 'status' | 'alert'
  modelValue?: boolean
}>(), {
  variant: 'info',
  dismissible: false,
  dismissLabel: 'Dismiss',
  dense: false,
  modelValue: true,
})

const emit = defineEmits<{
  'update:modelValue': [value: boolean]
  dismiss: []
}>()

const ALIASES: Record<AlertVariantInput, AlertVariant> = {
  info: 'info',
  ok: 'ok',
  warn: 'warn',
  danger: 'danger',
  success: 'ok',
  warning: 'warn',
  error: 'danger',
}

const DEFAULT_ICONS: Record<AlertVariant, IconName> = {
  info: 'info',
  ok: 'ok',
  warn: 'warn',
  danger: 'error',
}

const dismissed = ref(false)
watch(() => props.modelValue, (open) => { if (open) dismissed.value = false })

const variantKey = computed<AlertVariant>(() => ALIASES[props.variant] ?? 'info')
const open = computed(() => props.modelValue && !dismissed.value)
const glyph = computed<IconName | null>(() =>
  props.icon === null ? null : (props.icon ?? DEFAULT_ICONS[variantKey.value]))
const liveRole = computed(() => props.role ?? (variantKey.value === 'danger' ? 'alert' : 'status'))

function dismiss() {
  dismissed.value = true
  emit('update:modelValue', false)
  emit('dismiss')
}

function onKeydown(event: KeyboardEvent) {
  if (props.dismissible && event.key === 'Escape') dismiss()
}
</script>

<template>
  <Transition data-ui="alert"
    :enter-from-class="$style.gone"
    :enter-active-class="$style.moving"
    :leave-active-class="$style.moving"
    :leave-to-class="$style.gone"
  >
    <section
      v-if="open"
      :class="[$style.alert, $style[variantKey], dense && $style.dense]"
      :role="liveRole"
      @keydown="onKeydown"
    >
      <span v-if="glyph || $slots.icon" :class="$style.glyph">
        <slot name="icon">
          <Icon v-if="glyph" :name="glyph" :size="dense ? 14 : 16" />
        </slot>
      </span>

      <div :class="$style.main">
        <div v-if="title || count !== undefined" :class="$style.head">
          <strong v-if="title" :class="$style.title">{{ title }}</strong>
          <span
            v-if="count !== undefined"
            :class="$style.count"
            :aria-label="`${count} occurrences`"
          >x{{ count }}</span>
        </div>

        <div v-if="$slots.default" :class="$style.body">
          <slot />
        </div>

        <div v-if="sub || $slots.sub" :class="$style.sub">
          <span aria-hidden="true">//&nbsp;</span><slot name="sub">{{ sub }}</slot>
        </div>

        <div v-if="$slots.actions" :class="$style.actions">
          <slot name="actions" />
        </div>
      </div>

      <button
        v-if="dismissible"
        type="button"
        :class="$style.close"
        :aria-label="dismissLabel"
        @click="dismiss"
      >
        <Icon name="close" :size="14" />
      </button>
    </section>
  </Transition>
</template>

<style module>
.alert {
  --alert-color: var(--color-accent);
  display: flex;
  align-items: flex-start;
  gap: var(--space-3);
  width: 100%;
  padding: var(--space-3) var(--space-4);
  border: var(--border);
  border-left: 2px solid var(--alert-color);
  border-radius: var(--radius);
  background: var(--color-surface);
  text-align: left;
}
.info   { --alert-color: var(--color-accent); }
.ok     { --alert-color: var(--color-ok); }
.warn   { --alert-color: var(--color-warn); }
.danger { --alert-color: var(--color-danger); }

.glyph {
  display: inline-flex;
  align-items: center;
  height: calc(var(--font-size-sm) * 1.5);
  color: var(--alert-color);
}

.main {
  display: flex;
  flex-direction: column;
  gap: var(--space-1);
  min-width: 0;
  flex: 1;
}

.head {
  display: flex;
  align-items: baseline;
  gap: var(--space-2);
}
.title {
  font-family: var(--font-family);
  font-size: var(--font-size-sm);
  font-weight: 600;
  line-height: 1.5;
  color: var(--color-fg);
  overflow-wrap: anywhere;
}
.count {
  font-family: var(--font-mono);
  font-size: var(--font-size-xs);
  color: var(--alert-color);
  border: 1px solid var(--color-border);
  border-radius: var(--r-1);
  padding: 0 var(--space-1);
}

.body {
  font-size: var(--font-size-sm);
  line-height: 1.55;
  color: var(--color-text-dim);
  overflow-wrap: anywhere;
}

/* Data inside prose switches to mono — the font is the signal. */
.body code,
.body kbd,
.body samp {
  font-family: var(--font-mono);
  font-size: var(--font-size-xs);
  color: var(--color-fg);
  background: var(--color-surface-mute);
  border: 1px solid var(--color-border-soft);
  border-radius: var(--r-1);
  padding: 1px var(--space-1);
}

.sub {
  font-family: var(--font-mono);
  font-size: var(--font-size-xs);
  line-height: 1.5;
  color: var(--color-muted);
}

.actions {
  display: flex;
  flex-wrap: wrap;
  align-items: center;
  gap: var(--space-2);
  margin-top: var(--space-2);
}

.close {
  display: inline-flex;
  align-items: center;
  justify-content: center;
  flex-shrink: 0;
  width: 22px;
  height: 22px;
  padding: 0;
  border: 1px solid transparent;
  border-radius: var(--r-1);
  background: none;
  color: var(--color-text-ghost);
  cursor: pointer;
}
.close:hover {
  color: var(--color-fg);
  background: var(--color-surface-hi);
  border-color: var(--color-border);
}
.close:focus-visible {
  outline: 2px solid var(--color-accent);
  outline-offset: 1px;
  color: var(--color-fg);
}

.dense {
  gap: var(--space-2);
  padding: var(--space-2) var(--space-3);
}
.dense .title,
.dense .body { font-size: var(--font-size-xs); }

/* Dismiss motion — one small slide toward the rail it leaves behind. */
.moving { transition: opacity 140ms ease, transform 140ms ease; }
.gone {
  opacity: 0;
  transform: translateX(-6px);
}

@media (prefers-reduced-motion: reduce) {
  .moving { transition: none; }
  .gone { transform: none; }
}
</style>
