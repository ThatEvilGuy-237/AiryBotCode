<script setup lang="ts">
/**
 * TableCell
 * Internal — renders one <Table> cell for a column that has no custom slot.
 * The column's `type` picks the shape: mono data, sans prose, a tabular number,
 * an Intl date, or a chip. Missing values render as a ghosted em dash.
 *
 * @prop column - the registered column definition
 * @prop row    - the row object
 *
 * Status: new | Consumers: Table
 */
import { computed } from 'vue'
import type { TableColumnDef, TableRow, TableTone, TableToneInput } from './types'

const props = defineProps<{ column: TableColumnDef; row: TableRow }>()

const TONE_ALIASES: Record<string, TableTone> = {
  neutral: 'neutral',
  accent: 'accent',
  ok: 'ok',
  warn: 'warn',
  danger: 'danger',
  plan: 'plan',
  success: 'ok',
  brand: 'accent',
  warning: 'warn',
  error: 'danger',
  fail: 'danger',
  failed: 'danger',
  info: 'accent',
  active: 'ok',
  inactive: 'neutral',
}

const value = computed(() => props.row[props.column.field])

const text = computed(() => {
  const column = props.column
  if (column.format) return column.format(value.value, props.row)
  if (column.type === 'date') return formatDate(value.value)
  if (value.value == null || value.value === '') return ''
  return String(value.value)
})

const tone = computed<TableTone>(() => {
  const raw = props.column.tones?.[String(value.value)] as TableToneInput | undefined
  return TONE_ALIASES[String(raw ?? 'neutral')] ?? 'neutral'
})

const isChip = computed(() => props.column.type === 'tag' || props.column.type === 'role')

function formatDate(input: unknown): string {
  if (input == null || input === '') return ''
  const date = input instanceof Date ? input : new Date(String(input))
  if (Number.isNaN(date.getTime())) return String(input)
  return new Intl.DateTimeFormat(undefined, { year: 'numeric', month: 'short', day: '2-digit' }).format(date)
}
</script>

<template>
  <span v-if="!text" :class="$style.blank" aria-hidden="true">—</span>

  <span
    v-else-if="isChip"
    :class="[$style.chip, $style[`tone_${tone}`], column.type === 'role' && $style.role]"
  >
    <span v-if="column.type === 'tag'" :class="$style.dot" />
    {{ text }}
  </span>

  <span v-else :class="[$style.cell, column.type === 'prose' ? $style.prose : $style.data, column.type === 'num' && $style.num]">
    {{ text }}
  </span>
</template>

<style module>
.cell {
  display: block;
  overflow: hidden;
  text-overflow: ellipsis;
  white-space: nowrap;
}
.data {
  font-family: var(--font-mono);
  color: var(--color-fg);
}
.prose {
  font-family: var(--font-family);
  color: var(--color-text-dim, var(--color-fg));
}
.num {
  font-family: var(--font-mono);
  font-variant-numeric: tabular-nums;
  color: var(--color-fg);
}
.blank {
  font-family: var(--font-mono);
  color: var(--color-text-ghost, var(--color-muted));
}

/* Chips — the tone colors the dot, never the whole pill. */
.chip {
  display: inline-flex;
  align-items: center;
  gap: var(--space-2);
  max-width: 100%;
  padding: 1px var(--space-2);
  border: 1px solid var(--color-border);
  border-radius: 999px;
  background: var(--color-surface-mute, var(--color-surface));
  font-family: var(--font-mono);
  font-size: var(--font-size-xs);
  color: var(--color-text-dim, var(--color-fg));
  white-space: nowrap;
  overflow: hidden;
  text-overflow: ellipsis;
}
.role {
  background: none;
  letter-spacing: 0.06em;
  text-transform: uppercase;
  color: var(--color-muted);
}
.dot {
  flex: none;
  width: 6px;
  height: 6px;
  border-radius: 50%;
  background: var(--color-muted);
}
.tone_accent .dot  { background: var(--color-accent); }
.tone_ok .dot      { background: var(--color-ok); }
.tone_warn .dot    { background: var(--color-warn); }
.tone_danger .dot  { background: var(--color-danger); }
.tone_plan .dot    { background: var(--color-plan); }

.tone_accent { color: var(--color-fg); border-color: var(--color-accent-edge, var(--color-border)); }
.tone_danger { color: var(--color-fg); }
</style>
