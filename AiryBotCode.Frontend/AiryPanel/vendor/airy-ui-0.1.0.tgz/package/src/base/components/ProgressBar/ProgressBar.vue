<script setup lang="ts">
/**
 * ProgressBar
 * Slim horizontal progress / load bar. Clamps value to [0, 100].
 *
 * @prop value   - 0–100, percent fill
 * @prop variant - accent | ok | warn | err (default 'accent')
 *
 * Status: stable | Consumers: Patterns
 */
import { computed } from 'vue'

const props = withDefaults(defineProps<{
  value: number
  variant?: 'accent' | 'ok' | 'warn' | 'err'
}>(), { variant: 'accent' })

const pct = computed(() => Math.max(0, Math.min(100, props.value)))
</script>

<template>
  <div data-ui="progress-bar" :class="$style.bar" role="progressbar" :aria-valuenow="pct" aria-valuemin="0" aria-valuemax="100">
    <div :class="[$style.fill, $style[variant]]" :style="{ width: `${pct}%` }" />
  </div>
</template>

<style module>
.bar {
  height: 4px;
  border-radius: 2px;
  border: 1px solid var(--color-border-soft, var(--color-border));
  background: var(--color-bg-2, var(--color-bg));
  overflow: hidden;
}
.fill {
  height: 100%;
}
.accent { background: linear-gradient(to right, var(--color-accent-mute, var(--color-accent)), var(--color-accent)); }
.ok     { background: var(--color-ok); }
.warn   { background: var(--color-warn); }
.err    { background: var(--color-danger); }
</style>
