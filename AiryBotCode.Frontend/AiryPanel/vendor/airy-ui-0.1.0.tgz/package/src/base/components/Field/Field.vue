<script setup lang="ts">
/**
 * Field
 * The label / hint / error shell around one form control. Put any control in
 * the default slot — TextField, Textarea, Select, Checkbox, Toggle, TagInput,
 * SearchField, Slider, or a plain <input> — and Field owns everything around
 * it: the label, the required marker, the mono `//` hint, the error line, and
 * the a11y plumbing (`for`, `aria-describedby`, `aria-invalid`, `aria-required`).
 *
 * It wires the real focusable element it finds in the slot, so the controls in
 * this package work exactly as they are — none of them had to change. A control
 * that renders its own <label> (Checkbox) is detected and the field switches to
 * `role="group"` labelling instead of stacking a second, conflicting label.
 *
 * Never hand-roll a `<label>` + `<input>` + grey caption stack again — that is
 * where `for`, `aria-describedby` and `role="alert"` always go missing. Controls
 * that carry their own `label` prop (TextField, Textarea, Slider) go inside a
 * Field *without* it: one label, not two.
 *
 * @prop label       - label text (sans). Use `hideLabel` to keep it for screen
 *                     readers only instead of dropping it.
 * @prop hideLabel   - visually hide the label, keep the association.
 * @prop hint        - guidance below the control, rendered as the mono `//` line.
 * @prop error       - error message, or `true` for a message-less invalid state.
 *                     Truthy = the field is invalid.
 * @prop required    - mark the field required: quiet mono marker + `aria-required`.
 * @prop layout      - 'stacked' (default) or 'horizontal' (label column left).
 * @prop labelWidth  - width of the label column in `horizontal` layout.
 * @prop mono        - render the label as an uppercase mono eyebrow, for
 *                     data-shaped fields (ids, ports, keys).
 * @prop counter     - small mono readout on the right of the label row, e.g. "42 / 280".
 * @prop disabled    - dim the shell (the control keeps its own disabled state).
 * @prop id          - force the control id instead of the generated one.
 *
 * @slot default - the control. Slot props: { id, describedBy, invalid, required, disabled }.
 * @slot label   - replaces the label text.
 * @slot hint    - replaces the hint text (the `//` prefix stays).
 * @slot error   - replaces the error text.
 * @slot aside   - right side of the label row; overrides `counter`.
 *
 * Status: new | Consumers: portal-kit Field, ThatEvilGuyMemory portal forms
 */
import { computed, onMounted, onUpdated, provide, ref, watch } from 'vue'
import { FIELD_KEY, nextFieldId } from './keys'

export type FieldLayout = 'stacked' | 'horizontal'

const props = withDefaults(defineProps<{
  label?: string
  hideLabel?: boolean
  hint?: string
  error?: string | boolean
  required?: boolean
  layout?: FieldLayout
  labelWidth?: string
  mono?: boolean
  counter?: string | number
  disabled?: boolean
  id?: string
}>(), {
  layout: 'stacked',
  labelWidth: '180px',
  hideLabel: false,
  required: false,
  mono: false,
  disabled: false,
})

const slots = defineSlots<{
  default?: (p: { id: string; describedBy: string | undefined; invalid: boolean; required: boolean; disabled: boolean }) => any
  label?: () => any
  hint?: () => any
  error?: () => any
  aside?: () => any
}>()

const fallbackId = nextFieldId()

const host = ref<HTMLElement>()
const adoptedId = ref<string>()
const grouped = ref(false)

const controlId = computed(() => props.id ?? adoptedId.value ?? fallbackId)
const labelId = computed(() => `${controlId.value}-label`)
const hintId = computed(() => `${controlId.value}-hint`)
const errorId = computed(() => `${controlId.value}-error`)

const invalid = computed(() => props.error === true || (typeof props.error === 'string' && props.error.length > 0))
const errorText = computed(() => (typeof props.error === 'string' ? props.error : ''))
const hasHint = computed(() => !!props.hint || !!slots.hint)
const hasAside = computed(() => !!slots.aside || props.counter != null)
const hasLabel = computed(() => !!props.label || !!slots.label)
const showHead = computed(() => hasLabel.value || hasAside.value)
const headHidden = computed(() => props.hideLabel && !hasAside.value)
const required = computed(() => props.required)
const disabled = computed(() => props.disabled)

const baseDescribedBy = ref<string | null>(null)

const describedBy = computed(() => {
  const own = [errorId.value, hintId.value]
  const base = (baseDescribedBy.value ?? '').split(/\s+/).filter(id => id && !own.includes(id))
  const ids = [
    ...base,
    invalid.value ? errorId.value : null,
    hasHint.value ? hintId.value : null,
  ].filter(Boolean) as string[]
  return ids.length ? Array.from(new Set(ids)).join(' ') : undefined
})

const CONTROL_SELECTOR = [
  'input:not([type="hidden"])',
  'select',
  'textarea',
  '[contenteditable="true"]',
  '[role="switch"]',
  '[role="slider"]',
  '[role="spinbutton"]',
  '[role="combobox"]',
  '[role="textbox"]',
].join(',')

let wired: HTMLElement | null = null

function control(): HTMLElement | null {
  return host.value?.querySelector<HTMLElement>(CONTROL_SELECTOR) ?? null
}

function sync() {
  const el = control()

  if (el !== wired) {
    baseDescribedBy.value = el?.getAttribute('aria-describedby') ?? null
    wired = el
  }

  if (!el) {
    grouped.value = true
    adoptedId.value = undefined
    return
  }

  grouped.value = !!el.closest('label')
  if (!el.id) el.id = controlId.value
  adoptedId.value = el.id

  if (grouped.value) {
    if (baseDescribedBy.value) el.setAttribute('aria-describedby', baseDescribedBy.value)
    else el.removeAttribute('aria-describedby')
    el.removeAttribute('aria-invalid')
    el.removeAttribute('aria-required')
    return
  }

  const described = describedBy.value
  if (described) el.setAttribute('aria-describedby', described)
  else el.removeAttribute('aria-describedby')

  if (invalid.value) el.setAttribute('aria-invalid', 'true')
  else el.removeAttribute('aria-invalid')

  if (required.value) el.setAttribute('aria-required', 'true')
  else el.removeAttribute('aria-required')
}

function focus() {
  control()?.focus()
}

onMounted(sync)
onUpdated(sync)
watch([invalid, hasHint, required, controlId], sync)

provide(FIELD_KEY, { id: controlId, describedBy, invalid, required, disabled })

defineExpose({ controlId, focus })
</script>

<template>
  <div data-ui="field"
    :class="[
      $style.field,
      $style[layout],
      invalid && $style.invalid,
      disabled && $style.disabled,
    ]"
    :style="{ '--field-label-w': labelWidth }"
    :role="grouped ? 'group' : undefined"
    :aria-labelledby="grouped && hasLabel ? labelId : undefined"
    :aria-describedby="grouped ? describedBy : undefined"
    :aria-invalid="grouped && invalid ? 'true' : undefined"
    :aria-required="grouped && required ? 'true' : undefined"
    :aria-disabled="disabled || undefined"
  >
    <div v-if="showHead" :class="[$style.head, headHidden && $style.offscreen]">
      <component
        :is="grouped ? 'span' : 'label'"
        v-if="hasLabel"
        :id="labelId"
        :for="grouped ? undefined : controlId"
        :class="[$style.label, mono && $style.eyebrow, hideLabel && !headHidden && $style.offscreen]"
      >
        <slot name="label">{{ label }}</slot>
        <span v-if="required" :class="$style.req" aria-hidden="true">required</span>
      </component>
      <span v-if="hasAside" :class="$style.aside">
        <slot name="aside">{{ counter }}</slot>
      </span>
    </div>

    <div ref="host" :class="$style.control" :data-invalid="invalid || undefined">
      <slot
        :id="controlId"
        :described-by="describedBy"
        :invalid="invalid"
        :required="required"
        :disabled="disabled"
      />
    </div>

    <p v-if="hasHint" :id="hintId" :class="$style.hint">
      <span :class="$style.slashes" aria-hidden="true">//</span>
      <span><slot name="hint">{{ hint }}</slot></span>
    </p>

    <p v-if="invalid" :id="errorId" :class="$style.error" role="alert" @click="focus">
      <slot name="error">{{ errorText }}</slot>
    </p>
  </div>
</template>

<style module>
/* Shell */
.field {
  display: flex;
  flex-direction: column;
  gap: var(--space-1);
  min-width: 0;
}
.head {
  display: flex;
  align-items: baseline;
  gap: var(--space-3);
  min-width: 0;
}
.control { min-width: 0; }

/* Label */
.label {
  font-family: var(--font-family);
  font-size: var(--font-size-sm);
  font-weight: 500;
  color: var(--color-text-dim);
  transition: color 0.12s ease;
}
label.label { cursor: pointer; }
.field:focus-within .label { color: var(--color-fg); }
.eyebrow {
  font-family: var(--font-mono);
  font-size: var(--font-size-xs);
  font-weight: 400;
  letter-spacing: 0.08em;
  text-transform: uppercase;
  color: var(--color-text-ghost);
}

/* Required marker — quiet mono, not a red asterisk */
.req {
  margin-left: var(--space-2);
  font-family: var(--font-mono);
  font-size: var(--font-size-xs);
  letter-spacing: 0.08em;
  text-transform: uppercase;
  color: var(--color-text-ghost);
  transition: color 0.12s ease;
}
.invalid .req { color: var(--color-danger); }

/* Label-row aside / counter */
.aside {
  margin-left: auto;
  font-family: var(--font-mono);
  font-size: var(--font-size-xs);
  color: var(--color-muted);
  flex-shrink: 0;
}

/* Hint — the house `//` engineer line */
.hint {
  display: flex;
  gap: var(--space-2);
  margin: 0;
  font-family: var(--font-mono);
  font-size: var(--font-size-xs);
  line-height: 1.5;
  color: var(--color-muted);
}
.slashes { color: var(--color-text-ghost); flex-shrink: 0; }

/* Error — hairline, never a filled banner */
.error {
  margin: 0;
  padding-left: var(--space-2);
  border-left: 1px solid var(--color-danger);
  font-family: var(--font-mono);
  font-size: var(--font-size-xs);
  line-height: 1.5;
  color: var(--color-danger);
  cursor: pointer;
  animation: field-error-in 120ms ease-out;
}
@keyframes field-error-in {
  from { opacity: 0; transform: translateY(-2px); }
  to   { opacity: 1; transform: none; }
}

/* Invalid state reaches the slotted control without touching its source */
.control[data-invalid] :is(input, select, textarea) { border-color: var(--color-danger); }
.control[data-invalid] :is([role='switch'], [role='slider']) { border-color: var(--color-danger); }

/* Disabled shell */
.disabled .label,
.disabled .hint,
.disabled .aside,
.disabled .req { opacity: 0.5; }

/* Horizontal layout */
.horizontal {
  display: grid;
  grid-template-columns: var(--field-label-w, 180px) minmax(0, 1fr);
  column-gap: var(--space-4);
  row-gap: var(--space-1);
  align-items: start;
}
.horizontal .head { grid-column: 1; padding-top: var(--space-2); }
.horizontal .control,
.horizontal .hint,
.horizontal .error { grid-column: 2; }
@media (max-width: 640px) {
  .horizontal { grid-template-columns: minmax(0, 1fr); }
  .horizontal .head,
  .horizontal .control,
  .horizontal .hint,
  .horizontal .error { grid-column: 1; }
  .horizontal .head { padding-top: 0; }
}

/* Screen-reader-only, out of flow so it costs no gap */
.offscreen {
  position: absolute;
  width: 1px;
  height: 1px;
  margin: 0;
  padding: 0;
  overflow: hidden;
  white-space: nowrap;
  clip-path: inset(50%);
}

@media (prefers-reduced-motion: reduce) {
  .error { animation: none; }
  .label, .req { transition: none; }
}
</style>
