<script setup lang="ts">
import Icon from '../Icon/Icon.vue'
/**
 * Collapsible — a header that toggles a body. Optional v-model:open, else it
 * manages its own state from defaultOpen. Slots: header, default (body).
 *
 * @prop open (controlled) / title / defaultOpen
 * @event update:open
 *
 * Status: new
 */
import { ref, watch } from 'vue'

const props = withDefaults(defineProps<{
  open?: boolean | null
  title?: string
  defaultOpen?: boolean
}>(), { open: null, defaultOpen: false })

const emit = defineEmits<{ 'update:open': [v: boolean] }>()

const internal = ref(props.open ?? props.defaultOpen)
watch(() => props.open, (v) => { if (v !== null && v !== undefined) internal.value = v })

function toggle() {
  internal.value = !internal.value
  emit('update:open', internal.value)
}
</script>

<template>
  <div data-ui="collapsible" :class="$style.wrap">
    <button type="button" :class="$style.head" :aria-expanded="internal ? 'true' : 'false'" @click="toggle">
      <span :class="$style.chev"><Icon :name="internal ? 'chevron-down' : 'chevron-right'" :size="14" /></span>
      <slot name="header"><span :class="$style.title">{{ title }}</span></slot>
    </button>
    <div v-if="internal" :class="$style.body"><slot /></div>
  </div>
</template>

<style module>
.wrap { border: var(--border); border-radius: var(--radius); overflow: hidden; }
.head { display: flex; align-items: center; gap: var(--space-2); width: 100%; min-height: var(--collapsible-head-min-height, auto); background: var(--color-surface); border: 0; cursor: pointer; padding: var(--space-2) var(--space-3); color: var(--color-fg); font: inherit; text-align: left; }
.head:hover { background: var(--color-surface-hi, var(--color-bg)); }
.chev { color: var(--color-muted); flex-shrink: 0; }
.title { font-weight: 500; }
.body { padding: var(--space-3); border-top: 1px solid var(--color-border-soft, var(--color-border)); }
</style>
