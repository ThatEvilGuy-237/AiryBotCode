<script setup lang="ts">
/**
 * NewBadge
 * Small accent-colored pill marking a component, feature, or surface as
 * recently added / not fully battle-tested. Stylistically distinct from
 * <Badge> so consumers don't confuse "new" with status chips like "active".
 *
 * @prop variant - new (accent, default) | draft (warn) | beta (muted) | todo (warn, distinct from draft — flags UI placeholders that lack a backend)
 *
 * Slot:
 *   default - optional custom label. Defaults to the variant name.
 *
 * Status: stable | Consumers: showcase sidebar, ComponentHeader, AI node config placeholders
 */
withDefaults(defineProps<{
  variant?: 'new' | 'draft' | 'beta' | 'todo'
}>(), { variant: 'new' })
</script>

<template>
  <span data-ui="new-badge" :class="[$style.badge, $style[variant]]">
    <slot>{{ variant }}</slot>
  </span>
</template>

<style module>
.badge {
  display: inline-block;
  font-family: var(--font-mono);
  font-size: 10px;
  letter-spacing: 0.1em;
  text-transform: uppercase;
  font-weight: 600;
  line-height: 1.6;
  padding: 1px var(--space-2);
  border: 1px solid;
  border-radius: var(--radius);
  white-space: nowrap;
}

.new {
  color: var(--color-accent);
  border-color: var(--color-accent-edge, var(--color-accent));
  background: var(--color-accent-soft, transparent);
}
.draft {
  color: var(--color-warn);
  border-color: var(--color-warn);
  background: transparent;
}
.beta {
  color: var(--color-muted);
  border-color: var(--color-border);
  background: transparent;
}
.todo {
  color: var(--color-warn);
  border-color: var(--color-warn);
  background: var(--color-warn-soft, transparent);
  border-style: dashed;
}
</style>
