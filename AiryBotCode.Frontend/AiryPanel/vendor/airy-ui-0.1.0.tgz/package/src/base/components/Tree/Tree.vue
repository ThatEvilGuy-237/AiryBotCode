<script setup lang="ts">
/**
 * Tree
 * Data-driven hierarchy: spaces holding concepts holding concepts, a module
 * parent chain, a folder listing. You supply `nodes` as a recursive `TreeNode[]`
 * and Tree owns the rest — expansion, single selection, lazy child loading and
 * the full ARIA tree keyboard model.
 *
 * The row selects, the caret expands. Deliberately separate, so a parent is
 * selectable in its own right.
 *
 * Both stateful bits are controlled-or-uncontrolled: bind `v-model` /
 * `v-model:expanded` to drive them from outside (deep-link a selection, restore
 * an open path), or leave them unbound and Tree keeps its own.
 *
 * Large trees stay cheap with `lazy`: mark a node `lazy: true`, pass
 * `loadChildren`, and its children are fetched the first time it opens, with a
 * spinner in the caret's place and a `//` line if the branch comes back empty or
 * unreadable. A failed branch retries on the next expand.
 *
 * @prop nodes           - the hierarchy; every node needs a tree-unique `key`
 * @prop modelValue      - selected key (`v-model`); omit to self-manage
 * @prop expanded        - open-node map (`v-model:expanded`); omit to self-manage
 * @prop defaultExpanded - keys open on first render, when `expanded` is unbound
 * @prop loadChildren    - async children fetcher for `lazy` nodes
 * @prop label           - mono eyebrow above the tree; also its accessible name
 * @prop emptyText       - `//` line shown when there is nothing to render
 * @prop dense           - tighter rows, for sidebars and long vaults
 * @prop hints           - show the `//` keyboard affordance line under the tree
 *
 * Status: new | Consumers: available for future use
 */
import { computed, nextTick, provide, ref, watch } from 'vue'
import TreeBranch from './TreeBranch.vue'
import { TREE_CTX, type TreeContext } from './keys'
import type {
  TreeExpandedMap,
  TreeKey,
  TreeLoadState,
  TreeLoadChildren,
  TreeNode,
  TreeNodeSlotProps,
} from './types'

const props = withDefaults(defineProps<{
  nodes?: TreeNode[]
  modelValue?: TreeKey | null
  expanded?: TreeExpandedMap
  defaultExpanded?: TreeKey[]
  loadChildren?: TreeLoadChildren
  label?: string
  emptyText?: string
  dense?: boolean
  hints?: boolean
}>(), {
  nodes: () => [],
  defaultExpanded: () => [],
  emptyText: 'nothing here',
  dense: false,
  hints: false,
})

const emit = defineEmits<{
  'update:modelValue': [key: TreeKey]
  'update:expanded': [map: TreeExpandedMap]
  select: [node: TreeNode]
  toggle: [node: TreeNode, expanded: boolean]
  loaded: [node: TreeNode, children: TreeNode[]]
  'load-error': [node: TreeNode, error: unknown]
}>()

defineSlots<{
  label?: (props: TreeNodeSlotProps) => unknown
  trailing?: (props: TreeNodeSlotProps) => unknown
}>()

let seq = 0
const treeId = `hive-tree-${++seq}-${Math.random().toString(36).slice(2, 7)}`
const labelId = computed(() => (props.label ? `${treeId}-label` : undefined))

const controlledSelection = computed(() => props.modelValue !== undefined)
const ownSelected = ref<TreeKey | null>(props.modelValue ?? null)
const selectedKey = computed<TreeKey | null>(() =>
  controlledSelection.value ? (props.modelValue ?? null) : ownSelected.value,
)

const controlledExpansion = computed(() => props.expanded !== undefined)
const ownExpanded = ref<TreeExpandedMap>(
  Object.fromEntries(props.defaultExpanded.map(k => [k, true])),
)
const expandedMap = computed<TreeExpandedMap>(() =>
  controlledExpansion.value ? (props.expanded ?? {}) : ownExpanded.value,
)
function isExpanded(key: TreeKey) {
  return expandedMap.value[key] === true
}

const loaded = ref(new Map<TreeKey, TreeNode[]>())
const loadState = ref(new Map<TreeKey, TreeLoadState>())
function loadStateOf(key: TreeKey): TreeLoadState {
  return loadState.value.get(key) ?? 'idle'
}

function childrenOf(node: TreeNode): TreeNode[] {
  const kids = loaded.value.get(node.key) ?? node.children ?? []
  return kids.filter(child => !child.hidden)
}
function expandable(node: TreeNode): boolean {
  if (node.locked) return false
  return node.lazy === true || childrenOf(node).length > 0
}

const roots = computed(() => props.nodes.filter(node => !node.hidden))

interface Row { node: TreeNode; parent: TreeKey | null; siblings: TreeNode[] }

const rows = computed<Row[]>(() => {
  const flat: Row[] = []
  const walk = (list: TreeNode[], parent: TreeKey | null) => {
    for (const node of list) {
      flat.push({ node, parent, siblings: list })
      if (expandable(node) && isExpanded(node.key)) walk(childrenOf(node), node.key)
    }
  }
  walk(roots.value, null)
  return flat
})

const visibleKeys = computed(() => rows.value.map(row => row.node.key))
const rowByKey = computed(() => new Map(rows.value.map(row => [row.node.key, row])))

const parentOfAll = computed(() => {
  const map = new Map<TreeKey, TreeKey | null>()
  const walk = (list: TreeNode[], parent: TreeKey | null) => {
    for (const node of list) {
      map.set(node.key, parent)
      walk(childrenOf(node), node.key)
    }
  }
  walk(roots.value, null)
  return map
})

const spine = computed(() => {
  const chain = new Set<TreeKey>()
  let cursor = selectedKey.value
  while (cursor != null) {
    const parent = parentOfAll.value.get(cursor) ?? null
    if (parent == null) break
    chain.add(parent)
    cursor = parent
  }
  return chain
})

const anyIcon = computed(() => rows.value.some(row => !!row.node.icon || !!row.node.locked))

const activeKey = ref<TreeKey | null>(null)
const tabKey = computed<TreeKey | null>(() => {
  const keys = visibleKeys.value
  if (activeKey.value != null && keys.includes(activeKey.value)) return activeKey.value
  if (selectedKey.value != null && keys.includes(selectedKey.value)) return selectedKey.value
  return keys[0] ?? null
})

const rowEls = new Map<TreeKey, HTMLElement>()
function registerRow(key: TreeKey, el: HTMLElement) { rowEls.set(key, el) }
function unregisterRow(key: TreeKey) { rowEls.delete(key) }
function setActive(key: TreeKey) { activeKey.value = key }

function focusKey(key: TreeKey) {
  activeKey.value = key
  nextTick(() => rowEls.get(key)?.focus())
}
function focusIndex(index: number) {
  const keys = visibleKeys.value
  if (!keys.length) return
  const clamped = Math.max(0, Math.min(keys.length - 1, index))
  focusKey(keys[clamped]!)
}

async function ensureChildren(node: TreeNode) {
  if (!node.lazy || !props.loadChildren) return
  const state = loadStateOf(node.key)
  if (state === 'loading' || state === 'loaded') return
  loadState.value.set(node.key, 'loading')
  try {
    const kids = await props.loadChildren(node)
    loaded.value.set(node.key, kids)
    loadState.value.set(node.key, 'loaded')
    emit('loaded', node, kids)
  }
  catch (error) {
    loadState.value.set(node.key, 'error')
    emit('load-error', node, error)
  }
}

watch(rows, (list) => {
  for (const row of list) {
    if (row.node.lazy && isExpanded(row.node.key) && loadStateOf(row.node.key) === 'idle') {
      void ensureChildren(row.node)
    }
  }
}, { immediate: true })

function setExpanded(node: TreeNode, open: boolean) {
  if (!expandable(node)) return
  const next: TreeExpandedMap = { ...expandedMap.value, [node.key]: open }
  if (!controlledExpansion.value) ownExpanded.value = next
  emit('update:expanded', next)
  emit('toggle', node, open)
  if (open) void ensureChildren(node)
}
function toggle(node: TreeNode) {
  setExpanded(node, !isExpanded(node.key))
}

function select(node: TreeNode) {
  if (node.disabled || node.locked) return
  if (!controlledSelection.value) ownSelected.value = node.key
  emit('update:modelValue', node.key)
  emit('select', node)
}

function expandSiblings(node: TreeNode) {
  const row = rowByKey.value.get(node.key)
  if (!row) return
  const next: TreeExpandedMap = { ...expandedMap.value }
  for (const sibling of row.siblings) {
    if (!expandable(sibling)) continue
    next[sibling.key] = true
    void ensureChildren(sibling)
  }
  if (!controlledExpansion.value) ownExpanded.value = next
  emit('update:expanded', next)
}

let typed = ''
let typedTimer: ReturnType<typeof setTimeout> | undefined
function typeahead(char: string, from: number) {
  if (typedTimer) clearTimeout(typedTimer)
  typed += char.toLowerCase()
  typedTimer = setTimeout(() => { typed = '' }, 600)
  const list = rows.value
  const start = typed.length > 1 ? from : from + 1
  for (let step = 0; step < list.length; step++) {
    const row = list[(start + step + list.length) % list.length]!
    if (row.node.label.toLowerCase().startsWith(typed)) {
      focusKey(row.node.key)
      return
    }
  }
}

function onKeydown(event: KeyboardEvent, node: TreeNode) {
  const keys = visibleKeys.value
  const index = keys.indexOf(node.key)
  const open = expandable(node) && isExpanded(node.key)

  switch (event.key) {
    case 'ArrowDown':
      event.preventDefault()
      focusIndex(index + 1)
      return
    case 'ArrowUp':
      event.preventDefault()
      focusIndex(index - 1)
      return
    case 'Home':
      event.preventDefault()
      focusIndex(0)
      return
    case 'End':
      event.preventDefault()
      focusIndex(keys.length - 1)
      return
    case 'ArrowRight':
      event.preventDefault()
      if (expandable(node) && !open) setExpanded(node, true)
      else if (open) focusIndex(index + 1)
      return
    case 'ArrowLeft': {
      event.preventDefault()
      if (open) { setExpanded(node, false); return }
      const parent = parentOfAll.value.get(node.key)
      if (parent != null) focusKey(parent)
      return
    }
    case '*':
      event.preventDefault()
      expandSiblings(node)
      return
    case 'Enter':
    case ' ':
      event.preventDefault()
      select(node)
      return
  }

  if (event.key.length === 1 && !event.ctrlKey && !event.metaKey && !event.altKey && /\S/.test(event.key)) {
    event.preventDefault()
    typeahead(event.key, index)
  }
}

const context: TreeContext = {
  selectedKey,
  tabKey,
  spine,
  anyIcon,
  dense: computed(() => props.dense),
  childrenOf,
  expandable,
  isExpanded,
  loadStateOf,
  select,
  toggle,
  onKeydown,
  registerRow,
  unregisterRow,
  setActive,
}
provide(TREE_CTX, context)

defineExpose({ focusKey })
</script>

<template>
  <div data-ui="tree" :class="$style.tree">
    <div v-if="label" :id="labelId" :class="$style.eyebrow">{{ label }}</div>

    <ul
      v-if="roots.length"
      :class="$style.root"
      role="tree"
      :aria-labelledby="labelId"
      :aria-label="label ? undefined : 'Tree'"
    >
      <TreeBranch
        v-for="(node, index) in roots"
        :key="node.key"
        :node="node"
        :depth="0"
        :set-size="roots.length"
        :pos="index + 1"
      >
        <template v-if="$slots.label" #label="s"><slot name="label" v-bind="s" /></template>
        <template v-if="$slots.trailing" #trailing="s"><slot name="trailing" v-bind="s" /></template>
      </TreeBranch>
    </ul>

    <p v-else :class="$style.empty">// {{ emptyText }}</p>

    <p v-if="hints && roots.length" :class="$style.empty">
      // ↑↓ move · → open · ← close · * open level · type to jump
    </p>
  </div>
</template>

<style module>
.tree { display: flex; flex-direction: column; gap: var(--space-2); }

.eyebrow {
  font-family: var(--font-mono);
  font-size: var(--font-size-xs);
  letter-spacing: 0.08em;
  text-transform: uppercase;
  color: var(--color-text-ghost);
}

.root { margin: 0; padding: 0; list-style: none; }

/* The house sub-text: a mono `//` line for empty, unreadable, or hints. */
.empty {
  margin: 0;
  font-family: var(--font-mono);
  font-size: var(--font-size-xs);
  color: var(--color-text-ghost);
}
</style>
