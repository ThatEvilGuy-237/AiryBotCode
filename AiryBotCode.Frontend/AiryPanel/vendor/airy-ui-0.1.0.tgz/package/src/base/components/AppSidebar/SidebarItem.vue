<script setup lang="ts">
/**
 * SidebarItem
 * One destination in an `<AppSidebar>`: icon, label, optional badge. Give it a
 * `to` and it routes through vue-router (no full page request), resolves its own
 * active state and marks it `aria-current="page"` — the thing a hand-rolled
 * `<a class="active">` always forgets.
 *
 * Active is a left-bar in the accent plus one surface step, never a fill: the
 * eye finds the bar, the label stays readable. By default a parent path counts as
 * active for its children (`/spaces` stays lit inside `/spaces/42`); pass `exact`
 * to the item that would otherwise always be lit — the `/` root.
 *
 * `active` is an escape hatch for links vue-router can't answer for: external
 * `href`s, a docs page, an app driving highlighting from its own state. It is
 * typed `boolean | null` and defaults to `null`, not `false` — an optional
 * `boolean` prop with no default resolves to `false`, which would make "let the
 * router decide" indistinguishable from "force it off".
 *
 * The label carries prose weight in sans; the badge is a count, so it is mono.
 * In the sidebar's rail mode the label is visually hidden but stays in the
 * accessible name, and a badge shrinks to an accent dot.
 *
 * With neither `to` nor `href` the row renders a `<button>` instead of a link —
 * the honest element for a sidebar row that runs a command (sign out, open a
 * dialog) rather than going somewhere. Listen for `click` on it as usual.
 *
 * @prop label    - the item's text, and its accessible name
 * @prop to       - vue-router target
 * @prop href     - plain link target, for anything outside the router
 * @prop exact    - active only on an exact route match
 * @prop icon     - icon from the curated Hive set
 * @prop badge    - count or short tag rendered mono at the end of the row
 * @prop active   - force active state; `null` (default) lets the router decide
 * @prop disabled - visible, announced disabled, not navigable
 *
 * Slot:
 *   trailing - right-aligned extra, e.g. a `<StatusDot>`; hidden in rail mode
 *
 * Status: new | Consumers: AppSidebar
 */
import { computed, inject, onBeforeUnmount } from 'vue'
import { useLink, useRoute, type RouteLocationRaw } from 'vue-router'
import Icon from '../Icon/Icon.vue'
import type { IconName } from '../Icon/icons'
import { SIDEBAR_CTX, SIDEBAR_SECTION_CTX } from './keys'
import type { SidebarBadge, SidebarItemFacts } from './types'

const props = withDefaults(defineProps<{
  label: string
  to?: RouteLocationRaw
  href?: string
  exact?: boolean
  icon?: IconName
  badge?: SidebarBadge
  active?: boolean | null
  disabled?: boolean
}>(), {
  exact: false,
  badge: null,
  active: null,
  disabled: false,
})

defineSlots<{ trailing?: () => unknown }>()

const sidebar = inject(SIDEBAR_CTX, null)
const section = inject(SIDEBAR_SECTION_CTX, null)
const rail = computed(() => sidebar?.rail.value ?? false)

const link = props.to !== undefined
  ? useLink({ to: computed(() => props.to as RouteLocationRaw) })
  : null
const route = link ? useRoute() : null

const isActive = computed(() => {
  if (props.active !== null) return props.active
  if (!link) return false
  if (props.exact) return link.isExactActive.value
  if (link.isActive.value) return true
  const base = link.route.value.path.replace(/\/+$/, '')
  return !!base && !!route && route.path.startsWith(`${base}/`)
})

const target = computed(() => (props.disabled ? undefined : props.href ?? link?.href.value))

const facts = computed<SidebarItemFacts>(() => ({
  active: isActive.value,
  badge: props.badge ?? null,
}))

if (section) {
  section.register(facts)
  onBeforeUnmount(() => section.unregister(facts))
}

const hint = computed(() =>
  props.badge === null || props.badge === '' ? props.label : `${props.label} · ${props.badge}`,
)

function onClick(event: MouseEvent) {
  if (props.disabled) {
    event.preventDefault()
    return
  }
  if (link && !props.href) link.navigate(event)
}
</script>

<template>
  <li :class="$style.item">
    <component
      :is="target ? 'a' : 'button'"
      :type="target ? undefined : 'button'"
      :class="[
        $style.link,
        rail && $style.rail,
        isActive && $style.active,
        disabled && $style.inert,
      ]"
      :href="target"
      :aria-current="isActive ? 'page' : undefined"
      :aria-disabled="disabled ? 'true' : undefined"
      :tabindex="disabled ? -1 : undefined"
      :title="rail ? hint : undefined"
      data-hive-sidebar-stop
      @click="onClick"
    >
      <Icon v-if="icon" :name="icon" :size="16" :class="$style.icon" />
      <span v-else :class="$style.slot" aria-hidden="true" />

      <span :class="$style.label">{{ label }}</span>

      <template v-if="!rail">
        <span v-if="badge !== null && badge !== ''" :class="$style.badge">{{ badge }}</span>
        <span v-if="$slots.trailing" :class="$style.trailing"><slot name="trailing" /></span>
      </template>
      <span
        v-else-if="badge !== null && badge !== ''"
        :class="$style.dot"
        aria-hidden="true"
      />
    </component>
  </li>
</template>

<style module>
.item { list-style: none; }

.link {
  position: relative;
  display: flex;
  align-items: center;
  gap: var(--space-2);
  min-height: var(--sidebar-item-h, 32px);
  width: 100%;
  padding: var(--space-1) var(--space-2);
  border: 0;
  border-radius: var(--r-2);
  background: none;
  color: var(--color-text-dim);
  font: inherit;
  text-align: left;
  text-decoration: none;
  cursor: pointer;
  transition: background 100ms ease, color 100ms ease;
}
.link:hover { background: var(--color-surface-hi); color: var(--color-fg); }
.link:focus-visible { outline: 1px solid var(--color-accent-edge); outline-offset: -1px; }

/* Where you are: one surface step and an accent left-bar. No fill, no glow. */
.active { background: var(--color-surface-hi); color: var(--color-fg); }
.active::before {
  content: '';
  position: absolute;
  inset: 4px auto 4px 0;
  width: 2px;
  border-radius: 1px;
  background: var(--color-accent);
}
.active .icon { color: var(--color-accent); }

.inert { cursor: default; color: var(--color-muted); }
.inert:hover { background: none; color: var(--color-muted); }

.icon { flex: 0 0 auto; color: var(--color-text-ghost); }
.slot { width: 16px; height: 16px; flex: 0 0 auto; }

.label {
  flex: 1 1 auto;
  min-width: 0;
  font-family: var(--font-family);
  font-size: var(--font-size-sm);
  white-space: nowrap;
  overflow: hidden;
  text-overflow: ellipsis;
}

/* Counts are data. */
.badge {
  flex: 0 0 auto;
  font-family: var(--font-mono);
  font-size: var(--font-size-xs);
  color: var(--color-muted);
}

.trailing {
  display: inline-flex;
  align-items: center;
  gap: var(--space-1);
  flex: 0 0 auto;
}

/* Rail: the label leaves the layout but stays the accessible name. */
.rail { justify-content: center; padding: var(--space-1); }
.rail .label {
  position: absolute;
  width: 1px;
  height: 1px;
  margin: -1px;
  padding: 0;
  overflow: hidden;
  clip-path: inset(50%);
  white-space: nowrap;
}
.rail.active::before { inset: auto 4px 2px 4px; width: auto; height: 2px; }

.dot {
  position: absolute;
  top: 5px;
  right: 7px;
  width: 5px;
  height: 5px;
  border-radius: 999px;
  background: var(--color-accent);
}

@media (prefers-reduced-motion: reduce) {
  .link { transition: none; }
}
</style>
