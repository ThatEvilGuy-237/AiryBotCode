<script setup lang="ts">
/**
 * TagInput — editable list of string tags. v-model is string[].
 * Enter (or blur) adds the draft; the × on a tag removes it. Dedupes.
 *
 * @prop modelValue / placeholder / lowercase
 *
 * Status: new
 */
import { ref } from 'vue'
import Tag from '../Tag/Tag.vue'

const props = withDefaults(defineProps<{
  modelValue: string[]
  placeholder?: string
  lowercase?: boolean
}>(), { placeholder: '+ tag', lowercase: false })

const emit = defineEmits<{ 'update:modelValue': [v: string[]] }>()

const draft = ref('')

function add() {
  let v = draft.value.trim()
  if (props.lowercase) v = v.toLowerCase()
  if (v && !props.modelValue.includes(v)) emit('update:modelValue', [...props.modelValue, v])
  draft.value = ''
}
function remove(t: string) {
  emit('update:modelValue', props.modelValue.filter(x => x !== t))
}
</script>

<template>
  <div data-ui="tag-input" :class="$style.wrap">
    <Tag v-for="t in modelValue" :key="t" :label="t" removable @remove="remove(t)" />
    <input
      v-model="draft"
      :class="$style.input"
      :placeholder="placeholder"
      @keyup.enter="add"
      @blur="add"
    />
  </div>
</template>

<style module>
.wrap { display: flex; align-items: center; gap: 6px; flex-wrap: wrap; }
.input { flex: 1; min-width: 80px; height: 26px; background: transparent; border: 1px dashed var(--color-border); border-radius: var(--radius); padding: 0 8px; color: var(--color-fg); font-size: var(--font-size-xs); }
.input:focus { outline: none; border-style: solid; border-color: var(--color-accent, var(--color-border)); }
</style>
