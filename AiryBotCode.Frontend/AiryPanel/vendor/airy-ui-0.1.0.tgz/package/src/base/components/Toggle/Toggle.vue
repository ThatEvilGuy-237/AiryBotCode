<script setup lang="ts">
/**
 * Toggle
 * On/off switch. Use to enable or disable a tool or feature inline.
 *
 * @prop modelValue - controlled state (use v-model)
 * @prop disabled   - disables interaction
 * @prop label      - accessible name when no visible label names the switch (aria-label)
 * @prop labelledby - id of the element that names the switch (aria-labelledby)
 *
 * Naming order: `labelledby`, then `label`, then the enclosing <SettingRow> name,
 * then the enclosing <Field> label (through the Field's `for`). A bare Toggle with
 * none of these has no accessible name; wrap it in a <label> or pass `label`.
 *
 * Status: stable | Consumers: ToolsPage
 */
import { computed, inject } from 'vue'
import { FIELD_KEY } from '../Field/keys'
import { SETTING_ROW_KEY } from '../SettingRow/keys'

const props = defineProps<{
  modelValue: boolean
  disabled?: boolean
  label?: string
  labelledby?: string
}>()

defineEmits<{ 'update:modelValue': [value: boolean] }>()

const field = inject(FIELD_KEY, null)
const settingRow = inject(SETTING_ROW_KEY, null)
const controlId = computed(() => field?.id.value)
const ariaLabelledby = computed(() => props.labelledby ?? (props.label ? undefined : settingRow?.labelId.value))
const ariaDescribedby = computed(() => field?.describedBy.value ?? settingRow?.descriptionId.value)
const isDisabled = computed(() => props.disabled || field?.disabled.value || false)
</script>

<template>
  <button
    data-ui="toggle"
    type="button"
    role="switch"
    :id="controlId"
    :aria-checked="modelValue"
    :aria-label="label"
    :aria-labelledby="ariaLabelledby"
    :aria-describedby="ariaDescribedby"
    :disabled="isDisabled"
    :class="[$style.toggle, modelValue ? $style.on : $style.off]"
    @click="$emit('update:modelValue', !modelValue)"
  />
</template>

<style module>
.toggle {
  position: relative;
  width: 36px;
  height: 20px;
  border-radius: 10px;
  border: 1px solid var(--color-border-hi, var(--color-border));
  cursor: pointer;
  transition: background 0.12s, border-color 0.12s;
  flex-shrink: 0;
  padding: 0;
}
.toggle::before {
  content: '';
  position: absolute;
  top: 50%;
  left: 50%;
  width: max(100%, var(--toggle-hit-w, 0px));
  height: max(100%, var(--toggle-hit-h, 0px));
  transform: translate(-50%, -50%);
}
.toggle::after {
  content: '';
  position: absolute;
  top: 2px;
  width: 14px;
  height: 14px;
  border-radius: 50%;
  background: var(--color-muted);
  transition: left 0.12s, background 0.12s;
}
.on {
  background: var(--color-accent-soft, var(--color-fg));
  border-color: var(--color-accent, var(--color-fg));
}
.on::after { left: 18px; background: var(--color-accent, var(--color-fg)); }
.off { background: var(--color-bg); }
.off::after { left: 2px; }
.toggle:disabled { opacity: 0.4; cursor: not-allowed; }
</style>
