<script setup lang="ts">
/**
 * CodeBlock
 * Syntax-highlighted code surface. Uses highlight.js for tokenizing and
 * our own theme (./code-theme.css) for coloring — keywords get the accent,
 * strings semantic green, numbers amber, comments muted italic.
 *
 * Languages registered out of the box: js, ts, csharp, vue, html, css, json,
 * bash. Pass lang='auto' (or omit lang) to let highlight.js detect.
 *
 * Editable mode:
 *   Set :readonly="false" to expose an "edit" toggle next to copy. Pressing
 *   it swaps the highlighted view for a plain monospaced textarea. Bind with
 *   v-model:code to receive live updates as the user types — the parent's
 *   variable updates on every keystroke.
 *
 * @prop code     - the source string (use v-model:code for two-way binding)
 * @prop lang     - 'js' | 'ts' | 'csharp' | 'cs' | 'vue' | 'html' | 'css' |
 *                  'json' | 'bash' | 'sh' | 'auto' | (any registered name)
 * @prop filename - shown in the head strip on the left
 * @prop copy     - show the copy button (default true)
 * @prop readonly - lock the code (default true). Set false to enable editing.
 *
 * @event update:code - new value, fires on every input while editing
 *
 * Status: stable | Consumers: showcase, future docs / project surfaces
 */
import { computed, ref } from 'vue'
import hljs, { SUPPORTED_LANGS } from '../_internal/hljs'

import './code-theme.css'

const props = withDefaults(defineProps<{
  code: string
  lang?: string
  filename?: string
  copy?: boolean
  readonly?: boolean
}>(), { copy: true, readonly: true })

const emit = defineEmits<{ 'update:code': [value: string] }>()

const editing = ref(false)

const highlighted = computed(() => {
  if (!props.lang || props.lang === 'auto') {
    return hljs.highlightAuto(props.code, SUPPORTED_LANGS).value
  }
  try {
    return hljs.highlight(props.code, { language: props.lang, ignoreIllegals: true }).value
  } catch {
    return escapeHtml(props.code)
  }
})

function escapeHtml(s: string): string {
  return s.replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;')
}

const hasHead = computed(() =>
  !!props.filename || (!!props.lang && props.lang !== 'auto') || props.copy || !props.readonly
)

const copied = ref(false)
async function doCopy() {
  try {
    await navigator.clipboard.writeText(props.code)
    copied.value = true
    setTimeout(() => { copied.value = false }, 1200)
  } catch { /* clipboard blocked — ignore */ }
}

function onInput(e: Event) {
  emit('update:code', (e.target as HTMLTextAreaElement).value)
}
</script>

<template>
  <div data-ui="code-block" :class="$style.block">
    <div v-if="hasHead" :class="$style.head">
      <span v-if="filename" :class="$style.filename">{{ filename }}</span>
      <span v-if="lang && lang !== 'auto'" :class="$style.lang">{{ lang }}</span>
      <div :class="$style.spacer" />

      <button
        v-if="!readonly"
        type="button"
        :class="[$style.btn, editing && $style.btnOn]"
        @click="editing = !editing"
      >
        {{ editing ? 'done' : 'edit' }}
      </button>

      <button v-if="copy" type="button" :class="$style.btn" @click="doCopy">
        {{ copied ? 'copied' : 'copy' }}
      </button>
    </div>

    <pre v-if="!editing" :class="$style.pre"><code class="hljs" :class="$style.code" v-html="highlighted" /></pre>

    <!-- Edit mode: a transparent textarea overlaid on top of the highlighted
         pre. Both have identical font metrics (same font, size, line-height,
         padding, white-space, tab-size) so the caret in the textarea lines
         up character-for-character with the colored glyphs in the pre below.
         The pre is aria-hidden — the textarea is the real input. -->
    <div v-else :class="$style.editorWrap">
      <pre :class="$style.editorView" aria-hidden="true"><code class="hljs" v-html="highlighted" /> </pre>
      <textarea
        :class="$style.editorInput"
        :value="code"
        spellcheck="false"
        autocorrect="off"
        autocapitalize="off"
        @input="onInput"
      />
    </div>
  </div>
</template>

<style module>
.block {
  border: var(--border);
  border-radius: var(--radius);
  background: var(--color-bg-2, var(--color-bg));
  overflow: hidden;
}

.head {
  display: flex;
  align-items: center;
  gap: var(--space-2);
  padding: var(--space-2) var(--space-3);
  border-bottom: 1px solid var(--color-border-soft, var(--color-border));
  background: var(--color-surface);
}

.filename {
  font-family: var(--font-mono);
  font-size: var(--font-size-sm);
  color: var(--color-fg);
}

.lang {
  font-family: var(--font-mono);
  font-size: var(--font-size-xs);
  text-transform: uppercase;
  letter-spacing: 0.08em;
  color: var(--color-accent);
  padding: 1px var(--space-2);
  border: 1px solid var(--color-accent-edge, var(--color-accent));
  border-radius: var(--radius);
}

.spacer { flex: 1; }

.btn {
  font-family: var(--font-mono);
  font-size: var(--font-size-xs);
  color: var(--color-muted);
  background: transparent;
  border: var(--border);
  border-radius: var(--radius);
  padding: 2px var(--space-2);
  cursor: pointer;
  transition: color 0.12s, border-color 0.12s, background 0.12s;
}
.btn:hover {
  color: var(--color-fg);
  border-color: var(--color-border-hi, var(--color-border));
}
.btnOn {
  color: var(--color-accent);
  border-color: var(--color-accent-edge, var(--color-accent));
  background: var(--color-accent-soft, transparent);
}

.pre {
  margin: 0;
  padding: var(--space-3) var(--space-4);
  overflow-x: auto;
  background: var(--color-bg-2, var(--color-bg));
}

.code {
  font-family: var(--font-mono);
  font-size: var(--font-size-sm);
  line-height: 1.6;
  color: var(--color-text-dim, var(--color-fg));
  background: transparent;
  display: block;
}

/* Edit mode — overlay technique.
   A highlighted <pre> sits underneath; a transparent <textarea> sits on top
   with identical font metrics. The user types into the textarea (caret +
   selection are visible) but the text glyphs themselves are transparent —
   the colored ones come from the pre below. Both reference the same string
   so they stay glyph-for-glyph aligned. */
.editorWrap {
  position: relative;
  background: var(--color-bg-2, var(--color-bg));
}

/* Shared metrics — every property that affects character layout MUST be
   identical between .editorView and .editorInput or the cursor and selection
   will drift from the colored glyphs. */
.editorView,
.editorInput {
  margin: 0;
  padding: var(--space-3) var(--space-4);
  font-family: var(--font-mono);
  font-size: var(--font-size-sm);
  font-weight: 400;
  font-style: normal;
  line-height: 1.6;
  letter-spacing: 0;
  word-spacing: 0;
  tab-size: 2;
  white-space: pre-wrap;
  word-break: break-word;
  border: 0;
  box-sizing: border-box;
}

.editorView {
  display: block;
  pointer-events: none;
  color: var(--color-text-dim, var(--color-fg));
  background: transparent;
  min-height: calc(1.6em * 3);
}
.editorView code {
  background: transparent;
  font: inherit;
  display: block;
}

.editorInput {
  position: absolute;
  inset: 0;
  width: 100%;
  height: 100%;
  background: transparent;
  color: transparent;
  caret-color: var(--color-fg);
  resize: none;
  outline: 0;
  overflow: hidden;
}
.editorInput:focus {
  outline: 2px solid var(--color-accent);
  outline-offset: -2px;
}
.editorInput::selection {
  background: var(--color-accent-soft, oklch(0.80 0.13 var(--accent-hue, 220) / 0.35));
  color: var(--color-fg);
}
.editorInput::-moz-selection {
  background: var(--color-accent-soft, oklch(0.80 0.13 var(--accent-hue, 220) / 0.35));
  color: var(--color-fg);
}
</style>
