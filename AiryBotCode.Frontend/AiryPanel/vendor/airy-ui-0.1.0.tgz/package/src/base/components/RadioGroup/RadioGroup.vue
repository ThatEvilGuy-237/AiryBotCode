<script setup lang="ts">
/**
 * RadioGroup
 * One choice out of a few, as a form value. Real `<input type="radio">`s share a
 * `name`, so arrow-key cycling, disabled-option skipping, "2 of 4" announcements
 * and native form submission come for free — no roving tabindex to get wrong.
 *
 * Reach for this — not `Segmented` — when the choice is a value you save and each
 * option may need a sentence to be understood (`description`). Segmented is a
 * one-word view switch that acts the instant you press it. Over ~6 options, or
 * options that arrive from the server, use `Select`.
 *
 * Inside a `Field`, leave `label` and `hint` off: Field detects the option
 * `<label>`s, switches itself to `role="group"` + `aria-labelledby`, and owns the
 * label / hint / error. This component then drops its own `role="radiogroup"` so
 * there is exactly one named group in the accessibility tree — the canonical
 * fieldset/legend shape — instead of a named group wrapping an unnamed radiogroup.
 *
 * @prop modelValue   - selected option value (use v-model). A value matching no
 *                      option renders as "nothing selected", which is a legal state.
 * @prop options      - the choices. `SelectOption` plus `description` and `mono`.
 * @prop name         - shared radio `name`. Defaults to a generated, hydration-stable
 *                      id. Set it when the group is inside a real submitted <form>.
 * @prop label        - group label (sans). Omit inside a Field.
 * @prop hint         - group guidance, rendered as the mono `//` line. Omit inside a Field.
 * @prop orientation  - 'vertical' (default) or 'horizontal'. Horizontal wraps and
 *                      shares width evenly; keep descriptions short there.
 * @prop variant      - 'surface' (default) bordered option tiles, or 'plain' dot +
 *                      label with no chrome, for two or three short options in a row.
 * @prop showValues   - render each option's raw `value` as a mono chip beside its
 *                      label. For machine values a user has to match to config (`auto`, `eager`).
 * @prop ramp         - the options are an ordered scale: everything below the
 *                      selection gets a quiet accent edge, so the group reads as a dial.
 * @prop required     - quiet mono `required` marker plus `aria-required`.
 * @prop disabled     - disable the whole group. Per-option `disabled` still applies.
 *
 * @slot label  - replaces the label text (the required marker stays).
 * @slot hint   - replaces the hint text (the `//` prefix stays).
 * @slot option - replaces one option's label content. Slot props: { option, checked,
 *                index }. Whatever you render stays the radio's accessible name — the
 *                wrapper that `aria-labelledby` points at is kept for you.
 *
 * Status: new | Consumers: ThatEvilGuyMemory portal accounts (housekeeping / extraction dials)
 */
import { computed, inject, ref } from 'vue'
import type { SelectOption } from '../Select/Select.vue'
import { FIELD_KEY, nextFieldId } from '../Field/keys'

export type RadioGroupOrientation = 'vertical' | 'horizontal'
export type RadioGroupVariant = 'surface' | 'plain'

export interface RadioOption extends SelectOption {
  description?: string
  mono?: boolean
}

const props = withDefaults(defineProps<{
  modelValue: string
  options: RadioOption[]
  name?: string
  label?: string
  hint?: string
  orientation?: RadioGroupOrientation
  variant?: RadioGroupVariant
  showValues?: boolean
  ramp?: boolean
  required?: boolean
  disabled?: boolean
}>(), {
  orientation: 'vertical',
  variant: 'surface',
  showValues: false,
  ramp: false,
  required: false,
  disabled: false,
})

const emit = defineEmits<{ 'update:modelValue': [value: string] }>()

const slots = defineSlots<{
  label?: () => any
  hint?: () => any
  option?: (p: { option: RadioOption; checked: boolean; index: number }) => any
}>()

const uid = nextFieldId()
const field = inject(FIELD_KEY, null)
const host = ref<HTMLElement>()

const inField = computed(() => !!field)
const groupDisabled = computed(() => props.disabled || !!field?.disabled.value)
const groupRequired = computed(() => props.required || !!field?.required.value)
const invalid = computed(() => !!field?.invalid.value)

const hasLabel = computed(() => !!props.label || !!slots.label)
const hasHint = computed(() => !!props.hint || !!slots.hint)
const labelId = `${uid}-label`
const hintId = `${uid}-hint`
const groupName = computed(() => props.name ?? uid)
const selectedIndex = computed(() => props.options.findIndex(o => o.value === props.modelValue))

const optId = (i: number) => `${uid}-o${i}`
const textId = (i: number) => `${uid}-t${i}`
const descId = (i: number) => `${uid}-d${i}`
const valueId = (i: number) => `${uid}-v${i}`

function describedBy(option: RadioOption, i: number): string | undefined {
  const ids = [
    props.showValues ? valueId(i) : null,
    option.description ? descId(i) : null,
  ].filter(Boolean) as string[]
  return ids.length ? ids.join(' ') : undefined
}

function lit(i: number): boolean {
  return props.ramp && selectedIndex.value > 0 && i < selectedIndex.value
}

function select(value: string) {
  if (groupDisabled.value) return
  const option = props.options.find(o => o.value === value)
  if (!option || option.disabled) return
  if (value !== props.modelValue) emit('update:modelValue', value)
}

function focusValue(value: string) {
  const i = props.options.findIndex(o => o.value === value)
  if (i < 0) return
  host.value?.querySelector<HTMLInputElement>(`#${optId(i)}`)?.focus()
}

function onKeydown(event: KeyboardEvent) {
  if (event.key !== 'Home' && event.key !== 'End') return
  const enabled = props.options.filter(o => !o.disabled)
  const target = event.key === 'Home' ? enabled[0] : enabled[enabled.length - 1]
  if (!target || groupDisabled.value) return
  event.preventDefault()
  select(target.value)
  focusValue(target.value)
}

defineExpose({ focusValue })
</script>

<template>
  <div data-ui="radio-group"
    ref="host"
    :class="[
      $style.wrap,
      $style[orientation],
      $style[variant],
      invalid && $style.invalid,
      groupDisabled && $style.disabled,
    ]"
    @keydown="onKeydown"
  >
    <span v-if="hasLabel" :id="labelId" :class="$style.label">
      <slot name="label">{{ label }}</slot>
      <span v-if="groupRequired" :class="$style.req" aria-hidden="true">required</span>
    </span>

    <div
      :class="$style.group"
      :role="inField ? undefined : 'radiogroup'"
      :aria-labelledby="!inField && hasLabel ? labelId : undefined"
      :aria-describedby="!inField && hasHint ? hintId : undefined"
      :aria-orientation="!inField && orientation === 'horizontal' ? 'horizontal' : undefined"
      :aria-required="!inField && groupRequired ? 'true' : undefined"
      :aria-disabled="groupDisabled || undefined"
    >
      <label
        v-for="(o, i) in options"
        :key="o.value"
        :class="[$style.option, lit(i) && $style.lit]"
      >
        <input
          :id="optId(i)"
          type="radio"
          :class="$style.input"
          :name="groupName"
          :value="o.value"
          :checked="o.value === modelValue"
          :disabled="groupDisabled || o.disabled"
          :aria-labelledby="textId(i)"
          :aria-describedby="describedBy(o, i)"
          @change="select(o.value)"
        />
        <span :class="$style.mark" aria-hidden="true" />
        <span :class="$style.body">
          <span :class="$style.head">
            <span :id="textId(i)" :class="[$style.text, o.mono && $style.monoText]">
              <slot name="option" :option="o" :checked="o.value === modelValue" :index="i">{{ o.label }}</slot>
            </span>
            <code v-if="showValues" :id="valueId(i)" :class="$style.value">{{ o.value }}</code>
          </span>
          <span v-if="o.description" :id="descId(i)" :class="$style.desc">{{ o.description }}</span>
        </span>
      </label>
    </div>

    <p v-if="hasHint" :id="hintId" :class="$style.hint">
      <span :class="$style.slashes" aria-hidden="true">//</span>
      <span><slot name="hint">{{ hint }}</slot></span>
    </p>
  </div>
</template>

<style module>
/* Shell */
.wrap {
  display: flex;
  flex-direction: column;
  gap: var(--space-2);
  min-width: 0;
}
.group {
  display: flex;
  flex-direction: column;
  gap: var(--space-2);
  min-width: 0;
}

/* Group label + required marker */
.label {
  font-family: var(--font-family);
  font-size: var(--font-size-sm);
  font-weight: 500;
  color: var(--color-text-dim);
}
.req {
  margin-left: var(--space-2);
  font-family: var(--font-mono);
  font-size: var(--font-size-xs);
  letter-spacing: 0.08em;
  text-transform: uppercase;
  color: var(--color-text-ghost);
}

/* Option tile — borders over fills, accent edge on the selected one */
.option {
  position: relative;
  display: flex;
  align-items: flex-start;
  gap: var(--space-3);
  padding: var(--space-3);
  border: var(--border);
  border-radius: var(--r-2);
  background: var(--color-bg-2);
  cursor: pointer;
  min-width: 0;
  transition: border-color 0.12s ease, background 0.12s ease, box-shadow 0.12s ease;
}
.option:hover { background: var(--color-surface); }
.option:has(.input:checked) {
  border-color: var(--color-accent-edge);
  background: var(--color-surface);
  box-shadow: inset 2px 0 0 var(--color-accent);
}
.option:has(.input:focus-visible) {
  outline: 2px solid var(--color-accent);
  outline-offset: 2px;
}
.option:has(.input:disabled) {
  cursor: not-allowed;
  opacity: 0.45;
  background: var(--color-bg-2);
}

/* Ramp — options below the selection read as a lit ladder */
.lit {
  border-color: var(--color-border-hi);
  box-shadow: inset 2px 0 0 var(--color-accent-edge);
}

/* The real radio, kept focusable and out of the layout */
.input {
  position: absolute;
  top: 0;
  left: 0;
  width: 1px;
  height: 1px;
  margin: 0;
  opacity: 0;
  pointer-events: none;
}

/* Ring + dot */
.mark {
  position: relative;
  flex-shrink: 0;
  width: 14px;
  height: 14px;
  margin-top: 2px;
  border: 1px solid var(--color-border-hi);
  border-radius: 50%;
  background: var(--color-bg);
  transition: border-color 0.12s ease;
}
.mark::after {
  content: '';
  position: absolute;
  inset: 2px;
  border-radius: 50%;
  background: var(--color-accent);
  transform: scale(0);
  opacity: 0;
  transition: transform 0.12s ease, opacity 0.12s ease;
}
.option:hover .input:not(:disabled) + .mark { border-color: var(--color-accent-edge); }
.input:checked + .mark { border-color: var(--color-accent); }
.input:checked + .mark::after {
  transform: scale(1);
  opacity: 1;
  animation: hive-radio-pop 160ms ease-out;
}
.input:focus-visible + .mark { border-color: var(--color-accent); }
@keyframes hive-radio-pop {
  0%   { transform: scale(0.2); }
  60%  { transform: scale(1.15); }
  100% { transform: scale(1); }
}

/* Option content — sans label, mono machine value, dim description */
.body {
  display: flex;
  flex-direction: column;
  gap: var(--space-1);
  min-width: 0;
}
.head {
  display: flex;
  align-items: baseline;
  flex-wrap: wrap;
  gap: var(--space-2);
  min-width: 0;
}
.text {
  font-family: var(--font-family);
  font-size: var(--font-size-sm);
  font-weight: 500;
  color: var(--color-fg);
}
.monoText { font-family: var(--font-mono); }
.value {
  font-family: var(--font-mono);
  font-size: var(--font-size-xs);
  color: var(--color-muted);
  background: var(--color-surface-mute);
  border: var(--border);
  border-radius: var(--r-1);
  padding: 0 var(--space-1);
  transition: color 0.12s ease, border-color 0.12s ease;
}
.option:has(.input:checked) .value {
  color: var(--color-accent);
  border-color: var(--color-accent-edge);
}
.desc {
  font-family: var(--font-family);
  font-size: var(--font-size-xs);
  line-height: 1.5;
  color: var(--color-text-dim);
}

/* Hint — the house `//` engineer line */
.hint {
  display: flex;
  gap: var(--space-2);
  margin: 0;
  font-family: var(--font-mono);
  font-size: var(--font-size-xs);
  line-height: 1.5;
  color: var(--color-muted);
}
.slashes { color: var(--color-text-ghost); flex-shrink: 0; }

/* Horizontal — equal columns that wrap */
.horizontal .group {
  flex-direction: row;
  flex-wrap: wrap;
}
.horizontal .option {
  flex: 1 1 0;
  min-width: 14ch;
}
.horizontal .option:has(.input:checked) { box-shadow: inset 0 2px 0 var(--color-accent); }
.horizontal .lit { box-shadow: inset 0 2px 0 var(--color-accent-edge); }

/* Plain — dot and label only, no chrome */
.plain .group { gap: var(--space-1); }
.plain .option {
  flex: 0 0 auto;
  align-items: center;
  gap: var(--space-2);
  padding: var(--space-1) var(--space-1);
  border: 0;
  border-radius: var(--r-1);
  background: none;
  box-shadow: none;
  min-width: var(--radio-plain-min-w, 0);
  min-height: var(--radio-plain-min-h, auto);
}
.plain .option:hover { background: none; }
.plain .option:has(.input:checked) {
  border: 0;
  background: none;
  box-shadow: none;
}
.plain .mark { margin-top: 0; }
.plain.horizontal .group { gap: var(--space-4); }

/* Invalid — set by a wrapping Field, reached through the ring */
.invalid .input:not(:checked) + .mark { border-color: var(--color-danger); }

/* Disabled group */
.disabled .label,
.disabled .hint,
.disabled .req { opacity: 0.5; }

@media (prefers-reduced-motion: reduce) {
  .option,
  .mark,
  .mark::after,
  .value { transition: none; }
  .input:checked + .mark::after { animation: none; }
}
</style>
