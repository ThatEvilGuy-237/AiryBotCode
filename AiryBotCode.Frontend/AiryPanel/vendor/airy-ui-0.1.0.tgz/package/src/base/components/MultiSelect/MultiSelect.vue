<script setup lang="ts">
/**
 * MultiSelect
 * Pick many values from a list you already have. `v-model` is an array of
 * `SelectOption.value`s, the picks show as hairline mono chips inside the
 * control, and the options live in a bordered popover listbox with a checkable
 * state per row.
 *
 * It is the multi sibling of <Select> and shares its `SelectOption` shape, so a
 * list written for one works in the other. It is NOT <TagInput>: TagInput is for
 * values the user invents (free text, no `options`), MultiSelect is for values
 * you offer. If the user must be able to add a value that is not on the list,
 * that is two controls — a MultiSelect for the offered ones and a TagInput for
 * the invented ones — not one blurred control.
 *
 * The short-list / long-list boundary is automatic and is the main design
 * decision here. Under `searchAfter` options the control is a plain picker and
 * typing jumps to the first matching label, exactly like a native select. At or
 * over it the control gains a real filter input and typing narrows the list.
 * Force either side with `searchable`. If the options are not in memory at all —
 * a server-backed dataset you cannot dump into the DOM — this is the wrong
 * component; fetch and page instead.
 *
 * @prop modelValue     - selected values (v-model). Order is selection order.
 * @prop options        - the options. `hint` is a mono sub-label, `group` starts
 *                        a group heading (keep a group's options together).
 * @prop placeholder    - shown while nothing is selected.
 * @prop searchable     - `'auto'` (default) turns the filter on at `searchAfter`
 *                        options; `true` / `false` force it.
 * @prop searchAfter    - option count at which `'auto'` enables the filter (8).
 * @prop max            - cap the selection. At the cap the unchecked options go
 *                        aria-disabled and the `//` line says so.
 * @prop size           - 'sm' | 'md' control height.
 * @prop disabled       - dim and lock the control.
 * @prop summary        - show the mono `// 3 of 9 selected` line (default true).
 * @prop selectAll      - offer an `all` action in the popover footer.
 * @prop clearable      - offer a `clear` action in the popover footer (default true).
 * @prop chipLimit      - show at most n chips, collapse the rest into `+n more`.
 * @prop empty          - headline when `options` is empty.
 * @prop noMatch        - headline when the filter matches nothing.
 * @prop listMaxHeight  - max height of the popover list before it scrolls.
 * @prop ariaLabel      - accessible name when the control is not inside a <Field>.
 *
 * @event update:modelValue - (string[]) any change
 * @event add               - (value) one option was checked
 * @event remove            - (value) one option was unchecked or its chip removed
 * @event open              - the popover opened
 * @event close             - the popover closed
 *
 * @slot option  - one option row. Slot props: { option, selected, active, blocked }.
 * @slot chip    - one selected chip. Slot props: { option, remove }.
 * @slot empty   - replaces the empty / no-matches state.
 *
 * Status: new | Consumers: catalog, portal-kit MultiSelect, memory portal roles
 */
import { computed, nextTick, onBeforeUnmount, ref, watch } from 'vue'
import Icon from '../Icon/Icon.vue'
import type { SelectOption } from '../Select/Select.vue'

export interface MultiSelectOption extends SelectOption {
  hint?: string
  group?: string
}

const props = withDefaults(defineProps<{
  modelValue: string[]
  options: MultiSelectOption[]
  placeholder?: string
  searchable?: boolean | 'auto'
  searchAfter?: number
  max?: number
  size?: 'sm' | 'md'
  disabled?: boolean
  summary?: boolean
  selectAll?: boolean
  clearable?: boolean
  chipLimit?: number
  empty?: string
  noMatch?: string
  listMaxHeight?: string
  ariaLabel?: string
}>(), {
  placeholder: 'Select…',
  searchable: 'auto',
  searchAfter: 8,
  size: 'md',
  disabled: false,
  summary: true,
  selectAll: false,
  clearable: true,
  chipLimit: 0,
  empty: 'No options',
  noMatch: 'No matches',
  listMaxHeight: '260px',
})

const emit = defineEmits<{
  'update:modelValue': [v: string[]]
  add: [value: string]
  remove: [value: string]
  open: []
  close: []
}>()

const slots = defineSlots<{
  option?: (p: { option: MultiSelectOption, selected: boolean, active: boolean, blocked: boolean }) => any
  chip?: (p: { option: MultiSelectOption, remove: () => void }) => any
  empty?: () => any
}>()

const uid = `hive-ms-${Math.random().toString(36).slice(2, 9)}`
const listId = `${uid}-list`
const summaryId = `${uid}-summary`
const optionId = (i: number) => `${uid}-opt-${i}`

const root = ref<HTMLElement>()
const inputEl = ref<HTMLInputElement>()
const listEl = ref<HTMLElement>()

const open = ref(false)
const query = ref('')
const activeIndex = ref(-1)
const dropUp = ref(false)

let jumpBuffer = ''
let jumpTimer: ReturnType<typeof setTimeout> | undefined

const searchable = computed(() =>
  props.searchable === 'auto' ? props.options.length >= props.searchAfter : props.searchable)

const byValue = computed(() => {
  const map = new Map<string, MultiSelectOption>()
  for (const o of props.options) map.set(o.value, o)
  return map
})

const selected = computed(() =>
  props.modelValue.map(v => byValue.value.get(v) ?? { label: v, value: v }))

const chips = computed(() =>
  props.chipLimit > 0 ? selected.value.slice(0, props.chipLimit) : selected.value)
const hiddenChips = computed(() => selected.value.length - chips.value.length)

const filtered = computed(() => {
  const q = query.value.trim().toLowerCase()
  if (!q) return props.options
  return props.options.filter(o =>
    o.label.toLowerCase().includes(q)
    || o.value.toLowerCase().includes(q)
    || (o.hint?.toLowerCase().includes(q) ?? false))
})

const indexOfValue = computed(() => {
  const map = new Map<string, number>()
  filtered.value.forEach((o, i) => map.set(o.value, i))
  return map
})

const groups = computed(() => {
  const out: { label: string, options: MultiSelectOption[] }[] = []
  for (const o of filtered.value) {
    const label = o.group ?? ''
    const last = out[out.length - 1]
    if (last && last.label === label) last.options.push(o)
    else out.push({ label, options: [o] })
  }
  return out
})

const count = computed(() => props.modelValue.length)
const atLimit = computed(() => props.max !== undefined && count.value >= props.max)

const summaryText = computed(() => {
  const total = props.options.length
  const base = count.value === 0
    ? `none selected · ${total} available`
    : `${count.value} of ${total} selected`
  if (props.max === undefined) return base
  if (atLimit.value) return `${base} · limit ${props.max} reached, remove one to swap`
  return `${base} · up to ${props.max}`
})

function isSelected(value: string) {
  return props.modelValue.includes(value)
}
function isBlocked(option: MultiSelectOption) {
  return !!option.disabled || (atLimit.value && !isSelected(option.value))
}

function idx(option: MultiSelectOption) {
  return indexOfValue.value.get(option.value) ?? -1
}

function openList() {
  if (props.disabled || open.value) return
  open.value = true
  emit('open')
  const first = filtered.value.findIndex(o => isSelected(o.value) && !o.disabled)
  activeIndex.value = first >= 0 ? first : filtered.value.findIndex(o => !o.disabled)
  measure()
  nextTick(scrollActiveIntoView)
}

function closeList(refocus = true) {
  if (!open.value) return
  open.value = false
  query.value = ''
  activeIndex.value = -1
  emit('close')
  if (refocus) inputEl.value?.focus()
}

function toggleList() {
  if (open.value) closeList()
  else openList()
}

function measure() {
  const el = root.value
  if (!el || typeof window === 'undefined') return
  const rect = el.getBoundingClientRect()
  const need = parseInt(props.listMaxHeight, 10) || 260
  dropUp.value = window.innerHeight - rect.bottom < need + 24 && rect.top > window.innerHeight - rect.bottom
}

function scrollActiveIntoView() {
  if (activeIndex.value < 0) return
  const el = listEl.value?.querySelector<HTMLElement>(`#${optionId(activeIndex.value)}`)
  el?.scrollIntoView({ block: 'nearest' })
}

function move(step: number) {
  const list = filtered.value
  if (!list.length) return
  let i = activeIndex.value
  for (let n = 0; n < list.length; n++) {
    i = i + step
    if (i < 0) i = list.length - 1
    if (i >= list.length) i = 0
    if (!list[i].disabled) break
  }
  activeIndex.value = i
  nextTick(scrollActiveIntoView)
}

function edge(to: 'first' | 'last') {
  const list = filtered.value
  const order = to === 'first' ? list.map((_, i) => i) : list.map((_, i) => list.length - 1 - i)
  const found = order.find(i => !list[i].disabled)
  if (found !== undefined) {
    activeIndex.value = found
    nextTick(scrollActiveIntoView)
  }
}

function toggle(option: MultiSelectOption) {
  if (props.disabled || isBlocked(option)) return
  if (isSelected(option.value)) {
    emit('update:modelValue', props.modelValue.filter(v => v !== option.value))
    emit('remove', option.value)
  } else {
    emit('update:modelValue', [...props.modelValue, option.value])
    emit('add', option.value)
  }
  query.value = ''
  inputEl.value?.focus()
}

function remove(value: string) {
  if (props.disabled) return
  emit('update:modelValue', props.modelValue.filter(v => v !== value))
  emit('remove', value)
}

function pickAll() {
  const next = props.options.filter(o => !o.disabled).map(o => o.value)
  emit('update:modelValue', props.max === undefined ? next : next.slice(0, props.max))
  inputEl.value?.focus()
}

function clearAll() {
  emit('update:modelValue', [])
  inputEl.value?.focus()
}

function onControlPointer(event: MouseEvent) {
  if (props.disabled) return
  if ((event.target as HTMLElement).closest('button')) return
  openList()
  inputEl.value?.focus()
}

function typeJump(key: string) {
  clearTimeout(jumpTimer)
  jumpBuffer += key.toLowerCase()
  jumpTimer = setTimeout(() => { jumpBuffer = '' }, 700)
  const found = filtered.value.findIndex(o => !o.disabled && o.label.toLowerCase().startsWith(jumpBuffer))
  if (found >= 0) {
    activeIndex.value = found
    nextTick(scrollActiveIntoView)
  }
}

function onKeydown(event: KeyboardEvent) {
  const key = event.key

  if (key === 'ArrowDown' || key === 'ArrowUp') {
    event.preventDefault()
    if (!open.value) openList()
    else move(key === 'ArrowDown' ? 1 : -1)
    return
  }
  if (key === 'Home' || key === 'End') {
    if (!open.value) return
    event.preventDefault()
    edge(key === 'Home' ? 'first' : 'last')
    return
  }
  if (key === 'Enter') {
    if (!open.value) { event.preventDefault(); openList(); return }
    event.preventDefault()
    const option = filtered.value[activeIndex.value]
    if (option) toggle(option)
    return
  }
  if (key === ' ' && (!searchable.value || query.value === '')) {
    if (!open.value) { event.preventDefault(); openList(); return }
    event.preventDefault()
    const option = filtered.value[activeIndex.value]
    if (option) toggle(option)
    return
  }
  if (key === 'Escape') {
    if (!open.value && !query.value) return
    event.preventDefault()
    event.stopPropagation()
    closeList()
    return
  }
  if (key === 'Tab') {
    if (open.value) closeList(false)
    return
  }
  if (key === 'Backspace' && query.value === '' && count.value) {
    event.preventDefault()
    remove(props.modelValue[count.value - 1])
    return
  }
  if (!searchable.value && key.length === 1 && !event.metaKey && !event.ctrlKey && !event.altKey && key !== ' ') {
    event.preventDefault()
    if (!open.value) openList()
    typeJump(key)
  }
}

function onDocumentPointer(event: PointerEvent) {
  if (root.value?.contains(event.target as Node)) return
  closeList(false)
}

watch(open, (isOpen) => {
  if (typeof document === 'undefined') return
  if (isOpen) {
    document.addEventListener('pointerdown', onDocumentPointer, true)
    window.addEventListener('resize', measure)
  } else {
    document.removeEventListener('pointerdown', onDocumentPointer, true)
    window.removeEventListener('resize', measure)
  }
})

watch(filtered, () => {
  if (!open.value) return
  if (activeIndex.value >= filtered.value.length) activeIndex.value = filtered.value.length - 1
  if (activeIndex.value < 0) activeIndex.value = filtered.value.findIndex(o => !o.disabled)
})

onBeforeUnmount(() => {
  clearTimeout(jumpTimer)
  if (typeof document === 'undefined') return
  document.removeEventListener('pointerdown', onDocumentPointer, true)
  window.removeEventListener('resize', measure)
})

function focus() {
  inputEl.value?.focus()
}

defineExpose({ focus, openList, closeList })
</script>

<template>
  <div data-ui="multi-select" ref="root" :class="[$style.root, $style[size], disabled && $style.disabled]">
    <div
      :class="[$style.control, open && $style.controlOpen, atLimit && $style.atLimit]"
      @mousedown="onControlPointer"
    >
      <TransitionGroup
        tag="span"
        :class="$style.chipflow"
        :enter-active-class="$style.chipEnterActive"
        :enter-from-class="$style.chipEnterFrom"
        :leave-active-class="$style.chipLeaveActive"
        :leave-to-class="$style.chipLeaveTo"
      >
        <span v-for="option in chips" :key="option.value" :class="$style.chip">
          <slot name="chip" :option="option" :remove="() => remove(option.value)">
            <span :class="$style.chipLabel">{{ option.label }}</span>
            <button
              type="button"
              :class="$style.chipX"
              :aria-label="`Remove ${option.label}`"
              :disabled="disabled"
              @click.stop="remove(option.value)"
            >
              <Icon name="close" :size="11" />
            </button>
          </slot>
        </span>
      </TransitionGroup>

      <button
        v-if="hiddenChips > 0"
        type="button"
        :class="$style.more"
        @click.stop="toggleList"
      >
        +{{ hiddenChips }} more
      </button>

      <input
        ref="inputEl"
        :class="$style.input"
        type="text"
        role="combobox"
        autocomplete="off"
        spellcheck="false"
        aria-haspopup="listbox"
        :aria-expanded="open"
        :aria-controls="listId"
        :aria-autocomplete="searchable ? 'list' : 'none'"
        :aria-activedescendant="open && activeIndex >= 0 ? optionId(activeIndex) : undefined"
        :aria-label="ariaLabel"
        :aria-describedby="summary ? summaryId : undefined"
        :readonly="!searchable"
        :disabled="disabled"
        :placeholder="count ? '' : placeholder"
        :value="query"
        @input="query = ($event.target as HTMLInputElement).value; openList()"
        @keydown="onKeydown"
      />

      <button
        type="button"
        :class="[$style.caret, open && $style.caretOpen]"
        tabindex="-1"
        aria-hidden="true"
        :disabled="disabled"
        @click.stop="toggleList"
      >
        <Icon name="chevron-down" :size="14" />
      </button>
    </div>

    <div v-if="open" :class="[$style.popover, dropUp && $style.popoverUp]">
      <ul
        :id="listId"
        ref="listEl"
        :class="$style.list"
        role="listbox"
        aria-multiselectable="true"
        :style="{ maxHeight: listMaxHeight }"
      >
        <template v-for="group in groups" :key="group.label || '_'">
          <li v-if="group.label" :class="$style.group" role="presentation">{{ group.label }}</li>
          <li
            v-for="option in group.options"
            :id="optionId(idx(option))"
            :key="option.value"
            :class="[
              $style.option,
              isSelected(option.value) && $style.on,
              activeIndex === idx(option) && $style.active,
              isBlocked(option) && $style.blocked,
            ]"
            role="option"
            :aria-selected="isSelected(option.value)"
            :aria-disabled="isBlocked(option) || undefined"
            @click="toggle(option)"
            @mousemove="activeIndex = idx(option)"
          >
            <slot
              name="option"
              :option="option"
              :selected="isSelected(option.value)"
              :active="activeIndex === idx(option)"
              :blocked="isBlocked(option)"
            >
              <span :class="$style.box" aria-hidden="true">
                <Icon v-if="isSelected(option.value)" name="check" :size="12" />
              </span>
              <span :class="$style.optionText">
                <span :class="$style.optionLabel">{{ option.label }}</span>
                <span v-if="option.hint" :class="$style.optionHint">{{ option.hint }}</span>
              </span>
            </slot>
          </li>
        </template>

        <li v-if="!filtered.length" :class="$style.none" role="presentation">
          <slot name="empty">
            <span :class="$style.noneTitle">{{ options.length ? noMatch : empty }}</span>
            <span :class="$style.noneHint">
              <span :class="$style.slashes">//</span>
              {{ options.length ? `nothing here matches “${query}” — esc clears the filter` : 'nothing to choose from yet' }}
            </span>
          </slot>
        </li>
      </ul>

      <div v-if="(selectAll || clearable) && options.length" :class="$style.footer">
        <span :class="$style.footerCount">{{ count }} / {{ options.length }}</span>
        <button
          v-if="selectAll"
          type="button"
          :class="$style.action"
          :disabled="count === options.length"
          @click="pickAll"
        >
          all
        </button>
        <button
          v-if="clearable"
          type="button"
          :class="$style.action"
          :disabled="!count"
          @click="clearAll"
        >
          clear
        </button>
      </div>
    </div>

    <p v-if="summary" :id="summaryId" :class="[$style.summary, atLimit && $style.summaryLimit]" role="status">
      <span :class="$style.slashes" aria-hidden="true">//</span>
      <span>{{ summaryText }}</span>
    </p>
  </div>
</template>

<style module>
/* Shell */
.root {
  position: relative;
  display: flex;
  flex-direction: column;
  gap: var(--space-1);
  min-width: 0;
  width: 100%;
}

/* Control — chips + filter input on one wrapping hairline surface */
.control {
  display: flex;
  flex-wrap: wrap;
  align-items: center;
  gap: var(--space-1);
  padding: 3px var(--space-2) 3px var(--space-2);
  background: var(--color-bg);
  border: 1px solid var(--color-border);
  border-radius: var(--radius);
  cursor: text;
  transition: border-color 0.12s ease;
}
.sm .control { min-height: 28px; }
.md .control { min-height: 34px; }
.control:hover { border-color: var(--color-border-hi); }
.controlOpen,
.control:focus-within { border-color: var(--color-accent); }
.atLimit { border-color: var(--color-warn); }
.disabled .control { opacity: 0.5; cursor: not-allowed; }

.chipflow { display: contents; }

/* Chips — hairline mono, square-ish. Rounded filled pills are TagInput's, for
   values the user invented; these are values we offered. */
.chip {
  display: inline-flex;
  align-items: center;
  gap: var(--space-1);
  max-width: 100%;
  padding: 1px var(--space-1) 1px var(--space-2);
  border: 1px solid var(--color-border);
  border-radius: var(--r-1);
  background: var(--color-surface-mute);
  font-family: var(--font-mono);
  font-size: var(--font-size-xs);
  color: var(--color-text-dim);
  overflow: hidden;
}
.chipLabel {
  overflow: hidden;
  text-overflow: ellipsis;
  white-space: nowrap;
}
.chipX {
  display: inline-flex;
  align-items: center;
  padding: 1px;
  border: 0;
  border-radius: var(--r-1);
  background: none;
  color: var(--color-text-ghost);
  cursor: pointer;
}
.chipX:hover { color: var(--color-fg); }
.chipX:focus-visible {
  outline: 1px solid var(--color-accent);
  outline-offset: 1px;
  color: var(--color-fg);
}

.more {
  padding: 1px var(--space-2);
  border: 1px dashed var(--color-border);
  border-radius: var(--r-1);
  background: none;
  font-family: var(--font-mono);
  font-size: var(--font-size-xs);
  color: var(--color-muted);
  cursor: pointer;
}
.more:hover { color: var(--color-fg); border-color: var(--color-border-hi); }
.more:focus-visible { outline: 1px solid var(--color-accent); outline-offset: 1px; }

.input {
  flex: 1 1 4rem;
  min-width: 4rem;
  height: 22px;
  border: 0;
  background: transparent;
  color: var(--color-fg);
  font-family: var(--font-family);
  font-size: var(--font-size-sm);
}
.input:focus { outline: none; }
.input::placeholder { color: var(--color-text-ghost); }
.input:read-only { cursor: pointer; }

.caret {
  display: inline-flex;
  align-items: center;
  margin-left: auto;
  padding: 0;
  border: 0;
  background: none;
  color: var(--color-muted);
  cursor: pointer;
  transition: transform 0.12s ease, color 0.12s ease;
}
.caretOpen { transform: rotate(180deg); color: var(--color-accent); }

/* Popover — bordered surface, no shadow */
.popover {
  position: absolute;
  z-index: 20;
  top: calc(100% + var(--space-1));
  left: 0;
  right: 0;
  display: flex;
  flex-direction: column;
  background: var(--color-surface);
  border: 1px solid var(--color-border-hi);
  border-radius: var(--radius);
  overflow: hidden;
}
.popoverUp {
  top: auto;
  bottom: calc(100% + var(--space-1));
}

.list {
  margin: 0;
  padding: var(--space-1);
  list-style: none;
  overflow-y: auto;
}

.group {
  padding: var(--space-2) var(--space-2) var(--space-1);
  font-family: var(--font-mono);
  font-size: var(--font-size-xs);
  letter-spacing: 0.08em;
  text-transform: uppercase;
  color: var(--color-text-ghost);
}

.option {
  display: flex;
  align-items: center;
  gap: var(--space-2);
  padding: var(--space-1) var(--space-2);
  border: 1px solid transparent;
  border-radius: var(--r-1);
  cursor: pointer;
}
.active {
  border-color: var(--color-accent-edge);
  background: var(--color-surface-hi);
}
.blocked { opacity: 0.45; cursor: not-allowed; }

.box {
  display: inline-flex;
  align-items: center;
  justify-content: center;
  flex-shrink: 0;
  width: 15px;
  height: 15px;
  border: 1px solid var(--color-border-hi);
  border-radius: var(--r-1);
  color: var(--color-bg);
}
.on .box {
  background: var(--color-accent);
  border-color: var(--color-accent);
}

.optionText {
  display: flex;
  flex-direction: column;
  min-width: 0;
}
.optionLabel {
  font-family: var(--font-family);
  font-size: var(--font-size-sm);
  color: var(--color-text-dim);
  overflow: hidden;
  text-overflow: ellipsis;
  white-space: nowrap;
}
.on .optionLabel { color: var(--color-fg); }
.optionHint {
  font-family: var(--font-mono);
  font-size: var(--font-size-xs);
  color: var(--color-text-ghost);
  overflow: hidden;
  text-overflow: ellipsis;
  white-space: nowrap;
}

/* Empty / no-matches — a real state, with the house `//` line */
.none {
  display: flex;
  flex-direction: column;
  gap: 2px;
  padding: var(--space-4) var(--space-2);
  text-align: left;
}
.noneTitle {
  font-family: var(--font-family);
  font-size: var(--font-size-sm);
  color: var(--color-text-dim);
}
.noneHint {
  display: flex;
  gap: var(--space-2);
  font-family: var(--font-mono);
  font-size: var(--font-size-xs);
  color: var(--color-muted);
}

.footer {
  display: flex;
  align-items: center;
  gap: var(--space-3);
  padding: var(--space-1) var(--space-2);
  border-top: 1px solid var(--color-border-soft);
}
.footerCount {
  margin-right: auto;
  font-family: var(--font-mono);
  font-size: var(--font-size-xs);
  color: var(--color-text-ghost);
}
.action {
  padding: 0;
  border: 0;
  background: none;
  font-family: var(--font-mono);
  font-size: var(--font-size-xs);
  color: var(--color-muted);
  cursor: pointer;
}
.action:hover:not(:disabled) { color: var(--color-accent); }
.action:disabled { opacity: 0.4; cursor: not-allowed; }
.action:focus-visible { outline: 1px solid var(--color-accent); outline-offset: 2px; }

/* The `//` engineer line */
.summary {
  display: flex;
  gap: var(--space-2);
  margin: 0;
  font-family: var(--font-mono);
  font-size: var(--font-size-xs);
  line-height: 1.5;
  color: var(--color-muted);
}
.summaryLimit { color: var(--color-warn); }
.slashes { color: var(--color-text-ghost); flex-shrink: 0; }

/* Motion — chips arrive and collapse away, nothing else moves */
.chipEnterActive,
.chipLeaveActive {
  transition: opacity 0.12s ease, transform 0.12s ease, max-width 0.12s ease, padding 0.12s ease;
}
.chipEnterFrom { opacity: 0; transform: translateY(-2px); }
.chipLeaveTo {
  opacity: 0;
  transform: scale(0.92);
  max-width: 0;
  padding-left: 0;
  padding-right: 0;
  border-color: transparent;
}

@media (prefers-reduced-motion: reduce) {
  .chipEnterActive,
  .chipLeaveActive,
  .caret,
  .control { transition: none; }
  .chipEnterFrom, .chipLeaveTo { transform: none; }
}
</style>
