<script setup lang="ts">
/**
 * Tabs — a tab bar. v-model the active value; render content via the default
 * slot, which receives { active }.
 *
 *   <Tabs v-model="tab" :tabs="[{ label:'Prompt', value:'prompt' }]">
 *     <template #default="{ active }"> ...v-if on active... </template>
 *   </Tabs>
 *
 * Status: new
 */
export interface TabItem { label: string; value: string; badge?: string | number }

defineProps<{ modelValue: string; tabs: TabItem[]; label?: string }>()
const emit = defineEmits<{ 'update:modelValue': [v: string] }>()
</script>

<template>
  <div data-ui="tabs">
    <div :class="$style.bar" role="tablist" :aria-label="label">
      <button
        data-ui="tab"
        v-for="t in tabs"
        :key="t.value"
        type="button"
        role="tab"
        :aria-selected="modelValue === t.value"
        :class="[$style.tab, modelValue === t.value && $style.active]"
        @click="emit('update:modelValue', t.value)"
      >
        {{ t.label }}<span v-if="t.badge !== undefined" :class="$style.badge">{{ t.badge }}</span>
      </button>
    </div>
    <slot :active="modelValue" />
  </div>
</template>

<style module>
.bar { display: flex; gap: 2px; border-bottom: 1px solid var(--color-border-soft, var(--color-border)); margin-bottom: var(--space-3); }
.tab { background: none; border: 0; border-bottom: 2px solid transparent; color: var(--color-text-dim, var(--color-muted)); cursor: pointer; padding: var(--space-2) var(--space-3); font-family: var(--font-family); font-size: var(--font-size-sm); display: inline-flex; align-items: center; gap: 6px; }
.tab:hover { color: var(--color-fg); }
.active { color: var(--color-fg); border-bottom-color: var(--color-accent, var(--color-fg)); }
.badge { font-family: var(--font-mono); font-size: 10px; color: var(--color-muted); }
</style>
