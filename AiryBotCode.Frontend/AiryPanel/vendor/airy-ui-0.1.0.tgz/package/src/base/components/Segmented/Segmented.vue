<script setup lang="ts">
/**
 * Segmented — a compact single-choice control: all options visible as a row of
 * buttons, the selected one highlighted. Nicer than a <Select> for 2–4 short,
 * mutually-exclusive choices (e.g. fusion strategy, a filter). Each option may
 * carry a `hint` shown under the row when selected.
 */
export interface SegmentedOption {
  label: string
  value: string
  hint?: string
}

const props = defineProps<{ modelValue: string; options: SegmentedOption[] }>()
const emit = defineEmits<{ 'update:modelValue': [v: string] }>()

const hint = () => props.options.find(o => o.value === props.modelValue)?.hint
</script>

<template>
  <div data-ui="segmented" class="seg-wrap">
    <div class="seg" role="tablist">
      <button
        v-for="o in options"
        :key="o.value"
        type="button"
        role="tab"
        :aria-selected="o.value === modelValue"
        :class="['seg-btn', { active: o.value === modelValue }]"
        @click="emit('update:modelValue', o.value)"
      >
        {{ o.label }}
      </button>
    </div>
    <p v-if="hint()" class="seg-hint">{{ hint() }}</p>
  </div>
</template>

<style scoped>
.seg-wrap { display: flex; flex-direction: column; gap: 4px; }
.seg {
  display: inline-flex; padding: 2px; gap: 2px;
  background: var(--color-bg); border: 1px solid var(--color-border);
  border-radius: var(--radius); width: fit-content;
}
.seg-btn {
  appearance: none; border: 0; cursor: pointer;
  background: transparent; color: var(--color-muted);
  font-family: inherit; font-size: var(--font-size-sm);
  padding: 6px 14px; border-radius: calc(var(--radius) - 2px);
  min-height: var(--segmented-h, auto);
  min-width: var(--segmented-min-w, auto);
  transition: background 0.12s, color 0.12s;
}
.seg-btn:hover { color: var(--color-fg); }
.seg-btn.active { background: var(--segmented-active-bg, var(--color-surface)); color: var(--segmented-active-fg, var(--color-fg)); box-shadow: var(--segmented-active-ring, 0 1px 2px rgba(0,0,0,0.15)); }
.seg-btn:focus-visible { outline: 2px solid var(--color-accent); outline-offset: 1px; }
.seg-hint { margin: 0; font-size: var(--font-size-xs); color: var(--color-muted); }
</style>
