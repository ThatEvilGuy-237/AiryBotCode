/**
 * AppSidebar — the public types a consumer types their own state with.
 *
 * The fold map is the one that matters: it is what you persist. Keys are
 * section fold keys (`name`, or a slug of `label`), values are `true` when the
 * section is *folded shut*. Absent key = the section's own `defaultFolded`, so
 * a fresh cookie is `{}` and every section still opens the way its author
 * intended.
 */
export type SidebarFoldMap = Record<string, boolean>

export type SidebarBadge = string | number | null

/** What a SidebarItem reports up to its section, so a folded header can still speak. */
export interface SidebarItemFacts {
  active: boolean
  badge: SidebarBadge
}
