<script setup lang="ts">
/**
 * Chart · donut design
 * Part-to-whole at a glance, one series, at most `maxSeries` segments — a ring of
 * accent-ramp steps separated by a 2px surface gap, with the total in the middle.
 * Hovering or arrowing a segment swaps the centre for that segment's value and share,
 * so the ring never needs on-arc labels that would collide.
 *
 * Use it when the reader only needs "roughly how is this split". For comparing close
 * values, use the bar design instead.
 *
 * @prop ctx    - plot context handed down by Chart.vue
 * @prop active - hovered/focused segment index, or null
 *
 * Status: new | Consumers: Chart
 */
import { computed } from 'vue'
import type { ChartPlotCtx } from '../types'

const props = defineProps<{ ctx: ChartPlotCtx, active: number | null }>()

const emit = defineEmits<{ active: [index: number | null], point: [index: number, seriesIndex: number] }>()

const GAP = 2

const geometry = computed(() => {
  const box = props.ctx.scale.plot
  const thickness = props.ctx.sparkline ? Math.max(4, props.ctx.thickness / 3) : props.ctx.thickness
  const radius = Math.max(Math.min(box.w, box.h) / 2 - thickness / 2 - 1, 1)
  return {
    cx: box.x + box.w / 2,
    cy: box.y + box.h / 2,
    radius,
    thickness,
    circumference: 2 * Math.PI * radius,
  }
})

const values = computed(() => (props.ctx.series[0]?.values ?? []).map(value => Math.max(value ?? 0, 0)))
const total = computed(() => values.value.reduce((sum, value) => sum + value, 0))

const segments = computed(() => {
  const { circumference } = geometry.value
  if (total.value <= 0) return []
  let offset = 0
  return values.value.map((value, index) => {
    const length = (value / total.value) * circumference
    const drawn = Math.max(length - GAP, 0.5)
    const segment = {
      index,
      value,
      length: drawn,
      offset,
      color: props.ctx.keys[index]?.color ?? 'var(--hive-chart-1)',
      share: Math.round((value / total.value) * 100),
    }
    offset += length
    return segment
  }).filter(segment => segment.value > 0)
})

const center = computed(() => {
  if (props.active !== null && total.value > 0) {
    const value = values.value[props.active] ?? 0
    return {
      label: props.ctx.labels[props.active] ?? props.ctx.center.label,
      value: `${props.ctx.fmt(value)}`,
      share: `${Math.round((value / total.value) * 100)}%`,
    }
  }
  return { label: props.ctx.center.label, value: props.ctx.center.value, share: '' }
})
</script>

<template>
  <g :class="$style.marks">
    <circle
      :class="$style.track"
      :cx="geometry.cx"
      :cy="geometry.cy"
      :r="geometry.radius"
      :stroke-width="geometry.thickness"
      fill="none"
    />
    <g :transform="`rotate(-90 ${geometry.cx} ${geometry.cy})`">
      <circle
        v-for="segment in segments"
        :key="segment.index"
        :class="[$style.segment, active === segment.index && $style.segmentActive]"
        :cx="geometry.cx"
        :cy="geometry.cy"
        :r="geometry.radius"
        :stroke="segment.color"
        :stroke-width="active === segment.index ? geometry.thickness + 4 : geometry.thickness"
        :stroke-dasharray="`${segment.length} ${geometry.circumference - segment.length}`"
        :stroke-dashoffset="-segment.offset"
        fill="none"
        @pointerenter="emit('active', segment.index)"
        @pointerleave="emit('active', null)"
        @click="emit('point', segment.index, 0)"
      />
    </g>

    <text v-if="!ctx.sparkline" :class="$style.value" :x="geometry.cx" :y="geometry.cy" text-anchor="middle">
      {{ center.value }}<tspan v-if="center.share" :class="$style.share"> {{ center.share }}</tspan>
    </text>
    <text v-if="!ctx.sparkline" :class="$style.label" :x="geometry.cx" :y="geometry.cy + 18" text-anchor="middle">
      {{ center.label }}
    </text>
  </g>
</template>

<style module>
.track { stroke: var(--color-border-soft, var(--color-border)); }
.segment {
  pointer-events: stroke;
  cursor: pointer;
  transition: stroke-width 120ms ease;
}
.segmentActive { pointer-events: stroke; }
.value {
  font-family: var(--font-family);
  font-size: var(--font-size-xl);
  font-weight: 600;
  fill: var(--color-fg);
}
.share {
  font-family: var(--font-mono);
  font-size: var(--font-size-sm);
  fill: var(--color-muted);
}
.label {
  font-family: var(--font-mono);
  font-size: var(--font-size-xs);
  letter-spacing: 0.08em;
  text-transform: uppercase;
  fill: var(--color-text-ghost, var(--color-muted));
}

/* The one motion: the ring settles in on mount. */
.marks {
  animation: settle 320ms ease-out both;
  transform-box: fill-box;
  transform-origin: center;
}
@keyframes settle {
  from { opacity: 0; transform: scale(0.965); }
  to { opacity: 1; transform: scale(1); }
}
@media (prefers-reduced-motion: reduce) {
  .marks { animation: none; }
  .segment { transition: none; }
}
</style>
