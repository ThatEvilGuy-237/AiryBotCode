<script setup lang="ts">
/**
 * TileGrid
 * Responsive grid wrapper for <Tile> components.
 * Uses repeat(auto-fit, minmax(min, 1fr)) so tiles reflow to fill width.
 *
 * @prop min - minimum tile width in px before reflow (default 180)
 *
 * Slot: default — one or more <Tile>s
 *
 * Status: stable | Consumers: Patterns
 */
withDefaults(defineProps<{ min?: number }>(), { min: 180 })
</script>

<template>
  <div data-ui="tile-grid"
    :class="$style.grid"
    :style="{ gridTemplateColumns: `repeat(auto-fit, minmax(${min}px, 1fr))` }"
  >
    <slot />
  </div>
</template>

<style module>
.grid {
  display: grid;
  gap: var(--space-3);
  width: 100%;
}
</style>
