<script setup lang="ts">
import Icon from '../Icon/Icon.vue'
/**
 * Drawer — slide-in side panel, teleported to <body>. Slots: header, default,
 * footer. Esc + backdrop close. A roomier alternative to Modal for inspectors.
 *
 * @prop open / side (right | left) / title / width(px)
 * @event close
 *
 * Status: new
 */
import { watch, onBeforeUnmount } from 'vue'

const props = withDefaults(defineProps<{
  open: boolean
  side?: 'right' | 'left'
  title?: string
  width?: number
}>(), { side: 'right', width: 420 })

const emit = defineEmits<{ close: [] }>()

function onKey(e: KeyboardEvent) { if (props.open && e.key === 'Escape') emit('close') }

// Guarded because this runs during setup, which on an SSR host (the Nuxt portal)
// has no window. Without it the immediate watch throws while rendering.
const canListen = () => typeof window !== 'undefined'
watch(() => props.open, (o) => {
  if (!canListen()) return
  if (o) window.addEventListener('keydown', onKey)
  else window.removeEventListener('keydown', onKey)
}, { immediate: true })
onBeforeUnmount(() => { if (canListen()) window.removeEventListener('keydown', onKey) })
</script>

<template>
  <Teleport to="body">
    <div v-if="open" :class="$style.overlay" @click.self="emit('close')">
      <aside data-ui="drawer" :class="[$style.drawer, $style[side]]" :style="{ width: width + 'px' }" role="dialog" aria-modal="true">
        <header v-if="title || $slots.header" :class="$style.head">
          <slot name="header"><span :class="$style.title">{{ title }}</span></slot>
          <button type="button" :class="$style.close" aria-label="Close" @click="emit('close')"><Icon name="x" :size="16" /></button>
        </header>
        <div :class="$style.body"><slot /></div>
        <footer v-if="$slots.footer" :class="$style.foot"><slot name="footer" /></footer>
      </aside>
    </div>
  </Teleport>
</template>

<style module>
.overlay { position: fixed; inset: 0; background: rgba(0,0,0,0.4); z-index: 120; display: flex; }
.drawer { background: var(--color-surface); height: 100%; display: flex; flex-direction: column; max-width: 92vw; box-shadow: 0 0 30px rgba(0,0,0,0.3); }
.right { margin-left: auto; border-left: var(--border); }
.left { margin-right: auto; border-right: var(--border); }
.head { display: flex; align-items: center; gap: var(--space-2); padding: var(--space-3) var(--space-4); border-bottom: 1px solid var(--color-border-soft, var(--color-border)); }
.title { font-weight: 600; flex: 1; min-width: 0; overflow: hidden; text-overflow: ellipsis; white-space: nowrap; }
.close { background: none; border: 0; color: var(--color-muted); cursor: pointer; font-size: 20px; line-height: 1; flex-shrink: 0; }
.close:hover { color: var(--color-fg); }
.body { padding: var(--space-4); overflow: auto; flex: 1; }
.foot { padding: var(--space-3) var(--space-4); border-top: 1px solid var(--color-border-soft, var(--color-border)); display: flex; justify-content: flex-end; gap: var(--space-2); }
</style>
