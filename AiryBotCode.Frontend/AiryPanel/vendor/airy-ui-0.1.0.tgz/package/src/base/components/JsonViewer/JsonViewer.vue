<script setup lang="ts">
import Icon from '../Icon/Icon.vue'
/**
 * JsonViewer — collapsible, colour-tinted JSON tree. Recurses on objects/arrays
 * (self-referencing component). Replaces <pre>{{ JSON.stringify }}</pre> blocks.
 *
 * @prop value       - any JSON-ish value
 * @prop name        - key label (set internally during recursion)
 * @prop depth       - nesting level (internal)
 * @prop defaultOpen - expand objects/arrays at depth 0–1 (default true)
 *
 * Status: new
 */
import { ref, computed } from 'vue'

const props = withDefaults(defineProps<{
  value: unknown
  name?: string
  depth?: number
  defaultOpen?: boolean
}>(), { depth: 0, defaultOpen: true })

const isObject = computed(() => props.value !== null && typeof props.value === 'object')
const isArray = computed(() => Array.isArray(props.value))
const entries = computed<[string, unknown][]>(() => {
  if (!isObject.value) return []
  return isArray.value
    ? (props.value as unknown[]).map((v, i) => [String(i), v])
    : Object.entries(props.value as Record<string, unknown>)
})
const summary = computed(() => (isArray.value ? `[${entries.value.length}]` : `{${entries.value.length}}`))
const open = ref(props.defaultOpen && props.depth < 2)

function preview(v: unknown): string {
  if (v === null) return 'null'
  if (typeof v === 'string') return `"${v}"`
  return String(v)
}
function cls(v: unknown): string {
  if (v === null) return 'null'
  if (typeof v === 'string') return 'str'
  if (typeof v === 'number') return 'num'
  if (typeof v === 'boolean') return 'bool'
  return 'other'
}
</script>

<template>
  <div :data-ui="depth ? undefined : 'json-viewer'" :class="$style.node" :style="{ paddingLeft: depth ? '12px' : '0' }">
    <template v-if="isObject">
      <div :class="$style.row" @click="open = !open">
        <span :class="$style.chev"><Icon :name="open ? 'chevron-down' : 'chevron-right'" :size="12" /></span>
        <span v-if="name !== undefined" :class="$style.key">{{ name }}:</span>
        <span :class="$style.summary">{{ summary }}</span>
      </div>
      <div v-if="open">
        <JsonViewer v-for="[k, v] in entries" :key="k" :value="v" :name="k" :depth="depth + 1" />
      </div>
    </template>
    <div v-else :class="$style.row">
      <span v-if="name !== undefined" :class="$style.key">{{ name }}:</span>
      <span :class="[$style.val, $style[cls(value)]]">{{ preview(value) }}</span>
    </div>
  </div>
</template>

<style module>
.node { font-family: var(--font-mono); font-size: var(--font-size-xs); line-height: 1.6; }
.row { display: flex; gap: 6px; align-items: baseline; }
.chev { color: var(--color-muted); cursor: pointer; width: 10px; flex-shrink: 0; }
.summary { color: var(--color-muted); cursor: pointer; }
.key { color: var(--color-accent, var(--color-fg)); }
.val { word-break: break-word; }
.str { color: var(--color-ok, #46c489); }
.num { color: var(--color-warn, #e0b24a); }
.bool { color: var(--color-accent, #7c6af7); }
.null { color: var(--color-muted); }
.other { color: var(--color-fg); }
</style>
