<script setup lang="ts">
import Icon from '../Icon/Icon.vue'
/**
 * TraceRow
 * One step of an agent / LLM run log. Stack them as direct siblings and the
 * hairline in the gutter joins them into a single sequence — the first row's
 * rail starts at its own marker, the last row's ends at it, so a stack reads as
 * a run and not as a pile of cards.
 *
 * The status is the only colour on the row: a 2px segment on that hairline, plus
 * a dotted chip. Everything a machine produced — seq, timestamp, duration, ids,
 * paths, the detail body — is mono; only the step title is sans. `running` is a
 * real state, not a spinner bolted on: the segment travels, the chip stays lit
 * and the row reports `aria-busy`.
 *
 * The detail body is collapsed by default. A run log is scanned first and read
 * second, so the head (title, aside, path, time, duration, status) is the row and
 * the body is opt-in. Set `defaultOpen` on the steps you know the reader wants —
 * usually the failing one.
 *
 * @prop title        - step name, in sans. Required unless the `title` slot is used
 * @prop status       - 'ok' | 'warn' | 'fail' | 'running' | 'skipped' | 'idle'.
 *                      Aliases (success, completed, fallback, degraded, failed,
 *                      error, started, queued, …) are normalised for the colour,
 *                      while the chip keeps the exact word you passed
 * @prop label        - override the chip text without touching the colour
 * @prop seq          - step number for the head; plain numbers pad to 2 digits
 * @prop meta         - mono `// …` aside under the title (the house sub-caption)
 * @prop path         - a file path / route / id. Truncates in the middle of the
 *                      directory part, keeps the last segment whole, carries the
 *                      full value as a title, and unfolds when the row expands
 * @prop time         - timestamp, already formatted by the caller
 * @prop duration     - milliseconds; formats itself (`0ms`, `179ms`, `2.0s`,
 *                      `90.0s`). A string is printed verbatim
 * @prop detail       - long monospace body. Capped at `detailLines` and scrolls
 * @prop detailLines  - visible line cap for `detail` (default 16)
 * @prop collapsible  - set false to keep the body permanently open (default true)
 * @prop defaultOpen  - start expanded, when uncontrolled
 * @prop open         - controlled expansion (v-model:open). `null` (the default)
 *                      leaves the row in charge of its own state
 * @prop dense        - tighter row, for long traces and drawers
 * @prop first        - force "first in the sequence" rail; only needed when the
 *                      rows are not real DOM siblings
 * @prop last         - force "last in the sequence" rail
 *
 * @event update:open - expansion changed
 * @event toggle      - (open) the same change, for logging a reader's drill-down
 *
 * Slots:
 *   default - detail body; replaces nothing, renders under `detail`
 *   title   - rich title
 *   meta    - rich version of the `meta` aside (still mono, still `//`)
 *   actions - head-right controls, before the status chip
 *
 * Status: new | Consumers: catalog, portal-kit (TraceRow), memory portal /activity
 */
import { computed, ref, useSlots, watch } from 'vue'
import { formatTraceDuration, nextTraceRowId } from './trace'

export type TraceStatus = 'ok' | 'warn' | 'fail' | 'running' | 'skipped' | 'idle'

export type TraceStatusInput = TraceStatus
  | 'success' | 'succeeded' | 'completed' | 'done' | 'pass'
  | 'fallback' | 'warning' | 'degraded' | 'partial'
  | 'failed' | 'error' | 'danger' | 'rejected'
  | 'started' | 'busy' | 'active' | 'live' | 'pending'
  | 'skip' | 'skipped' | 'ignored'
  | 'queued' | 'waiting' | 'neutral'
  | (string & {})

const props = withDefaults(defineProps<{
  title?: string
  status?: TraceStatusInput
  label?: string
  seq?: number | string
  meta?: string
  path?: string
  time?: string
  duration?: number | string | null
  detail?: string
  detailLines?: number
  collapsible?: boolean
  defaultOpen?: boolean
  open?: boolean | null
  dense?: boolean
  first?: boolean
  last?: boolean
}>(), {
  detailLines: 16,
  collapsible: true,
  defaultOpen: false,
  open: null,
  dense: false,
  first: false,
  last: false,
})

const emit = defineEmits<{
  'update:open': [open: boolean]
  toggle: [open: boolean]
}>()

const STATUS_ALIASES: Record<string, TraceStatus> = {
  ok: 'ok', success: 'ok', succeeded: 'ok', completed: 'ok', done: 'ok', pass: 'ok',
  warn: 'warn', warning: 'warn', fallback: 'warn', degraded: 'warn', partial: 'warn',
  fail: 'fail', failed: 'fail', error: 'fail', danger: 'fail', rejected: 'fail',
  running: 'running', started: 'running', busy: 'running', active: 'running', live: 'running',
  skipped: 'skipped', skip: 'skipped', ignored: 'skipped',
  idle: 'idle', queued: 'idle', waiting: 'idle', pending: 'idle', neutral: 'idle',
}

const bodyId = nextTraceRowId()

const slots = useSlots()

const statusKey = computed<TraceStatus>(() => {
  const raw = (props.status ?? '').toString().trim().toLowerCase()
  return STATUS_ALIASES[raw] ?? 'idle'
})

const chipText = computed(() => props.label ?? props.status ?? '')
const showChip = computed(() => Boolean(chipText.value))
const running = computed(() => statusKey.value === 'running')

const seqText = computed(() => {
  if (props.seq === undefined || props.seq === null) return ''
  return typeof props.seq === 'number' ? String(props.seq).padStart(2, '0') : String(props.seq)
})

const durationText = computed(() => {
  const value = props.duration
  if (value === undefined || value === null || value === '') return ''
  const base = typeof value === 'number' ? formatTraceDuration(value) : value
  return running.value ? `${base}…` : base
})

const pathParts = computed(() => {
  const value = props.path ?? ''
  if (!value) return null
  const cut = value.lastIndexOf('/')
  if (cut < 0) return { dir: '', base: value }
  return { dir: value.slice(0, cut + 1), base: value.slice(cut + 1) }
})

const hasBody = computed(() => Boolean(props.detail || slots.default))
const canToggle = computed(() => props.collapsible && hasBody.value)

const controlled = computed(() => props.open !== null && props.open !== undefined)

const internalOpen = ref(props.open ?? props.defaultOpen)
watch(() => props.open, (value) => { if (value !== null && value !== undefined) internalOpen.value = value })

const expanded = computed(() => (hasBody.value && !canToggle.value) || internalOpen.value)

function toggle() {
  if (!canToggle.value) return
  const next = !internalOpen.value
  if (!controlled.value) internalOpen.value = next
  emit('update:open', next)
  emit('toggle', next)
}

function onKeydown(event: KeyboardEvent) {
  if (event.key !== 'ArrowRight' && event.key !== 'ArrowLeft') return
  if (!canToggle.value) return
  const wantOpen = event.key === 'ArrowRight'
  if (wantOpen === internalOpen.value) return
  event.preventDefault()
  toggle()
}
</script>

<template>
  <article data-ui="trace-row"
    :class="[
      $style.row,
      $style[statusKey],
      dense && $style.dense,
      first && $style.first,
      last && $style.last,
      expanded && $style.isOpen,
    ]"
    :aria-busy="running || undefined"
  >
    <div :class="$style.gutter" aria-hidden="true">
      <span :class="$style.seg" />
    </div>

    <div :class="$style.content">
      <component
        :is="canToggle ? 'button' : 'div'"
        :type="canToggle ? 'button' : undefined"
        :class="[$style.head, canToggle && $style.headBtn]"
        :aria-expanded="canToggle ? expanded : undefined"
        :aria-controls="canToggle ? bodyId : undefined"
        @click="toggle"
        @keydown="onKeydown"
      >
        <span :class="$style.lead">
          <span v-if="canToggle" :class="$style.chev" aria-hidden="true"><Icon name="chevron-right" :size="12" /></span>
          <span v-if="seqText" :class="$style.seq">{{ seqText }}</span>
          <span :class="$style.title"><slot name="title">{{ title }}</slot></span>
        </span>

        <span :class="$style.end">
          <slot name="actions" />
          <time v-if="time" :class="$style.time">{{ time }}</time>
          <span v-if="durationText" :class="$style.duration">{{ durationText }}</span>
          <span v-if="showChip" :class="$style.chip">
            <span :class="$style.dot" aria-hidden="true" />
            <span :class="$style.chipText">{{ chipText }}</span>
          </span>
        </span>
      </component>

      <div v-if="meta || $slots.meta" :class="$style.meta">
        <span aria-hidden="true">//&nbsp;</span><slot name="meta">{{ meta }}</slot>
      </div>

      <div v-if="pathParts" :class="$style.path" :title="path">
        <span :class="$style.pathDir">{{ pathParts.dir }}</span><span :class="$style.pathBase">{{ pathParts.base }}</span>
      </div>

      <div
        v-if="hasBody"
        :id="bodyId"
        :class="[$style.bodyWrap, expanded && $style.bodyOpen]"
      >
        <div :class="$style.body">
          <pre
            v-if="detail"
            :class="$style.detail"
            :style="{ '--hive-trace-lines': detailLines }"
          >{{ detail }}</pre>
          <slot />
        </div>
      </div>
    </div>
  </article>
</template>

<style module>
.row {
  --hive-trace-color: var(--color-text-ghost);
  --hive-trace-node: 10px;
  --hive-trace-gap: var(--space-5);
  display: grid;
  grid-template-columns: var(--space-4) minmax(0, 1fr);
  gap: var(--space-3);
  text-align: left;
}
.dense {
  --hive-trace-node: 9px;
  --hive-trace-gap: var(--space-3);
  gap: var(--space-2);
}

.ok      { --hive-trace-color: var(--color-ok); }
.warn    { --hive-trace-color: var(--color-warn); }
.fail    { --hive-trace-color: var(--color-danger); }
.running { --hive-trace-color: var(--color-accent); }
.skipped { --hive-trace-color: var(--color-text-ghost); }
.idle    { --hive-trace-color: var(--color-border-hi); }

/* The rail: a hairline through the whole row, with the status as a 2px segment. */
.gutter {
  position: relative;
  display: flex;
  justify-content: center;
}
.gutter::before {
  content: '';
  position: absolute;
  top: 0;
  bottom: 0;
  width: 1px;
  background: var(--color-border);
}
.row:first-child .gutter::before,
.first .gutter::before { top: calc(var(--hive-trace-node) - 8px); }
.row:last-child .gutter::before,
.last .gutter::before { bottom: calc(100% - var(--hive-trace-node) - 8px); }

.seg {
  position: absolute;
  top: calc(var(--hive-trace-node) - 8px);
  width: 2px;
  height: 16px;
  background: var(--hive-trace-color);
  border-radius: 1px;
}
.skipped .seg {
  height: 6px;
  top: calc(var(--hive-trace-node) - 3px);
}
.idle .seg { opacity: 0.6; }

.content {
  min-width: 0;
  padding-bottom: var(--hive-trace-gap);
}
.row:last-child .content,
.last .content { padding-bottom: 0; }

.head {
  display: flex;
  flex-wrap: wrap;
  align-items: baseline;
  justify-content: space-between;
  gap: var(--space-1) var(--space-3);
  width: 100%;
  margin: 0;
  padding: 0;
  border: 0;
  background: none;
  color: inherit;
  font: inherit;
  text-align: left;
}
.headBtn { cursor: pointer; }
.headBtn:focus-visible {
  outline: 2px solid var(--color-accent);
  outline-offset: 3px;
  border-radius: var(--r-1);
}
.headBtn:hover .title { color: var(--color-accent); }

.lead {
  display: inline-flex;
  align-items: baseline;
  gap: var(--space-2);
  flex: 1 1 14rem;
  min-width: 0;
}

/* The one motion: the chevron turns down as the body opens. */
.chev {
  flex: none;
  color: var(--color-text-ghost);
  font-size: var(--font-size-xs);
  line-height: 1.35;
  transition: transform 120ms ease, color 120ms ease;
}
.isOpen .chev {
  transform: rotate(90deg);
  color: var(--color-muted);
}

.seq {
  flex: none;
  font-family: var(--font-mono);
  font-size: var(--font-size-xs);
  font-variant-numeric: tabular-nums;
  color: var(--color-text-ghost);
}

.title {
  min-width: 0;
  font-family: var(--font-family);
  font-size: var(--font-size-base);
  font-weight: 600;
  line-height: 1.35;
  color: var(--color-fg);
  overflow-wrap: anywhere;
  transition: color 120ms ease;
}
.dense .title { font-size: var(--font-size-sm); }
.skipped .title { color: var(--color-text-dim); }

.end {
  display: inline-flex;
  align-items: center;
  gap: var(--space-2);
  flex: 0 0 auto;
}

.time,
.duration {
  font-family: var(--font-mono);
  font-size: var(--font-size-xs);
  font-variant-numeric: tabular-nums;
  white-space: nowrap;
  color: var(--color-muted);
}
.duration { color: var(--color-text-ghost); }

/* Status = a dot in a hairline chip. No fills, no glow. */
.chip {
  display: inline-flex;
  align-items: center;
  gap: var(--space-1);
  flex: none;
  padding: 1px var(--space-2);
  border: 1px solid var(--color-border);
  border-radius: var(--r-1);
  background: var(--color-surface-mute);
}
.dot {
  width: 6px;
  height: 6px;
  border-radius: 50%;
  background: var(--hive-trace-color);
  flex: none;
}
.skipped .dot { background: none; box-shadow: inset 0 0 0 1px var(--color-text-ghost); }
.chipText {
  font-family: var(--font-mono);
  font-size: var(--font-size-xs);
  line-height: 1.5;
  color: var(--color-text-dim);
  white-space: nowrap;
}

.meta {
  margin-top: var(--space-1);
  font-family: var(--font-mono);
  font-size: var(--font-size-xs);
  line-height: 1.5;
  color: var(--color-muted);
  overflow-wrap: anywhere;
}

/* Paths keep their last segment whole and lose the middle of the directory. */
.path {
  display: flex;
  min-width: 0;
  overflow: hidden;
  margin-top: var(--space-1);
  font-family: var(--font-mono);
  font-size: var(--font-size-xs);
  line-height: 1.5;
  color: var(--color-text-ghost);
}

/* The directory gives up its width 100x faster than the basename, so the tail
   stays readable until it alone is wider than the row — then it clips too. */
.pathDir {
  flex: 0 100 auto;
  overflow: hidden;
  text-overflow: ellipsis;
  white-space: nowrap;
  min-width: 0;
}
.pathBase {
  flex: 0 1 auto;
  overflow: hidden;
  text-overflow: ellipsis;
  white-space: nowrap;
  min-width: 0;
  color: var(--color-text-dim);
}
.isOpen .path { flex-wrap: wrap; }
.isOpen .pathDir {
  overflow: visible;
  white-space: normal;
  word-break: break-all;
}

.bodyWrap {
  display: grid;
  grid-template-rows: 0fr;
  visibility: hidden;
  transition: grid-template-rows 160ms ease;
}
.bodyOpen {
  grid-template-rows: 1fr;
  visibility: visible;
}
.body {
  overflow: hidden;
  min-height: 0;
  font-size: var(--font-size-sm);
  line-height: 1.55;
  color: var(--color-text-dim);
}
.bodyOpen .body { padding-top: var(--space-2); }

.detail {
  margin: 0;
  max-height: calc(var(--hive-trace-lines, 16) * 1.5em);
  overflow: auto;
  padding: var(--space-2) var(--space-3);
  border: var(--border);
  border-radius: var(--r-2);
  background: var(--color-bg-2);
  font-family: var(--font-mono);
  font-size: var(--font-size-xs);
  line-height: 1.5;
  color: var(--color-text-dim);
  white-space: pre-wrap;
  overflow-wrap: anywhere;
  tab-size: 2;
}

/* Running is a state, not a spinner: the segment travels its own rail. */
.running .seg { animation: hiveTraceRun 1400ms ease-in-out infinite; }
.running .dot { animation: hiveTracePulse 1400ms ease-in-out infinite; }

@keyframes hiveTraceRun {
  0%   { transform: translateY(-4px) scaleY(0.6); }
  50%  { transform: translateY(4px) scaleY(1); }
  100% { transform: translateY(-4px) scaleY(0.6); }
}
@keyframes hiveTracePulse {
  0%, 100% { opacity: 1; }
  50%      { opacity: 0.35; }
}

@media (prefers-reduced-motion: reduce) {
  .chev,
  .title { transition: none; }
  .bodyWrap { transition: none; }
  .running .seg,
  .running .dot { animation: none; }
}
</style>
