<script setup lang="ts">
/**
 * Tooltip — hover/focus bubble around its slotted trigger. CSS-only.
 *
 * @prop text / placement (top | bottom)
 *
 * Status: new
 */
withDefaults(defineProps<{ text: string; placement?: 'top' | 'bottom' }>(), { placement: 'top' })
</script>

<template>
  <span data-ui="tooltip" :class="$style.wrap" tabindex="0">
    <slot />
    <span data-ui="tooltip-bubble" :class="[$style.bubble, $style[placement]]" role="tooltip">{{ text }}</span>
  </span>
</template>

<style module>
.wrap { position: relative; display: inline-flex; }
.bubble { position: absolute; left: 50%; transform: translateX(-50%) scale(0.96); white-space: nowrap; background: var(--color-fg); color: var(--color-bg); font-size: var(--font-size-xs); padding: 4px 8px; border-radius: var(--radius); opacity: 0; pointer-events: none; transition: opacity 0.12s, transform 0.12s; z-index: 50; }
.top { bottom: calc(100% + 6px); }
.bottom { top: calc(100% + 6px); }
.wrap:hover .bubble, .wrap:focus-visible .bubble { opacity: 1; transform: translateX(-50%) scale(1); }
</style>
