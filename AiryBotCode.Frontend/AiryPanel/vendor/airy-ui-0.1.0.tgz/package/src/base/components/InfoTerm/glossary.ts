/**
 * glossary — the shared vocabulary registry behind <InfoTerm>.
 *
 * A plain module-level Map, not a Vue provider: an app calls `defineGlossary()`
 * once (in `main.ts`, a Nuxt plugin, or any module the pages import) and every
 * <InfoTerm> anywhere in the tree resolves against it. No provider to install,
 * no injection key to thread through layouts, works in SSR and in tests.
 *
 * Register a term once; every call site picks up the wording, and rewording the
 * definition later is a one-line change instead of a grep.
 *
 * Status: new | Consumers: InfoTerm
 */

export interface GlossaryEntry {
  term: string
  def: string
  kind?: 'prose' | 'machine'
  more?: string
  href?: string
  aka?: string[]
}

export type GlossaryInput = string | (Omit<GlossaryEntry, 'term'> & { term?: string })

const registry = new Map<string, GlossaryEntry>()

function normalize(key: string): string {
  return key.trim().toLowerCase()
}

export function defineGlossary(entries: Record<string, GlossaryInput>): void {
  for (const [key, value] of Object.entries(entries)) {
    const entry: GlossaryEntry = typeof value === 'string'
      ? { term: key, def: value }
      : { ...value, term: value.term ?? key }
    registry.set(normalize(key), entry)
    for (const alias of entry.aka ?? []) registry.set(normalize(alias), entry)
  }
}

export function glossaryEntry(key: string): GlossaryEntry | undefined {
  return registry.get(normalize(key))
}

export function hasGlossaryEntry(key: string): boolean {
  return registry.has(normalize(key))
}

export function glossaryEntries(): GlossaryEntry[] {
  return [...new Set(registry.values())].sort((a, b) => a.term.localeCompare(b.term))
}

export function clearGlossary(): void {
  registry.clear()
}
