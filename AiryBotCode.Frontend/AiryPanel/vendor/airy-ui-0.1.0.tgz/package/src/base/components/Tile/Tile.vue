<script setup lang="ts">
/**
 * Tile
 * Single mini metric tile: label / value / sub stack with an accent left bar.
 * Drop into <TileGrid> for a responsive row of stats.
 *
 * @prop label   - small uppercase mono label
 * @prop value   - the main number / string (mono, large)
 * @prop sub     - small mono caption under the value
 * @prop variant - default | ok | warn | err — colors the value
 * @prop trend   - up | down | none — small arrow before the sub line
 *
 * Status: stable | Consumers: Patterns
 */
withDefaults(defineProps<{
  label: string
  value: string | number
  sub?: string
  variant?: 'default' | 'ok' | 'warn' | 'err'
  trend?: 'up' | 'down' | 'none'
}>(), { variant: 'default', trend: 'none' })
</script>

<template>
  <div data-ui="tile" :class="$style.tile" role="group" :aria-label="label">
    <div :class="$style.label" aria-hidden="true">{{ label }}</div>
    <div :class="[$style.value, $style[variant]]">{{ value }}</div>
    <div v-if="sub" :class="[$style.sub, trend !== 'none' && $style[trend]]">{{ sub }}</div>
  </div>
</template>

<style module>
.tile {
  display: flex;
  flex-direction: column;
  gap: 4px;
  padding: var(--space-3) var(--space-4);
  background: var(--color-surface);
  border: var(--border);
  border-radius: var(--radius);
  box-shadow: inset 3px 0 0 0 var(--color-accent, var(--color-fg));
}
.label {
  font-family: var(--tile-label-font, var(--font-mono));
  font-size: var(--tile-label-size, var(--font-size-xs));
  letter-spacing: var(--tile-label-tracking, 0.08em);
  text-transform: var(--tile-label-transform, uppercase);
  color: var(--color-text-ghost, var(--color-muted));
}
.value {
  font-family: var(--font-mono);
  font-size: var(--tile-value-size, 24px);
  font-weight: 500;
  color: var(--color-fg);
  line-height: 1.1;
}
.value.ok   { color: var(--color-ok); }
.value.warn { color: var(--color-warn); }
.value.err  { color: var(--color-danger); }
.sub {
  font-family: var(--tile-sub-font, var(--font-mono));
  font-size: var(--font-size-xs);
  color: var(--color-muted);
}
.sub.up::before   { content: '↑ '; color: var(--color-ok); }
.sub.down::before { content: '↓ '; color: var(--color-warn); }
</style>
