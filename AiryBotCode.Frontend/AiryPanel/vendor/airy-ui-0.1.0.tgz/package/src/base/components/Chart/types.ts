/**
 * Chart — shared types.
 *
 * Series colour is deliberately NOT a categorical palette: Hive has one accent.
 * A series either *means* something (tone) or it is just identity, in which case
 * it takes a step of the one-hue accent ramp plus a dash pattern and a mark shape.
 * See Chart.vue for the full reasoning and the validated numbers.
 */

export type ChartVariant = 'line' | 'area' | 'bar' | 'donut'

export type ChartTone = 'accent' | 'ok' | 'warn' | 'danger' | 'plan'

export type ChartFormat = 'auto' | 'int' | 'compact' | 'currency' | 'percent'

export type ChartShape = 'circle' | 'square' | 'triangle' | 'diamond'

export type ChartValue = number | null | undefined

export interface ChartSeries {
  name: string
  data: ChartValue[]
  tone?: ChartTone
  quiet?: boolean
  band?: ChartValue[]
}

export interface ChartSeriesView {
  name: string
  slot: number
  tone: ChartTone | null
  color: string
  dash: string
  shape: ChartShape
  values: (number | null)[]
  total: number
  quiet: boolean
  band: (number | null)[] | null
}

export interface ChartBox {
  x: number
  y: number
  w: number
  h: number
}

export interface ChartScale {
  plot: ChartBox
  count: number
  band: number
  min: number
  max: number
  zeroY: number
  x: (index: number) => number
  y: (value: number) => number
}

export interface ChartKey {
  name: string
  slot: number
  tone: ChartTone | null
  color: string
  dash: string
  shape: ChartShape
}

export interface ChartPlotCtx {
  scale: ChartScale
  series: ChartSeriesView[]
  keys: ChartKey[]
  labels: string[]
  stacked: boolean
  barWidth: number
  thickness: number
  sparkline: boolean
  center: { label: string, value: string }
  fmt: (value: number) => string
  endLabels: boolean
}

export interface ChartHover {
  index: number
  label: string
  entries: { name: string, value: number | null, text: string }[]
}

export interface ChartPointEvent {
  seriesIndex: number
  series: string
  index: number
  label: string
  value: number | null
}
