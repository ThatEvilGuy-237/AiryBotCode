import type { InjectionKey, ComputedRef } from 'vue'

export interface SettingRowContext {
  labelId: ComputedRef<string>
  descriptionId: ComputedRef<string | undefined>
}

export const SETTING_ROW_KEY: InjectionKey<SettingRowContext> = Symbol('hive:setting-row')

let seq = 0

export function nextSettingRowId(): string {
  seq += 1
  return `hive-setting-${seq}`
}
