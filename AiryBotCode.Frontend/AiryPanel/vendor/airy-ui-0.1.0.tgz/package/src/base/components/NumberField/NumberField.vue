<script setup lang="ts">
/**
 * NumberField
 * A numeric input that always speaks `number | null` — never a numeric string.
 * That is the whole reason it exists: a plain `<input type="number">` hands you
 * `event.target.value` as a string, and a component that forwards that string
 * makes `v-model.number` a silent no-op in the consumer, so the setting reads
 * back as `"30"` and quietly never applies. This component parses once, emits a
 * `number` (or `null` when the box is empty), and nothing else.
 *
 * Typing is not clamped. `min`/`max` are applied on commit — blur, Enter, or a
 * step — because clamping every keystroke makes "10" impossible to type in a
 * field whose `min` is 2. While a draft is out of range the offending bound is
 * shown as a small mono tag, so the clamp that is about to happen is visible
 * before it happens.
 *
 * Put it in a `<Field>` for the label / hint / error shell: Field finds this
 * component's `<input>`, gives it an id and points its `<label for>` at it, and
 * this component reads Field's context back so an error state reaches the
 * control border. Do not pass `label` to both.
 *
 * @prop modelValue     - the value (use v-model). `null` means empty, which is
 *                        not the same thing as 0.
 * @prop min            - lower bound. Applied on commit and to steps, and
 *                        published as `aria-valuemin`.
 * @prop max            - upper bound. Same rules as `min`.
 * @prop step           - Arrow-key / stepper increment (default 1).
 * @prop bigStep        - PageUp / PageDown and Shift+Arrow increment
 *                        (default `step * 10`).
 * @prop precision      - decimals kept on commit, e.g. 2 for money. Omit to
 *                        keep exactly what was typed.
 * @prop decimal        - the decimal mark shown: '.' (default) or ',' for
 *                        Belgian and Dutch money. Typing accepts both.
 * @prop unit           - suffix rendered inside the control (`%`, `ms`, `days`,
 *                        `$/1M`). It is decoration plus `aria-valuetext`; it is
 *                        never part of the value.
 * @prop allowEmpty     - let the field be empty and emit `null` (default true).
 *                        With `false`, leaving it empty commits `min ?? 0`.
 * @prop steppers       - show the hover/focus stepper chevrons (default true).
 *                        Arrow keys work either way.
 * @prop placeholder    - placeholder text. Defaults to the mono em dash when
 *                        `allowEmpty`, so "unset" reads differently from "0".
 * @prop align          - 'auto' (default: right when there is a unit, else
 *                        left), 'left' or 'right'.
 * @prop width          - CSS width of the input box (default '9ch'). Numeric
 *                        fields should be as wide as their widest number, not
 *                        as wide as the form.
 * @prop block          - fill the container instead of being content-sized.
 * @prop size           - 'sm' | 'md' (default 'md').
 * @prop selectOnFocus  - select the whole value on focus, for fields that get
 *                        replaced rather than edited (default false).
 * @prop readonly       - display-only, still focusable and still announced.
 * @prop disabled       - disabled.
 * @prop id             - force the input id. Leave it off inside a `<Field>`.
 * @prop name           - form field name.
 * @prop ariaLabel      - accessible name when there is no `<Field>` label.
 *
 * @event update:modelValue - `number | null`, on every parseable keystroke
 *                            (unclamped) and on every commit (clamped).
 * @event change            - `number | null`, on commit only. Use this to save.
 *
 * @slot unit - replaces the unit suffix.
 *
 * Status: new | Consumers: portal-kit NumberField, ThatEvilGuyMemory portal settings
 */
import { computed, inject, nextTick, ref, watch } from 'vue'
import Icon from '../Icon/Icon.vue'
import { FIELD_KEY } from '../Field/keys'

export type NumberFieldAlign = 'auto' | 'left' | 'right'
export type NumberFieldSize = 'sm' | 'md'

const props = withDefaults(defineProps<{
  modelValue: number | null
  min?: number
  max?: number
  step?: number
  bigStep?: number
  precision?: number
  decimal?: '.' | ','
  unit?: string
  allowEmpty?: boolean
  steppers?: boolean
  placeholder?: string
  align?: NumberFieldAlign
  width?: string
  block?: boolean
  size?: NumberFieldSize
  selectOnFocus?: boolean
  readonly?: boolean
  disabled?: boolean
  id?: string
  name?: string
  ariaLabel?: string
}>(), {
  step: 1,
  decimal: '.',
  allowEmpty: true,
  steppers: true,
  align: 'auto',
  width: '9ch',
  block: false,
  size: 'md',
  selectOnFocus: false,
  readonly: false,
  disabled: false,
})

const emit = defineEmits<{
  'update:modelValue': [value: number | null]
  change: [value: number | null]
}>()

const slots = defineSlots<{ unit?: () => any }>()

const field = inject(FIELD_KEY, null)

const el = ref<HTMLInputElement>()
const draft = ref('')
const focused = ref(false)
const bump = ref<'up' | 'down'>()

const invalid = computed(() => field?.invalid.value ?? false)
const inert = computed(() => props.disabled || props.readonly)
const hasUnit = computed(() => !!props.unit || !!slots.unit)
const bigStep = computed(() => props.bigStep ?? props.step * 10)

const decimals = computed(() => {
  if (props.precision != null) return props.precision
  return Math.max(fractionDigits(props.step), fractionDigits(bigStep.value))
})

const align = computed(() => {
  if (props.align !== 'auto') return props.align
  return hasUnit.value ? 'right' : 'left'
})

const placeholder = computed(() => {
  if (props.placeholder != null) return props.placeholder
  return props.allowEmpty ? '—' : undefined
})

const inputMode = computed(() => {
  const negative = props.min == null || props.min < 0
  return decimals.value === 0 && !negative ? 'numeric' : 'decimal'
})

const display = computed(() => (focused.value ? draft.value : format(props.modelValue)))
const parsed = computed(() => (focused.value ? parse(draft.value) : props.modelValue))
const unparsed = computed(() => focused.value && draft.value.trim() !== '' && parsed.value === null)

const overMax = computed(() => props.max != null && parsed.value != null && parsed.value > props.max)
const underMin = computed(() => props.min != null && parsed.value != null && parsed.value < props.min)
const bound = computed(() => {
  if (overMax.value) return `max ${format(props.max!)}`
  if (underMin.value) return `min ${format(props.min!)}`
  return ''
})

const atMin = computed(() => props.min != null && props.modelValue != null && props.modelValue <= props.min)
const atMax = computed(() => props.max != null && props.modelValue != null && props.modelValue >= props.max)

const valueText = computed(() => {
  if (props.modelValue == null) return props.allowEmpty ? 'empty' : undefined
  return props.unit ? `${format(props.modelValue)} ${props.unit}` : undefined
})

function fractionDigits(n: number): number {
  if (!Number.isFinite(n)) return 0
  const s = String(n)
  const dot = s.indexOf('.')
  return dot === -1 ? 0 : s.length - dot - 1
}

function parse(raw: string): number | null {
  let s = raw.trim()
  if (!s) return null
  s = s.replace(/[−‒–—―]/g, '-')
  s = s.replace(/[\s   ']/g, '')
  s = s.replace(/[^0-9eE.,+-]/g, '')
  const comma = s.lastIndexOf(',')
  const dot = s.lastIndexOf('.')
  if (comma > -1 && dot > -1) {
    if (comma > dot) s = s.replace(/\./g, '').replace(',', '.')
    else s = s.replace(/,/g, '')
  } else if (comma > -1) {
    s = (s.match(/,/g) ?? []).length > 1 ? s.replace(/,/g, '') : s.replace(',', '.')
  }
  if (s === '' || s === '-' || s === '+' || s === '.' || s === '-.') return null
  const n = Number(s)
  return Number.isFinite(n) ? n : null
}

function round(n: number): number {
  const d = decimals.value
  if (d <= 0) return props.precision === 0 ? Math.round(n) : n
  return Number(n.toFixed(Math.min(d, 15)))
}

function clamp(n: number): number {
  let out = n
  if (props.min != null) out = Math.max(props.min, out)
  if (props.max != null) out = Math.min(props.max, out)
  return out
}

function format(n: number | null | undefined): string {
  if (n == null) return ''
  const s = props.precision != null ? n.toFixed(props.precision) : String(n)
  return props.decimal === ',' ? s.replace('.', ',') : s
}

function push(v: number | null) {
  if (v !== props.modelValue) emit('update:modelValue', v)
}

function commit(v: number | null) {
  const changed = v !== props.modelValue
  if (changed) emit('update:modelValue', v)
  draft.value = format(v)
  emit('change', v)
}

function onInput() {
  if (inert.value) return
  draft.value = el.value?.value ?? ''
  if (draft.value.trim() === '') {
    if (props.allowEmpty) push(null)
    return
  }
  const n = parse(draft.value)
  if (n !== null) push(n)
}

function onPaste(e: ClipboardEvent) {
  if (inert.value) return
  const text = e.clipboardData?.getData('text')
  if (text == null) return
  e.preventDefault()
  const n = parse(text)
  if (n === null) return
  draft.value = format(round(n))
  push(round(n))
}

function onFocus() {
  focused.value = true
  draft.value = format(props.modelValue)
  if (props.selectOnFocus && !inert.value) nextTick(() => el.value?.select())
}

function onBlur() {
  focused.value = false
  settle()
}

function settle() {
  if (props.readonly || props.disabled) return
  const raw = draft.value.trim()
  if (raw === '') {
    commit(props.allowEmpty ? null : clamp(round(props.min ?? 0)))
    return
  }
  const n = parse(raw)
  commit(n === null ? props.modelValue : clamp(round(n)))
}

function step(dir: 1 | -1, big = false) {
  if (inert.value) return
  const amount = (big ? bigStep.value : props.step) * dir
  const next = props.modelValue == null
    ? clamp(round(props.min ?? 0))
    : clamp(round(props.modelValue + amount))
  if (next !== props.modelValue) {
    emit('update:modelValue', next)
    emit('change', next)
  }
  draft.value = format(next)
  tick(dir)
}

function jump(to: 'min' | 'max') {
  const target = to === 'min' ? props.min : props.max
  if (inert.value || target == null) return
  if (target !== props.modelValue) {
    emit('update:modelValue', target)
    emit('change', target)
  }
  draft.value = format(target)
  tick(to === 'min' ? -1 : 1)
}

let bumpTimer: ReturnType<typeof setTimeout> | undefined
function tick(dir: 1 | -1) {
  bump.value = undefined
  clearTimeout(bumpTimer)
  nextTick(() => {
    bump.value = dir === 1 ? 'up' : 'down'
    bumpTimer = setTimeout(() => { bump.value = undefined }, 200)
  })
}

let holdDelay: ReturnType<typeof setTimeout> | undefined
let holdRepeat: ReturnType<typeof setInterval> | undefined
let repeated = false
function hold(dir: 1 | -1) {
  release()
  repeated = false
  holdDelay = setTimeout(() => {
    repeated = true
    holdRepeat = setInterval(() => step(dir), 70)
  }, 420)
}
function release() {
  clearTimeout(holdDelay)
  clearInterval(holdRepeat)
  holdDelay = undefined
  holdRepeat = undefined
}
function tap(dir: 1 | -1) {
  if (repeated) { repeated = false; return }
  step(dir)
}

function onKeydown(e: KeyboardEvent) {
  if (e.key === 'ArrowUp') { e.preventDefault(); step(1, e.shiftKey) }
  else if (e.key === 'ArrowDown') { e.preventDefault(); step(-1, e.shiftKey) }
  else if (e.key === 'PageUp') { e.preventDefault(); step(1, true) }
  else if (e.key === 'PageDown') { e.preventDefault(); step(-1, true) }
  else if (e.key === 'Home' && props.min != null) { e.preventDefault(); jump('min') }
  else if (e.key === 'End' && props.max != null) { e.preventDefault(); jump('max') }
  else if (e.key === 'Enter') settle()
  else if (e.key === 'Escape') draft.value = format(props.modelValue)
}

watch(() => props.modelValue, v => {
  if (!focused.value) draft.value = format(v)
})

watch(() => props.precision, () => {
  if (!focused.value) draft.value = format(props.modelValue)
})

draft.value = format(props.modelValue)

defineExpose({
  focus: () => el.value?.focus(),
  select: () => el.value?.select(),
  stepUp: (big = false) => step(1, big),
  stepDown: (big = false) => step(-1, big),
})
</script>

<template>
  <div data-ui="number-field"
    :class="[
      $style.wrap,
      $style[size],
      block && $style.block,
      focused && $style.focused,
      invalid && $style.invalid,
      disabled && $style.disabled,
      readonly && $style.readonly,
    ]"
  >
    <input
      ref="el"
      :id="id"
      type="text"
      role="spinbutton"
      autocomplete="off"
      spellcheck="false"
      :class="[$style.input, $style[align], unparsed && $style.bad]"
      :style="{ width: block ? undefined : width }"
      :name="name"
      :value="display"
      :placeholder="placeholder"
      :inputmode="inputMode"
      :disabled="disabled"
      :readonly="readonly"
      :data-bump="bump"
      :aria-label="ariaLabel"
      :aria-valuenow="modelValue ?? undefined"
      :aria-valuemin="min"
      :aria-valuemax="max"
      :aria-valuetext="valueText"
      :aria-readonly="readonly || undefined"
      @input="onInput"
      @paste="onPaste"
      @focus="onFocus"
      @blur="onBlur"
      @keydown="onKeydown"
    />

    <span v-if="hasUnit" :class="$style.unit" aria-hidden="true">
      <slot name="unit">{{ unit }}</slot>
    </span>

    <span v-if="bound" :class="$style.bound" role="status">{{ bound }}</span>

    <span v-if="steppers" :class="$style.steppers">
      <button
        type="button"
        tabindex="-1"
        aria-hidden="true"
        :class="$style.stepBtn"
        :disabled="inert || atMax"
        @pointerdown="hold(1)"
        @pointerup="release"
        @pointerleave="release"
        @pointercancel="release"
        @click="tap(1)"
      >
        <Icon name="chevron-up" :size="11" />
      </button>
      <button
        type="button"
        tabindex="-1"
        aria-hidden="true"
        :class="$style.stepBtn"
        :disabled="inert || atMin"
        @pointerdown="hold(-1)"
        @pointerup="release"
        @pointerleave="release"
        @pointercancel="release"
        @click="tap(-1)"
      >
        <Icon name="chevron-down" :size="11" />
      </button>
    </span>
  </div>
</template>

<style module>
/* Shell — one hairline box, accent only on the focus ring */
.wrap {
  display: inline-flex;
  align-items: stretch;
  gap: var(--space-2);
  min-width: 0;
  padding-right: var(--space-1);
  background: var(--color-surface-mute, var(--color-bg));
  border: 1px solid var(--color-border);
  border-radius: var(--radius);
  transition: border-color 0.12s ease;
}
.wrap:hover:not(.disabled) { border-color: var(--color-border-hi, var(--color-border)); }
.focused {
  border-color: var(--color-accent);
  outline: 1px solid var(--color-accent-edge);
  outline-offset: 0;
}
.invalid { border-color: var(--color-danger); }
.invalid.focused { outline-color: var(--color-danger); }
.disabled { opacity: 0.5; }
.readonly { background: var(--color-bg); }
.block { display: flex; width: 100%; }
.sm { height: 28px; }
.md { height: var(--input-h, 34px); }

/* The value — mono and tabular so digits do not jitter as they change */
.input {
  flex: 1 1 auto;
  min-width: 0;
  border: 0;
  background: none;
  padding: 0 0 0 var(--space-3);
  color: var(--color-fg);
  font-family: var(--font-mono);
  font-variant-numeric: tabular-nums;
  letter-spacing: 0;
}
.sm .input { font-size: var(--font-size-sm); }
.md .input { font-size: var(--font-size-base); }
.input:focus { outline: none; }
.input:disabled { cursor: not-allowed; }
.input::placeholder { color: var(--color-text-ghost); }
.left { text-align: left; }
.right { text-align: right; }
.bad { color: var(--color-danger); }

/* Unit suffix — muted mono, part of the control, never part of the value */
.unit {
  display: inline-flex;
  align-items: center;
  flex-shrink: 0;
  font-family: var(--font-mono);
  font-size: var(--font-size-xs);
  color: var(--color-muted);
  white-space: nowrap;
  pointer-events: none;
}

/* The bound about to be applied on commit */
.bound {
  display: inline-flex;
  align-items: center;
  flex-shrink: 0;
  padding-left: var(--space-2);
  border-left: 1px solid var(--color-border-soft, var(--color-border));
  font-family: var(--font-mono);
  font-size: var(--font-size-xs);
  color: var(--color-warn);
  white-space: nowrap;
}

/* Steppers — hairline ghosts that keep their space but only show on hover/focus */
.steppers {
  display: flex;
  flex-direction: column;
  flex-shrink: 0;
  width: 16px;
  margin: var(--space-1) 0;
  opacity: 0;
  transition: opacity 0.12s ease;
}
.wrap:hover .steppers,
.focused .steppers { opacity: 1; }
.disabled .steppers { display: none; }
.stepBtn {
  flex: 1 1 50%;
  display: inline-flex;
  align-items: center;
  justify-content: center;
  padding: 0;
  border: 0;
  background: none;
  color: var(--color-text-ghost);
  cursor: pointer;
}
.stepBtn:hover:not(:disabled) { color: var(--color-accent); }
.stepBtn:disabled { color: var(--color-border); cursor: not-allowed; }

/* One motion: the value nudges in the direction it just stepped */
.input[data-bump='up'] { animation: nf-up 140ms ease-out; }
.input[data-bump='down'] { animation: nf-down 140ms ease-out; }
@keyframes nf-up {
  from { transform: translateY(2px); opacity: 0.6; }
  to   { transform: none; opacity: 1; }
}
@keyframes nf-down {
  from { transform: translateY(-2px); opacity: 0.6; }
  to   { transform: none; opacity: 1; }
}

@media (prefers-reduced-motion: reduce) {
  .wrap, .steppers { transition: none; }
  .input[data-bump='up'],
  .input[data-bump='down'] { animation: none; }
}
</style>
