<script setup lang="ts">
/**
 * Slider
 * Range input with a label strip and a live value readout. Use for bounded
 * numeric settings (thresholds, weights, ratios) where the exact number
 * matters less than the relative position.
 *
 * @prop modelValue - current value (use v-model)
 * @prop min        - lower bound (default 0)
 * @prop max        - upper bound (default 1)
 * @prop step       - increment (default 0.01)
 * @prop label      - optional caption shown above the track
 * @prop format     - optional fn to render the value readout (default: toString)
 * @prop disabled   - disables interaction
 *
 * @event update:modelValue - new value, fires on every drag tick
 *
 * Status: stable | Consumers: Chronos-Mind/frontend (CatcherForm)
 */
import { computed } from 'vue'

const props = withDefaults(defineProps<{
  modelValue: number
  min?: number
  max?: number
  step?: number
  label?: string
  format?: (v: number) => string
  disabled?: boolean
}>(), { min: 0, max: 1, step: 0.01 })

const emit = defineEmits<{ 'update:modelValue': [value: number] }>()

const readout = computed(() =>
  props.format ? props.format(props.modelValue) : String(props.modelValue)
)

// Fill the track up to the current value so the thumb has a visible "progress"
// behind it. Percentage of the [min,max] span.
const fillPct = computed(() => {
  const span = props.max - props.min
  if (span <= 0) return 0
  return Math.min(100, Math.max(0, ((props.modelValue - props.min) / span) * 100))
})

function onInput(e: Event) {
  emit('update:modelValue', Number((e.target as HTMLInputElement).value))
}
</script>

<template>
  <div data-ui="slider" :class="$style.wrap">
    <div v-if="label" :class="$style.head">
      <span :class="$style.label">{{ label }}</span>
      <span :class="$style.value">{{ readout }}</span>
    </div>
    <input
      type="range"
      :class="$style.range"
      :style="{ '--fill': fillPct + '%' }"
      :min="min"
      :max="max"
      :step="step"
      :value="modelValue"
      :disabled="disabled"
      @input="onInput"
    />
  </div>
</template>

<style module>
.wrap { display: flex; flex-direction: column; gap: var(--space-2); }

.head { display: flex; align-items: baseline; justify-content: space-between; }
.label { font-size: var(--font-size-sm); color: var(--color-muted); }
.value {
  font-family: var(--font-mono);
  font-size: var(--font-size-sm);
  color: var(--color-accent, var(--color-fg));
  font-weight: 600;
}

/* Track: a thin rounded bar, filled to --fill with the accent, rest is bg. */
.range {
  -webkit-appearance: none;
  appearance: none;
  width: 100%;
  height: 6px;
  border-radius: 3px;
  background: linear-gradient(
    to right,
    var(--color-accent, var(--color-fg)) 0%,
    var(--color-accent, var(--color-fg)) var(--fill),
    var(--color-bg) var(--fill),
    var(--color-bg) 100%
  );
  border: 1px solid var(--color-border-hi, var(--color-border));
  outline: none;
  cursor: pointer;
}
.range:disabled { opacity: 0.4; cursor: not-allowed; }

.range::-webkit-slider-thumb {
  -webkit-appearance: none;
  appearance: none;
  width: 16px;
  height: 16px;
  border-radius: 50%;
  background: var(--color-accent, var(--color-fg));
  border: 2px solid var(--color-surface, var(--color-bg));
  cursor: pointer;
}
.range::-moz-range-thumb {
  width: 16px;
  height: 16px;
  border-radius: 50%;
  background: var(--color-accent, var(--color-fg));
  border: 2px solid var(--color-surface, var(--color-bg));
  cursor: pointer;
}
.range:focus-visible {
  outline: 2px solid var(--color-accent);
  outline-offset: 2px;
}
</style>
