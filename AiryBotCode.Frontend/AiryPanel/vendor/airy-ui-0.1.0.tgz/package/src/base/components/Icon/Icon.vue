<script setup lang="ts">
/**
 * Icon
 * Outline icon from the curated Lucide set. Monochrome — it inherits
 * `currentColor`, so it takes whatever color its context sets (sit it in body
 * text → --color-fg; wrap it in an accent-colored span → --color-accent). That
 * means it re-themes for free when the accent hue changes.
 *
 * @prop name   - icon name from the curated set (see `iconNames` / the showcase)
 * @prop size   - px diameter (default 16)
 * @prop stroke - stroke width (default 1.75 — a touch lighter than lucide's 2)
 *
 * Status: new | Consumers: available for future use
 */
import { ICONS, type IconName } from './icons'

withDefaults(defineProps<{
  name: IconName
  size?: number
  stroke?: number
}>(), { size: 16, stroke: 1.75 })
</script>

<template>
  <component data-ui="icon"
    :is="ICONS[name]"
    :size="size"
    :stroke-width="stroke"
    :class="$style.icon"
    aria-hidden="true"
  />
</template>

<style module>
.icon {
  display: inline-block;
  vertical-align: middle;
  flex-shrink: 0;
  color: currentColor;
}
</style>
