<script setup lang="ts">
/**
 * StatusDot
 * Small colored circle for state. Communicates status without text.
 *
 * @prop variant - ok | warn | err | off | live (default 'off')
 * @prop size    - px diameter (default 8)
 *
 * Status: stable | Consumers: Patterns
 */
withDefaults(defineProps<{
  variant?: 'ok' | 'warn' | 'err' | 'off' | 'live'
  size?: number
}>(), { variant: 'off', size: 8 })
</script>

<template>
  <span data-ui="status-dot"
    :class="[$style.dot, $style[variant]]"
    :style="{ width: `${size}px`, height: `${size}px` }"
    aria-hidden="true"
  />
</template>

<style module>
.dot {
  display: inline-block;
  border-radius: 50%;
  background: var(--color-muted);
  flex-shrink: 0;
}
.ok   { background: var(--color-ok); }
.warn { background: var(--color-warn); }
.err  { background: var(--color-danger); }
.off  { background: var(--color-text-ghost, var(--color-muted)); }
.live { background: var(--color-accent); }
</style>
