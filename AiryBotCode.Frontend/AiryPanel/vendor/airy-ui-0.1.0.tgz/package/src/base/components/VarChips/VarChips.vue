<script setup lang="ts">
/**
 * VarChips — a labeled row of clickable variable chips. Clicking one emits the
 * exact `{{$token}}` to insert, so users add template variables (user id,
 * session id, the user/AI message, …) without typing them and fat-fingering the
 * name. Pair with the unknown-variable check in the consumer to flag typos.
 */
export interface VarItem {
  /** What gets inserted, e.g. "{{$user_id}}" or a literal like "global". */
  token: string
  /** Friendly label shown on the chip, e.g. "User ID". */
  label: string
  /** Optional tooltip explaining the variable. */
  desc?: string
}

defineProps<{ vars: VarItem[]; label?: string }>()
const emit = defineEmits<{ insert: [token: string] }>()
</script>

<template>
  <div data-ui="var-chips" class="varchips">
    <span class="vc-label">{{ label ?? 'Insert:' }}</span>
    <button
      v-for="v in vars"
      :key="v.token"
      type="button"
      class="vc-chip"
      :title="v.desc ?? v.token"
      @click="emit('insert', v.token)"
    >
      {{ v.label }}
      <code class="vc-tok">{{ v.token }}</code>
    </button>
  </div>
</template>

<style scoped>
.varchips { display: flex; flex-wrap: wrap; align-items: center; gap: var(--space-1, 4px) var(--space-2); }
.vc-label { font-family: var(--font-mono); font-size: var(--font-size-xs); color: var(--color-muted); text-transform: uppercase; letter-spacing: 0.06em; }
.vc-chip {
  display: inline-flex; align-items: center; gap: 6px; cursor: pointer;
  font-family: inherit; font-size: var(--font-size-xs); color: var(--color-fg);
  background: var(--color-surface); border: 1px solid var(--color-border);
  border-radius: var(--radius); padding: 3px 8px; transition: border-color 0.12s, background 0.12s;
}
.vc-chip:hover { border-color: var(--color-accent, var(--color-border-hi, var(--color-border))); background: var(--color-accent-soft, var(--color-bg)); }
.vc-tok { font-family: var(--font-mono); font-size: 0.92em; color: var(--color-accent, var(--color-muted)); }
</style>
