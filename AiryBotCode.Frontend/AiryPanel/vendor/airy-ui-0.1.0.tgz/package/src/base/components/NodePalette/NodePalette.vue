<script setup lang="ts">
import Icon from '../Icon/Icon.vue'
/**
 * NodePalette
 * Slide-in panel anchored to the right edge of its positioned parent.
 * Lists draggable items (node types). Pointer-based drag (no HTML5 DnD).
 *
 * The palette doesn't own the drag lifecycle — it only handles pointerdown
 * + the movement threshold. Once an item drag is confirmed, it emits
 * `start-drag(item, event)` and the consumer hands the event off to a
 * FlowCanvas (which then runs the rest of the drag).
 *
 * @prop open    - whether the panel is visible. Bind to a ref in the parent.
 * @prop items   - PaletteItem[] to render as draggable cards.
 * @prop title   - panel header text. Default 'Add node'.
 * @prop width   - panel width in px. Default 280.
 *
 * @event close       - close button clicked. Parent flips `open`.
 * @event start-drag  - an item drag confirmed (passed the movement
 *                       threshold). Payload: (item, PointerEvent).
 *
 * Status: new | Consumers: Neural-Spine FlowEditorPage
 */
import { exceedsThreshold } from '../../composables/useSortable'
import type { PaletteItem } from '../FlowCanvas/types'

withDefaults(defineProps<{
  open: boolean
  items: PaletteItem[]
  title?: string
  width?: number
}>(), {
  title: 'Add node',
  width: 280,
})

const emit = defineEmits<{
  close: []
  'start-drag': [item: PaletteItem, event: PointerEvent]
}>()

// — Per-pointerdown threshold tracking. We listen on window so the user can
//   drag the item outside the palette before crossing the threshold. —
interface Pending { item: PaletteItem; originX: number; originY: number }
let pending: Pending | null = null

function onItemPointerDown(e: PointerEvent, item: PaletteItem) {
  pending = { item, originX: e.clientX, originY: e.clientY }
  window.addEventListener('pointermove', onPendingMove)
  window.addEventListener('pointerup',   onPendingUp)
  window.addEventListener('pointercancel', onPendingUp)
}

function onPendingMove(e: PointerEvent) {
  if (!pending) return
  if (!exceedsThreshold(e.clientX, e.clientY, pending.originX, pending.originY)) return
  emit('start-drag', pending.item, e)
  teardown()
}

function onPendingUp() { teardown() }

function teardown() {
  pending = null
  window.removeEventListener('pointermove', onPendingMove)
  window.removeEventListener('pointerup',   onPendingUp)
  window.removeEventListener('pointercancel', onPendingUp)
}
</script>

<template>
  <Transition data-ui="node-palette" :name="$style.slide">
    <aside
      v-if="open"
      :class="$style.panel"
      :style="{ width: width + 'px' }"
      role="dialog"
      aria-label="Add node"
    >
      <header :class="$style.head">
        <span :class="$style.title">{{ title }}</span>
        <button
          type="button"
          :class="$style.closeBtn"
          aria-label="Close palette"
          @click="emit('close')"
        ><Icon name="x" :size="14" /></button>
      </header>

      <div :class="$style.body">
        <p :class="$style.hint">
          <span :class="$style.comment">// drag onto the canvas</span>
        </p>
        <ul :class="$style.list">
          <li
            v-for="item in items"
            :key="item.id"
            :class="$style.item"
            @pointerdown="onItemPointerDown($event, item)"
          >
            <div :class="$style.itemHead">
              <span :class="$style.itemLabel">{{ item.label }}</span>
              <span :class="$style.itemType">{{ item.nodeType }}</span>
            </div>
            <p v-if="item.description" :class="$style.itemDesc">{{ item.description }}</p>
          </li>
        </ul>
      </div>
    </aside>
  </Transition>
</template>

<style module>
.panel {
  position: absolute;
  top: 0;
  right: 0;
  bottom: 0;
  background: var(--color-bg-2, var(--color-surface));
  border-left: var(--border);
  display: flex;
  flex-direction: column;
  z-index: 4;
  box-shadow: -8px 0 24px oklch(0 0 0 / 0.25);
  box-sizing: border-box;
}

.head {
  display: flex;
  align-items: center;
  gap: var(--space-3);
  padding: var(--space-3) var(--space-4);
  border-bottom: var(--border);
  flex-shrink: 0;
}

.title { flex: 1; font-weight: 600; font-size: var(--font-size-base); }

.closeBtn {
  background: transparent;
  border: 0;
  color: var(--color-text-dim, var(--color-muted));
  font-size: var(--font-size-lg);
  line-height: 1;
  cursor: pointer;
  padding: var(--space-1) var(--space-2);
  border-radius: var(--radius);
}
.closeBtn:hover { color: var(--color-fg); background: var(--color-surface-hi, var(--color-surface)); }

.body {
  flex: 1;
  overflow-y: auto;
  padding: var(--space-3) var(--space-4);
  display: flex;
  flex-direction: column;
  gap: var(--space-3);
}

.hint { margin: 0; }
.comment {
  font-family: var(--font-mono);
  font-size: var(--font-size-xs);
  color: var(--color-muted);
}

.list {
  list-style: none;
  margin: 0;
  padding: 0;
  display: flex;
  flex-direction: column;
  gap: var(--space-2);
}

.item {
  border: var(--border);
  border-radius: var(--radius);
  padding: var(--space-2) var(--space-3);
  background: var(--color-surface);
  cursor: grab;
  user-select: none;
  touch-action: none;
  display: flex;
  flex-direction: column;
  gap: var(--space-1);
  transition: border-color 0.12s, background 0.12s;
}

.item:hover {
  border-color: var(--color-border-hi, var(--color-border));
  background: var(--color-surface-hi, var(--color-surface));
}
.item:active { cursor: grabbing; }

.itemHead {
  display: flex;
  align-items: baseline;
  justify-content: space-between;
  gap: var(--space-2);
}

.itemLabel { font-weight: 600; font-size: var(--font-size-sm); }

.itemType {
  font-family: var(--font-mono);
  font-size: var(--font-size-xs);
  color: var(--color-muted);
  text-transform: uppercase;
  letter-spacing: 0.06em;
}

.itemDesc {
  margin: 0;
  font-size: var(--font-size-xs);
  color: var(--color-text-dim, var(--color-muted));
  line-height: 1.4;
}

.slide-enter-from, .slide-leave-to { transform: translateX(100%); opacity: 0; }
.slide-enter-active, .slide-leave-active { transition: transform 0.18s ease-out, opacity 0.18s ease-out; }
.slide-enter-to, .slide-leave-from { transform: translateX(0); opacity: 1; }
</style>
