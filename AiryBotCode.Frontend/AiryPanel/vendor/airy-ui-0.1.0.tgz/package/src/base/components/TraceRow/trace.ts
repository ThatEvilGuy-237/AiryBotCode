/**
 * The run-log duration format, kept here so pages that show the same numbers in a
 * Table cell or a DescriptionList print them identically to the TraceRow head.
 * Sub-second stays whole milliseconds (`0ms`, `179ms`), anything longer becomes
 * one decimal of seconds (`2.0s`, `90.0s`, `509.3s`) — no unit hopping to minutes,
 * because a trace is read by comparing numbers in the same unit.
 */
export function formatTraceDuration(ms: number): string {
  if (!Number.isFinite(ms) || ms < 0) return '—'
  if (ms < 1000) return `${Math.round(ms)}ms`
  return `${(ms / 1000).toFixed(1)}s`
}

let seq = 0

/** Module-scoped so every row's collapsible body gets its own aria-controls id. */
export function nextTraceRowId(): string {
  return `hive-trace-${++seq}`
}
