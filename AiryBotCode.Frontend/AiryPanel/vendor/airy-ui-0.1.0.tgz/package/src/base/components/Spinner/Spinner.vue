<script setup lang="ts">
/**
 * Spinner — indeterminate loading indicator. Inherits the accent colour.
 *
 * @prop size   - px diameter (default 18)
 * @prop stroke - ring thickness (default 2)
 *
 * Status: new
 */
withDefaults(defineProps<{ size?: number; stroke?: number }>(), { size: 18, stroke: 2 })
</script>

<template>
  <span
    data-ui="spinner"
    :class="$style.spinner"
    :style="{ width: size + 'px', height: size + 'px', borderWidth: stroke + 'px' }"
    role="status"
    aria-label="Loading"
  />
</template>

<style module>
.spinner { display: inline-block; box-sizing: border-box; border-style: solid; border-color: var(--color-border); border-top-color: var(--color-accent, var(--color-fg)); border-radius: 50%; animation: spin 0.7s linear infinite; }
@keyframes spin { to { transform: rotate(360deg); } }
</style>
