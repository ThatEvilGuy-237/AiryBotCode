<script setup lang="ts">
/**
 * AppSidebar
 * The app shell's left column: a brand header, a scrolling stack of
 * `<SidebarSection>`s full of `<SidebarItem>`s, and a footer that stays put.
 * Use it for the one permanent navigation column of an application. For a
 * hierarchy of data reach for `<Tree>`; for a flat strip of links inside a page
 * reach for `<Tabs>`.
 *
 * The header and footer are hairline-separated regions of the same panel, not
 * boxes: only the middle band scrolls, so the brand and the footer note never
 * scroll away from a long nav.
 *
 * Fold state is real and it lives here, in one `Record<string, boolean>` keyed
 * by section — `true` means folded shut. Bind `v-model:folds` to a cookie or
 * localStorage and the whole sidebar's shape round-trips a reload; leave it
 * unbound and the sidebar keeps its own. An absent key falls back to that
 * section's `defaultFolded`, which is why a first-visit `{}` is not "everything
 * shut".
 *
 * `rail` is the same deal, controlled-or-uncontrolled: it collapses the column
 * to icons only. Note the trap this package has hit twice — an optional
 * `boolean` prop with no default resolves to `false`, never `undefined`, so
 * `props.rail ?? props.defaultRail` would silently ignore the default. Optional
 * booleans that need three states are typed `boolean | null` and default to
 * `null`. `rail` is one; `railToggle` is a plain flag and is not.
 *
 * @prop label       - accessible name of the inner <nav> landmark
 * @prop width       - CSS width of the expanded column
 * @prop railWidth   - CSS width when collapsed to the icon rail
 * @prop logo        - icon for the built-in brand block (from the curated set)
 * @prop title       - brand title, sans
 * @prop subtitle    - brand sub-line, mono
 * @prop folds       - fold map (`v-model:folds`); omit to self-manage
 * @prop defaultFolds- section keys folded on first render, when `folds` is unbound
 * @prop rail        - icon-only rail (`v-model:rail`); omit to self-manage
 * @prop defaultRail - rail state on first render, when `rail` is unbound
 * @prop railToggle  - show the built-in collapse/expand button in the footer
 * @prop note        - footer `//` line; the house sub-text
 *
 * @event update:folds - the whole next fold map, not a delta
 * @event update:rail  - the rail was toggled
 * @event fold         - (key, folded) for the one section that just moved
 *
 * Slot:
 *   brand   - replaces the built-in logo/title block. Scope: { rail }
 *   default - the sections
 *   footer  - footer content under the `//` note; hidden in rail mode
 *
 * Status: new | Consumers: ThatEvilGuyMemory portal layout
 */
import { computed, provide, ref } from 'vue'
import Icon from '../Icon/Icon.vue'
import type { IconName } from '../Icon/icons'
import { SIDEBAR_CTX, type SidebarContext } from './keys'
import type { SidebarFoldMap } from './types'

const props = withDefaults(defineProps<{
  label?: string
  width?: string
  railWidth?: string
  logo?: IconName
  title?: string
  subtitle?: string
  folds?: SidebarFoldMap
  defaultFolds?: string[]
  rail?: boolean | null
  defaultRail?: boolean
  railToggle?: boolean
  note?: string
}>(), {
  width: '256px',
  railWidth: '60px',
  defaultFolds: () => [],
  rail: null,
  defaultRail: false,
  railToggle: false,
})

const emit = defineEmits<{
  'update:folds': [map: SidebarFoldMap]
  'update:rail': [rail: boolean]
  fold: [key: string, folded: boolean]
}>()

defineSlots<{
  brand?: (props: { rail: boolean }) => unknown
  default?: () => unknown
  footer?: () => unknown
}>()

const controlledFolds = computed(() => props.folds !== undefined)
const ownFolds = ref<SidebarFoldMap>(
  Object.fromEntries(props.defaultFolds.map(key => [key, true])),
)
const foldMap = computed<SidebarFoldMap>(() =>
  controlledFolds.value ? (props.folds ?? {}) : ownFolds.value,
)

function isFolded(key: string, fallback: boolean) {
  const value = foldMap.value[key]
  return value === undefined ? fallback : value === true
}

function setFolded(key: string, folded: boolean) {
  const next: SidebarFoldMap = { ...foldMap.value, [key]: folded }
  if (!controlledFolds.value) ownFolds.value = next
  emit('update:folds', next)
  emit('fold', key, folded)
}

function toggleFold(key: string, fallback: boolean) {
  setFolded(key, !isFolded(key, fallback))
}

const controlledRail = computed(() => props.rail !== null)
const ownRail = ref(props.defaultRail)
const rail = computed(() => (controlledRail.value ? props.rail === true : ownRail.value))

function setRail(next: boolean) {
  if (!controlledRail.value) ownRail.value = next
  emit('update:rail', next)
}

const navEl = ref<HTMLElement | null>(null)

function stops(): HTMLElement[] {
  if (!navEl.value) return []
  return Array.from(navEl.value.querySelectorAll<HTMLElement>('[data-hive-sidebar-stop]'))
    .filter(el => el.offsetParent !== null && el.getAttribute('aria-disabled') !== 'true')
}

function step(from: HTMLElement, delta: number) {
  const list = stops()
  if (!list.length) return
  const index = list.indexOf(from)
  const next = index === -1 ? 0 : (index + delta + list.length) % list.length
  list[next]?.focus()
}

function onKeydown(event: KeyboardEvent) {
  const target = event.target as HTMLElement | null
  if (!target || !target.hasAttribute('data-hive-sidebar-stop')) return
  const list = stops()
  if (!list.length) return

  switch (event.key) {
    case 'ArrowDown':
      event.preventDefault()
      step(target, 1)
      return
    case 'ArrowUp':
      event.preventDefault()
      step(target, -1)
      return
    case 'Home':
      event.preventDefault()
      list[0]?.focus()
      return
    case 'End':
      event.preventDefault()
      list[list.length - 1]?.focus()
  }
}

const context: SidebarContext = {
  rail,
  isFolded,
  setFolded,
  toggleFold,
}
provide(SIDEBAR_CTX, context)

defineExpose({ setRail })
</script>

<template>
  <aside data-ui="app-sidebar"
    :class="[$style.sidebar, rail && $style.railed]"
    :style="{ width: rail ? railWidth : width }"
  >
    <header v-if="$slots.brand || logo || title" :class="$style.head">
      <slot name="brand" :rail="rail">
        <span v-if="logo" :class="$style.logo" aria-hidden="true">
          <Icon :name="logo" :size="20" />
        </span>
        <span v-if="!rail && (title || subtitle)" :class="$style.brand">
          <span v-if="title" :class="$style.title">{{ title }}</span>
          <span v-if="subtitle" :class="$style.sub">{{ subtitle }}</span>
        </span>
      </slot>
    </header>

    <nav
      ref="navEl"
      :class="$style.scroll"
      :aria-label="label ?? 'Sidebar'"
      @keydown="onKeydown"
    >
      <slot />
    </nav>

    <footer v-if="note || $slots.footer || railToggle" :class="$style.foot">
      <p v-if="note && !rail" :class="$style.note">// {{ note }}</p>
      <slot v-if="!rail" name="footer" />
      <button
        v-if="railToggle"
        type="button"
        :class="$style.railBtn"
        :aria-label="rail ? 'Expand sidebar' : 'Collapse sidebar to icons'"
        :aria-pressed="rail"
        @click="setRail(!rail)"
      >
        <Icon :name="rail ? 'chevron-right' : 'chevron-left'" :size="14" />
        <span v-if="!rail">collapse</span>
      </button>
    </footer>
  </aside>
</template>

<style module>
.sidebar {
  display: flex;
  flex-direction: column;
  min-height: 0;
  flex: 0 0 auto;
  background: var(--color-bg-2);
  border: var(--border);
  border-radius: var(--radius);
  overflow: hidden;
  transition: width 140ms ease;
}

/* Header and footer are regions of one panel, split by hairlines — not cards. */
.head {
  flex: 0 0 auto;
  display: flex;
  align-items: center;
  gap: var(--space-3);
  min-height: 56px;
  padding: var(--space-3);
  border-bottom: 1px solid var(--color-border-soft);
}
.railed .head { justify-content: center; padding: var(--space-3) 0; }

.logo {
  display: grid;
  place-items: center;
  width: 34px;
  height: 34px;
  flex: 0 0 auto;
  border-radius: var(--r-3);
  background: var(--color-accent-soft);
  color: var(--color-accent);
}

.brand { display: flex; flex-direction: column; min-width: 0; }
.title {
  font-family: var(--font-family);
  font-size: var(--font-size-base);
  font-weight: 600;
  color: var(--color-fg);
  white-space: nowrap;
  overflow: hidden;
  text-overflow: ellipsis;
}
.sub {
  font-family: var(--font-mono);
  font-size: var(--font-size-xs);
  color: var(--color-text-dim);
  white-space: nowrap;
  overflow: hidden;
  text-overflow: ellipsis;
}

/* The only scroller. A long nav never pushes the brand or the footer away. */
.scroll {
  flex: 1 1 auto;
  min-height: 0;
  overflow-y: auto;
  display: flex;
  flex-direction: column;
  gap: var(--space-4);
  padding: var(--space-3) var(--space-2);
}
.railed .scroll { gap: var(--space-3); padding: var(--space-3) var(--space-1); }

.foot {
  flex: 0 0 auto;
  display: flex;
  flex-direction: column;
  align-items: flex-start;
  gap: var(--space-2);
  padding: var(--space-3);
  border-top: 1px solid var(--color-border-soft);
}
.railed .foot { align-items: center; padding: var(--space-2) 0; }

.note {
  margin: 0;
  font-family: var(--font-mono);
  font-size: var(--font-size-xs);
  line-height: 1.4;
  color: var(--color-text-ghost);
}

.railBtn {
  display: inline-flex;
  align-items: center;
  gap: var(--space-2);
  padding: var(--space-1) var(--space-2);
  border: 1px solid transparent;
  border-radius: var(--r-2);
  background: none;
  color: var(--color-muted);
  font-family: var(--font-mono);
  font-size: var(--font-size-xs);
  cursor: pointer;
}
.railBtn:hover {
  background: var(--color-surface-hi);
  border-color: var(--color-border-soft);
  color: var(--color-fg);
}
.railBtn:focus-visible { outline: 1px solid var(--color-accent-edge); outline-offset: 1px; }

@media (prefers-reduced-motion: reduce) {
  .sidebar { transition: none; }
}
</style>
