/**
 * AppSidebar — the two injection contracts of the family.
 *
 * `SIDEBAR_CTX` runs downhill: the root owns fold state and rail mode, every
 * section and item reads it from here, so no child ever keeps a second copy of
 * a truth the root already has.
 *
 * `SIDEBAR_SECTION_CTX` runs uphill: each item registers what it knows about
 * itself (is it the current page, does it carry a badge) with its section. That
 * is what lets a folded section still show the count it is hiding, and mark
 * that the page you are on lives inside it.
 */
import type { ComputedRef, InjectionKey } from 'vue'
import type { SidebarItemFacts } from './types'

export interface SidebarContext {
  rail: ComputedRef<boolean>
  /** `fallback` is the section's own `defaultFolded`, used when the map has no entry. */
  isFolded: (key: string, fallback: boolean) => boolean
  setFolded: (key: string, folded: boolean) => void
  toggleFold: (key: string, fallback: boolean) => void
}

export const SIDEBAR_CTX: InjectionKey<SidebarContext> = Symbol('hive:sidebar')

export interface SidebarSectionContext {
  /** The ref itself is the handle — no ids to keep unique across instances. */
  register: (facts: ComputedRef<SidebarItemFacts>) => void
  unregister: (facts: ComputedRef<SidebarItemFacts>) => void
}

export const SIDEBAR_SECTION_CTX: InjectionKey<SidebarSectionContext> = Symbol('hive:sidebar-section')
