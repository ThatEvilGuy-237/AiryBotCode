<script setup lang="ts">
import Icon from '../Icon/Icon.vue'
/**
 * FlowNode
 * One node card inside a FlowCanvas chain. Three regions via the Card primitive:
 *
 *   head — status dot + name + type badge + (optional) inspect button
 *   body — description
 *   foot — 2×2 stat grid: PROVIDER · MODEL · TOOLS · (PORTS / EXITS)
 *
 * Interaction model when used inside an editable FlowCanvas:
 *   - The whole card is the drag handle. `pointerdown` initiates a drag-
 *     pending state; if the cursor moves past the threshold, the parent
 *     FlowCanvas takes over and starts the drag.
 *   - A single click does NOT open the inspector — clicks are reserved for
 *     drag initiation. To open the inspector, use the small "inspect" button
 *     in the card head.
 *
 * @prop node     - { id, nodeType, label, description?, config }. Matches FlowNodeDto.
 * @prop selected - draws an accent left-bar.
 * @prop orphan   - dims the card.
 * @prop draggable- enables the pointer-down drag-initiator (cursor: grab).
 * @prop inCount  - incoming control edges → rendered as PORTS.
 * @prop outCount - outgoing control edges → rendered as EXITS.
 * @prop dragging - true when this specific node is currently being dragged
 *                  (parent FlowCanvas sets it). Renders as a faint placeholder.
 *
 * @event inspect       - "inspect" button clicked. Parent opens the side panel.
 * @event pointer-down  - card received pointerdown. Parent decides whether
 *                        this becomes a drag (after threshold).
 *
 * Status: new | Consumers: FlowCanvas
 */
import { computed } from 'vue'
import Card from '../Card/Card.vue'
import Badge from '../Badge/Badge.vue'
import StatusDot from '../StatusDot/StatusDot.vue'
import NewBadge from '../NewBadge/NewBadge.vue'

export interface FlowNodeData {
  id: string
  nodeType: string
  label: string
  description?: string | null
  config: Record<string, unknown>
}

const props = withDefaults(defineProps<{
  node: FlowNodeData
  selected?: boolean
  orphan?: boolean
  draggable?: boolean
  dragging?: boolean
  inCount?: number
  outCount?: number
}>(), {
  selected: false,
  orphan: false,
  draggable: false,
  dragging: false,
  inCount: 0,
  outCount: 0,
})

const emit = defineEmits<{
  inspect: [node: FlowNodeData]
  'pointer-down': [event: PointerEvent, node: FlowNodeData]
}>()

const typeDisplay = computed(() => {
  const map: Record<string, string> = {
    trigger_chat:    'trigger',
    trigger_webhook: 'trigger',
    agent:           'agent',
    ai:              'agent',
    output_chat:     'output',
    router:          'router',
    memory_read:     'memory',
    memory_write:    'memory',
    if_else:         'if/else',
  }
  return map[props.node.nodeType] ?? props.node.nodeType
})

// Router node: surface its branch map (keys) on the card so the branching is
// visible on the canvas — default branch marked, unwired branches dimmed.
const router = computed(() => {
  if (props.node.nodeType !== 'router') return null
  const c = props.node.config as { branches?: { key?: string; target?: string }[]; default?: string | null }
  const branches = (c.branches ?? [])
    .map(b => ({ key: (b.key ?? '').trim(), wired: !!b.target }))
    .filter(b => b.key)
  return { branches, default: c.default ?? null }
})

// Low-level node types now handled inside an agent — kept for old flows, tagged.
const DEPRECATED = ['memory_read', 'memory_write', 'if_else']
const deprecated = computed(() => DEPRECATED.includes(props.node.nodeType))

const ai = computed(() => {
  if (props.node.nodeType !== 'ai' && props.node.nodeType !== 'agent') return null
  const c = props.node.config as {
    model?: string
    system_prompt?: string
    tools?: string[]
    internal_tools?: { name?: string }[]
  }
  const raw = c.model ?? ''
  const slash = raw.indexOf('/')
  return {
    provider:     slash > 0 ? raw.slice(0, slash) : null,
    model:        slash > 0 ? raw.slice(slash + 1) : raw || null,
    systemPrompt: c.system_prompt ?? null,
    toolCount:    (c.tools ?? []).length,
  }
})

const description = computed(() => {
  if (props.node.description)        return truncate(props.node.description, 180)
  if (ai.value?.systemPrompt)        return truncate(ai.value.systemPrompt, 140)
  return null
})

function truncate(s: string, n: number): string {
  return s.length <= n ? s : s.slice(0, n).trimEnd() + '…'
}

function onPointerDown(e: PointerEvent) {
  if (!props.draggable) return
  // Don't initiate drag from the inspect button — let its own click through.
  const target = e.target as HTMLElement
  if (target.closest('[data-no-drag]')) return
  emit('pointer-down', e, props.node)
}

function onInspectClick(e: MouseEvent) {
  e.stopPropagation()
  emit('inspect', props.node)
}
</script>

<template>
  <div data-ui="flow-node"
    :class="[
      $style.node,
      selected && $style.selected,
      orphan && $style.orphan,
      draggable && $style.draggable,
      dragging && $style.dragging,
    ]"
    @pointerdown="onPointerDown"
  >
    <Card>
      <template #head>
        <StatusDot variant="live" />
        <span :class="$style.name">{{ node.label }}</span>
        <span :class="$style.spacer" />
        <NewBadge v-if="deprecated" variant="todo">deprecated</NewBadge>
        <Badge variant="inactive">{{ typeDisplay }}</Badge>
        <button
          type="button"
          data-no-drag
          :class="$style.inspectBtn"
          aria-label="Edit node"
          title="Edit node"
          @click="onInspectClick"
        ><Icon name="pencil" :size="13" /></button>
      </template>

      <!-- Router: show the branch map (each key routes to an agent). -->
      <div v-if="router" :class="$style.branches">
        <template v-if="router.branches.length">
          <span
            v-for="b in router.branches"
            :key="b.key"
            :class="[$style.branchChip, !b.wired && $style.branchUnwired, b.key === router.default && $style.branchDefault]"
            :title="b.wired ? (b.key === router.default ? 'default branch' : 'branch') : 'no target agent set'"
          >{{ b.key }}<span v-if="b.key === router.default" :class="$style.branchStar"><Icon name="star" :size="10" /></span></span>
        </template>
        <span v-else :class="$style.commentPrefix">// add branches in the editor</span>
      </div>
      <p v-else-if="description" :class="$style.description">{{ description }}</p>
      <p v-else :class="$style.descriptionMissing">
        <NewBadge variant="todo">todo</NewBadge>
        <span :class="$style.commentPrefix">// description</span>
      </p>

      <template #foot>
        <div :class="$style.statGrid">
          <div :class="$style.stat">
            <span :class="$style.statLabel">PROVIDER</span>
            <span :class="$style.statValue">{{ ai?.provider ?? '—' }}</span>
          </div>
          <div :class="$style.stat">
            <span :class="$style.statLabel">MODEL</span>
            <span :class="$style.statValue">{{ ai?.model ?? '—' }}</span>
          </div>
          <div :class="$style.stat">
            <span :class="$style.statLabel">TOOLS</span>
            <span :class="$style.statValue">{{ ai?.toolCount ?? 0 }}</span>
          </div>
          <div :class="[$style.stat, $style.statSplit]">
            <div :class="$style.splitHalf">
              <span :class="$style.statLabel">PORTS</span>
              <span :class="$style.statValue">{{ inCount }}</span>
            </div>
            <div :class="$style.splitHalf">
              <span :class="$style.statLabel">EXITS</span>
              <span :class="$style.statValue">{{ outCount }}</span>
            </div>
          </div>
        </div>
      </template>
    </Card>
  </div>
</template>

<style module>
.node {
  flex-shrink: 0;
  min-width: 280px;
  max-width: 320px;
  border-radius: var(--radius);
  transition: box-shadow 0.12s, opacity 0.12s, transform 0.12s;
  /* Prevent native touch gestures (pan/zoom) from interfering with pointer drag. */
  touch-action: none;
}

.draggable { cursor: grab; user-select: none; }
.draggable:active { cursor: grabbing; }

.node:not(.dragging):hover {
  box-shadow: inset 2px 0 0 0 var(--color-accent-edge, var(--color-accent));
}

.selected:not(.dragging) {
  box-shadow: inset 2px 0 0 0 var(--color-accent);
}

.orphan { opacity: 0.55; }

/* Placeholder state — original position while the card is being dragged.
   Reads as "this slot is reserved" without disappearing. */
.dragging {
  opacity: 0.25;
  cursor: grabbing;
}

.name {
  font-weight: 600;
  font-size: var(--font-size-base);
  color: var(--color-fg);
  flex-shrink: 1;
  min-width: 0;
  overflow: hidden;
  text-overflow: ellipsis;
  white-space: nowrap;
}

.spacer { flex: 1; }

.inspectBtn {
  background: transparent;
  border: 0;
  color: var(--color-text-dim, var(--color-muted));
  cursor: pointer;
  width: 22px;
  height: 22px;
  border-radius: var(--radius);
  display: flex;
  align-items: center;
  justify-content: center;
  font-size: var(--font-size-base);
  line-height: 1;
}
.inspectBtn:hover {
  color: var(--color-fg);
  background: var(--color-surface-hi, var(--color-surface));
}

.description {
  font-size: var(--font-size-sm);
  color: var(--color-text-dim, var(--color-fg));
  line-height: 1.5;
  display: -webkit-box;
  -webkit-line-clamp: 4;
  -webkit-box-orient: vertical;
  overflow: hidden;
}

.descriptionMissing { display: flex; align-items: center; gap: var(--space-2); }

/* Router branch chips */
.branches { display: flex; flex-wrap: wrap; gap: var(--space-1); align-items: center; }
.branchChip {
  font-family: var(--font-mono);
  font-size: var(--font-size-xs);
  color: var(--color-fg);
  background: var(--color-surface-hi, var(--color-surface));
  border: 1px solid var(--color-border);
  border-radius: var(--radius);
  padding: 1px 7px;
  display: inline-flex;
  align-items: center;
  gap: 3px;
}
.branchDefault { border-color: var(--color-accent); }
.branchStar { color: var(--color-accent); font-size: 9px; }
.branchUnwired { opacity: 0.5; border-style: dashed; }

.commentPrefix {
  font-family: var(--font-mono);
  font-size: var(--font-size-xs);
  color: var(--color-muted);
}

.statGrid {
  display: grid;
  grid-template-columns: 1fr 1fr;
  width: calc(100% + var(--space-4) * 2);
  margin: calc(var(--space-3) * -1) calc(var(--space-4) * -1);
}

.stat {
  display: flex;
  flex-direction: column;
  gap: 2px;
  padding: var(--space-2) var(--space-3);
  border-right: 1px solid var(--color-border-soft, var(--color-border));
  border-top: 1px solid var(--color-border-soft, var(--color-border));
  min-width: 0;
}
.stat:nth-child(2n) { border-right: 0; }
.stat:nth-child(-n + 2) { border-top: 0; }

.statLabel {
  font-family: var(--font-mono);
  font-size: 10px;
  letter-spacing: 0.08em;
  color: var(--color-text-ghost, var(--color-muted));
  text-transform: uppercase;
}

.statValue {
  font-family: var(--font-mono);
  font-size: var(--font-size-sm);
  color: var(--color-fg);
  white-space: nowrap;
  overflow: hidden;
  text-overflow: ellipsis;
}

.statSplit { flex-direction: row; gap: 0; padding: 0; }

.splitHalf {
  flex: 1;
  display: flex;
  flex-direction: column;
  gap: 2px;
  padding: var(--space-2) var(--space-3);
  min-width: 0;
}

.splitHalf + .splitHalf {
  border-left: 1px solid var(--color-border-soft, var(--color-border));
}
</style>
