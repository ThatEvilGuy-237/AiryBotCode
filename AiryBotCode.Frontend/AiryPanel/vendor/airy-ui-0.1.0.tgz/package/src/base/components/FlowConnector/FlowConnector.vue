<script setup lang="ts">
/**
 * FlowConnector
 * Horizontal line + chevron arrow between two FlowNodes. Pure CSS — no SVG.
 *
 * Width is content-driven:
 *   - No label   → comfortable default gap so the chain reads clearly.
 *   - With label → grows with the label text (mono pill above the line).
 *
 * Line thickness + arrowhead are sized so the connector reads at a glance
 * without dominating the card content. Matched to the FlowDropZone arrow
 * so they feel like the same family of element.
 *
 * @prop label - optional port label. Defaults to nothing for linear v1 flows.
 *
 * Status: new | Consumers: FlowCanvas
 */
defineProps<{
  label?: string | null
}>()
</script>

<template>
  <div data-ui="flow-connector" :class="[$style.connector, label && $style.labeled]">
    <span v-if="label" :class="$style.label">{{ label }}</span>
    <div :class="$style.line" />
    <span :class="$style.arrow" />
  </div>
</template>

<style module>
.connector {
  position: relative;
  flex-shrink: 0;
  min-width: 80px;
  height: 36px;
  display: flex;
  align-items: center;
  justify-content: center;
  padding: 0 var(--space-3);
}

.labeled {
  min-width: 128px;
  padding: 0 var(--space-4);
}

.line {
  position: relative;
  width: 100%;
  height: 3px;                                  /* heavier — reads at glance distance */
  background: var(--color-border);
  border-radius: 2px;
}

/* Chunky chevron arrowhead. Scaled with the line so the two read as a single
   stroke. Larger than before to match the heavier drop-zone block on hover. */
.arrow {
  position: absolute;
  right: var(--space-3);
  width: 0;
  height: 0;
  border-left: 14px solid var(--color-border);
  border-top: 8px solid transparent;
  border-bottom: 8px solid transparent;
}
.labeled .arrow { right: var(--space-4); }

.label {
  position: absolute;
  top: 2px;
  left: 50%;
  transform: translateX(-50%);
  font-family: var(--font-mono);
  font-size: 10px;
  letter-spacing: 0.08em;
  text-transform: uppercase;
  color: var(--color-muted);
  background: var(--color-bg);
  padding: 0 var(--space-2);
  white-space: nowrap;
  line-height: 1;
}
</style>
