<script setup lang="ts">
import Icon from '../Icon/Icon.vue'
/**
 * Tag — a small rounded chip, optionally removable.
 *
 * @prop label / variant (soft | solid) / removable
 * @event remove
 *
 * Status: new
 */
withDefaults(defineProps<{
  label: string
  variant?: 'soft' | 'solid'
  removable?: boolean
}>(), { variant: 'soft', removable: false })

const emit = defineEmits<{ remove: [] }>()
</script>

<template>
  <span data-ui="tag" :class="[$style.tag, $style[variant]]">
    {{ label }}
    <button v-if="removable" type="button" :class="$style.x" aria-label="Remove" @click="emit('remove')"><Icon name="x" :size="12" /></button>
  </span>
</template>

<style module>
.tag { display: inline-flex; align-items: center; gap: 4px; font-family: var(--font-mono); font-size: var(--font-size-xs); padding: 2px 8px; border-radius: 999px; }
.soft { border: 1px solid var(--color-border); color: var(--color-text-dim, var(--color-fg)); }
.solid { background: var(--color-accent, var(--color-fg)); color: var(--color-bg); }
.x { background: none; border: 0; color: inherit; opacity: 0.65; cursor: pointer; font-size: 13px; line-height: 1; padding: 0; }
.x:hover { opacity: 1; }
</style>
