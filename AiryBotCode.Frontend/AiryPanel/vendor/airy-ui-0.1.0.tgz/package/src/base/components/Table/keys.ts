/**
 * Injection key <TableColumn> uses to register itself with its parent <Table>.
 *
 * Status: new | Consumers: Table, TableColumn
 */
import type { InjectionKey } from 'vue'
import type { TableRegistry } from './types'

export const HIVE_TABLE_REGISTRY: InjectionKey<TableRegistry> = Symbol('hive:table-registry')
