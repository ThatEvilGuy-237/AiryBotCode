<script setup lang="ts">
/**
 * AppMark
 * The square mark of an app: its logo when there is one, otherwise a
 * monogram of its name. The app's accent arrives as data (a hex colour from
 * the app's own metadata) and tints only the mark's fill and border; the
 * letters stay in the foreground colour, so any accent keeps them readable.
 * Without an accent the mark is neutral. Corners follow the app-icon rule (22 %).
 * Decorative: the name is always printed next to it, so the mark is hidden
 * from assistive tech.
 *
 * @prop name   - app name the monogram is made from
 * @prop accent - #rrggbb of the app, or null for the neutral mark
 * @prop src    - image URL of the logo, or null for the monogram
 * @prop size   - px edge length (default 40)
 *
 * Status: new | Consumers: evil-dash apps page
 */
import { computed } from 'vue'

const props = withDefaults(defineProps<{
  name: string
  accent?: string | null
  src?: string | null
  size?: number
}>(), { accent: null, src: null, size: 40 })

const letters = computed(() => {
  const words = props.name.replace(/[^\p{L}\p{N}\s-]/gu, ' ').split(/[\s-]+/).filter(Boolean)
  if (words.length >= 2) return (words[0][0] + words[1][0]).toUpperCase()
  const word = words[0] ?? '?'
  const caps = word.match(/\p{Lu}/gu) ?? []
  if (caps.length >= 2) return caps[0] + caps[1]
  return (word[0].toUpperCase() + (word[1] ?? '')).slice(0, 2)
})

const style = computed(() => ({
  width: `${props.size}px`,
  height: `${props.size}px`,
  fontSize: `${Math.round(props.size * 0.38)}px`,
  ...(props.accent && /^#[0-9a-fA-F]{6}$/.test(props.accent) ? { '--app-mark-accent': props.accent } : {}),
}))
</script>

<template>
  <span data-ui="app-mark" :class="[$style.mark, accent ? $style.tinted : $style.neutral]" :style="style" aria-hidden="true">
    <img v-if="src" :src="src" alt="" :class="$style.img" />
    <template v-else>{{ letters }}</template>
  </span>
</template>

<style module>
.mark {
  display: inline-flex;
  align-items: center;
  justify-content: center;
  flex-shrink: 0;
  border-radius: 22%;
  overflow: hidden;
  font-weight: 600;
  letter-spacing: 0.02em;
  line-height: 1;
  user-select: none;
}
.tinted {
  background: color-mix(in srgb, var(--app-mark-accent) 22%, var(--color-surface));
  color: var(--color-fg);
  border: 1px solid color-mix(in srgb, var(--app-mark-accent) 45%, transparent);
}
.neutral {
  background: var(--color-surface);
  color: var(--color-text-dim, var(--color-muted));
  border: var(--border);
}
.img { width: 100%; height: 100%; object-fit: cover; }
</style>
