<script setup lang="ts">
/**
 * FormRow
 * Two or more controls sharing one line, collapsing to a stack when the row
 * itself gets narrow — measured with a ResizeObserver on the row, not with a
 * viewport media query, so a form inside a drawer or a split pane stacks when
 * *it* is cramped instead of waiting for the whole window to shrink.
 * (Same reason ButtonBar measures itself.)
 *
 * Group controls that are read as one answer — first / last name, host / port,
 * from / to. A row of unrelated fields just makes the form harder to scan.
 * For a labelled row of arbitrary content, use `<Field layout="horizontal">`:
 * Field already falls back to a labelled `role="group"` when the slot holds no
 * single control.
 *
 * @prop columns  - equal columns when no `template` is given. Default 2.
 * @prop template - explicit `grid-template-columns`, e.g. '2fr 1fr' or
 *                  'minmax(0, 1fr) 6rem' for a value + unit pair.
 * @prop stackAt  - row width in px below which it stacks. Default columns × 180.
 * @prop gap      - 'sm' | 'md' | 'lg' between columns. Default 'md'.
 * @prop align    - 'start' (default) | 'center' | 'end' — how uneven columns line up.
 *
 * @slot default - the controls, usually <Field>s.
 *
 * Status: new | Consumers: portal accounts (who-grid), setup
 */
import { computed, onBeforeUnmount, onMounted, ref } from 'vue'

export type FormRowGap = 'sm' | 'md' | 'lg'
export type FormRowAlign = 'start' | 'center' | 'end'

const props = withDefaults(defineProps<{
  columns?: number
  template?: string
  stackAt?: number
  gap?: FormRowGap
  align?: FormRowAlign
}>(), {
  columns: 2,
  gap: 'md',
  align: 'start',
})

const el = ref<HTMLElement>()
const narrow = ref(false)

const threshold = computed(() => props.stackAt ?? Math.max(240, props.columns * 180))
const gapClass = computed(() => ({ sm: 'gapSm', md: 'gapMd', lg: 'gapLg' } as const)[props.gap])
const columns = computed(() =>
  narrow.value ? 'minmax(0, 1fr)' : (props.template ?? `repeat(${Math.max(1, props.columns)}, minmax(0, 1fr))`))

let observer: ResizeObserver | null = null

function measure() {
  if (el.value) narrow.value = el.value.clientWidth > 0 && el.value.clientWidth < threshold.value
}

onMounted(() => {
  if (typeof ResizeObserver !== 'undefined') {
    observer = new ResizeObserver(measure)
    if (el.value) observer.observe(el.value)
  }
  measure()
})

onBeforeUnmount(() => {
  observer?.disconnect()
  observer = null
})

defineExpose({ narrow })
</script>

<template>
  <div
    ref="el"
    :class="[$style.row, $style[gapClass], $style[align], narrow && $style.stacked]"
    :style="{ '--form-row-cols': columns }"
  >
    <slot />
  </div>
</template>

<style module>
.row {
  display: grid;
  grid-template-columns: var(--form-row-cols, minmax(0, 1fr));
  min-width: 0;
}

.gapSm { gap: var(--space-2) var(--space-3); }
.gapMd { gap: var(--space-3) var(--space-4); }
.gapLg { gap: var(--space-4) var(--space-6); }

.start  { align-items: start; }
.center { align-items: center; }
.end    { align-items: end; }

/* Stacked rows align to the start regardless — nothing to line up against. */
.stacked { align-items: stretch; }
</style>
