<script setup lang="ts">
/**
 * FlowCanvas
 * Read-only renderer for a Spine flow. Horizontal chain of FlowNodes
 * connected by FlowConnectors. Pure HTML/CSS, no SVG.
 *
 * Edit mode (reorderable / droppable):
 *   - Pointer-based drag. No HTML5 DnD anywhere.
 *   - The card being dragged fades to a faint placeholder at its current
 *     position. A node-sized PLACEHOLDER appears where it would land —
 *     the gap IS the preview, no separate indicator.
 *   - A custom GHOST element follows the cursor (so the user sees what
 *     they're carrying).
 *   - Connectors are derived from a "preview order" that reflects the live
 *     drop position, so the chain re-shapes itself as you drag.
 *   - Single `@drop` event with discriminated source+target on pointerup.
 *
 * @prop flow            - { nodes, controlEdges }. Matches Spine's FlowDetailDto.
 * @prop selectedNodeId  - id to highlight with the accent left-bar.
 * @prop reorderable     - existing nodes are draggable for chain reorder.
 * @prop droppable       - drop accepted from external sources (e.g. NodePalette).
 *
 * @event select - node's inspect button clicked. Payload: FlowNodeData.
 * @event drop   - drag completed on a valid drop position. Payload: { source, target }.
 */
import { computed, onBeforeUnmount, ref } from 'vue'
import FlowNode from '../FlowNode/FlowNode.vue'
import FlowConnector from '../FlowConnector/FlowConnector.vue'
import EmptyState from '../EmptyState/EmptyState.vue'
import { linearize, type FlowGraph } from './linearize'
import { useSortable, exceedsThreshold } from '../../composables/useSortable'
import type { FlowNodeData } from '../FlowNode/FlowNode.vue'
import type { DragSource, DropTarget, DropEvent, PaletteItem } from './types'

const props = withDefaults(defineProps<{
  flow: FlowGraph
  selectedNodeId?: string | null
  reorderable?: boolean
  droppable?: boolean
}>(), {
  reorderable: false,
  droppable: false,
})

const emit = defineEmits<{
  select: [node: FlowNodeData]
  drop:   [event: DropEvent]
}>()

// — Linear chain order derived from control edges —
const baseChain = computed(() => linearize(props.flow))

// Just the nodes in order (the chain has alternating node/edge items).
const orderIds = computed<string[]>(() =>
  baseChain.value.filter(i => i.kind === 'node').map(i => i.kind === 'node' ? i.node.id : ''),
)

const nodeById = computed(() => new Map(props.flow.nodes.map(n => [n.id, n])))

const degree = computed(() => {
  const inCount  = new Map<string, number>()
  const outCount = new Map<string, number>()
  for (const e of props.flow.controlEdges) {
    inCount.set(e.toNodeId,    (inCount.get(e.toNodeId)    ?? 0) + 1)
    outCount.set(e.fromNodeId, (outCount.get(e.fromNodeId) ?? 0) + 1)
  }
  return { inCount, outCount }
})

const editable = computed(() => props.reorderable || props.droppable)

// =====================================================================
// Drag state — owned by this canvas instance (single drag at a time).
// =====================================================================
const sortable = useSortable()

interface GhostState { x: number; y: number; w: number; h: number; payload: DragSource }
const ghost = ref<GhostState | null>(null)
const draggedSource = ref<DragSource | null>(null)

/** Movement-pending state: pointerdown happened but threshold not crossed yet. */
interface Pending { source: DragSource; originX: number; originY: number; rect: DOMRect; nodeEl: HTMLElement }
let pending: Pending | null = null

const slotsEl = ref<HTMLElement | null>(null)

// =====================================================================
// Preview order — the chain rendered during drag, reflecting where the
// dragged node would land. Reorder pushes/pulls nodes; palette inserts a
// '__phantom__' marker the renderer turns into a placeholder card.
// =====================================================================
const PHANTOM_ID = '__phantom__'

const previewOrder = computed<string[]>(() => {
  const base = orderIds.value
  const src = draggedSource.value
  const idx = sortable.dropIndex.value
  if (!src || idx === null) return base

  if (src.kind === 'node') {
    const fromIdx = base.indexOf(src.nodeId)
    if (fromIdx === -1) return base
    const without = base.filter(x => x !== src.nodeId)
    const insertAt = fromIdx < idx ? idx - 1 : idx
    return [...without.slice(0, insertAt), src.nodeId, ...without.slice(insertAt)]
  }

  if (src.kind === 'palette') {
    return [...base.slice(0, idx), PHANTOM_ID, ...base.slice(idx)]
  }

  return base
})

/** Chain items rendered from the previewOrder — interleaved with connectors. */
interface DisplayItem {
  kind: 'node' | 'edge' | 'phantom'
  key: string
  node?: FlowNodeData
  phantom?: PaletteItem
  isDragging?: boolean
  orphan?: boolean
}

const displayChain = computed<DisplayItem[]>(() => {
  const order = previewOrder.value
  if (order.length === 0) return []
  const items: DisplayItem[] = []
  for (let i = 0; i < order.length; i++) {
    const id = order[i]
    if (id === PHANTOM_ID) {
      const src = draggedSource.value
      const phantom = src?.kind === 'palette' ? src.item : { id: 'x', nodeType: 'unknown', label: 'New node' }
      items.push({ kind: 'phantom', key: PHANTOM_ID, phantom })
    } else {
      const node = nodeById.value.get(id)
      if (!node) continue
      const dragging = draggedSource.value?.kind === 'node' && draggedSource.value.nodeId === id
      items.push({
        kind: 'node',
        key: id,
        node: {
          id: node.id,
          nodeType: node.nodeType,
          label: node.label,
          description: node.description,
          config: node.config,
        },
        isDragging: dragging,
      })
    }
    if (i < order.length - 1) {
      items.push({ kind: 'edge', key: `edge-${i}` })
    }
  }
  // Append orphans (nodes that exist but aren't in the linearised order).
  const seen = new Set(order)
  for (const n of props.flow.nodes) {
    if (seen.has(n.id)) continue
    if (items.length > 0) items.push({ kind: 'edge', key: `edge-orphan-${n.id}` })
    items.push({
      kind: 'node',
      key: n.id,
      node: {
        id: n.id, nodeType: n.nodeType, label: n.label, description: n.description, config: n.config,
      },
      orphan: true,
    })
  }
  return items
})

const isEmpty = computed(() => props.flow.nodes.length === 0)

// =====================================================================
// Pointer handlers
// =====================================================================
function onNodePointerDown(e: PointerEvent, node: FlowNodeData) {
  if (!props.reorderable) return
  const nodeEl = (e.currentTarget as HTMLElement | null) ?? (e.target as HTMLElement).closest('[data-node-slot]') as HTMLElement | null
  if (!nodeEl) return
  pending = {
    source: { kind: 'node', nodeId: node.id },
    originX: e.clientX,
    originY: e.clientY,
    rect: nodeEl.getBoundingClientRect(),
    nodeEl,
  }
  window.addEventListener('pointermove', onPendingMove)
  window.addEventListener('pointerup',   onPendingUp)
  window.addEventListener('pointercancel', onPendingUp)
}

function onPendingMove(e: PointerEvent) {
  if (!pending) return
  if (!exceedsThreshold(e.clientX, e.clientY, pending.originX, pending.originY)) return
  startDrag(pending.source, e.clientX, e.clientY, pending.rect)
  teardownPending()
}

function onPendingUp() {
  // If we reach here, the drag threshold was never crossed (onPendingMove tears
  // down pending the moment a drag starts), so a node pointerdown→up is a click →
  // open its inspector. This makes the whole card an "edit" affordance.
  const src = pending?.source
  teardownPending()
  if (src?.kind === 'node') {
    const node = nodeById.value.get(src.nodeId)
    if (node) emit('select', node)
  }
}

function teardownPending() {
  pending = null
  window.removeEventListener('pointermove', onPendingMove)
  window.removeEventListener('pointerup',   onPendingUp)
  window.removeEventListener('pointercancel', onPendingUp)
}

/**
 * Public-ish helper: external drag origins (NodePalette) call this to start
 * a palette drag once their own threshold passes. Exposed via defineExpose.
 */
function startPaletteDrag(item: PaletteItem, e: PointerEvent, sourceRect?: DOMRect) {
  startDrag({ kind: 'palette', item }, e.clientX, e.clientY, sourceRect)
}

function startDrag(source: DragSource, cursorX: number, cursorY: number, sourceRect?: DOMRect) {
  draggedSource.value = source
  const w = sourceRect?.width  ?? 280
  const h = sourceRect?.height ?? 180
  const offX = sourceRect ? cursorX - sourceRect.left : w / 2
  const offY = sourceRect ? cursorY - sourceRect.top  : h / 2
  ghost.value = { x: cursorX - offX, y: cursorY - offY, w, h, payload: source }

  sortable.beginDrag(source, {
    cursorX, cursorY, sourceRect,
    onDrop:   onSortableDrop,
    onCancel: cancelDrag,
  })

  window.addEventListener('pointermove', onDragMove, { passive: true })
}

function onDragMove(e: PointerEvent) {
  if (!ghost.value) return
  // Keep the ghost anchored to the original grab offset
  const offX = (sortable.drag.value?.offsetX) ?? ghost.value.w / 2
  const offY = (sortable.drag.value?.offsetY) ?? ghost.value.h / 2
  ghost.value = { ...ghost.value, x: e.clientX - offX, y: e.clientY - offY }
  sortable.setDropIndex(computeDropIndex(e.clientX))
}

function computeDropIndex(cursorX: number): number | null {
  const slots = slotsEl.value
  if (!slots) return null
  const nodeEls = Array.from(slots.querySelectorAll<HTMLElement>('[data-node-slot]'))
  if (nodeEls.length === 0) return 0
  // Drop index = number of node centres that cursorX has passed.
  let idx = 0
  for (const el of nodeEls) {
    const r = el.getBoundingClientRect()
    if (cursorX > r.left + r.width / 2) idx++
    else break
  }
  return idx
}

function onSortableDrop(dropIdx: number | null) {
  const src = draggedSource.value
  if (src && dropIdx !== null) {
    const target = targetForIndex(dropIdx, src)
    if (target) emit('drop', { source: src, target })
  }
  cleanupDrag()
}

function targetForIndex(idx: number, source: DragSource): DropTarget | null {
  // Indices map onto the ORIGINAL chain order (not the preview).
  const base = orderIds.value
  // For a node-source reorder, exclude the dragged node when picking neighbours.
  const filtered = source.kind === 'node' ? base.filter(id => id !== source.nodeId) : base
  // When reorder lands the node back at its same position, ignore.
  if (source.kind === 'node') {
    const fromIdx = base.indexOf(source.nodeId)
    const wouldLandAt = fromIdx < idx ? idx - 1 : idx
    if (wouldLandAt === fromIdx) return null
  }
  const beforeNodeId = filtered[idx] ?? null
  const afterNodeId  = filtered[idx - 1] ?? null
  return { kind: 'between-nodes', afterNodeId, beforeNodeId }
}

function cancelDrag() { cleanupDrag() }

function cleanupDrag() {
  draggedSource.value = null
  ghost.value = null
  window.removeEventListener('pointermove', onDragMove)
}

onBeforeUnmount(() => {
  teardownPending()
  cleanupDrag()
})

defineExpose({ startPaletteDrag })
</script>

<template>
  <div data-ui="flow-canvas" :class="$style.scroll">
    <div :class="$style.inner" ref="slotsEl">
      <!-- Optional lead card (e.g. the flow's trigger). Not part of the sortable chain. -->
      <div v-if="$slots.lead" :class="$style.slot"><slot name="lead" /></div>
      <FlowConnector v-if="$slots.lead && !isEmpty" />

      <EmptyState
        v-if="isEmpty && !$slots.lead"
        title="Empty flow"
        sub="Drag a node from the palette to get started."
      />
      <span
        v-else-if="isEmpty"
        style="font-family: var(--font-mono); font-size: 13px; color: var(--color-muted); align-self: center; padding: 0 16px; white-space: nowrap;"
      >// add an Agent node from the palette →</span>

      <template v-else>
        <template v-for="item in displayChain" :key="item.key">
          <!-- Real node -->
          <div
            v-if="item.kind === 'node'"
            data-node-slot
            :class="$style.slot"
          >
            <FlowNode
              :node="item.node!"
              :selected="item.node!.id === selectedNodeId"
              :orphan="item.orphan"
              :dragging="item.isDragging"
              :draggable="reorderable && !item.orphan"
              :in-count="degree.inCount.get(item.node!.id) ?? 0"
              :out-count="degree.outCount.get(item.node!.id) ?? 0"
              @pointer-down="onNodePointerDown"
              @inspect="emit('select', $event)"
            />
          </div>

          <!-- Palette phantom — the preview of where the new node will land -->
          <div
            v-else-if="item.kind === 'phantom'"
            data-node-slot
            :class="[$style.slot, $style.phantom]"
          >
            <div :class="$style.phantomCard">
              <span :class="$style.phantomLabel">{{ item.phantom?.label ?? 'New node' }}</span>
              <span :class="$style.phantomType">{{ item.phantom?.nodeType ?? '' }}</span>
            </div>
          </div>

          <!-- Connector between adjacent items -->
          <FlowConnector v-else />
        </template>
      </template>
    </div>

    <!-- Ghost element following the cursor. Position: fixed so it ignores
         scroll. Pointer-events: none so it never intercepts drop handling. -->
    <Teleport to="body">
      <div
        v-if="ghost"
        :class="$style.ghost"
        :style="{
          transform: `translate(${ghost.x}px, ${ghost.y}px)`,
          width: ghost.w + 'px',
        }"
      >
        <div :class="$style.ghostInner">
          <template v-if="ghost.payload.kind === 'node'">
            <span :class="$style.ghostLabel">
              {{ nodeById.get(ghost.payload.nodeId)?.label ?? 'Node' }}
            </span>
            <span :class="$style.ghostType">
              {{ nodeById.get(ghost.payload.nodeId)?.nodeType ?? '' }}
            </span>
          </template>
          <template v-else-if="ghost.payload.kind === 'palette'">
            <span :class="$style.ghostLabel">{{ ghost.payload.item.label }}</span>
            <span :class="$style.ghostType">{{ ghost.payload.item.nodeType }}</span>
          </template>
        </div>
      </div>
    </Teleport>
  </div>
</template>

<style module>
.scroll {
  width: 100%;
  max-width: 100%;
  min-width: 0;
  height: 100%;
  overflow-x: auto;
  overflow-y: hidden;
  min-height: 240px;
  box-sizing: border-box;

  background-image: radial-gradient(
    circle at 1px 1px,
    var(--color-border-soft, var(--color-border)) 1px,
    transparent 0
  );
  background-size: 20px 20px;
  background-position: 0 0;
}

.inner {
  display: flex;
  align-items: center;
  width: max-content;
  min-width: 100%;
  height: 100%;
  min-height: 240px;
  padding: var(--space-6);
  gap: 0;
  box-sizing: border-box;
}

.slot {
  display: flex;
  align-items: stretch;
  flex-shrink: 0;
}

.scroll::-webkit-scrollbar { height: 8px; }
.scroll::-webkit-scrollbar-track { background: transparent; }
.scroll::-webkit-scrollbar-thumb {
  background: var(--color-border-soft, var(--color-border));
  border-radius: 4px;
}

/* — Palette phantom — the placeholder shown where a new node will drop. — */
.phantom {
  min-width: 280px;
  max-width: 320px;
}

.phantomCard {
  flex: 1;
  display: flex;
  flex-direction: column;
  gap: var(--space-2);
  border: 2px dashed var(--color-accent);
  border-radius: var(--radius);
  background: var(--color-accent-soft, transparent);
  padding: var(--space-3) var(--space-4);
  min-height: 120px;
  justify-content: center;
}

.phantomLabel {
  font-weight: 600;
  color: var(--color-accent);
}

.phantomType {
  font-family: var(--font-mono);
  font-size: var(--font-size-xs);
  color: var(--color-accent);
  text-transform: uppercase;
  letter-spacing: 0.06em;
}

/* — Ghost (teleported to body) — follows the cursor during drag. — */
.ghost {
  position: fixed;
  top: 0;
  left: 0;
  z-index: 100;
  pointer-events: none;
  opacity: 0.92;
  filter: drop-shadow(0 8px 16px oklch(0 0 0 / 0.45));
  transition: none;
}

.ghostInner {
  display: flex;
  flex-direction: column;
  gap: var(--space-1);
  padding: var(--space-3) var(--space-4);
  border: 1px solid var(--color-accent);
  border-radius: var(--radius);
  background: var(--color-bg-2, var(--color-surface));
  transform: rotate(-1.5deg);
}

.ghostLabel {
  font-weight: 600;
  color: var(--color-fg);
  font-size: var(--font-size-base);
}

.ghostType {
  font-family: var(--font-mono);
  font-size: var(--font-size-xs);
  color: var(--color-text-dim, var(--color-muted));
  text-transform: uppercase;
  letter-spacing: 0.06em;
}
</style>
