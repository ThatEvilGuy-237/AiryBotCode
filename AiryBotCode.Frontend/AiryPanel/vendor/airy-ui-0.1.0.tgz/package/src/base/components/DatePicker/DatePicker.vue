<script setup lang="ts">
/**
 * DatePicker
 * A calendar date — a day on a wall calendar, with no time and no timezone.
 * The value is an ISO `yyyy-mm-dd` string, or `null` when empty. That is the
 * entire contract and it is deliberately narrow.
 *
 * It is a string and not a `Date` on purpose. A `Date` is an instant, not a
 * day: `new Date('2026-08-17')` is parsed as UTC midnight, which is still the
 * 16th anywhere west of Greenwich, so a picker that speaks `Date` shows one day
 * and saves another for half the planet. `Date` also drags a time along, so
 * two "equal" days compare unequal. ISO days have none of that — they sort and
 * compare correctly as plain strings (`day >= from && day <= to`), they are what
 * an API wants on the wire, and `null` is unambiguously empty.
 *
 * All calendar arithmetic here is done on a **local-noon anchor**
 * (`new Date(y, m, d, 12)`). Local midnight is not safe: in zones whose DST
 * transition lands on or near midnight, `new Date(y, m, d)` can normalise to
 * 23:00 the previous day, and then `getDate()` is off by one and "add a day"
 * silently stays put. Noon is twelve hours from either edge, so no real-world
 * offset shift can cross a date boundary. The value is never produced by
 * `toISOString()` — that would reintroduce the UTC bug the string type exists
 * to avoid.
 *
 * Typing beats clicking, so the control is a real text input, not a div that
 * opens a calendar. Accepted input:
 *   `2026-08-17`, `2026/8/17`, `20260817`   — year first, never ambiguous
 *   `17 aug 2026`, `Aug 17 2026`            — textual month, any locale
 *   `17`                                    — that day of the viewed month
 *   `today` / `t`, `+7`, `-30`              — relative to today
 * All-numeric day/month input (`03/04/2026`) is **rejected** unless you opt in
 * with `numericOrder`, because guessing between 3 April and 4 March is how a
 * form quietly saves the wrong day. Rejected text does not commit: the field
 * reverts and says so.
 *
 * There is no range mode and no time. A range is two of these, cross-bound with
 * `:max="to"` / `:min="from"` — that keeps both ends independently typeable and
 * keeps this component's value one thing. An hour-of-day is a `<NumberField>`
 * with `:min="0" :max="23"`, not a calendar.
 *
 * Put it in a `<Field>` for the label / hint / error shell: Field finds this
 * component's `<input>`, gives it an id, points its `<label for>` at it, and
 * this component reads Field's context back so an error reaches the control
 * border. Do not pass `label` to both.
 *
 * @prop modelValue     - the value (use v-model): ISO `yyyy-mm-dd`, or `null`
 *                        for empty. Any other string is treated as empty.
 * @prop min            - earliest selectable day (ISO). Earlier days are
 *                        `aria-disabled`, unreachable by arrow keys, and refuse
 *                        to commit if typed.
 * @prop max            - latest selectable day (ISO). Same rules as `min`.
 * @prop disabledDates  - `(iso) => boolean` for holes inside the range, e.g.
 *                        weekends or booked days.
 * @prop locale         - BCP-47 tag for month and weekday names. Omit to follow
 *                        the browser. It never changes the value, only labels.
 * @prop weekStart      - first column: 0 Sunday … 6 Saturday (default 1, Monday).
 * @prop numericOrder   - how to read all-numeric `nn/nn/nnnn`: 'iso' (default,
 *                        reject it), 'dmy', or 'mdy'. Year-first always works.
 * @prop placeholder    - default 'yyyy-mm-dd', so the accepted shape is visible.
 * @prop clearable      - show the clear button once a day is set (default true).
 * @prop todayButton    - show "Today" in the calendar footer (default true).
 * @prop hint           - show the mono `//` footer line (default true).
 * @prop openOnFocus    - open the calendar on focus as well as on click.
 * @prop width          - CSS width of the input box (default '13ch').
 * @prop block          - fill the container instead of being content-sized.
 * @prop size           - 'sm' | 'md' (default 'md').
 * @prop readonly       - display-only, still focusable and announced.
 * @prop disabled       - disabled.
 * @prop id             - force the input id. Leave it off inside a `<Field>`.
 * @prop name           - form field name.
 * @prop ariaLabel      - accessible name when there is no `<Field>` label.
 *
 * @event update:modelValue - ISO string or `null`, on **commit only**: Enter,
 *                            blur, a clicked day, or Clear. Deliberately not
 *                            per keystroke — `2026-08-1` parses as 1 August, and
 *                            emitting that mid-word would hand the parent a real
 *                            but wrong day on the way to the 17th.
 * @event change            - same payload as above. Use either; `change` exists
 *                            so a save handler reads the same as NumberField's.
 * @event open              - the calendar opened.
 * @event close             - the calendar closed.
 *
 * @slot footer - replaces the mono `//` line in the calendar footer.
 *
 * Status: new | Consumers: available — first adopter is the ThatEvilGuyMemory
 * portal graph page date filter
 */
import { computed, inject, nextTick, onBeforeUnmount, ref, watch } from 'vue'
import Icon from '../Icon/Icon.vue'
import { FIELD_KEY } from '../Field/keys'

export type DatePickerSize = 'sm' | 'md'
export type DatePickerNumericOrder = 'iso' | 'dmy' | 'mdy'

export interface DatePickerDay {
  iso: string
  day: number
  outside: boolean
  blocked: boolean
  selected: boolean
  today: boolean
}

const props = withDefaults(defineProps<{
  modelValue: string | null
  min?: string
  max?: string
  disabledDates?: (iso: string) => boolean
  locale?: string
  weekStart?: number
  numericOrder?: DatePickerNumericOrder
  placeholder?: string
  clearable?: boolean
  todayButton?: boolean
  hint?: boolean
  openOnFocus?: boolean
  width?: string
  block?: boolean
  size?: DatePickerSize
  readonly?: boolean
  disabled?: boolean
  id?: string
  name?: string
  ariaLabel?: string
}>(), {
  weekStart: 1,
  numericOrder: 'iso',
  placeholder: 'yyyy-mm-dd',
  clearable: true,
  todayButton: true,
  hint: true,
  openOnFocus: false,
  width: '13ch',
  block: false,
  size: 'md',
  readonly: false,
  disabled: false,
})

const emit = defineEmits<{
  'update:modelValue': [value: string | null]
  change: [value: string | null]
  open: []
  close: []
}>()

const slots = defineSlots<{ footer?: () => any }>()

const field = inject(FIELD_KEY, null)

const panelId = `hive-dp-${Math.random().toString(36).slice(2, 9)}-panel`

const root = ref<HTMLElement>()
const inputEl = ref<HTMLInputElement>()
const panelEl = ref<HTMLElement>()
const gridEl = ref<HTMLElement>()

const open = ref(false)
const dropUp = ref(false)
const focused = ref(false)
const draft = ref('')
const note = ref<'unreadable' | 'unavailable' | 'min' | 'max'>()
const slide = ref<'next' | 'prev'>()
const todayIso = ref(isoOf(new Date()))

const value = computed(() => (isIso(props.modelValue) ? (props.modelValue as string) : null))
const invalid = computed(() => field?.invalid.value ?? false)
const inert = computed(() => props.disabled || props.readonly)

const view = ref(monthOf(value.value ?? todayIso.value))
const focusIso = ref(value.value ?? land(todayIso.value, 1))

function pad2(n: number): string {
  return String(n).padStart(2, '0')
}

function toIso(y: number, m: number, d: number): string {
  return `${String(y).padStart(4, '0')}-${pad2(m + 1)}-${pad2(d)}`
}

function isoOf(d: Date): string {
  return toIso(d.getFullYear(), d.getMonth(), d.getDate())
}

function parts(iso: string): [number, number, number] | null {
  const m = /^(\d{4})-(\d{2})-(\d{2})$/.exec(iso)
  if (!m) return null
  const y = Number(m[1])
  const mo = Number(m[2]) - 1
  const d = Number(m[3])
  if (mo < 0 || mo > 11) return null
  if (d < 1 || d > daysInMonth(y, mo)) return null
  return [y, mo, d]
}

function isIso(v: unknown): boolean {
  return typeof v === 'string' && parts(v) !== null
}

function anchor(iso: string | null): Date | null {
  const p = iso ? parts(iso) : null
  return p ? new Date(p[0], p[1], p[2], 12, 0, 0, 0) : null
}

function daysInMonth(y: number, m: number): number {
  return new Date(y, m + 1, 0, 12).getDate()
}

function monthOf(iso: string): { y: number; m: number } {
  const p = parts(iso)
  const now = new Date()
  return p ? { y: p[0], m: p[1] } : { y: now.getFullYear(), m: now.getMonth() }
}

function addDays(iso: string, n: number): string {
  const a = anchor(iso)
  if (!a) return iso
  a.setDate(a.getDate() + n)
  return isoOf(a)
}

function addMonths(iso: string, n: number): string {
  const p = parts(iso)
  if (!p) return iso
  const total = p[0] * 12 + p[1] + n
  const y = Math.floor(total / 12)
  const m = total - y * 12
  return toIso(y, m, Math.min(p[2], daysInMonth(y, m)))
}

function beyond(iso: string): 'min' | 'max' | null {
  if (props.min && isIso(props.min) && iso < props.min) return 'min'
  if (props.max && isIso(props.max) && iso > props.max) return 'max'
  return null
}

function isBlocked(iso: string): boolean {
  if (beyond(iso)) return true
  return props.disabledDates ? props.disabledDates(iso) === true : false
}

function seek(from: string, step: number, limit = 200): string {
  let cur = from
  for (let i = 0; i < limit; i += 1) {
    const next = addDays(cur, step)
    if (beyond(next)) return from
    if (!isBlocked(next)) return next
    cur = next
  }
  return from
}

function land(iso: string, dir: number): string {
  let target = iso
  const off = beyond(target)
  if (off === 'min') target = props.min as string
  if (off === 'max') target = props.max as string
  if (!isBlocked(target)) return target
  return seek(target, dir >= 0 ? 1 : -1)
}

function weekIndex(iso: string): number {
  const a = anchor(iso)
  if (!a) return 0
  return (a.getDay() - props.weekStart + 7) % 7
}

const fmtLong = computed(() => new Intl.DateTimeFormat(props.locale, {
  weekday: 'long', day: 'numeric', month: 'long', year: 'numeric',
}))
const fmtMonth = computed(() => new Intl.DateTimeFormat(props.locale, { month: 'long', year: 'numeric' }))

const monthLabel = computed(() => {
  const a = new Date(view.value.y, view.value.m, 15, 12)
  return fmtMonth.value.format(a)
})

const weekdays = computed(() => {
  const short = new Intl.DateTimeFormat(props.locale, { weekday: 'short' })
  const long = new Intl.DateTimeFormat(props.locale, { weekday: 'long' })
  return Array.from({ length: 7 }, (_unused, i) => {
    const d = new Date(2024, 0, 7 + ((props.weekStart + i) % 7), 12)
    return {
      abbr: short.format(d).replace('.', '').slice(0, 2).toUpperCase(),
      full: long.format(d),
    }
  })
})

const gridStart = computed(() => {
  const first = toIso(view.value.y, view.value.m, 1)
  return addDays(first, -weekIndex(first))
})

const rows = computed<DatePickerDay[][]>(() => {
  const cursor = anchor(gridStart.value)
  const out: DatePickerDay[][] = []
  if (!cursor) return out
  for (let r = 0; r < 6; r += 1) {
    const row: DatePickerDay[] = []
    for (let c = 0; c < 7; c += 1) {
      const iso = isoOf(cursor)
      row.push({
        iso,
        day: cursor.getDate(),
        outside: cursor.getMonth() !== view.value.m,
        blocked: isBlocked(iso),
        selected: iso === value.value,
        today: iso === todayIso.value,
      })
      cursor.setDate(cursor.getDate() + 1)
    }
    out.push(row)
  }
  return out
})

const viewKey = computed(() => `${view.value.y}-${view.value.m}`)

const monthTable = computed(() => {
  const tags = [props.locale, 'en-US'].filter(Boolean) as string[]
  return Array.from({ length: 12 }, (_unused, m) => {
    const d = new Date(2024, m, 15, 12)
    const names = new Set<string>()
    for (const tag of tags) {
      for (const style of ['long', 'short'] as const) {
        const n = new Intl.DateTimeFormat(tag, { month: style })
          .format(d).toLowerCase().replace(/\.$/, '')
        if (/^[a-zÀ-ɏ]{3,}$/.test(n)) names.add(n)
      }
    }
    return { m, names: [...names] }
  })
})

function matchMonth(word: string): number | null {
  const w = word.toLowerCase().replace(/\.$/, '')
  if (w.length < 3) return null
  let hit: number | null = null
  for (const entry of monthTable.value) {
    for (const n of entry.names) {
      if (!n.startsWith(w) && !w.startsWith(n)) continue
      if (hit !== null && hit !== entry.m) return null
      hit = entry.m
    }
  }
  return hit
}

function fullYear(raw: string | undefined, fallback: number): number {
  if (!raw) return fallback
  const n = Number(raw)
  return raw.length <= 2 ? 2000 + n : n
}

function build(y: number, m: number, d: number): string | null {
  if (y < 1000 || y > 9999) return null
  if (m < 0 || m > 11) return null
  if (d < 1 || d > daysInMonth(y, m)) return null
  return toIso(y, m, d)
}

function parseInput(raw: string): { ok: boolean; iso: string | null } {
  const s = raw.trim().replace(/\s+/g, ' ')
  if (s === '') return { ok: true, iso: null }
  const low = s.toLowerCase()

  if (low === 'today' || low === 't' || low === 'now') return { ok: true, iso: todayIso.value }

  const rel = /^([+-])(\d{1,4})$/.exec(low)
  if (rel) return { ok: true, iso: addDays(todayIso.value, Number(rel[2]) * (rel[1] === '-' ? -1 : 1)) }

  const yFirst = /^(\d{4})[-/. ](\d{1,2})[-/. ](\d{1,2})$/.exec(s)
  if (yFirst) {
    const iso = build(Number(yFirst[1]), Number(yFirst[2]) - 1, Number(yFirst[3]))
    return { ok: iso !== null, iso }
  }

  const packed = /^(\d{4})(\d{2})(\d{2})$/.exec(s)
  if (packed) {
    const iso = build(Number(packed[1]), Number(packed[2]) - 1, Number(packed[3]))
    return { ok: iso !== null, iso }
  }

  const dayFirstText = /^(\d{1,2})[ .-]+([^\s.,\d]{3,})\.?[ ,]*(\d{2}|\d{4})?$/.exec(s)
  if (dayFirstText) {
    const m = matchMonth(dayFirstText[2])
    if (m === null) return { ok: false, iso: null }
    const iso = build(fullYear(dayFirstText[3], view.value.y), m, Number(dayFirstText[1]))
    return { ok: iso !== null, iso }
  }

  const monthFirstText = /^([^\s.,\d]{3,})\.?[ .-]+(\d{1,2})[ ,]*(\d{2}|\d{4})?$/.exec(s)
  if (monthFirstText) {
    const m = matchMonth(monthFirstText[1])
    if (m === null) return { ok: false, iso: null }
    const iso = build(fullYear(monthFirstText[3], view.value.y), m, Number(monthFirstText[2]))
    return { ok: iso !== null, iso }
  }

  const dayOnly = /^(\d{1,2})$/.exec(s)
  if (dayOnly) {
    const iso = build(view.value.y, view.value.m, Number(dayOnly[1]))
    return { ok: iso !== null, iso }
  }

  const numeric = /^(\d{1,2})[-/. ](\d{1,2})(?:[-/. ](\d{2}|\d{4}))?$/.exec(s)
  if (numeric) {
    if (props.numericOrder === 'iso') return { ok: false, iso: null }
    const a = Number(numeric[1])
    const b = Number(numeric[2])
    const d = props.numericOrder === 'dmy' ? a : b
    const m = (props.numericOrder === 'dmy' ? b : a) - 1
    const iso = build(fullYear(numeric[3], view.value.y), m, d)
    return { ok: iso !== null, iso }
  }

  return { ok: false, iso: null }
}

const longLabel = computed(() => {
  const a = anchor(value.value)
  return a ? fmtLong.value.format(a) : ''
})

const boundLine = computed(() => {
  const bits: string[] = []
  if (props.min && isIso(props.min)) bits.push(`from ${props.min}`)
  if (props.max && isIso(props.max)) bits.push(`to ${props.max}`)
  if (bits.length) return bits.join(' · ')
  if (longLabel.value) return longLabel.value
  return 'yyyy-mm-dd · 17 aug · today · +7'
})

const boundTag = computed(() => {
  if (note.value === 'unreadable') return 'unreadable'
  if (note.value === 'unavailable') return 'unavailable'
  if (note.value === 'min') return `from ${props.min}`
  if (note.value === 'max') return `to ${props.max}`
  return ''
})

const display = computed(() => (focused.value ? draft.value : (value.value ?? '')))

function label(iso: string): string {
  const a = anchor(iso)
  return a ? fmtLong.value.format(a) : iso
}

function clearNotes() {
  note.value = undefined
}

function refuse(reason: 'unreadable' | 'unavailable' | 'min' | 'max') {
  note.value = reason
  draft.value = value.value ?? ''
}

function commit(iso: string | null) {
  clearNotes()
  const next = iso === null ? null : iso
  if (next !== value.value) {
    emit('update:modelValue', next)
    emit('change', next)
  }
  draft.value = next ?? ''
  if (next) {
    view.value = monthOf(next)
    focusIso.value = next
  }
}

function settle() {
  if (inert.value) return
  const result = parseInput(draft.value)
  if (!result.ok) {
    refuse('unreadable')
    return
  }
  if (result.iso === null) {
    commit(null)
    return
  }
  const off = beyond(result.iso)
  if (off) {
    refuse(off)
    return
  }
  if (isBlocked(result.iso)) {
    refuse('unavailable')
    return
  }
  commit(result.iso)
}

function measure() {
  const box = root.value?.getBoundingClientRect()
  if (!box) return
  dropUp.value = box.bottom + 336 > window.innerHeight && box.top > 336
}

function openPanel(focusGrid = false) {
  if (inert.value || open.value) return
  todayIso.value = isoOf(new Date())
  const seed = value.value ?? land(todayIso.value, 1)
  view.value = monthOf(seed)
  focusIso.value = seed
  open.value = true
  measure()
  emit('open')
  if (focusGrid) nextTick(focusCell)
}

function closePanel(restore = true) {
  if (!open.value) return
  open.value = false
  slide.value = undefined
  emit('close')
  if (restore) inputEl.value?.focus()
}

function toggle() {
  inputEl.value?.focus()
  if (open.value) closePanel()
  else openPanel()
}

function focusCell() {
  gridEl.value?.querySelector<HTMLElement>(`[data-iso="${focusIso.value}"]`)?.focus()
}

let slideTimer: ReturnType<typeof setTimeout> | undefined
function nudge(dir: 'next' | 'prev') {
  slide.value = undefined
  clearTimeout(slideTimer)
  nextTick(() => {
    slide.value = dir
    slideTimer = setTimeout(() => { slide.value = undefined }, 200)
  })
}

function moveFocus(iso: string) {
  if (iso === focusIso.value) return
  const from = focusIso.value
  const key = viewKey.value
  focusIso.value = iso
  view.value = monthOf(iso)
  if (viewKey.value !== key) nudge(iso > from ? 'next' : 'prev')
  nextTick(focusCell)
}

function shiftMonth(n: number) {
  nudge(n > 0 ? 'next' : 'prev')
  const next = addMonths(toIso(view.value.y, view.value.m, 1), n)
  view.value = monthOf(next)
  const kept = land(addMonths(focusIso.value, n), n)
  focusIso.value = monthOf(kept).m === view.value.m ? kept : land(toIso(view.value.y, view.value.m, 1), 1)
}

function pick(iso: string) {
  if (isBlocked(iso)) return
  commit(iso)
  closePanel()
}

function goToday() {
  todayIso.value = isoOf(new Date())
  const target = land(todayIso.value, 1)
  view.value = monthOf(target)
  focusIso.value = target
  nextTick(focusCell)
}

function clear() {
  commit(null)
  inputEl.value?.focus()
}

function onInput() {
  draft.value = inputEl.value?.value ?? ''
  clearNotes()
}

function onFocus() {
  focused.value = true
  draft.value = value.value ?? ''
  if (props.openOnFocus) openPanel()
}

function onBlur(e: FocusEvent) {
  const to = e.relatedTarget as Node | null
  if (!to && open.value) return
  if (to && root.value?.contains(to)) return
  focused.value = false
  settle()
  closePanel(false)
}

function onInputKeydown(e: KeyboardEvent) {
  if (e.key === 'ArrowDown' || e.key === 'ArrowUp') {
    e.preventDefault()
    if (open.value) focusCell()
    else openPanel(true)
    return
  }
  if (e.key === 'Enter') {
    e.preventDefault()
    settle()
    closePanel(false)
    return
  }
  if (e.key === 'Escape') {
    if (open.value) { e.preventDefault(); closePanel(); return }
    draft.value = value.value ?? ''
    clearNotes()
  }
}

function onGridKeydown(e: KeyboardEvent) {
  const key = e.key
  if (key === 'Escape') { e.preventDefault(); closePanel(); return }
  if (key === 'Enter' || key === ' ' || key === 'Spacebar') { e.preventDefault(); pick(focusIso.value); return }

  if (key === 'ArrowLeft') { e.preventDefault(); moveFocus(seek(focusIso.value, -1)); return }
  if (key === 'ArrowRight') { e.preventDefault(); moveFocus(seek(focusIso.value, 1)); return }
  if (key === 'ArrowUp') { e.preventDefault(); moveFocus(seek(focusIso.value, -7, 30)); return }
  if (key === 'ArrowDown') { e.preventDefault(); moveFocus(seek(focusIso.value, 7, 30)); return }

  if (key === 'Home' || key === 'End') {
    e.preventDefault()
    const idx = weekIndex(focusIso.value)
    const edge = addDays(focusIso.value, key === 'Home' ? -idx : 6 - idx)
    moveFocus(isBlocked(edge) ? seek(edge, key === 'Home' ? 1 : -1, 6) : edge)
    return
  }

  if (key === 'PageUp' || key === 'PageDown') {
    e.preventDefault()
    const n = (key === 'PageUp' ? -1 : 1) * (e.shiftKey ? 12 : 1)
    shiftMonth(n)
    nextTick(focusCell)
  }
}

function onPanelKeydown(e: KeyboardEvent) {
  if (e.key !== 'Tab') return
  const items = [...(panelEl.value?.querySelectorAll<HTMLElement>('[data-stop]') ?? [])]
    .filter(el => !el.hasAttribute('disabled') && el.getAttribute('aria-disabled') !== 'true')
  if (items.length < 2) return
  const first = items[0]
  const last = items[items.length - 1]
  if (!e.shiftKey && e.target === last) { e.preventDefault(); first.focus() }
  else if (e.shiftKey && e.target === first) { e.preventDefault(); last.focus() }
}

function onDocumentPointer(e: PointerEvent) {
  if (root.value?.contains(e.target as Node)) return
  settle()
  closePanel(false)
}

watch(open, isOpen => {
  if (typeof document === 'undefined') return
  if (isOpen) {
    document.addEventListener('pointerdown', onDocumentPointer, true)
    window.addEventListener('resize', measure)
    window.addEventListener('scroll', measure, true)
  } else {
    document.removeEventListener('pointerdown', onDocumentPointer, true)
    window.removeEventListener('resize', measure)
    window.removeEventListener('scroll', measure, true)
  }
})

watch(() => props.modelValue, () => {
  clearNotes()
  if (!focused.value) draft.value = value.value ?? ''
  if (value.value && !open.value) {
    view.value = monthOf(value.value)
    focusIso.value = value.value
  }
})

onBeforeUnmount(() => {
  if (typeof document === 'undefined') return
  document.removeEventListener('pointerdown', onDocumentPointer, true)
  window.removeEventListener('resize', measure)
  window.removeEventListener('scroll', measure, true)
})

draft.value = value.value ?? ''

defineExpose({
  focus: () => inputEl.value?.focus(),
  open: () => openPanel(),
  close: () => closePanel(false),
})
</script>

<template>
  <div data-ui="date-picker" ref="root" :class="[$style.root, block && $style.block]" @focusout="onBlur">
    <div
      :class="[
        $style.control,
        $style[size],
        focused && $style.focused,
        open && $style.live,
        invalid && $style.invalid,
        disabled && $style.disabled,
        readonly && $style.readonly,
      ]"
    >
      <input
        ref="inputEl"
        :id="id"
        type="text"
        role="combobox"
        autocomplete="off"
        spellcheck="false"
        inputmode="numeric"
        :class="[$style.input, note && $style.bad]"
        :style="{ width: block ? undefined : width }"
        :name="name"
        :value="display"
        :placeholder="placeholder"
        :disabled="disabled"
        :readonly="readonly"
        :aria-label="ariaLabel"
        :aria-expanded="open"
        :aria-controls="panelId"
        aria-haspopup="dialog"
        aria-autocomplete="none"
        @input="onInput"
        @focus="onFocus"
        @keydown="onInputKeydown"
      />

      <span v-if="boundTag" :class="$style.tag" role="status">{{ boundTag }}</span>

      <button
        v-if="clearable && value && !inert"
        type="button"
        tabindex="-1"
        :class="$style.iconBtn"
        aria-label="Clear date"
        @mousedown.prevent
        @click="clear"
      >
        <Icon name="close" :size="12" />
      </button>

      <button
        type="button"
        tabindex="-1"
        :class="[$style.iconBtn, $style.caret, open && $style.caretOpen]"
        :disabled="inert"
        :aria-label="open ? 'Close calendar' : 'Open calendar'"
        @mousedown.prevent
        @click="toggle"
      >
        <Icon name="chevron-down" :size="13" />
      </button>
    </div>

    <div
      v-if="open"
      ref="panelEl"
      :id="panelId"
      role="dialog"
      aria-modal="false"
      :aria-label="`Choose a date — ${monthLabel}`"
      :class="[$style.panel, dropUp && $style.panelUp]"
      @keydown="onPanelKeydown"
    >
      <div :class="$style.head">
        <button
          type="button"
          data-stop
          :class="$style.navBtn"
          aria-label="Previous month"
          @click="shiftMonth(-1)"
        >
          <Icon name="chevron-left" :size="14" />
        </button>
        <span :class="$style.month" aria-live="polite">{{ monthLabel }}</span>
        <button
          type="button"
          data-stop
          :class="$style.navBtn"
          aria-label="Next month"
          @click="shiftMonth(1)"
        >
          <Icon name="chevron-right" :size="14" />
        </button>
      </div>

      <div ref="gridEl" role="grid" :aria-label="monthLabel" :class="$style.grid" @keydown="onGridKeydown">
        <div role="rowgroup">
          <div role="row" :class="$style.week">
            <span
              v-for="w in weekdays"
              :key="w.full"
              role="columnheader"
              :aria-label="w.full"
              :class="$style.wd"
            >{{ w.abbr }}</span>
          </div>
        </div>

        <div :key="viewKey" role="rowgroup" :class="$style.body" :data-slide="slide">
          <div v-for="(row, r) in rows" :key="r" role="row" :class="$style.week">
            <span
              v-for="cell in row"
              :key="cell.iso"
              role="gridcell"
              :data-iso="cell.iso"
              :data-stop="cell.iso === focusIso ? '' : undefined"
              :tabindex="cell.iso === focusIso ? 0 : -1"
              :aria-label="label(cell.iso)"
              :aria-selected="cell.selected"
              :aria-disabled="cell.blocked || undefined"
              :aria-current="cell.today ? 'date' : undefined"
              :class="[
                $style.day,
                cell.outside && $style.dayOut,
                cell.blocked && $style.dayOff,
                cell.today && $style.dayToday,
                cell.selected && $style.daySel,
              ]"
              @mousedown.prevent
              @click="pick(cell.iso)"
              @focus="focusIso = cell.iso"
            >{{ cell.day }}</span>
          </div>
        </div>
      </div>

      <div :class="$style.foot">
        <p v-if="hint || $slots.footer" :class="$style.hintLine">
          <span :class="$style.slashes" aria-hidden="true">//</span>
          <span><slot name="footer">{{ boundLine }}</slot></span>
        </p>
        <button
          v-if="todayButton"
          type="button"
          data-stop
          :class="$style.footBtn"
          :aria-disabled="isBlocked(todayIso) || undefined"
          @click="goToday"
        >Today</button>
      </div>
    </div>
  </div>
</template>

<style module>
/* Shell */
.root { position: relative; display: inline-block; min-width: 0; }
.block { display: block; width: 100%; }

/* Control — one hairline box, accent only on the focus ring */
.control {
  display: inline-flex;
  align-items: stretch;
  gap: var(--space-2);
  min-width: 0;
  padding-right: var(--space-1);
  background: var(--color-surface-mute, var(--color-bg));
  border: 1px solid var(--color-border);
  border-radius: var(--radius);
  transition: border-color 0.12s ease;
}
.control:hover:not(.disabled) { border-color: var(--color-border-hi, var(--color-border)); }
.focused, .live {
  border-color: var(--color-accent);
  outline: 1px solid var(--color-accent-edge);
}
.invalid { border-color: var(--color-danger); }
.invalid.focused { outline-color: var(--color-danger); }
.disabled { opacity: 0.5; }
.readonly { background: var(--color-bg); }
.block .control { display: flex; width: 100%; }
.sm { height: 28px; }
.md { height: 34px; }

/* The value — always ISO, mono and tabular so the field never reflows */
.input {
  flex: 1 1 auto;
  min-width: 0;
  border: 0;
  background: none;
  padding: 0 0 0 var(--space-3);
  color: var(--color-fg);
  font-family: var(--font-mono);
  font-variant-numeric: tabular-nums;
  letter-spacing: 0;
}
.sm .input { font-size: var(--font-size-sm); }
.md .input { font-size: var(--font-size-base); }
.input:focus { outline: none; }
.input:disabled { cursor: not-allowed; }
.input::placeholder { color: var(--color-text-ghost); }
.bad { color: var(--color-danger); }

/* Why the value did not commit */
.tag {
  display: inline-flex;
  align-items: center;
  flex-shrink: 0;
  padding-left: var(--space-2);
  border-left: 1px solid var(--color-border-soft, var(--color-border));
  font-family: var(--font-mono);
  font-size: var(--font-size-xs);
  color: var(--color-warn);
  white-space: nowrap;
}

.iconBtn {
  display: inline-flex;
  align-items: center;
  justify-content: center;
  flex-shrink: 0;
  width: 20px;
  padding: 0;
  border: 0;
  background: none;
  color: var(--color-text-ghost);
  cursor: pointer;
  transition: color 0.12s ease, transform 0.12s ease;
}
.iconBtn:hover:not(:disabled) { color: var(--color-accent); }
.iconBtn:disabled { cursor: not-allowed; color: var(--color-border); }
.caretOpen { transform: rotate(180deg); color: var(--color-accent); }

/* Popover — bordered surface panel, no shadow */
.panel {
  position: absolute;
  z-index: 20;
  top: calc(100% + var(--space-1));
  left: 0;
  display: flex;
  flex-direction: column;
  background: var(--color-surface);
  border: 1px solid var(--color-border-hi);
  border-radius: var(--radius);
  padding: var(--space-2);
  overflow: hidden;
}
.panelUp { top: auto; bottom: calc(100% + var(--space-1)); }

.head {
  display: flex;
  align-items: center;
  gap: var(--space-1);
  padding-bottom: var(--space-2);
}
.month {
  flex: 1 1 auto;
  text-align: center;
  font-family: var(--font-family);
  font-size: var(--font-size-sm);
  color: var(--color-fg);
  text-transform: capitalize;
}
.navBtn {
  display: inline-flex;
  align-items: center;
  justify-content: center;
  width: 24px;
  height: 24px;
  padding: 0;
  border: 1px solid transparent;
  border-radius: var(--r-1);
  background: none;
  color: var(--color-muted);
  cursor: pointer;
  transition: color 0.12s ease, border-color 0.12s ease;
}
.navBtn:hover { color: var(--color-fg); border-color: var(--color-border); }
.navBtn:focus-visible { outline: none; color: var(--color-accent); border-color: var(--color-accent); }

/* Grid — 6 fixed rows so opening the panel never reflows the page */
.grid { display: block; }
.week { display: grid; grid-template-columns: repeat(7, 30px); gap: 2px; }

/* Weekday headers — uppercase mono ghosts */
.wd {
  display: flex;
  align-items: center;
  justify-content: center;
  height: 22px;
  font-family: var(--font-mono);
  font-size: var(--font-size-xs);
  letter-spacing: 0.06em;
  color: var(--color-text-ghost);
  user-select: none;
}

.body { display: grid; gap: 2px; }

/* Day cells — mono tabular so the grid cannot jitter between months */
.day {
  display: flex;
  align-items: center;
  justify-content: center;
  height: 28px;
  border: 1px solid transparent;
  border-radius: var(--r-1);
  font-family: var(--font-mono);
  font-variant-numeric: tabular-nums;
  font-size: var(--font-size-sm);
  color: var(--color-text-dim);
  cursor: pointer;
  user-select: none;
  transition: background-color 0.12s ease, color 0.12s ease, border-color 0.12s ease;
}
.day:hover { background: var(--color-surface-hi); color: var(--color-fg); }
.day:focus-visible { outline: none; border-color: var(--color-accent); color: var(--color-fg); }
.dayOut { color: var(--color-text-ghost); }
.dayOff {
  color: var(--color-border-hi);
  cursor: not-allowed;
  text-decoration: line-through;
}
.dayOff:hover { background: none; color: var(--color-border-hi); }

/* Today = accent hairline ring only. Selected = accent. */
.dayToday { box-shadow: inset 0 0 0 1px var(--color-accent-edge); }
.daySel {
  background: var(--color-accent-soft);
  border-color: var(--color-accent);
  color: var(--color-accent);
}
.daySel:hover { background: var(--color-accent-soft); color: var(--color-accent); }

/* Footer — the house `//` engineer line plus one shortcut */
.foot {
  display: flex;
  align-items: center;
  gap: var(--space-3);
  margin-top: var(--space-2);
  padding-top: var(--space-2);
  border-top: 1px solid var(--color-border-soft, var(--color-border));
}
.hintLine {
  display: flex;
  gap: var(--space-2);
  margin: 0;
  min-width: 0;
  flex: 1 1 auto;
  font-family: var(--font-mono);
  font-size: var(--font-size-xs);
  line-height: 1.5;
  color: var(--color-muted);
}
.slashes { color: var(--color-text-ghost); flex-shrink: 0; }
.footBtn {
  flex-shrink: 0;
  padding: 2px var(--space-2);
  border: 1px solid var(--color-border);
  border-radius: var(--r-1);
  background: none;
  color: var(--color-text-dim);
  font-family: var(--font-mono);
  font-size: var(--font-size-xs);
  cursor: pointer;
  transition: color 0.12s ease, border-color 0.12s ease;
}
.footBtn:hover { color: var(--color-accent); border-color: var(--color-accent); }
.footBtn:focus-visible { outline: none; color: var(--color-accent); border-color: var(--color-accent); }
.footBtn[aria-disabled='true'] { opacity: 0.4; cursor: not-allowed; }

/* One motion: the month slides in from the direction it came */
.body[data-slide='next'] { animation: dp-next 120ms ease-out; }
.body[data-slide='prev'] { animation: dp-prev 120ms ease-out; }
@keyframes dp-next {
  from { transform: translateX(6px); opacity: 0.5; }
  to   { transform: none; opacity: 1; }
}
@keyframes dp-prev {
  from { transform: translateX(-6px); opacity: 0.5; }
  to   { transform: none; opacity: 1; }
}

@media (prefers-reduced-motion: reduce) {
  .control, .iconBtn, .navBtn, .day, .footBtn { transition: none; }
  .caretOpen { transform: none; }
  .body[data-slide='next'],
  .body[data-slide='prev'] { animation: none; }
}
</style>
