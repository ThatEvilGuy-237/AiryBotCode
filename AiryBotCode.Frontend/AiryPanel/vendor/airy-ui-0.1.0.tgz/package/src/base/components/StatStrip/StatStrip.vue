<script setup lang="ts">
/**
 * StatStrip
 * Container that lays out <Stat> cells in a responsive grid.
 *
 * Two looks:
 *  - `card` (default): bordered surface, cells separated by hairline borders.
 *  - `bare`: the list-page header strip — no border/background, a soft
 *    bottom rule, compact cells. Child <Stat>s adapt automatically (the
 *    variant is provided via injection, so pages don't repeat it per cell).
 *
 * @prop min     - minimum cell width in px before reflow (default 140; list
 *                 pages typically pass 92 for the bare variant)
 * @prop variant - 'card' | 'bare' (default 'card')
 *
 * Slot: default — one or more <Stat>s
 *
 * Status: stable | Consumers: Patterns, OverviewPage, list pages (bare)
 */
import { provide, toRef } from 'vue'

const props = withDefaults(defineProps<{
  min?: number
  variant?: 'card' | 'bare'
}>(), { min: 140, variant: 'card' })

provide('hive:stat-variant', toRef(props, 'variant'))
</script>

<template>
  <div data-ui="stat-strip"
    :class="[$style.strip, variant === 'bare' && $style.bare]"
    :style="{ gridTemplateColumns: `repeat(auto-fit, minmax(${min}px, 1fr))` }"
  >
    <slot />
  </div>
</template>

<style module>
.strip {
  display: grid;
  border: var(--border);
  border-radius: var(--radius);
  background: var(--color-surface);
  overflow: hidden;
}
.bare {
  border: 0;
  border-radius: 0;
  background: transparent;
  overflow: visible;
  gap: var(--space-3) var(--space-5);
  padding: 0 var(--space-1) var(--space-3);
  border-bottom: 1px solid var(--color-border-soft);
}
</style>
