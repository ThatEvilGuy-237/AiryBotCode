<script setup lang="ts">
/**
 * Stat
 * Single cell inside a <StatStrip>. Same label/value/sub stack as <Tile>
 * but without its own border — borders come from the parent strip.
 *
 * Adapts to the parent strip's `variant` (via injection): inside a `bare`
 * strip the cell drops its padding/dividers and uses the compact list-page
 * type scale.
 *
 * @prop label   - small uppercase mono label
 * @prop value   - the main number / string
 * @prop sub     - small mono caption
 * @prop tone    - value color: 'default' | 'ok' | 'warn' | 'fail' | 'mute' | 'accent'
 * @prop accent  - boolean — legacy shorthand for tone="accent"
 * @prop variant - explicit 'card' | 'bare'; overrides the parent strip's
 *                 injected variant, for standalone cells outside a StatStrip
 *
 * Status: stable | Consumers: StatStrip, Patterns, list pages, BankEditPage
 */
import { computed, inject, ref, type Ref } from 'vue'

const props = withDefaults(defineProps<{
  label: string
  value: string | number
  sub?: string
  tone?: 'default' | 'ok' | 'warn' | 'fail' | 'mute' | 'accent'
  accent?: boolean
  variant?: 'card' | 'bare'
}>(), { accent: false, tone: 'default' })

const injected = inject<Ref<'card' | 'bare'>>('hive:stat-variant', ref('card'))
const variant = computed(() => props.variant ?? injected.value)
</script>

<template>
  <div data-ui="stat" :class="[$style.stat, variant === 'bare' && $style.bare]">
    <div :class="$style.label">{{ label }}</div>
    <div :class="[$style.value, $style[tone], accent && $style.accent]">{{ value }}</div>
    <div v-if="sub" :class="$style.sub">{{ sub }}</div>
  </div>
</template>

<style module>
.stat {
  display: flex;
  flex-direction: column;
  gap: 4px;
  padding: var(--space-3) var(--space-4);
  border-right: 1px solid var(--color-border-soft, var(--color-border));
}
.stat:last-child { border-right: 0; }
.label {
  font-family: var(--stat-label-font, var(--font-mono));
  font-size: var(--stat-label-size, var(--font-size-xs));
  letter-spacing: var(--stat-label-tracking, 0.08em);
  text-transform: var(--stat-label-case, uppercase);
  color: var(--color-text-ghost, var(--color-muted));
}
.value {
  font-family: var(--font-mono);
  font-size: 22px;
  font-weight: 500;
  color: var(--color-fg);
  line-height: 1.1;
}
.value.accent { color: var(--color-accent); }
.value.ok     { color: var(--color-ok); }
.value.warn   { color: var(--color-warn); }
.value.fail   { color: var(--color-danger); }
.value.mute   { color: var(--color-muted); }
.sub {
  font-family: var(--stat-sub-font, var(--font-mono));
  font-size: var(--stat-sub-size, var(--font-size-xs));
  color: var(--color-muted);
}

/* Compact cell inside a bare strip (list-page header). */
.bare {
  padding: 0;
  border-right: 0;
  gap: 2px;
}
.bare .label { font-size: 9px; letter-spacing: 0.1em; }
.bare .value { font-size: 18px; }
</style>
