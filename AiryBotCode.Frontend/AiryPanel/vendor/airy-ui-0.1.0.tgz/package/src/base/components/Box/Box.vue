<script setup lang="ts">
/**
 * Box
 * Base container. Use for any card, panel, or grouped content area.
 *
 * @prop bordered - adds 1px solid border
 * @prop padded   - adds --space-4 padding on all sides
 *
 * Status: stable | Consumers: ToolsPage, ToolboxesPage
 */
withDefaults(defineProps<{
  bordered?: boolean
  padded?: boolean
}>(), { bordered: false, padded: false })
</script>

<template>
  <div data-ui="box" :class="[$style.box, bordered && $style.bordered, padded && $style.padded]">
    <slot />
  </div>
</template>

<style module>
.box {
  display: block;
}
.bordered {
  border: var(--border);
  border-radius: var(--radius);
}
.padded {
  padding: var(--space-4);
}
</style>
