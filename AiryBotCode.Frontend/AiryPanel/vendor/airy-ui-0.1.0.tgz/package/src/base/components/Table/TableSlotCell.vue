<script lang="ts">
/**
 * TableSlotCell
 * Internal — renders a column's custom `#default` scoped slot as the cell.
 * A render-function component on purpose: a stable component identity means an
 * inline control inside the cell keeps its DOM node (and its focus) across
 * table re-renders.
 *
 * @prop render - the column's slot function
 * @prop row    - the row object handed to the slot
 * @prop value  - the row's value for this column's field
 * @prop index  - the row's index in the rendered page
 *
 * Status: new | Consumers: Table
 */
import { defineComponent } from 'vue'
import type { PropType, VNodeChild } from 'vue'
import type { TableCellContext, TableRow } from './types'

export default defineComponent({
  name: 'TableSlotCell',
  props: {
    render: { type: Function as PropType<(context: TableCellContext) => VNodeChild>, required: true },
    row: { type: Object as PropType<TableRow>, required: true },
    value: { type: null, default: undefined },
    index: { type: Number, required: true },
  },
  setup(props) {
    return () => props.render({ row: props.row, value: props.value, index: props.index })
  },
})
</script>
