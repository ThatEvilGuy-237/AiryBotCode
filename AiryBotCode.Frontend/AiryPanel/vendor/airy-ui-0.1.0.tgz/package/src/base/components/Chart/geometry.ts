/**
 * Chart — pure geometry and number formatting.
 *
 * Everything here is side-effect free and degenerate-input safe: a zero span, a
 * single point and an all-null series all return something drawable.
 */
import type { ChartFormat } from './types'

const NICE_STEPS = [1, 2, 2.5, 5, 10]

export function niceCeil(value: number): number {
  if (!Number.isFinite(value) || value <= 0) return 1
  const magnitude = 10 ** Math.floor(Math.log10(value))
  const scaled = value / magnitude
  const step = NICE_STEPS.find(candidate => scaled <= candidate + 1e-9) ?? 10
  return round(step * magnitude)
}

export function niceFloor(value: number): number {
  if (!Number.isFinite(value) || value === 0) return 0
  if (value < 0) return -niceCeil(-value)
  const magnitude = 10 ** Math.floor(Math.log10(value))
  const scaled = value / magnitude
  const step = [...NICE_STEPS].reverse().find(candidate => candidate <= scaled + 1e-9) ?? 1
  return round(step * magnitude)
}

export function round(value: number): number {
  return Number.parseFloat(value.toPrecision(12))
}

function trim(value: number, digits: number): string {
  return Number.parseFloat(value.toFixed(digits)).toString()
}

export function compactNumber(value: number): string {
  const abs = Math.abs(value)
  if (abs >= 1e9) return `${trim(value / 1e9, 1)}B`
  if (abs >= 1e6) return `${trim(value / 1e6, 1)}M`
  if (abs >= 1e4) return `${trim(value / 1e3, 1)}K`
  if (abs >= 1) return round(value).toLocaleString(undefined, { maximumFractionDigits: 2 })
  return trim(value, 2)
}

export function formatChartValue(value: number, format: ChartFormat, unit?: string): string {
  if (!Number.isFinite(value)) return '—'
  if (format === 'currency') {
    const abs = Math.abs(value)
    if (value === 0) return '$0.00'
    if (abs < 0.0001) return '< $0.0001'
    if (abs < 0.01) return `$${value.toFixed(4)}`
    if (abs >= 1e4) return `$${compactNumber(value)}`
    return `$${value.toFixed(2)}`
  }
  if (format === 'percent') return `${trim(value, 1)}%`
  if (format === 'int') return Math.round(value).toLocaleString()
  if (format === 'compact') return compactNumber(value)
  const body = Math.abs(value) >= 1e4 ? compactNumber(value) : round(value).toLocaleString(undefined, { maximumFractionDigits: 2 })
  return unit ? `${body} ${unit}` : body
}

export interface Point {
  x: number
  y: number
}

export function linePath(points: (Point | null)[]): string {
  let path = ''
  let open = false
  for (const point of points) {
    if (!point) {
      open = false
      continue
    }
    path += `${open ? 'L' : 'M'}${fixed(point.x)} ${fixed(point.y)}`
    open = true
  }
  return path
}

export function areaPath(points: (Point | null)[], baseline: number): string {
  let path = ''
  let run: Point[] = []
  const flush = () => {
    if (run.length === 0) return
    if (run.length === 1) {
      run = [{ x: run[0]!.x - 0.5, y: run[0]!.y }, { x: run[0]!.x + 0.5, y: run[0]!.y }]
    }
    const first = run[0]!
    const last = run[run.length - 1]!
    path += `M${fixed(first.x)} ${fixed(baseline)}`
    for (const point of run) path += `L${fixed(point.x)} ${fixed(point.y)}`
    path += `L${fixed(last.x)} ${fixed(baseline)}Z`
    run = []
  }
  for (const point of points) {
    if (!point) flush()
    else run.push(point)
  }
  flush()
  return path
}

export function columnPath(x: number, width: number, valueY: number, baseY: number, radius: number): string {
  const w = Math.max(width, 0.5)
  const height = Math.abs(baseY - valueY)
  if (height < 0.01) return `M${fixed(x)} ${fixed(baseY)}h${fixed(w)}v0.75h${fixed(-w)}Z`
  const r = Math.max(0, Math.min(radius, w / 2, height))
  const down = valueY > baseY
  if (down) {
    return `M${fixed(x)} ${fixed(baseY)}h${fixed(w)}v${fixed(height - r)}a${fixed(r)} ${fixed(r)} 0 0 1 ${fixed(-r)} ${fixed(r)}h${fixed(-(w - 2 * r))}a${fixed(r)} ${fixed(r)} 0 0 1 ${fixed(-r)} ${fixed(-r)}Z`
  }
  return `M${fixed(x)} ${fixed(baseY)}v${fixed(-(height - r))}a${fixed(r)} ${fixed(r)} 0 0 1 ${fixed(r)} ${fixed(-r)}h${fixed(w - 2 * r)}a${fixed(r)} ${fixed(r)} 0 0 1 ${fixed(r)} ${fixed(r)}v${fixed(height - r)}Z`
}

export function markPath(shape: string, cx: number, cy: number, size: number): string {
  const r = size / 2
  if (shape === 'square') return `M${fixed(cx - r)} ${fixed(cy - r)}h${fixed(size)}v${fixed(size)}h${fixed(-size)}Z`
  if (shape === 'diamond') return `M${fixed(cx)} ${fixed(cy - r)}L${fixed(cx + r)} ${fixed(cy)}L${fixed(cx)} ${fixed(cy + r)}L${fixed(cx - r)} ${fixed(cy)}Z`
  if (shape === 'triangle') return `M${fixed(cx)} ${fixed(cy - r)}L${fixed(cx + r)} ${fixed(cy + r * 0.82)}L${fixed(cx - r)} ${fixed(cy + r * 0.82)}Z`
  return `M${fixed(cx - r)} ${fixed(cy)}a${fixed(r)} ${fixed(r)} 0 1 0 ${fixed(size)} 0a${fixed(r)} ${fixed(r)} 0 1 0 ${fixed(-size)} 0Z`
}

export function fixed(value: number): number {
  return Number.isFinite(value) ? Math.round(value * 100) / 100 : 0
}

export function bandPath(upper: (Point | null)[], lower: (Point | null)[]): string {
  let path = ''
  let run: { u: Point, l: Point }[] = []
  const flush = () => {
    if (run.length >= 2) {
      path += `M${run.map(p => `${fixed(p.u.x)} ${fixed(p.u.y)}`).join('L')}`
      path += `L${[...run].reverse().map(p => `${fixed(p.l.x)} ${fixed(p.l.y)}`).join('L')}Z`
    }
    run = []
  }
  upper.forEach((u, index) => {
    const l = lower[index]
    if (u && l) run.push({ u, l })
    else flush()
  })
  flush()
  return path
}
