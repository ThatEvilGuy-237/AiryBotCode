import type { ComputedRef, InjectionKey, Ref } from 'vue'

/**
 * A control's handle on the form it lives in.
 *
 * Registration is optional. `Form` finds invalid controls by reading the ARIA
 * that `Field` already writes (`aria-invalid`, `aria-describedby` → the
 * `role="alert"` line), so every existing Field works with no changes at all.
 * A control that owns its own error state — or renders no `aria-invalid` —
 * registers here instead so it still appears in the error summary.
 */
export interface FormFieldHandle {
  /** DOM id of the focusable element, so the summary can link to it. */
  id: string
  /** Name for the summary link. Falls back to the control's own label. */
  label?: string
  /** True while this control should block a submit. */
  invalid: Ref<boolean> | ComputedRef<boolean>
  /** Message for the summary line. Falls back to the field's rendered error. */
  message?: Ref<string> | ComputedRef<string>
  /** Move focus to the control. Falls back to focusing the element by id. */
  focus?: () => void
}

/**
 * Context a `<Form>` publishes to everything inside it.
 *
 * `submitted` is the answer to "when may I show this error?" — the piece
 * `Field` deliberately does not own. A control (or a page) reveals a computed
 * error once `submitted` is true, or earlier on blur if it wants to.
 */
export interface FormContext {
  /** True while a submit is in flight (own or the `busy` prop). */
  busy: ComputedRef<boolean>
  /** True once a submit has been attempted. Reset by `reset()`. */
  submitted: Ref<boolean>
  /** True while the tracked `model` differs from its baseline. */
  dirty: ComputedRef<boolean>
  register: (handle: FormFieldHandle) => void
  unregister: (id: string) => void
  /** Submit the form programmatically, honouring the busy guard. */
  submit: () => void
}

export const FORM_KEY: InjectionKey<FormContext> = Symbol('hive:form')

/** One line of the error summary. */
export interface FormInvalidField {
  id: string
  label: string
  message: string
  focus: () => void
}
