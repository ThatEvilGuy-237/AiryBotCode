<script setup lang="ts">
/**
 * Divider
 * Horizontal rule. Use to separate sections within a Box or page.
 *
 * Status: stable | Consumers: ToolboxesPage
 */
</script>

<template>
  <hr data-ui="divider" :class="$style.divider" />
</template>

<style module>
.divider { border: none; border-top: var(--border); margin: 0; }
</style>
