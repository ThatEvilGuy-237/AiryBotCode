<script setup lang="ts">
/**
 * Chart
 * Inline-SVG charts for Hive panels and stat tiles — no charting dependency. One
 * component, four designs in `vVariants/`: line, area, bar, donut. The parent owns
 * the wrapper, the axes, the legend, the hover layer, the text alternative and the
 * accessible name; a variant only draws marks.
 *
 * Colour, and why this component refuses a rainbow
 * ------------------------------------------------
 * Hive has ONE accent. So series identity is not a categorical palette here:
 *   · a series that *means* something wears a semantic tone (`ok` / `warn` /
 *     `danger` / `plan`) — failures are red because they are failures;
 *   · a series that is only identity takes a step of a one-hue ramp derived from
 *     `--accent-hue` (lightness/chroma steps, 4 steps, slot order fixed by
 *     declaration order so a filter never repaints the survivors);
 *   · identity is ALSO carried by a dash pattern, a mark shape and the legend, so
 *     colour is never the only channel;
 *   · past `maxSeries` (4) the chart refuses to draw. It does not invent a fifth
 *     hue — it shows the numbers as a table and tells you to fold the tail into
 *     "Other" or facet into small multiples.
 * Measured on the default theme against `--color-surface` (dark): the accent ramp
 * passes the ordinal checks (monotone L, ΔL 0.16, light end 2.80:1); accent + danger
 * + warn pass all-pairs CVD (ΔE 17.0) and normal-vision (ΔE 22.3). `ok` beside `warn`
 * collapses under protanopia (ΔE 5.9) — that pair is exactly why dash + shape +
 * legend are mandatory rather than decorative.
 *
 * @prop variant     - 'line' (default) | 'area' | 'bar' | 'donut'
 * @prop series      - one entry per series: `{ name, data, tone? }`. `donut` takes a
 *                     single series and treats `labels` as its segments
 * @prop labels      - x-axis / segment labels, one per data point
 * @prop label       - accessible name for the chart (always pass one)
 * @prop xLabel      - header of the label column in the text alternative
 * @prop caption     - sans caption under the plot (the figcaption)
 * @prop hint        - mono `// …` line under the caption
 * @prop height      - plot height in px (default 200, or 34 as a sparkline)
 * @prop sparkline   - strip axes, legend, caption and hover: a mark inside a stat tile
 * @prop gridlines   - hairline y gridlines (default true, off for sparklines)
 * @prop axis        - y ticks and x labels (default true, off for sparklines)
 * @prop legend      - true | false | 'auto' (default): a legend for 2+ keys
 * @prop xTicks      - most x labels to draw; the rest are thinned out (default 6)
 * @prop xTickAt     - exact label indices (thinned evenly when they do not fit)
 * @prop endLabels   - value label at the end of each line (default true)
 * @prop yFloor      - the y axis reaches at least this value
 * @prop guide       - one dashed horizontal line (a threshold), tone warn by default
 *                    series.band: upper edge per point, shaded down to the line (average to peak)
 * @prop yTicks      - gridline/tick segments (default 3)
 * @prop zeroBased   - keep zero in the domain (default true). Turn off for a cost or
 *                     latency trend where the interesting range sits far above zero
 * @prop stacked     - stack the series (bar and area) instead of grouping them
 * @prop format      - 'auto' | 'int' | 'compact' | 'currency' | 'percent'
 * @prop unit        - unit appended to formatted values in 'auto'
 * @prop formatValue - full override of value formatting
 * @prop barWidth    - max column thickness in px (default 24 — never fill the band)
 * @prop thickness   - donut ring thickness in px (default 22)
 * @prop centerLabel - mono eyebrow under the donut's centre value
 * @prop centerValue - override the donut's centre value (defaults to the total)
 * @prop maxSeries   - identity cap (default 4). Past it the chart refuses to draw
 * @prop table       - text alternative: 'hidden' (default, screen-reader only) |
 *                     'visible' | 'off'
 * @prop loading     - holds the frame: an existing render dims, an empty one skeletons
 * @prop empty       - headline when there is nothing to plot
 * @prop emptyHint   - mono `// …` line under it
 *
 * @event point-click - (ChartPointEvent) a point, column or segment was clicked
 * @event hover       - (ChartHover | null) the active x position changed
 *
 * Slots:
 *   caption - replaces the figcaption text
 *   empty   - replaces the whole empty state
 *
 * Status: new | Consumers: catalog, memory portal (activity)
 */
import { computed, onBeforeUnmount, onMounted, ref, watch, watchEffect } from 'vue'
import Skeleton from '../Skeleton/Skeleton.vue'
import ChartArea from './vVariants/ChartArea.vue'
import ChartBar from './vVariants/ChartBar.vue'
import ChartDonut from './vVariants/ChartDonut.vue'
import ChartLine from './vVariants/ChartLine.vue'
import { formatChartValue, niceCeil, round } from './geometry'
import type {
  ChartFormat, ChartHover, ChartKey, ChartPlotCtx, ChartPointEvent,
  ChartScale, ChartSeries, ChartSeriesView, ChartShape, ChartTone, ChartVariant,
} from './types'

const props = withDefaults(defineProps<{
  variant?: ChartVariant
  series: ChartSeries[]
  labels?: (string | number)[]
  label?: string
  xLabel?: string
  caption?: string
  hint?: string
  height?: number
  sparkline?: boolean
  gridlines?: boolean
  axis?: boolean
  legend?: boolean | 'auto'
  xTicks?: number
  yTicks?: number
  zeroBased?: boolean
  stacked?: boolean
  format?: ChartFormat
  unit?: string
  formatValue?: (value: number) => string
  barWidth?: number
  thickness?: number
  centerLabel?: string
  centerValue?: string
  maxSeries?: number
  table?: 'hidden' | 'visible' | 'off'
  loading?: boolean
  empty?: string
  emptyHint?: string
  endLabels?: boolean
  xTickAt?: number[]
  yFloor?: number
  guide?: { value: number, tone?: ChartTone, label?: string }
}>(), {
  variant: 'line',
  xLabel: 'Point',
  sparkline: false,
  gridlines: true,
  axis: true,
  legend: 'auto',
  xTicks: 6,
  yTicks: 3,
  zeroBased: true,
  stacked: false,
  format: 'auto',
  barWidth: 24,
  thickness: 22,
  centerLabel: 'total',
  maxSeries: 4,
  table: 'hidden',
  loading: false,
  empty: 'No data',
  emptyHint: 'nothing recorded for this range',
  endLabels: true,
})

const emit = defineEmits<{
  'point-click': [point: ChartPointEvent]
  hover: [hover: ChartHover | null]
}>()

const SLOT_COLORS = ['var(--hive-chart-1)', 'var(--hive-chart-2)', 'var(--hive-chart-3)', 'var(--hive-chart-4)']
const TONE_COLORS: Record<ChartTone, string> = {
  accent: 'var(--hive-chart-1)',
  ok: 'var(--color-ok)',
  warn: 'var(--color-warn)',
  danger: 'var(--color-danger)',
  plan: 'var(--color-plan)',
}
const DASHES = ['', '5 4', '1 3', '9 4 1 4']
const SHAPES: ChartShape[] = ['circle', 'square', 'triangle', 'diamond']
const CHAR_W = 7.2
const MIN_X_GAP = 56

const variants = {
  line: ChartLine,
  area: ChartArea,
  bar: ChartBar,
  donut: ChartDonut,
} as const

const design = computed(() => variants[props.variant])
const isDonut = computed(() => props.variant === 'donut')

const height = computed(() => props.height ?? (props.sparkline ? 34 : 200))
const axisOn = computed(() => props.axis && !props.sparkline && !isDonut.value)
const gridOn = computed(() => props.gridlines && !props.sparkline && !isDonut.value)

const count = computed(() => {
  const fromSeries = props.series.reduce((most, entry) => Math.max(most, entry.data.length), 0)
  return Math.max(fromSeries, props.labels?.length ?? 0)
})

const labels = computed(() => Array.from({ length: count.value }, (_, index) => String(props.labels?.[index] ?? index + 1)))

function clean(value: unknown): number | null {
  return typeof value === 'number' && Number.isFinite(value) ? value : null
}

const seriesViews = computed<ChartSeriesView[]>(() => props.series.map((entry, index) => {
  const values = Array.from({ length: count.value }, (_, slot) => clean(entry.data[slot]))
  return {
    name: entry.name,
    slot: index % SLOT_COLORS.length,
    tone: entry.tone ?? null,
    color: entry.tone ? TONE_COLORS[entry.tone] : SLOT_COLORS[index % SLOT_COLORS.length]!,
    dash: DASHES[index % DASHES.length]!,
    shape: SHAPES[index % SHAPES.length]!,
    values,
    total: values.reduce<number>((sum, value) => sum + (value ?? 0), 0),
    quiet: !!entry.quiet,
    band: entry.band ? Array.from({ length: count.value }, (_, slot) => clean(entry.band![slot])) : null,
  }
}))

const keys = computed<ChartKey[]>(() => {
  if (isDonut.value) {
    return labels.value.map((name, index) => ({
      name,
      slot: index % SLOT_COLORS.length,
      tone: null,
      color: SLOT_COLORS[index % SLOT_COLORS.length]!,
      dash: '',
      shape: SHAPES[index % SHAPES.length]!,
    }))
  }
  return seriesViews.value.map(entry => ({
    name: entry.name,
    slot: entry.slot,
    tone: entry.tone,
    color: entry.color,
    dash: entry.dash,
    shape: entry.shape,
  }))
})

const identityCount = computed(() => (isDonut.value ? count.value : seriesViews.value.length))
const refused = computed(() => identityCount.value > props.maxSeries)
const legendOn = computed(() => (props.legend === 'auto' ? keys.value.length > 1 : props.legend) && !props.sparkline)

const hasData = computed(() => seriesViews.value.some(entry => entry.values.some(value => value !== null)))

function fmt(value: number): string {
  return props.formatValue ? props.formatValue(value) : formatChartValue(value, props.format, props.unit)
}

const stackTotals = computed(() => Array.from({ length: count.value }, (_, index) =>
  seriesViews.value.reduce<number>((sum, entry) => sum + Math.max(entry.values[index] ?? 0, 0), 0)))

const domain = computed(() => {
  const raw = seriesViews.value.flatMap(entry => [...entry.values, ...(entry.band ?? [])].filter((value): value is number => value !== null))
  if (!raw.length) return { min: 0, max: 1, step: 1 }
  const pool = props.stacked && !isDonut.value ? stackTotals.value : raw
  const top = Math.max(...pool, props.zeroBased ? 0 : -Infinity, props.yFloor ?? -Infinity, props.guide?.value ?? -Infinity)
  if (top === 0 && Math.min(...raw) === 0) return { min: 0, max: 1, step: 1 }
  const bottom = props.zeroBased ? Math.min(...raw, 0) : Math.min(...raw)
  const span = top - bottom || Math.abs(top) || 1
  const step = niceCeil(span / Math.max(1, props.yTicks))
  const min = round(Math.floor(bottom / step) * step)
  let max = round(Math.ceil(top / step) * step)
  if (max <= min) max = round(min + step)
  return { min, max, step }
})

const yTickValues = computed(() => {
  if (!axisOn.value) return []
  const { min, max, step } = domain.value
  const out: number[] = []
  for (let value = min; value <= max + step / 2; value += step) out.push(round(value))
  return out
})

const gutter = computed(() => {
  if (!axisOn.value) return 0
  const longest = yTickValues.value.reduce((most, value) => Math.max(most, fmt(value).length), 1)
  return Math.min(76, longest * CHAR_W + 10)
})

const frame = ref<HTMLElement | null>(null)
const svgEl = ref<SVGSVGElement | null>(null)
const width = ref(0)
let observer: ResizeObserver | null = null

function measure() {
  width.value = frame.value?.clientWidth ?? 0
}

onMounted(() => {
  if (typeof ResizeObserver !== 'undefined') {
    observer = new ResizeObserver(measure)
    if (frame.value) observer.observe(frame.value)
  }
  else window.addEventListener('resize', measure)
  measure()
})

watch(frame, (element, previous) => {
  if (previous) observer?.unobserve(previous)
  if (element) observer?.observe(element)
  measure()
})

onBeforeUnmount(() => {
  observer?.disconnect()
  window.removeEventListener('resize', measure)
})

const plot = computed(() => {
  const pad = props.sparkline
    ? { t: 5, r: 5, b: 5, l: 5 }
    : { t: 12, r: 14, b: axisOn.value ? 22 : 8, l: axisOn.value ? gutter.value : 8 }
  return {
    x: pad.l,
    y: pad.t,
    w: Math.max(0, width.value - pad.l - pad.r),
    h: Math.max(0, height.value - pad.t - pad.b),
  }
})

const scale = computed<ChartScale>(() => {
  const box = plot.value
  const n = count.value
  const { min, max } = domain.value
  const span = max - min || 1
  const band = n > 0 ? box.w / n : box.w
  const step = n > 1 ? box.w / (n - 1) : 0
  const y = (value: number) => box.y + box.h - ((value - min) / span) * box.h
  const banded = props.variant === 'bar'
  return {
    plot: box,
    count: n,
    band,
    min,
    max,
    zeroY: y(Math.min(Math.max(0, min), max)),
    x: (index: number) => (banded
      ? box.x + band * (index + 0.5)
      : (n > 1 ? box.x + step * index : box.x + box.w / 2)),
    y,
  }
})

const ctx = computed<ChartPlotCtx>(() => ({
  scale: scale.value,
  series: seriesViews.value,
  keys: keys.value,
  labels: labels.value,
  stacked: props.stacked,
  barWidth: props.barWidth,
  thickness: props.thickness,
  sparkline: props.sparkline,
  center: {
    label: props.centerLabel,
    value: props.centerValue ?? fmt(seriesViews.value[0]?.total ?? 0),
  },
  fmt,
  endLabels: props.endLabels,
}))

const xTickIndices = computed(() => {
  const n = count.value
  if (!axisOn.value || n === 0) return []
  const room = Math.max(2, Math.floor(plot.value.w / MIN_X_GAP))
  if (props.xTickAt) {
    const at = props.xTickAt.filter(index => Number.isInteger(index) && index >= 0 && index < n)
    if (at.length <= room) return at
    const keep = Math.ceil(at.length / room)
    return at.filter((_, index) => index % keep === 0)
  }
  const allowed = Math.max(2, Math.min(props.xTicks, room))
  if (n <= allowed) return Array.from({ length: n }, (_, index) => index)
  const step = Math.ceil((n - 1) / (allowed - 1))
  const out: number[] = []
  for (let index = 0; index < n; index += step) out.push(index)
  const last = n - 1
  if (out[out.length - 1] !== last) {
    if (last - (out[out.length - 1] ?? 0) < step / 2) out.pop()
    out.push(last)
  }
  return out
})

const active = ref<number | null>(null)
const interactive = computed(() => !props.sparkline && hasData.value && !refused.value)

const readout = computed<ChartHover | null>(() => {
  const index = active.value
  if (index === null) return null
  if (isDonut.value) {
    const values = seriesViews.value[0]?.values ?? []
    const value = values[index] ?? null
    const total = values.reduce<number>((sum, entry) => sum + Math.max(entry ?? 0, 0), 0)
    const share = total > 0 && value !== null ? Math.round((value / total) * 100) : 0
    return {
      index,
      label: labels.value[index] ?? '',
      entries: [{ name: labels.value[index] ?? '', value, text: value === null ? '—' : `${fmt(value)} · ${share}%` }],
    }
  }
  return {
    index,
    label: labels.value[index] ?? '',
    entries: seriesViews.value.map(entry => ({
      name: entry.name,
      value: entry.values[index] ?? null,
      text: entry.values[index] === null || entry.values[index] === undefined ? '—' : fmt(entry.values[index]!),
    })),
  }
})

function setActive(index: number | null) {
  if (active.value === index) return
  active.value = index
  emit('hover', readout.value)
}

function indexFromX(offsetX: number): number | null {
  const n = count.value
  if (!n) return null
  const box = plot.value
  const local = offsetX - box.x
  const raw = props.variant === 'bar'
    ? Math.floor(local / (scale.value.band || 1))
    : Math.round(local / ((n > 1 ? box.w / (n - 1) : 0) || box.w || 1))
  return Math.min(Math.max(raw, 0), n - 1)
}

function onPointerMove(event: PointerEvent) {
  if (!interactive.value || isDonut.value) return
  const rect = svgEl.value?.getBoundingClientRect()
  if (!rect) return
  setActive(indexFromX(event.clientX - rect.left))
}

function onKeydown(event: KeyboardEvent) {
  if (!interactive.value) return
  const n = count.value
  if (!n) return
  const current = active.value
  let next: number | null = null
  if (event.key === 'ArrowRight') next = current === null ? 0 : Math.min(current + 1, n - 1)
  else if (event.key === 'ArrowLeft') next = current === null ? n - 1 : Math.max(current - 1, 0)
  else if (event.key === 'Home') next = 0
  else if (event.key === 'End') next = n - 1
  else if (event.key === 'Escape') {
    setActive(null)
    return
  }
  else if ((event.key === 'Enter' || event.key === ' ') && current !== null) {
    event.preventDefault()
    emitPoint(current)
    return
  }
  if (next === null) return
  event.preventDefault()
  setActive(next)
}

function emitPoint(index: number, seriesIndex = 0) {
  const entry = seriesViews.value[seriesIndex]
  emit('point-click', {
    seriesIndex,
    series: isDonut.value ? (labels.value[index] ?? '') : (entry?.name ?? ''),
    index,
    label: labels.value[index] ?? '',
    value: entry?.values[index] ?? null,
  })
}

const tipSide = computed(() => {
  if (active.value === null) return 'left'
  return scale.value.x(active.value) > plot.value.x + plot.value.w / 2 ? 'right' : 'left'
})

const tipX = computed(() => (active.value === null ? 0 : scale.value.x(active.value)))

const liveText = computed(() => {
  const current = readout.value
  if (!current) return ''
  return `${current.label}: ${current.entries.map(entry => `${entry.name} ${entry.text}`).join(', ')}`
})

const summary = computed(() => {
  const name = props.label ?? props.caption ?? 'Chart'
  if (refused.value) return `${name}: ${identityCount.value} series — too many to draw; the table below carries the numbers.`
  if (!hasData.value) return `${name}: no data.`
  if (isDonut.value) {
    const values = seriesViews.value[0]?.values ?? []
    const total = values.reduce<number>((sum, value) => sum + Math.max(value ?? 0, 0), 0)
    const parts = labels.value.map((entry, index) => {
      const value = values[index] ?? 0
      const share = total > 0 ? Math.round((value / total) * 100) : 0
      return `${entry} ${fmt(value)} (${share}%)`
    })
    return `${name}: donut of ${labels.value.length} segments, total ${fmt(total)}. ${parts.join('; ')}.`
  }
  const parts = seriesViews.value.map(entry => {
    const finite = entry.values.filter((value): value is number => value !== null)
    if (!finite.length) return `${entry.name} has no values`
    const last = finite[finite.length - 1]!
    return `${entry.name} from ${fmt(Math.min(...finite))} to ${fmt(Math.max(...finite))}, latest ${fmt(last)}`
  })
  return `${name}: ${props.variant} chart, ${count.value} points across ${labels.value[0] ?? ''}–${labels.value[count.value - 1] ?? ''}. ${parts.join('; ')}.`
})

const uid = Math.random().toString(36).slice(2, 8)
const captionId = computed(() => (props.caption || props.hint ? `hive-chart-cap-${uid}` : undefined))

const tableRows = computed(() => labels.value.map((label, index) => ({
  label,
  cells: isDonut.value
    ? [{ text: readoutValue(index) }]
    : seriesViews.value.map(entry => ({ text: entry.values[index] === null || entry.values[index] === undefined ? '—' : fmt(entry.values[index]!) })),
})))

function readoutValue(index: number): string {
  const value = seriesViews.value[0]?.values[index]
  return value === null || value === undefined ? '—' : fmt(value)
}

const tableHeads = computed(() => (isDonut.value ? [props.series[0]?.name ?? 'Value'] : seriesViews.value.map(entry => entry.name)))

const dev = Boolean((import.meta as ImportMeta & { env?: { DEV?: boolean } }).env?.DEV)

watchEffect(() => {
  if (!dev) return
  if (refused.value) {
    console.warn(`[hive/Chart] ${identityCount.value} identities exceeds maxSeries=${props.maxSeries}. Hive has one accent: fold the tail into "Other", facet into small multiples, or raise maxSeries knowingly.`)
  }
  const tones = seriesViews.value.map(entry => entry.tone)
  if (tones.includes('ok') && tones.includes('warn')) {
    console.warn('[hive/Chart] the ok and warn tones collapse under protanopia (ΔE 5.9) — keep the legend and dash patterns on, they are the only channel that separates them.')
  }
  if (props.labels && props.labels.length && count.value !== props.labels.length) {
    console.warn(`[hive/Chart] ${props.labels.length} labels for ${count.value} points — every point needs a label or the x axis lies.`)
  }
  if (isDonut.value && props.series.length > 1) {
    console.warn('[hive/Chart] donut plots one series; extra series are ignored. Use bar for a comparison.')
  }
})
</script>

<template>
  <figure data-ui="chart"
    :class="[$style.wrap, sparkline && $style.spark]"
    :aria-label="captionId ? undefined : label"
    :aria-labelledby="captionId"
    :aria-busy="loading || undefined"
  >
    <div :class="$style.body">
      <div v-if="legendOn && !refused" :class="$style.legend">
        <span v-for="key in keys" :key="key.name" :class="$style.key">
          <svg v-if="variant === 'line'" :class="$style.keyMark" viewBox="0 0 18 10" aria-hidden="true">
            <line x1="1" y1="5" x2="17" y2="5" :stroke="key.color" stroke-width="2" :stroke-dasharray="key.dash || undefined" />
            <path :d="key.shape === 'square' ? 'M6 2h6v6H6Z' : key.shape === 'diamond' ? 'M9 1l4 4-4 4-4-4Z' : key.shape === 'triangle' ? 'M9 1l4 7H5Z' : 'M5 5a4 4 0 1 0 8 0a4 4 0 1 0-8 0Z'" :fill="key.color" />
          </svg>
          <span v-else :class="$style.keySwatch" :style="{ background: key.color }" aria-hidden="true" />
          {{ key.name }}
        </span>
      </div>

      <div v-if="loading && !hasData" :class="$style.frame">
        <Skeleton variant="block" :height="`${height}px`" radius="var(--r-2, 6px)" />
      </div>

      <div
        v-else-if="refused"
        :class="$style.notice"
        role="status"
      >
        <div :class="$style.noticeTitle">{{ identityCount }} series is more than this chart will draw</div>
        <div :class="$style.noticeHint">// one accent, no rainbows — {{ maxSeries }} identities max. Fold the tail into "Other", or facet into small multiples.</div>
      </div>

      <div v-else-if="!hasData && !sparkline" :class="$style.empty">
        <slot name="empty">
          <div :class="$style.emptyTitle">{{ empty }}</div>
          <div v-if="emptyHint" :class="$style.emptyHint">// {{ emptyHint }}</div>
        </slot>
      </div>

      <div
        v-else
        ref="frame"
        :class="[$style.frame, loading && $style.dim]"
        :style="{ height: `${height}px` }"
      >
        <svg
          ref="svgEl"
          :class="$style.svg"
          :width="width || undefined"
          :height="height"
          :viewBox="`0 0 ${Math.max(width, 1)} ${height}`"
          role="img"
          :aria-label="interactive ? `${summary} Use the arrow keys to read each point.` : summary"
          :tabindex="interactive ? 0 : undefined"
          @pointermove="onPointerMove"
          @pointerleave="setActive(null)"
          @keydown="onKeydown"
          @blur="setActive(null)"
          @click="active !== null && emitPoint(active)"
        >
          <g v-if="gridOn" :class="$style.grid" aria-hidden="true">
            <line
              v-for="tick in yTickValues"
              :key="`grid-${tick}`"
              :x1="plot.x"
              :x2="plot.x + plot.w"
              :y1="scale.y(tick)"
              :y2="scale.y(tick)"
            />
          </g>
          <line
            v-if="guide && hasData && !isDonut"
            :class="$style.guide"
            :x1="plot.x"
            :x2="plot.x + plot.w"
            :y1="scale.y(guide.value)"
            :y2="scale.y(guide.value)"
            :stroke="TONE_COLORS[guide.tone ?? 'warn']"
            aria-hidden="true"
          />
          <text
            v-if="guide && guide.label && hasData && !isDonut"
            :class="$style.guideLabel"
            :x="plot.x + plot.w - 2"
            :y="scale.y(guide.value) - 5"
            :fill="TONE_COLORS[guide.tone ?? 'warn']"
            text-anchor="end"
            aria-hidden="true"
          >{{ guide.label }}</text>

          <line
            v-if="axisOn"
            :class="$style.axis"
            :x1="plot.x"
            :x2="plot.x + plot.w"
            :y1="scale.zeroY"
            :y2="scale.zeroY"
            aria-hidden="true"
          />

          <line
            v-if="active !== null && interactive && (variant === 'line' || variant === 'area')"
            :class="$style.crosshair"
            :x1="tipX"
            :x2="tipX"
            :y1="plot.y"
            :y2="plot.y + plot.h"
            aria-hidden="true"
          />

          <component :is="design" :ctx="ctx" :active="active" @active="setActive" @point="emitPoint" />

          <g v-if="axisOn" :class="$style.ticks" aria-hidden="true">
            <text
              v-for="tick in yTickValues"
              :key="`tick-${tick}`"
              :x="plot.x - 8"
              :y="scale.y(tick) + 4"
              text-anchor="end"
            >{{ fmt(tick) }}</text>
            <text
              v-for="index in xTickIndices"
              :key="`x-${index}`"
              :x="scale.x(index)"
              :y="plot.y + plot.h + 16"
              :text-anchor="index === 0 ? 'start' : index === count - 1 ? 'end' : 'middle'"
              :class="active === index ? $style.tickActive : undefined"
            >{{ labels[index] }}</text>
          </g>
        </svg>

        <div
          v-if="readout && interactive && !isDonut"
          :class="[$style.tip, tipSide === 'right' && $style.tipRight]"
          :style="{ left: `${tipX}px` }"
          aria-hidden="true"
        >
          <div :class="$style.tipHead">{{ readout.label }}</div>
          <div v-for="(entry, index) in readout.entries" :key="entry.name" :class="$style.tipRow">
            <span :class="$style.tipKey" :style="{ background: keys[isDonut ? readout.index : index]?.color }" />
            <span :class="$style.tipValue">{{ entry.text }}</span>
            <span :class="$style.tipName">{{ entry.name }}</span>
          </div>
        </div>
      </div>

      <div v-if="table !== 'off'" :class="table === 'hidden' ? $style.srOnly : undefined">
      <table :class="$style.table">
        <caption>{{ label ?? caption ?? 'Chart data' }}</caption>
        <thead>
          <tr>
            <th scope="col">{{ xLabel }}</th>
            <th v-for="head in tableHeads" :key="head" scope="col">{{ head }}</th>
          </tr>
        </thead>
        <tbody>
          <tr v-for="row in tableRows" :key="row.label">
            <th scope="row">{{ row.label }}</th>
            <td v-for="(cell, index) in row.cells" :key="index">{{ cell.text }}</td>
          </tr>
        </tbody>
      </table>
      </div>

      <div :class="$style.srOnly" role="status">{{ liveText }}</div>
    </div>

    <figcaption v-if="captionId" :id="captionId" :class="$style.cap">
      <span v-if="caption || $slots.caption" :class="$style.capText"><slot name="caption">{{ caption }}</slot></span>
      <span v-if="hint" :class="$style.capHint">// {{ hint }}</span>
    </figcaption>
  </figure>
</template>

<style module>
.guide { stroke-width: 1; stroke-dasharray: 4 4; opacity: 0.7; }
.guideLabel { font-size: var(--font-size-xs); font-family: var(--font-family); paint-order: stroke; stroke: var(--color-surface); stroke-width: 3px; }
/* The one-hue series ramp: four steps at --accent-hue. Slot 1 IS the accent, so a
   single-series chart is pure Hive; the other three step lightness, never hue. */
.wrap {
  --hive-chart-1: var(--color-accent);
  --hive-chart-2: oklch(clamp(0.3, calc(var(--accent-l, 0.66) + 0.16), 0.95) max(0.04, calc(var(--accent-c, 0.17) - 0.05)) var(--accent-hue, 287));
  --hive-chart-3: oklch(clamp(0.3, calc(var(--accent-l, 0.66) - 0.16), 0.95) max(0.04, calc(var(--accent-c, 0.17) - 0.03)) var(--accent-hue, 287));
  --hive-chart-4: oklch(clamp(0.3, calc(var(--accent-l, 0.66) + 0.27), 0.96) max(0.04, calc(var(--accent-c, 0.17) - 0.12)) var(--accent-hue, 287));
  --hive-chart-wash: 0.14;
  display: flex;
  flex-direction: column;
  gap: var(--space-2);
  margin: 0;
  min-width: 0;
  width: 100%;
}
.body {
  display: flex;
  flex-direction: column;
  gap: var(--space-2);
  min-width: 0;
}

.legend {
  display: flex;
  flex-wrap: wrap;
  gap: var(--space-1) var(--space-4);
  min-width: 0;
}
.key {
  display: inline-flex;
  align-items: center;
  gap: var(--space-2);
  font-family: var(--font-mono);
  font-size: var(--font-size-xs);
  color: var(--color-text-dim, var(--color-fg));
}
.keyMark { width: 18px; height: 10px; flex: none; }
.keySwatch {
  width: 10px;
  height: 10px;
  flex: none;
  border-radius: 2px;
}

.frame {
  position: relative;
  width: 100%;
  min-width: 0;
  transition: opacity 160ms ease;
}
.dim { opacity: 0.45; }
.svg { display: block; overflow: visible; }
.svg:focus-visible {
  outline: 2px solid var(--color-accent);
  outline-offset: 2px;
  border-radius: var(--r-1, 4px);
}

/* Chrome — hairlines only, one step off the surface. */
.grid line {
  stroke: var(--color-border-soft, var(--color-border));
  stroke-width: 1;
  shape-rendering: crispEdges;
}
.axis {
  stroke: var(--color-border, currentColor);
  stroke-width: 1;
  shape-rendering: crispEdges;
}
.crosshair {
  stroke: var(--color-accent-edge, var(--color-accent));
  stroke-width: 1;
  shape-rendering: crispEdges;
}
.ticks text {
  font-family: var(--font-mono);
  font-size: var(--font-size-xs);
  font-variant-numeric: tabular-nums;
  fill: var(--color-text-ghost, var(--color-muted));
}
.ticks .tickActive { fill: var(--color-fg); }

/* Tooltip — value leads in mono, the series name follows, dim. */
.tip {
  position: absolute;
  top: var(--space-1);
  transform: translateX(var(--space-3));
  min-width: 0;
  max-width: 15rem;
  padding: var(--space-2) var(--space-3);
  border: 1px solid var(--color-border);
  border-radius: var(--r-2, 6px);
  background: var(--color-bg-2, var(--color-bg));
  box-shadow: var(--shadow-1);
  pointer-events: none;
  z-index: 2;
}
.tipRight { transform: translateX(calc(-100% - var(--space-3))); }
.tipHead {
  font-family: var(--font-mono);
  font-size: var(--font-size-xs);
  color: var(--color-text-ghost, var(--color-muted));
  margin-bottom: var(--space-1);
}
.tipRow {
  display: flex;
  align-items: baseline;
  gap: var(--space-2);
  white-space: nowrap;
}
.tipKey {
  width: 10px;
  height: 2px;
  flex: none;
  align-self: center;
  border-radius: 1px;
}
.tipValue {
  font-family: var(--font-mono);
  font-size: var(--font-size-sm);
  font-variant-numeric: tabular-nums;
  color: var(--color-fg);
}
.tipName {
  font-family: var(--font-family);
  font-size: var(--font-size-xs);
  color: var(--color-muted);
  overflow: hidden;
  text-overflow: ellipsis;
}

.cap {
  display: flex;
  flex-direction: column;
  gap: 2px;
  min-width: 0;
}
.capText {
  font-family: var(--font-family);
  font-size: var(--font-size-sm);
  color: var(--color-text-dim, var(--color-fg));
}
.capHint {
  font-family: var(--font-mono);
  font-size: var(--font-size-xs);
  color: var(--color-text-ghost, var(--color-muted));
}

.empty,
.notice {
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: center;
  gap: var(--space-1);
  min-height: 96px;
  padding: var(--space-6) var(--space-4);
  border: 1px solid var(--color-border-soft, var(--color-border));
  border-radius: var(--r-2, 6px);
  text-align: center;
}
.emptyTitle,
.noticeTitle {
  font-family: var(--font-family);
  font-size: var(--font-size-base);
  color: var(--color-text-dim, var(--color-fg));
}
.emptyHint,
.noticeHint {
  font-family: var(--font-mono);
  font-size: var(--font-size-xs);
  color: var(--color-text-ghost, var(--color-muted));
}
.notice { border-color: var(--color-warn); }

/* The text alternative — screen-reader only by default, `table="visible"` prints it. */
.table {
  width: 100%;
  border-collapse: collapse;
  font-size: var(--font-size-sm);
}
.table caption {
  font-family: var(--font-mono);
  font-size: var(--font-size-xs);
  color: var(--color-text-ghost, var(--color-muted));
  text-align: left;
  padding-bottom: var(--space-1);
}
.table th,
.table td {
  padding: var(--space-1) var(--space-3);
  border-bottom: 1px solid var(--color-border-soft, var(--color-border));
  font-family: var(--font-mono);
  font-size: var(--font-size-xs);
  font-weight: 400;
  font-variant-numeric: tabular-nums;
  text-align: right;
  color: var(--color-text-dim, var(--color-fg));
}
.table thead th,
.table tbody th {
  text-align: left;
  color: var(--color-text-ghost, var(--color-muted));
  letter-spacing: 0.04em;
}

.srOnly {
  position: absolute;
  width: 1px;
  height: 1px;
  margin: -1px;
  padding: 0;
  border: 0;
  overflow: hidden;
  clip-path: inset(50%);
  white-space: nowrap;
}

.spark {
  gap: 0;
  width: 100%;
}
.spark .frame { min-width: 48px; }
</style>
