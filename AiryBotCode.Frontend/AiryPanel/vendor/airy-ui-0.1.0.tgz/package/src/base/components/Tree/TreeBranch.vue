<script setup lang="ts">
/**
 * TreeBranch
 * One `role="treeitem"` row plus its `role="group"` children, rendered
 * recursively. Internal to <Tree> — it holds no state of its own, it reads
 * everything from the tree context and reports focus/clicks back up.
 *
 * @prop node    - the node to render
 * @prop depth   - 0-based nesting level, becomes aria-level
 * @prop setSize - number of visible siblings, becomes aria-setsize
 * @prop pos     - 1-based index among visible siblings, becomes aria-posinset
 *
 * Status: new | Consumers: Tree
 */
import { computed, inject, onBeforeUnmount, ref, watch } from 'vue'
import Icon from '../Icon/Icon.vue'
import Spinner from '../Spinner/Spinner.vue'
import { TREE_CTX } from './keys'
import type { TreeNode, TreeNodeSlotProps } from './types'

const props = defineProps<{
  node: TreeNode
  depth: number
  setSize: number
  pos: number
}>()

defineSlots<{
  label?: (props: TreeNodeSlotProps) => unknown
  trailing?: (props: TreeNodeSlotProps) => unknown
}>()

const tree = inject(TREE_CTX)!
const rowRef = ref<HTMLElement | null>(null)

const expandable = computed(() => tree.expandable(props.node))
const expanded = computed(() => expandable.value && tree.isExpanded(props.node.key))
const selected = computed(() => tree.selectedKey.value === props.node.key)
const tabbable = computed(() => tree.tabKey.value === props.node.key)
const state = computed(() => tree.loadStateOf(props.node.key))
const loading = computed(() => state.value === 'loading')
const onSpine = computed(() => tree.spine.value.has(props.node.key))
const kids = computed(() => tree.childrenOf(props.node))

const hollow = computed(() => expanded.value && !loading.value && kids.value.length === 0)
const hollowText = computed(() =>
  state.value === 'error' ? 'could not read this branch' : 'nothing inside',
)

const scope = computed<TreeNodeSlotProps>(() => ({
  node: props.node,
  depth: props.depth,
  expanded: expanded.value,
  selected: selected.value,
  loading: loading.value,
}))

watch(rowRef, (el, prev) => {
  if (prev) tree.unregisterRow(props.node.key)
  if (el) tree.registerRow(props.node.key, el)
}, { immediate: true })

onBeforeUnmount(() => tree.unregisterRow(props.node.key))

function onRowClick() {
  tree.setActive(props.node.key)
  tree.select(props.node)
}

function onCaretClick(event: MouseEvent) {
  event.stopPropagation()
  tree.toggle(props.node)
}
</script>

<template>
  <li
    :class="$style.item"
    role="treeitem"
    :aria-level="depth + 1"
    :aria-setsize="setSize"
    :aria-posinset="pos"
    :aria-selected="selected"
    :aria-expanded="expandable ? expanded : undefined"
    :aria-busy="loading ? 'true' : undefined"
    :aria-disabled="node.disabled || node.locked ? 'true' : undefined"
  >
    <div
      ref="rowRef"
      :class="[
        $style.row,
        tree.dense.value && $style.dense,
        selected && $style.selected,
        (node.disabled || node.locked) && $style.inert,
      ]"
      :tabindex="tabbable ? 0 : -1"
      @click="onRowClick"
      @focus="tree.setActive(node.key)"
      @keydown="tree.onKeydown($event, node)"
    >
      <Spinner v-if="loading" :size="12" :stroke="1.5" :class="$style.slot" />
      <button
        v-else-if="expandable"
        type="button"
        tabindex="-1"
        :class="[$style.caret, expanded && $style.open]"
        :aria-label="expanded ? `Collapse ${node.label}` : `Expand ${node.label}`"
        @click="onCaretClick"
      >
        <Icon name="chevron-right" :size="14" />
      </button>
      <span v-else :class="$style.slot" aria-hidden="true" />

      <Icon v-if="node.locked" name="lock" :size="13" :class="$style.lock" />
      <Icon v-else-if="node.icon" :name="node.icon" :size="14" :class="$style.icon" />
      <span v-else-if="tree.anyIcon.value" :class="$style.slot" aria-hidden="true" />

      <span :class="$style.label">
        <slot name="label" v-bind="scope">{{ node.label }}</slot>
      </span>

      <span v-if="node.meta" :class="$style.meta">{{ node.meta }}</span>
      <span v-if="node.locked" :class="$style.note">// locked</span>

      <span :class="$style.spacer" />

      <span v-if="$slots.trailing" :class="$style.trailing">
        <slot name="trailing" v-bind="scope" />
      </span>
    </div>

    <ul
      v-if="expanded"
      :class="[$style.group, onSpine && $style.spine]"
      role="group"
    >
      <TreeBranch
        v-for="(child, index) in kids"
        :key="child.key"
        :node="child"
        :depth="depth + 1"
        :set-size="kids.length"
        :pos="index + 1"
      >
        <template v-if="$slots.label" #label="s"><slot name="label" v-bind="s" /></template>
        <template v-if="$slots.trailing" #trailing="s"><slot name="trailing" v-bind="s" /></template>
      </TreeBranch>

      <li v-if="hollow" :class="$style.hollow" role="none">// {{ hollowText }}</li>
    </ul>
  </li>
</template>

<style module>
.item { list-style: none; }

.row {
  position: relative;
  display: flex;
  align-items: center;
  gap: var(--space-2);
  min-height: 28px;
  padding: 3px var(--space-2) 3px var(--space-2);
  border-radius: var(--r-1);
  color: var(--color-text-dim);
  cursor: pointer;
  user-select: none;
}
.row.dense { min-height: 22px; padding-top: 1px; padding-bottom: 1px; }
.row:hover { background: var(--color-surface-hi); color: var(--color-fg); }
.row:focus-visible {
  outline: 1px solid var(--color-accent-edge);
  outline-offset: -1px;
}

/* Selection is an accent left-bar, never a fill. */
.selected { color: var(--color-fg); }
.selected::before {
  content: '';
  position: absolute;
  inset: 2px auto 2px -1px;
  width: 2px;
  border-radius: 1px;
  background: var(--color-accent);
}
.selected .label { color: var(--color-accent); }

.inert { cursor: default; color: var(--color-muted); }
.inert:hover { background: none; color: var(--color-muted); }

.caret {
  display: inline-grid;
  place-items: center;
  width: 16px;
  height: 16px;
  flex: 0 0 auto;
  padding: 0;
  border: 0;
  border-radius: var(--r-1);
  background: none;
  color: var(--color-text-ghost);
  cursor: pointer;
  transition: transform 120ms ease, color 120ms ease;
}
.caret:hover { color: var(--color-fg); }
.caret:focus-visible { outline: 1px solid var(--color-accent-edge); }
.caret.open { transform: rotate(90deg); color: var(--color-muted); }

.slot { width: 16px; height: 16px; flex: 0 0 auto; }

.icon { color: var(--color-text-ghost); }
.lock { color: var(--color-warn); }

.label {
  font-family: var(--font-family);
  font-size: var(--font-size-sm);
  white-space: nowrap;
  overflow: hidden;
  text-overflow: ellipsis;
}

/* Ids, paths, types and counts read as data — mono, one step back. */
.meta {
  font-family: var(--font-mono);
  font-size: var(--font-size-xs);
  color: var(--color-muted);
  white-space: nowrap;
}
.note {
  font-family: var(--font-mono);
  font-size: var(--font-size-xs);
  color: var(--color-text-ghost);
  white-space: nowrap;
}
.spacer { flex: 1 1 auto; min-width: var(--space-2); }
.trailing {
  display: inline-flex;
  align-items: center;
  gap: var(--space-1);
  flex: 0 0 auto;
  font-family: var(--font-mono);
  font-size: var(--font-size-xs);
  color: var(--color-muted);
}

/* Indent guide: a hairline, not a nested box. */
.group {
  margin: 0 0 0 14px;
  padding: 0 0 0 var(--space-3);
  border-left: 1px solid var(--color-border-soft);
  list-style: none;
  animation: sprout 120ms ease-out;
}
.group.spine { border-left-color: var(--color-accent-edge); }

.hollow {
  padding: 3px var(--space-2);
  font-family: var(--font-mono);
  font-size: var(--font-size-xs);
  color: var(--color-text-ghost);
  list-style: none;
}

@keyframes sprout {
  from { opacity: 0; transform: translateY(-2px); }
  to   { opacity: 1; transform: none; }
}

@media (prefers-reduced-motion: reduce) {
  .group { animation: none; }
  .caret { transition: none; }
}
</style>
