<script setup lang="ts">
/**
 * LoadingBar
 * A 2px accent line that says "this region is busy" without touching the
 * content it covers. Anchored to a container edge, so nothing reflows when it
 * appears — use it for refetches and navigations where the old content stays
 * on screen. For a 0–100 metric that is part of the layout use <ProgressBar>;
 * to replace content that isn't there yet use <Skeleton> or <LoadingState>.
 *
 * Driven by `active`, not by mounting: keep it mounted and toggle the flag.
 * It self-times — `delay` swallows fast responses so a 50ms fetch never
 * flashes, and `minDuration` keeps a bar that did appear on screen long enough
 * to be read. Pass `value` to switch to determinate; leave it undefined and the
 * bar is honestly indeterminate (a travelling segment, and NO aria-valuenow —
 * it never invents a percentage it doesn't know).
 *
 * @prop active      - is work outstanding right now
 * @prop value       - 0–100; supplying it switches the bar to determinate
 * @prop anchor      - 'top' | 'bottom' overlay a container edge | 'inline' sits in flow
 * @prop fixed       - anchor to the viewport instead of the nearest positioned ancestor
 * @prop variant     - accent | ok | warn | err (default 'accent')
 * @prop thickness   - line height in px (default 2)
 * @prop delay       - ms of work before the bar appears at all (default 180)
 * @prop minDuration - ms the bar stays once it has appeared (default 480)
 * @prop label       - accessible name, also the screen-reader announcement
 *
 * @emit shown  - the bar became visible (the work outlived `delay`)
 * @emit hidden - the bar left the screen
 *
 * Status: new | Consumers: portal activity ledger, night-shift queue
 */
import { computed, onBeforeUnmount, onMounted, ref, watch } from 'vue'

export type LoadingBarAnchor = 'top' | 'bottom' | 'inline'
export type LoadingBarVariant = 'accent' | 'ok' | 'warn' | 'err'

const props = withDefaults(defineProps<{
  active?: boolean
  value?: number
  anchor?: LoadingBarAnchor
  fixed?: boolean
  variant?: LoadingBarVariant
  thickness?: number
  delay?: number
  minDuration?: number
  label?: string
}>(), {
  active: false,
  anchor: 'top',
  fixed: false,
  variant: 'accent',
  thickness: 2,
  delay: 180,
  minDuration: 480,
  label: 'Loading',
})

const emit = defineEmits<{
  (e: 'shown'): void
  (e: 'hidden'): void
}>()

const visible = ref(false)
const determinate = computed(() => props.value !== undefined)
const pct = computed(() => Math.max(0, Math.min(100, props.value ?? 0)))

let appearTimer: ReturnType<typeof setTimeout> | null = null
let holdTimer: ReturnType<typeof setTimeout> | null = null
let shownAt = 0

function clearTimers() {
  if (appearTimer) { clearTimeout(appearTimer); appearTimer = null }
  if (holdTimer) { clearTimeout(holdTimer); holdTimer = null }
}

function reveal() {
  appearTimer = null
  shownAt = Date.now()
  visible.value = true
  emit('shown')
}

function conceal() {
  holdTimer = null
  visible.value = false
  emit('hidden')
}

function begin() {
  if (holdTimer) { clearTimeout(holdTimer); holdTimer = null }
  if (visible.value || appearTimer) return
  if (props.delay <= 0) { reveal(); return }
  appearTimer = setTimeout(reveal, props.delay)
}

function end() {
  if (appearTimer) { clearTimeout(appearTimer); appearTimer = null; return }
  if (!visible.value || holdTimer) return
  const left = props.minDuration - (Date.now() - shownAt)
  if (left <= 0) { conceal(); return }
  holdTimer = setTimeout(conceal, left)
}

function run(on: boolean) {
  if (typeof window === 'undefined') return
  if (on) begin()
  else end()
}

watch(() => props.active, run)
onMounted(() => run(props.active))
onBeforeUnmount(clearTimers)
</script>

<template>
  <Transition data-ui="loading-bar"
    :enter-active-class="$style.fadeActive"
    :leave-active-class="$style.fadeActive"
    :enter-from-class="$style.fadeOut"
    :leave-to-class="$style.fadeOut"
  >
    <div
      v-if="visible"
      :class="[$style.track, $style[anchor], fixed && $style.fixed]"
      :style="{ height: `${thickness}px` }"
      role="progressbar"
      aria-valuemin="0"
      aria-valuemax="100"
      :aria-valuenow="determinate ? pct : undefined"
      :aria-label="label"
    >
      <span
        :class="[$style.seg, $style[variant], determinate ? $style.determinate : $style.indeterminate]"
        :style="determinate ? { width: `${pct}%` } : undefined"
      />
      <span :class="$style.srOnly" role="status">{{ label }}</span>
    </div>
  </Transition>
</template>

<style module>
.track {
  position: absolute;
  inset-inline: 0;
  z-index: 5;
  overflow: hidden;
  pointer-events: none;
  background: var(--color-border-soft, var(--color-border));
}
.top { top: 0; }
.bottom { bottom: 0; }

/* In-flow variant: no overlay, occupies its own line. */
.inline {
  position: relative;
  inset: auto;
  display: block;
  width: 100%;
}

.fixed {
  position: fixed;
  z-index: 150;
}

.seg {
  display: block;
  height: 100%;
}
.determinate {
  width: 0;
  transition: width 0.16s linear;
}
.indeterminate {
  width: 28%;
  transform: translateX(-100%);
  animation: lb-travel 1.15s cubic-bezier(0.65, 0, 0.35, 1) infinite;
}

.accent { background: var(--color-accent); }
.ok     { background: var(--color-ok); }
.warn   { background: var(--color-warn); }
.err    { background: var(--color-danger); }

.fadeActive { transition: opacity 0.14s linear; }
.fadeOut { opacity: 0; }

.srOnly {
  position: absolute;
  width: 1px;
  height: 1px;
  overflow: hidden;
  clip-path: inset(50%);
  white-space: nowrap;
}

@keyframes lb-travel {
  0%   { transform: translateX(-100%); }
  100% { transform: translateX(357%); }
}

/* Motion off: indeterminate becomes a static busy rail, not a frozen segment. */
@media (prefers-reduced-motion: reduce) {
  .indeterminate {
    width: 100%;
    transform: none;
    animation: none;
    opacity: 0.45;
  }
  .determinate { transition: none; }
  .fadeActive { transition: none; }
}
</style>
