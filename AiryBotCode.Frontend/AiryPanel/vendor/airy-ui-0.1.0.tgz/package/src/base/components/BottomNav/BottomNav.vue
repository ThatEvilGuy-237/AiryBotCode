<script setup lang="ts">
/**
 * BottomNav
 * The phone half of an app's one navigation surface: a bar fixed to the bottom
 * edge with three to five `<BottomNavItem>`s, icon over label. On wider screens
 * the same destinations live in `<AppSidebar>`; hide this bar there with a media
 * query in the app, so each width has exactly one navigation surface.
 *
 * The bar pads itself by the safe-area inset, so an installed PWA on a phone
 * with a home indicator keeps its labels clear. Give the page below it a bottom
 * padding of `var(--bottom-nav-h)` so the last row is never hidden.
 *
 * @prop label - accessible name of the <nav> landmark
 *
 * Slot: default - the items
 *
 * Status: new | Consumers: evil-dash layout
 */
withDefaults(defineProps<{ label?: string }>(), { label: 'Main' })
defineSlots<{ default?: () => unknown }>()
</script>

<template>
  <nav :class="$style.bar" :aria-label="label" data-ui="bottom-nav">
    <ul :class="$style.list"><slot /></ul>
  </nav>
</template>

<style module>
.bar {
  position: fixed;
  inset: auto 0 0 0;
  z-index: 20;
  background: var(--color-bg);
  border-top: 1px solid var(--color-border-soft, var(--color-border));
  padding-bottom: env(safe-area-inset-bottom, 0px);
}
.list {
  display: flex;
  margin: 0;
  padding: 0;
  list-style: none;
}
</style>
