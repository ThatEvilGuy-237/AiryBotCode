<script setup lang="ts">
/**
 * InfoTerm
 * A house word rendered inline in prose that carries its own definition.
 * Reach for it when a sentence uses product vocabulary a newcomer cannot
 * infer — "promote", "the night shift", "extraction" — instead of a
 * parenthetical, a second sentence, or a `title` attribute nobody hears.
 *
 * Not <Tooltip>: that wraps a control and hints at what it does, single line,
 * hover/focus only. This is a reading affordance inside a paragraph — it
 * wraps across lines, opens on tap, pins on click, closes on Escape, and is
 * wired to the term with aria-describedby so it is announced, not guessed.
 *
 * Definitions come from the shared glossary registry (`defineGlossary()`) so a
 * word is worded once for the whole app; `def` overrides for a one-off.
 * With no definition available the term renders as plain prose with no
 * affordance — a missing entry never shows a dead control.
 *
 * @prop term       - the word as it reads in the sentence; also the glossary key
 * @prop entry      - explicit glossary key when the displayed word is inflected ("promoted" -> "promote")
 * @prop def        - inline definition; wins over the registry
 * @prop kind       - 'prose' (inherits the sentence font) | 'machine' (mono — a verb the system performs)
 * @prop more       - optional mono `// …` footer line inside the panel
 * @prop href       - optional link rendered at the foot of the panel
 * @prop hrefLabel  - label for that link (default: 'Read more')
 * @prop placement  - 'auto' | 'bottom' | 'top' (default: 'auto', flips near the viewport edge)
 * @prop disabled   - render as plain prose, keep the sentence intact
 * @prop modelValue - optional `v-model` over the open state; unbound, the component owns it
 *
 * @event update:modelValue - open state changed
 * @event open  - the definition became visible
 * @event close - the definition was dismissed
 *
 * Slot:
 *   default - the inline text, when it needs markup or differs from `term`
 *
 * Status: new | Consumers: available for future use
 */
import { computed, getCurrentInstance, nextTick, onBeforeUnmount, ref, watch } from 'vue'
import { glossaryEntry } from './glossary'

const props = withDefaults(defineProps<{
  term: string
  entry?: string
  def?: string
  kind?: 'prose' | 'machine'
  more?: string
  href?: string
  hrefLabel?: string
  placement?: 'auto' | 'bottom' | 'top'
  disabled?: boolean
}>(), { placement: 'auto', disabled: false, hrefLabel: 'Read more' })

const emit = defineEmits<{
  open: []
  close: []
}>()

const open = defineModel<boolean>({ default: false })

const descId = `hive-infoterm-${getCurrentInstance()?.uid ?? 0}`

const registered = computed(() => (props.def ? undefined : glossaryEntry(props.entry ?? props.term)))
const definition = computed(() => props.def ?? registered.value?.def ?? '')
const kind = computed(() => props.kind ?? registered.value?.kind ?? 'prose')
const more = computed(() => props.more ?? registered.value?.more)
const link = computed(() => props.href ?? registered.value?.href)
const live = computed(() => !props.disabled && definition.value.trim().length > 0)

const pinned = ref(false)

const root = ref<HTMLElement | null>(null)
const panel = ref<HTMLElement | null>(null)
const side = ref<'top' | 'bottom'>('bottom')
const align = ref<'start' | 'end'>('start')

let closeTimer: ReturnType<typeof setTimeout> | undefined

function clearTimer() {
  if (closeTimer) {
    clearTimeout(closeTimer)
    closeTimer = undefined
  }
}

function setOpen(next: boolean) {
  clearTimer()
  if (open.value === next) return
  open.value = next
  if (next) emit('open')
  else emit('close')
}

function peek() {
  if (!live.value) return
  setOpen(true)
}

function unpeek() {
  if (pinned.value) return
  clearTimer()
  closeTimer = setTimeout(() => setOpen(false), 110)
}

function dismiss() {
  pinned.value = false
  setOpen(false)
}

function toggle() {
  if (!live.value) return
  if (pinned.value) {
    dismiss()
    return
  }
  pinned.value = true
  setOpen(true)
}

function onFocusOut(event: FocusEvent) {
  const to = event.relatedTarget as Node | null
  if (to && root.value?.contains(to)) return
  dismiss()
}

function onEscape(event: KeyboardEvent) {
  if (event.key !== 'Escape' || !open.value) return
  event.stopPropagation()
  dismiss()
  root.value?.querySelector<HTMLElement>('[data-infoterm-trigger]')?.focus()
}

function onDocumentPointer(event: PointerEvent) {
  if (root.value?.contains(event.target as Node)) return
  dismiss()
}

async function place() {
  if (props.placement !== 'auto') {
    side.value = props.placement
    align.value = 'start'
    return
  }
  await nextTick()
  const anchor = root.value?.getBoundingClientRect()
  const box = panel.value?.getBoundingClientRect()
  if (!anchor || !box) return
  const room = 12
  const fitsBelow = anchor.bottom + box.height + room <= window.innerHeight
  side.value = fitsBelow || anchor.top - box.height - room < 0 ? 'bottom' : 'top'
  align.value = anchor.left + box.width + room > window.innerWidth ? 'end' : 'start'
}

function trackViewport(on: boolean) {
  if (typeof window === 'undefined') return
  if (on) {
    window.addEventListener('scroll', place, { capture: true, passive: true })
    window.addEventListener('resize', place)
  } else {
    window.removeEventListener('scroll', place, { capture: true })
    window.removeEventListener('resize', place)
  }
}

watch(open, (value) => {
  if (value) place()
  trackViewport(value)
})

watch(pinned, (value) => {
  if (typeof document === 'undefined') return
  if (value) {
    document.addEventListener('pointerdown', onDocumentPointer)
    document.addEventListener('keydown', onEscape)
  } else {
    document.removeEventListener('pointerdown', onDocumentPointer)
    document.removeEventListener('keydown', onEscape)
  }
})

onBeforeUnmount(() => {
  clearTimer()
  trackViewport(false)
  if (typeof document === 'undefined') return
  document.removeEventListener('pointerdown', onDocumentPointer)
  document.removeEventListener('keydown', onEscape)
})
</script>

<template>
  <span v-if="!live" data-ui="info-term" :class="$style.plain"><slot>{{ term }}</slot></span>

  <span data-ui="info-term"
    v-else
    ref="root"
    :class="$style.wrap"
    @mouseenter="peek"
    @mouseleave="unpeek"
    @focusout="onFocusOut"
    @keydown="onEscape"
  >
    <span
      data-infoterm-trigger
      role="button"
      tabindex="0"
      :class="[$style.term, $style[kind], open && $style.on]"
      :aria-expanded="open"
      :aria-describedby="descId"
      @click="toggle"
      @focus="peek"
      @keydown.enter.prevent="toggle"
      @keydown.space.prevent="toggle"
    ><slot>{{ term }}</slot></span>

    <span
      :id="descId"
      ref="panel"
      role="tooltip"
      :class="[$style.panel, $style[side], $style[align], open && $style.shown]"
    >
      <span :class="$style.eyebrow">{{ registered?.term ?? term }}</span>
      <span :class="$style.def">{{ definition }}</span>
      <span v-if="more" :class="$style.more">// {{ more }}</span>
      <span :class="$style.foot">
        <a v-if="link" :href="link" :class="$style.link" :tabindex="open ? 0 : -1">{{ hrefLabel }} &rarr;</a>
        <kbd v-if="pinned" :class="$style.kbd">esc</kbd>
      </span>
    </span>
  </span>
</template>

<style module>
.plain { font: inherit; color: inherit; }

.wrap {
  position: relative;
  display: inline;
  font: inherit;
}

/* The affordance: accent lives here and nowhere else in the component. */
.term {
  font: inherit;
  color: inherit;
  cursor: help;
  border-radius: var(--r-2);
  text-decoration-line: underline;
  text-decoration-style: dotted;
  text-decoration-thickness: 1px;
  text-decoration-color: var(--color-accent-edge);
  text-underline-offset: 3px;
  transition: text-decoration-color 0.12s ease, color 0.12s ease;
}
.term:hover,
.term.on {
  color: var(--color-fg);
  text-decoration-style: solid;
  text-decoration-color: var(--color-accent);
}
.term:focus-visible {
  outline: 2px solid var(--color-accent);
  outline-offset: 2px;
}

/* Mono is the signal that the word names something the system does. */
.machine {
  font-family: var(--font-mono);
  font-size: 0.92em;
  letter-spacing: -0.01em;
}

.panel {
  position: absolute;
  z-index: 60;
  display: flex;
  flex-direction: column;
  gap: var(--space-2);
  width: max-content;
  max-width: min(22rem, 78vw);
  padding: var(--space-3);
  background: var(--color-surface);
  border: var(--border);
  border-radius: var(--r-2);
  font-family: var(--font-family);
  font-size: var(--font-size-sm);
  font-weight: 400;
  line-height: 1.55;
  text-align: left;
  text-decoration: none;
  white-space: normal;
  opacity: 0;
  pointer-events: none;
  transform: translateY(-3px);
  transition: opacity 0.12s ease, transform 0.12s ease;
}
.bottom { top: calc(100% + var(--space-2)); }
.top    { bottom: calc(100% + var(--space-2)); }
.start  { left: 0; }
.end    { right: 0; }
.shown {
  opacity: 1;
  pointer-events: auto;
  transform: translateY(0);
}

.eyebrow {
  font-family: var(--font-mono);
  font-size: var(--font-size-xs);
  letter-spacing: 0.08em;
  text-transform: uppercase;
  color: var(--color-text-ghost);
}
.def { color: var(--color-text-dim); }
.more {
  font-family: var(--font-mono);
  font-size: var(--font-size-xs);
  color: var(--color-muted);
}
.foot {
  display: flex;
  align-items: center;
  justify-content: space-between;
  gap: var(--space-3);
}
.foot:empty { display: none; }
.link {
  font-family: var(--font-mono);
  font-size: var(--font-size-xs);
  color: var(--color-accent);
  text-decoration: none;
}
.link:hover { text-decoration: underline; }
.link:focus-visible {
  outline: 2px solid var(--color-accent);
  outline-offset: 2px;
  border-radius: var(--r-2);
}
.kbd {
  margin-left: auto;
  padding: 1px var(--space-1);
  background: var(--color-surface-mute);
  border: var(--border);
  border-radius: var(--r-2);
  font-family: var(--font-mono);
  font-size: var(--font-size-xs);
  color: var(--color-text-ghost);
}

@media (prefers-reduced-motion: reduce) {
  .term { transition: none; }
  .panel {
    transform: none;
    transition: none;
  }
  .shown { transform: none; }
}
</style>
