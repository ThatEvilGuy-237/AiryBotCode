<script setup lang="ts">
/**
 * SectionNavItem
 * One page in a `<SectionNav>`: a text link that routes through vue-router,
 * marks itself `aria-current="page"` and draws a 2 px accent line under the
 * current one, the same marker the sidebar and the bottom bar use on their edge.
 *
 * @prop label - the item's text, and its accessible name
 * @prop to    - vue-router target
 * @prop exact - active only on an exact route match
 *
 * Status: new | Consumers: evil-dash settings pages
 */
import { computed } from 'vue'
import { useLink, useRoute, type RouteLocationRaw } from 'vue-router'

const props = withDefaults(defineProps<{
  label: string
  to: RouteLocationRaw
  exact?: boolean
}>(), { exact: false })

const link = useLink({ to: computed(() => props.to) })
const route = useRoute()

const isActive = computed(() => {
  if (props.exact) return link.isExactActive.value
  if (link.isActive.value) return true
  const base = link.route.value.path.replace(/\/+$/, '')
  return !!base && route.path.startsWith(`${base}/`)
})
</script>

<template>
  <li :class="$style.item">
    <a
      :href="link.href.value"
      :class="[$style.link, isActive && $style.active]"
      :aria-current="isActive ? 'page' : undefined"
      @click="link.navigate"
    >{{ label }}</a>
  </li>
</template>

<style module>
.item { flex: 0 0 auto; }

.link {
  position: relative;
  display: flex;
  align-items: center;
  min-height: var(--section-nav-h, 44px);
  padding: 0 var(--space-3);
  color: var(--color-text-dim);
  font-family: var(--font-family);
  font-size: var(--font-size-sm);
  text-decoration: none;
  white-space: nowrap;
  -webkit-tap-highlight-color: transparent;
}
.link:hover { color: var(--color-fg); }
.link:focus-visible { outline: 1px solid var(--color-accent-edge); outline-offset: -3px; border-radius: var(--r-2); }

.active { color: var(--color-fg); }
.active::after {
  content: '';
  position: absolute;
  inset: auto var(--space-2) -1px var(--space-2);
  height: 2px;
  border-radius: 1px;
  background: var(--color-accent);
}
</style>
