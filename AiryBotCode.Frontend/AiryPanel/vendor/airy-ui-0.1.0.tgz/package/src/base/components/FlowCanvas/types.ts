/**
 * Shared types for the flow editor surface. Exported from `@hive/ui` so
 * consumers can type their drop handlers and palette items without
 * redeclaring.
 *
 * The `kind` discriminators are open by convention — future drag patterns
 * (e.g. data-edge wiring) add new kinds without breaking existing handlers.
 */

import type { FlowNodeData } from '../FlowNode/FlowNode.vue'

export interface PaletteItem {
  /** Stable id. Same item dragged twice still has the same id. */
  id: string
  /** Maps onto `flow_node.node_type` on insert. */
  nodeType: string
  label: string
  description?: string
}

/** Where a drag originated. */
export type DragSource =
  | { kind: 'palette'; item: PaletteItem }
  | { kind: 'node';    nodeId: string }

/** Where a drag landed. */
export type DropTarget =
  | {
      kind: 'between-nodes'
      /** id of the node immediately to the left, or null if dropping at the chain start. */
      afterNodeId: string | null
      /** id of the node immediately to the right, or null if dropping at the chain end. */
      beforeNodeId: string | null
    }

export interface DropEvent {
  source: DragSource
  target: DropTarget
}

// Re-export FlowNodeData for convenience in this types module
export type { FlowNodeData }
