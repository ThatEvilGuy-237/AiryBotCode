<script setup lang="ts">
/**
 * TableColumn
 * Declares one column of a <Table>. Renders nothing itself — it registers a
 * column definition with the parent table, which owns all the markup. Column
 * order follows declaration order, and a column removed with `v-if` returns to
 * its original position when it comes back.
 *
 * @prop field     - row property this column reads, sorts by, and is keyed on (required)
 * @prop header    - column label; falls back to `field`
 * @prop type      - cell renderer: 'text' (mono, default) | 'prose' (sans) |
 *                   'num' (mono tabular, right-aligned) | 'date' (Intl short date) |
 *                   'tag' (dot chip, tone from `tones`) | 'role' (outline chip)
 * @prop align     - 'left' | 'center' | 'right'; defaults to right for `num`, left otherwise
 * @prop width     - fixed column width, e.g. '8rem'. Usually omit it
 * @prop minWidth  - per-column floor in the table's `scroll-x` mode
 * @prop sortable  - header becomes a sort toggle (asc → desc → off)
 * @prop action    - marks this the sticky action column: pinned right, never sorted,
 *                   content not clipped. Must be the last column
 * @prop tones     - for type 'tag' / 'role': maps a cell value to a chip tone
 * @prop format    - (value, row) => string display transform; sorting keeps the raw value
 * @prop sortValue - (row) => unknown sort key when the displayed value is not sortable
 * @prop compare   - (a, b) => number full comparator; wins over field / sortValue
 *
 * Slots:
 *   default - scoped slot { row, value, index } rendering the whole cell. Replaces
 *             the `type` renderer; clicks inside it never select or click the row
 *
 * Status: new | Consumers: Table, portal-kit, memory portal
 */
import { computed, inject, onBeforeUnmount, onMounted, useSlots, watch } from 'vue'
import { HIVE_TABLE_REGISTRY } from './keys'
import type { TableAlign, TableCellContext, TableCellType, TableColumnDef, TableRow, TableToneInput } from './types'

const props = withDefaults(defineProps<{
  field: string
  header?: string
  type?: TableCellType
  align?: TableAlign
  width?: string
  minWidth?: string
  sortable?: boolean
  action?: boolean
  tones?: Record<string, TableToneInput>
  format?: (value: unknown, row: TableRow) => string
  sortValue?: (row: TableRow) => unknown
  compare?: (a: TableRow, b: TableRow) => number
}>(), { sortable: false, action: false })

const slots = useSlots()
const registry = inject(HIVE_TABLE_REGISTRY, null)

const definition = computed<TableColumnDef>(() => ({
  field: props.field,
  header: props.header,
  type: props.type,
  align: props.align,
  width: props.width,
  minWidth: props.minWidth,
  sortable: props.sortable && !props.action,
  action: props.action,
  tones: props.tones,
  format: props.format,
  sortValue: props.sortValue,
  compare: props.compare,
  cell: slots.default ? (context: TableCellContext) => slots.default!(context) : undefined,
}))

let stop: (() => void) | undefined

onMounted(() => {
  registry?.register(definition.value)
  stop = watch(definition, next => registry?.register(next))
})

onBeforeUnmount(() => {
  stop?.()
  registry?.unregister(props.field)
})
</script>

<template>
  <span v-if="false" />
</template>
