<script setup lang="ts">
/**
 * BottomNavItem
 * One destination in a `<BottomNav>`: an icon over a short label, the whole
 * cell one touch target of at least 56 px. Routes through vue-router like
 * `<SidebarItem>` and marks itself `aria-current="page"`; the current item gets
 * the accent on its icon and a 2 px accent bar on its top edge, the same marker
 * the sidebar draws on its left edge.
 *
 * @prop label - the item's text, and its accessible name; keep it to one word
 * @prop to    - vue-router target
 * @prop icon  - icon from the curated set
 * @prop exact - active only on an exact route match (use for `/`)
 *
 * Status: new | Consumers: evil-dash layout
 */
import { computed } from 'vue'
import { useLink, useRoute, type RouteLocationRaw } from 'vue-router'
import Icon from '../Icon/Icon.vue'
import type { IconName } from '../Icon/icons'

const props = withDefaults(defineProps<{
  label: string
  to: RouteLocationRaw
  icon?: IconName
  exact?: boolean
}>(), { exact: false })

const link = useLink({ to: computed(() => props.to) })
const route = useRoute()

const isActive = computed(() => {
  if (props.exact) return link.isExactActive.value
  if (link.isActive.value) return true
  const base = link.route.value.path.replace(/\/+$/, '')
  return !!base && route.path.startsWith(`${base}/`)
})

function onClick(event: MouseEvent) {
  link.navigate(event)
}
</script>

<template>
  <li :class="$style.item">
    <a
      :href="link.href.value"
      :class="[$style.link, isActive && $style.active]"
      :aria-current="isActive ? 'page' : undefined"
      @click="onClick"
    >
      <Icon v-if="icon" :name="icon" :size="20" :class="$style.icon" />
      <span :class="$style.label">{{ label }}</span>
    </a>
  </li>
</template>

<style module>
.item { flex: 1 1 0; min-width: 0; }

.link {
  position: relative;
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: center;
  gap: 2px;
  min-height: 56px;
  padding: var(--space-1) var(--bottom-nav-item-px, var(--space-2));
  color: var(--color-text-dim);
  text-decoration: none;
  -webkit-tap-highlight-color: transparent;
}
.link:hover { color: var(--color-fg); }
.link:focus-visible { outline: 1px solid var(--color-accent-edge); outline-offset: -3px; border-radius: var(--r-2); }

.active { color: var(--color-fg); }
.active::before {
  content: '';
  position: absolute;
  inset: 0 25% auto 25%;
  height: 2px;
  border-radius: 1px;
  background: var(--color-accent);
}
.active .icon { color: var(--color-accent); }

.icon { flex: 0 0 auto; color: var(--color-text-ghost); }
.label {
  max-width: 100%;
  font-family: var(--font-family);
  font-size: var(--font-size-xs, 12px);
  line-height: 1.2;
  white-space: nowrap;
  overflow: hidden;
  text-overflow: ellipsis;
}
</style>
