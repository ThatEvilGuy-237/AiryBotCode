<script setup lang="ts">
/**
 * CopyButton — copy a value to the clipboard with transient "Copied" feedback.
 *
 * @prop value - text to copy
 * @prop label - optional text beside the icon (e.g. "Copy URL")
 * @prop size  - sm | md
 *
 * Status: new
 */
import { ref } from 'vue'
import Icon from '../Icon/Icon.vue'

const props = withDefaults(defineProps<{
  value: string
  label?: string
  size?: 'sm' | 'md'
}>(), { size: 'sm' })

const copied = ref(false)

async function copy() {
  try {
    await navigator.clipboard?.writeText(props.value)
    copied.value = true
    setTimeout(() => (copied.value = false), 1500)
  } catch { /* clipboard blocked */ }
}
</script>

<template>
  <button type="button" data-ui="copy-button" :class="[$style.btn, $style[size]]" :title="label ?? 'Copy'" @click="copy">
    <Icon :name="copied ? 'check' : 'copy'" :size="14" />
    <span v-if="label || copied">{{ copied ? 'Copied' : label }}</span>
  </button>
</template>

<style module>
.btn { display: inline-flex; align-items: center; gap: 6px; background: transparent; border: 1px solid transparent; border-radius: var(--radius); color: var(--color-text-dim, var(--color-muted)); cursor: pointer; font-family: var(--font-family); }
.sm { height: 26px; padding: 0 8px; font-size: var(--font-size-xs); }
.md { height: 32px; padding: 0 12px; font-size: var(--font-size-sm); }
.btn:hover { color: var(--color-fg); background: var(--color-surface-mute, var(--color-surface)); }
</style>
