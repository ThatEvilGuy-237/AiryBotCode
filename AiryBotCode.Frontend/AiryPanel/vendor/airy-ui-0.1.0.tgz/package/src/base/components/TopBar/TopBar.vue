<script setup lang="ts">
/**
 * TopBar
 * Top bar with service name and optional status indicator.
 *
 * @prop serviceName - displayed on the left
 * @prop status      - "online" | "offline"
 * @slot lead        - optional leading content before the name (e.g. a mobile
 *                     menu toggle); omit it and the bar looks exactly as before
 * @slot actions     - optional trailing content before the status (e.g. a
 *                     workspace switcher); omit it for the original layout
 *
 * Status: stable | Consumers: Wraith-Worker/frontend App.vue
 */
defineProps<{
  serviceName: string
  status?: 'online' | 'offline'
}>()
</script>

<template>
  <header data-ui="top-bar" :class="$style.bar">
    <div :class="$style.left">
      <slot name="lead" />
      <span :class="$style.name">{{ serviceName }}</span>
    </div>
    <div :class="$style.right">
      <slot name="actions" />
      <span v-if="status" :class="[$style.status, $style[status]]">
        <span :class="$style.dot" />
        {{ status }}
      </span>
    </div>
  </header>
</template>

<style module>
.bar {
  display: flex;
  align-items: center;
  justify-content: space-between;
  padding: 0 var(--space-4);
  height: 52px;
  border-bottom: var(--border);
  flex-shrink: 0;
}

.left {
  display: flex;
  align-items: center;
  gap: var(--space-2);
  min-width: 0;
}

.right {
  display: flex;
  align-items: center;
  gap: var(--space-3);
}

.name {
  font-family: var(--font-mono);
  font-size: var(--font-size-base);
  font-weight: 700;
  letter-spacing: 0.1em;
  text-transform: uppercase;
}

.status {
  display: flex;
  align-items: center;
  gap: var(--space-1);
  font-family: var(--font-mono);
  font-size: var(--font-size-xs);
  color: var(--color-muted);
  letter-spacing: 0.06em;
  text-transform: uppercase;
}

.dot {
  width: 6px;
  height: 6px;
  border-radius: 50%;
  flex-shrink: 0;
}

.online .dot  { background: var(--color-fg); }
.offline .dot { background: var(--color-muted); }
</style>
