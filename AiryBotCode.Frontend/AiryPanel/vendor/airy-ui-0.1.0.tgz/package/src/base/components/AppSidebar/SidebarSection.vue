<script setup lang="ts">
/**
 * SidebarSection
 * One labelled group of `<SidebarItem>`s inside an `<AppSidebar>`. The label is
 * a mono uppercase eyebrow — an index tab for the eye, not a heading competing
 * with the items.
 *
 * `collapsible` actually collapses. The header becomes a real button carrying
 * `aria-expanded` and `aria-controls`, and the fold is stored in the root's fold
 * map under this section's fold key: `name` if you gave one, otherwise a slug of
 * `label`. Give long-lived sections an explicit `name` — a persisted fold map
 * keyed off the label forgets itself the day someone rewords the label.
 *
 * Folding hides items, not information. A folded header keeps the sum of its
 * items' numeric badges, and shows an accent dot when the page you are on is one
 * of the items you just folded away. That is why the section never force-opens
 * on navigation: you closed it on purpose, so it tells you instead of fighting
 * you.
 *
 * A section without a label is a plain group — use one to hold items that need
 * no eyebrow, since a bare `<SidebarItem>` has no list to live in.
 *
 * @prop label         - mono uppercase eyebrow, and the button's accessible name
 * @prop name          - stable fold key; defaults to a slug of `label`
 * @prop collapsible   - the header folds the section
 * @prop defaultFolded - folded when the root's fold map has no entry for this key
 * @prop emptyText     - `//` line shown when the section renders no items
 *
 * Slot:
 *   default - the `<SidebarItem>`s
 *
 * Status: new | Consumers: AppSidebar
 */
import { computed, inject, onMounted, provide, ref, type ComputedRef } from 'vue'
import Icon from '../Icon/Icon.vue'
import { SIDEBAR_CTX, SIDEBAR_SECTION_CTX, type SidebarSectionContext } from './keys'
import type { SidebarItemFacts } from './types'

const props = withDefaults(defineProps<{
  label?: string
  name?: string
  collapsible?: boolean
  defaultFolded?: boolean
  emptyText?: string
}>(), {
  collapsible: false,
  defaultFolded: false,
  emptyText: 'nothing here',
})

defineSlots<{ default?: () => unknown }>()

const sidebar = inject(SIDEBAR_CTX, null)
const rail = computed(() => sidebar?.rail.value ?? false)

const foldKey = computed(() =>
  props.name ?? (props.label ?? '').trim().toLowerCase().replace(/[^a-z0-9]+/g, '-'),
)
const bodyId = computed(() => (foldKey.value ? `hive-sidebar-${foldKey.value}-items` : undefined))

const folded = computed(() => {
  if (!props.collapsible || rail.value || !sidebar) return false
  return sidebar.isFolded(foldKey.value, props.defaultFolded)
})

const facts = ref(new Set<ComputedRef<SidebarItemFacts>>())
const context: SidebarSectionContext = {
  register: (entry) => { facts.value.add(entry) },
  unregister: (entry) => { facts.value.delete(entry) },
}
provide(SIDEBAR_SECTION_CTX, context)

const mounted = ref(false)
onMounted(() => { mounted.value = true })

const count = computed(() => facts.value.size)

const total = computed<number | null>(() => {
  let sum = 0
  let seen = false
  for (const entry of facts.value) {
    const badge = entry.value.badge
    const value = typeof badge === 'number' ? badge : Number(badge)
    if (badge !== null && badge !== '' && Number.isFinite(value)) {
      sum += value
      seen = true
    }
  }
  return seen ? sum : null
})

const holdsCurrent = computed(() => {
  for (const entry of facts.value) if (entry.value.active) return true
  return false
})

const unfurling = ref(false)

function toggle() {
  if (!sidebar) return
  const opening = folded.value
  sidebar.toggleFold(foldKey.value, props.defaultFolded)
  if (opening) unfurling.value = true
}

function onHeadKeydown(event: KeyboardEvent) {
  if (!sidebar) return
  if (event.key === 'ArrowRight' && folded.value) {
    event.preventDefault()
    sidebar.setFolded(foldKey.value, false)
    unfurling.value = true
    return
  }
  if (event.key === 'ArrowLeft' && !folded.value) {
    event.preventDefault()
    sidebar.setFolded(foldKey.value, true)
  }
}
</script>

<template>
  <section :class="$style.section">
    <button
      v-if="collapsible && !rail && label"
      type="button"
      :class="$style.head"
      :aria-expanded="!folded"
      :aria-controls="bodyId"
      data-hive-sidebar-stop
      @click="toggle"
      @keydown="onHeadKeydown"
    >
      <Icon
        name="chevron-down"
        :size="12"
        :class="[$style.chev, folded && $style.chevShut]"
      />
      <span :class="$style.eyebrow">{{ label }}</span>
      <span :class="$style.gap" />
      <span v-if="mounted && folded && total !== null" :class="$style.total">{{ total }}</span>
      <span v-if="mounted && folded && holdsCurrent" :class="$style.here" aria-hidden="true" />
      <span v-if="mounted && folded && holdsCurrent" :class="$style.sr">
        current page is inside
      </span>
    </button>

    <div v-else-if="label && !rail" :class="[$style.head, $style.plain]">
      <span :class="$style.eyebrow">{{ label }}</span>
    </div>

    <hr v-else-if="label && rail" :class="$style.rule" />

    <ul
      v-show="!folded"
      :id="bodyId"
      :class="[$style.items, unfurling && $style.unfurl]"
      @animationend="unfurling = false"
    >
      <slot />
      <li v-if="mounted && count === 0" :class="$style.empty">// {{ emptyText }}</li>
    </ul>
  </section>
</template>

<style module>
.section { display: flex; flex-direction: column; gap: var(--space-1); }

.head {
  display: flex;
  align-items: center;
  gap: var(--space-2);
  width: 100%;
  min-height: 24px;
  padding: var(--space-1) var(--space-2);
  border: 0;
  border-radius: var(--r-1);
  background: none;
  font: inherit;
  text-align: left;
  cursor: pointer;
}
.head:hover { background: var(--color-surface-hi); }
.head:hover .eyebrow { color: var(--color-muted); }
.head:focus-visible { outline: 1px solid var(--color-accent-edge); outline-offset: -1px; }

.plain { cursor: default; padding-left: calc(var(--space-2) + 12px + var(--space-2)); }
.plain:hover { background: none; }

/* Rail mode has no room for an eyebrow, so the group boundary becomes a hairline. */
.rule {
  margin: var(--space-1) var(--space-2);
  border: 0;
  border-top: 1px solid var(--color-border-soft);
}
.section:first-child .rule { display: none; }

.eyebrow {
  font-family: var(--font-mono);
  font-size: var(--font-size-xs);
  letter-spacing: 0.08em;
  text-transform: uppercase;
  color: var(--color-text-ghost);
  white-space: nowrap;
  overflow: hidden;
  text-overflow: ellipsis;
}

.chev {
  flex: 0 0 auto;
  color: var(--color-text-ghost);
  transition: transform 120ms ease;
}
.chevShut { transform: rotate(-90deg); }

.gap { flex: 1 1 auto; }

/* A folded section keeps its numbers: mono, because they are data. */
.total {
  font-family: var(--font-mono);
  font-size: var(--font-size-xs);
  color: var(--color-muted);
}

/* You folded away the page you are on — one dot, no glow. */
.here {
  width: 5px;
  height: 5px;
  flex: 0 0 auto;
  border-radius: 999px;
  background: var(--color-accent);
}

.sr {
  position: absolute;
  width: 1px;
  height: 1px;
  margin: -1px;
  padding: 0;
  overflow: hidden;
  clip-path: inset(50%);
  white-space: nowrap;
}

.items {
  margin: 0;
  padding: 0;
  list-style: none;
  display: flex;
  flex-direction: column;
  gap: 1px;
}
.unfurl { animation: unfurl 140ms ease-out; }

.empty {
  padding: var(--space-1) var(--space-2);
  font-family: var(--font-mono);
  font-size: var(--font-size-xs);
  color: var(--color-text-ghost);
}

@keyframes unfurl {
  from { opacity: 0; transform: translateY(-3px); }
  to   { opacity: 1; transform: none; }
}

@media (prefers-reduced-motion: reduce) {
  .chev { transition: none; }
  .unfurl { animation: none; }
}
</style>
