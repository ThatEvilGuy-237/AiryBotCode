<script setup lang="ts">
/**
 * Text
 * The typography primitive. Encodes the house rule "mono for data, sans for
 * prose" as a prop instead of leaving the font switch to each author's
 * `style="font-family: var(--font-mono)"`.
 *
 * Five variants, one per line of the Hive text vocabulary:
 *   body     - sans prose at --font-size-base, --color-text-dim
 *   caption  - sans prose at --font-size-sm, --color-muted (secondary copy)
 *   meta     - mono data: ids, ports, counts, timestamps, hashes
 *   eyebrow  - uppercase mono section label at --color-text-ghost
 *   comment  - the `// engineer line`; the `// ` is drawn for you
 *
 * @prop variant  - 'body' | 'caption' | 'meta' | 'eyebrow' | 'comment' (default: 'body')
 * @prop tone     - 'default' | 'dim' | 'muted' | 'ghost' | 'ok' | 'warn' | 'danger' | 'accent'
 *                  (default: 'default' — keeps the variant's own color)
 * @prop size     - 'xs' | 'sm' | 'base' | 'lg' | 'xl' off the --font-size-* scale.
 *                  Omit it: every variant already carries the right step.
 * @prop as       - element to render (default: 'p' for body/caption, 'span' for
 *                  meta/eyebrow/comment)
 * @prop truncate - clip to one line with an ellipsis; the full text becomes the
 *                  title attribute so it stays readable on hover
 * @prop copyable - show a CopyButton after the text. `true` copies the rendered
 *                  text, a string copies that value instead (for elided ids)
 *
 * Slot:
 *   default - the text. Inline elements are allowed; block elements are not.
 *
 * Status: new | Consumers: available for future use (replaces portal-kit's Text shim)
 */
import { computed, Text as VueText, type VNode } from 'vue'
import CopyButton from '../CopyButton/CopyButton.vue'

export type TextVariant = 'body' | 'caption' | 'meta' | 'eyebrow' | 'comment'
export type TextTone = 'default' | 'dim' | 'muted' | 'ghost' | 'ok' | 'warn' | 'danger' | 'accent'
export type TextSize = 'xs' | 'sm' | 'base' | 'lg' | 'xl'
export type TextAs =
  | 'p' | 'span' | 'div' | 'code' | 'strong' | 'em' | 'small'
  | 'time' | 'label' | 'dt' | 'dd' | 'li' | 'h2' | 'h3' | 'h4'

const props = withDefaults(defineProps<{
  variant?: TextVariant
  tone?: TextTone
  size?: TextSize
  as?: TextAs
  truncate?: boolean
  copyable?: boolean | string
}>(), { variant: 'body', tone: 'default', truncate: false, copyable: false })

const slots = defineSlots<{ default?: () => VNode[] }>()

const DEFAULT_TAG: Record<TextVariant, TextAs> = {
  body: 'p',
  caption: 'p',
  meta: 'span',
  eyebrow: 'span',
  comment: 'span',
}

const tag = computed(() => props.as ?? DEFAULT_TAG[props.variant])
const withCopy = computed(() => props.copyable !== false)

function flatten(nodes: VNode[]): string {
  return nodes.map((node) => {
    if (node.type === VueText) return String(node.children ?? '')
    if (Array.isArray(node.children)) return flatten(node.children as VNode[])
    return ''
  }).join('')
}

function slotText(): string {
  return flatten(slots.default?.() ?? []).trim()
}

function copyValue(): string {
  return typeof props.copyable === 'string' ? props.copyable : slotText()
}
</script>

<template>
  <component data-ui="text"
    :is="tag"
    :class="[
      $style.text,
      $style[variant],
      tone !== 'default' && $style[tone],
      size && $style[size],
      withCopy && $style.hasCopy,
      truncate && !withCopy && $style.truncate,
    ]"
    :title="truncate ? slotText() : undefined"
  >
    <template v-if="withCopy">
      <span :class="[$style.inner, truncate && $style.truncate]"><slot /></span>
      <CopyButton :class="$style.copy" :value="copyValue()" size="sm" />
    </template>
    <slot v-else />
  </component>
</template>

<style module>
.text {
  margin: 0;
  color: inherit;
}

/* Variants — the font switch is the signal. */
.body {
  font-family: var(--font-family);
  font-size: var(--font-size-base);
  line-height: 1.55;
  color: var(--color-text-dim);
}
.caption {
  font-family: var(--font-family);
  font-size: var(--font-size-sm);
  line-height: 1.5;
  color: var(--color-muted);
}
.meta {
  font-family: var(--font-mono);
  font-size: var(--font-size-sm);
  line-height: 1.45;
  color: var(--color-muted);
}
.eyebrow {
  font-family: var(--font-mono);
  font-size: var(--font-size-xs);
  line-height: 1.4;
  letter-spacing: 0.08em;
  text-transform: uppercase;
  color: var(--color-text-ghost);
}
.comment {
  font-family: var(--font-mono);
  font-size: var(--font-size-sm);
  line-height: 1.45;
  color: var(--color-muted);
}
.comment::before {
  content: '// ';
}

/* Tones — override the variant's own color. */
.dim    { color: var(--color-text-dim); }
.muted  { color: var(--color-muted); }
.ghost  { color: var(--color-text-ghost); }
.ok     { color: var(--color-ok); }
.warn   { color: var(--color-warn); }
.danger { color: var(--color-danger); }
.accent { color: var(--color-accent); }

/* Sizes — the --font-size-* scale, for the rare off-step case. */
.xs   { font-size: var(--font-size-xs); }
.sm   { font-size: var(--font-size-sm); }
.base { font-size: var(--font-size-base); }
.lg   { font-size: var(--font-size-lg); }
.xl   { font-size: var(--font-size-xl); }

.truncate {
  display: inline-block;
  max-width: 100%;
  overflow: hidden;
  text-overflow: ellipsis;
  white-space: nowrap;
  vertical-align: bottom;
}

/* Copyable — the button holds its slot so revealing it never shifts the line. */
.hasCopy {
  display: inline-flex;
  align-items: center;
  gap: var(--space-1);
  max-width: 100%;
}
.inner {
  min-width: 0;
}
.copy {
  flex: none;
  opacity: 0;
  transition: opacity 120ms ease;
}
.hasCopy:hover .copy,
.hasCopy:focus-within .copy {
  opacity: 1;
}

@media (prefers-reduced-motion: reduce) {
  .copy { transition: none; }
}
</style>
