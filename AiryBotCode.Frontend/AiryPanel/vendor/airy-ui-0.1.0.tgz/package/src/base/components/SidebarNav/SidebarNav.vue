<script setup lang="ts">
/**
 * SidebarNav
 * Left sidebar navigation. Shared layout primitive for all Hive frontends.
 * Renders <RouterLink>s so clicks navigate via vue-router instead of doing a
 * full browser request (which would otherwise hit any matching Vite proxy).
 *
 * @prop items - nav links: { label, href, active? }[]
 *
 * Status: stable | Consumers: Wraith-Worker/frontend App.vue, Neural-Spine/frontend App.vue
 */
import { RouterLink } from 'vue-router'

defineProps<{
  items: { label: string; href: string; active?: boolean }[]
}>()
</script>

<template>
  <nav data-ui="sidebar-nav" :class="$style.nav">
    <RouterLink
      v-for="item in items"
      :key="item.href"
      :to="item.href"
      :class="[$style.link, item.active && $style.active]"
    >
      {{ item.label }}
    </RouterLink>
  </nav>
</template>

<style module>
.nav {
  display: flex;
  flex-direction: column;
  width: 200px;
  flex-shrink: 0;
  border-right: var(--border);
  padding: var(--space-3) var(--space-2);
  height: 100%;
  gap: 2px;
}

.link {
  display: flex;
  align-items: center;
  height: 36px;
  padding: 0 var(--space-3);
  color: var(--color-text-dim, var(--color-muted));
  text-decoration: none;
  font-size: var(--font-size-base);
  font-weight: 500;
  border: 1px solid transparent;
  border-radius: var(--radius);
  transition: color 0.12s, background 0.12s, border-color 0.12s;
}

.link:hover {
  color: var(--color-fg);
  background: var(--color-surface-mute, var(--color-surface));
}

.active {
  background: var(--color-surface);
  border-color: var(--color-border);
  color: var(--color-fg);
  font-weight: 600;
  box-shadow: inset 2px 0 0 0 var(--color-accent, var(--color-fg));
}

.active:hover {
  background: var(--color-surface);
  color: var(--color-fg);
}
</style>
