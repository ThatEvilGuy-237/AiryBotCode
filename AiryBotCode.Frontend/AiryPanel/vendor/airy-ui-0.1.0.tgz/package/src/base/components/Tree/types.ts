/**
 * Tree — public data types.
 *
 * The node type is the contract: you hand Tree a recursive `TreeNode[]` and it
 * owns rendering, expansion, selection and keyboard navigation. Format `meta`
 * and any trailing count yourself; Tree renders them as given.
 */
import type { IconName } from '../Icon/icons'

/** Stable, unique node identity. Selection and expansion state hang off it. */
export type TreeKey = string | number

/** One node. Arbitrary depth via `children`, or `lazy` + a loader on the root. */
export interface TreeNode {
  /** Stable and unique across the WHOLE tree, not just among siblings. */
  key: TreeKey
  /** Prose label, rendered in the sans face. */
  label: string
  /** Mono secondary text after the label — an id, a path, a type. */
  meta?: string
  /** Icon from the curated Hive set, drawn before the label — never pasted svg. */
  icon?: IconName
  /** Children are fetched on first expand via the root's `loadChildren`. */
  lazy?: boolean
  /** Readable title, unreadable body: no caret, a lock, a `//` note. */
  locked?: boolean
  /** Still shown and focusable, but not selectable. */
  disabled?: boolean
  /** Dropped from render AND from keyboard navigation. */
  hidden?: boolean
  children?: TreeNode[]
}

/** Expansion state as a map: `{ [key]: true }` is open. Absent/false is shut. */
export type TreeExpandedMap = Record<TreeKey, boolean>

/** Per-node load lifecycle for lazy branches. */
export type TreeLoadState = 'idle' | 'loading' | 'loaded' | 'error'

/** Fetches one node's children. Rejecting marks that branch unreadable. */
export type TreeLoadChildren = (node: TreeNode) => Promise<TreeNode[]>

/** Scope handed to the `label` and `trailing` slots. */
export interface TreeNodeSlotProps {
  node: TreeNode
  depth: number
  expanded: boolean
  selected: boolean
  loading: boolean
}
