import type { InjectionKey, ComputedRef } from 'vue'

/**
 * Context a <Field> publishes to the control in its slot.
 *
 * Controls do not have to consume it — Field also wires the DOM directly, so
 * every existing @hive/ui control works unchanged. New controls that want to
 * own their own attributes can `inject(FIELD_KEY, null)` and read this instead.
 */
export interface FieldContext {
  /** id the label points at with `for` — put it on the focusable element. */
  id: ComputedRef<string>
  /** space-separated id list for `aria-describedby` (hint and/or error). */
  describedBy: ComputedRef<string | undefined>
  /** true while the field is showing an error. */
  invalid: ComputedRef<boolean>
  /** true when the field is marked required. */
  required: ComputedRef<boolean>
  /** true when the field is marked disabled. */
  disabled: ComputedRef<boolean>
}

export const FIELD_KEY: InjectionKey<FieldContext> = Symbol('hive:field')

let seq = 0

/**
 * Monotonic control id. Module-scoped so server and client renders walk the
 * same sequence and the `for` attribute survives hydration.
 */
export function nextFieldId(): string {
  seq += 1
  return `hive-field-${seq}`
}
