<script setup lang="ts">
/**
 * SettingRow
 * Label + description on the left, a control on the right.
 * Use inside a <Card> stacked with <Divider> between rows for a settings panel.
 *
 * @prop name        - the setting's title
 * @prop description - optional muted description below the name
 *
 * Slot: default — the control (Toggle, Checkbox, Button, etc.). A Toggle in the slot
 * takes this row's name as its accessible name through aria-labelledby.
 *
 * Status: stable | Consumers: Patterns
 */
import { computed, provide } from 'vue'
import { SETTING_ROW_KEY, nextSettingRowId } from './keys'

const props = defineProps<{ name: string; description?: string }>()
const rowId = nextSettingRowId()
const labelId = computed(() => `${rowId}-name`)
const descriptionId = computed(() => (props.description ? `${rowId}-desc` : undefined))
provide(SETTING_ROW_KEY, { labelId, descriptionId })
</script>

<template>
  <div data-ui="setting-row" :class="$style.row">
    <div :class="$style.text">
      <div :id="labelId" :class="$style.name">{{ name }}</div>
      <div v-if="description" :id="descriptionId" :class="$style.desc">{{ description }}</div>
    </div>
    <div :class="$style.control"><slot /></div>
  </div>
</template>

<style module>
.row {
  display: flex;
  align-items: center;
  gap: var(--space-4);
  padding: var(--space-3) var(--space-4);
}
.text {
  display: flex;
  flex-direction: column;
  gap: 2px;
  flex: 1;
  min-width: 0;
}
.name {
  font-size: var(--font-size-base);
  font-weight: 500;
  color: var(--color-fg);
}
.desc {
  font-size: var(--font-size-sm);
  color: var(--color-text-dim, var(--color-muted));
}
.control {
  display: flex;
  align-items: center;
  gap: var(--space-2);
  flex-shrink: 0;
}
</style>
