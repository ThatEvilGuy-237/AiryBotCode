// Shared highlight.js instance — register every language we support once,
// then re-use from CodeBlock and Markdown. Registration is idempotent so
// re-importing this module is safe.

import hljs       from 'highlight.js/lib/core'
import javascript from 'highlight.js/lib/languages/javascript'
import typescript from 'highlight.js/lib/languages/typescript'
import csharp     from 'highlight.js/lib/languages/csharp'
import xml        from 'highlight.js/lib/languages/xml'
import css        from 'highlight.js/lib/languages/css'
import json       from 'highlight.js/lib/languages/json'
import bash       from 'highlight.js/lib/languages/bash'

hljs.registerLanguage('javascript', javascript)
hljs.registerLanguage('js',         javascript)
hljs.registerLanguage('typescript', typescript)
hljs.registerLanguage('ts',         typescript)
hljs.registerLanguage('csharp',     csharp)
hljs.registerLanguage('cs',         csharp)
hljs.registerLanguage('xml',        xml)
hljs.registerLanguage('html',       xml)
hljs.registerLanguage('vue',        xml)
hljs.registerLanguage('css',        css)
hljs.registerLanguage('json',       json)
hljs.registerLanguage('bash',       bash)
hljs.registerLanguage('sh',         bash)

export const SUPPORTED_LANGS = [
  'javascript', 'typescript', 'csharp', 'xml', 'css', 'json', 'bash',
]

export default hljs
