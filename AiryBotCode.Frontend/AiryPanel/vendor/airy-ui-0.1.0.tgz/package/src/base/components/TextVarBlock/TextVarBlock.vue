<script setup lang="ts">
/**
 * TextVarBlock
 * Read or edit a template string. Highlights `{{$varname}}` placeholders as
 * accent-colored chips. Same monospace surface as CodeBlock, same overlay
 * trick in edit mode so the textarea caret tracks the colored glyphs.
 *
 * @prop text     - the template string (use v-model:text for two-way binding)
 * @prop filename - optional label in the head strip
 * @prop copy     - show the copy button (default true)
 * @prop readonly - lock the text (default true). Set false to enable editing.
 *
 * @event update:text - new value, fires on every input while editing
 *
 * Status: stable | Consumers: Chronos-Mind/frontend (CatcherForm, CatcherDetail)
 */
import { computed, ref } from 'vue'

const props = withDefaults(defineProps<{
  text: string
  filename?: string
  copy?: boolean
  readonly?: boolean
}>(), { copy: true, readonly: true })

const emit = defineEmits<{ 'update:text': [value: string] }>()

const editing = ref(false)

// `{{$varname}}` — same syntax as SK's KernelPromptTemplateFactory.
// Capture group + split lands matches at odd indices, literals at even ones.
const VAR_RE = /(\{\{\s*\$[a-zA-Z_][a-zA-Z0-9_]*\s*\}\})/g

function escapeHtml(s: string): string {
  return s
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
}

const highlighted = computed(() => {
  // Avoid `.test()` on the stateful /g regex (lastIndex bug). Index parity
  // tells us which chunk is a match.
  const parts = props.text.split(VAR_RE)
  return parts
    .map((part, i) => (i % 2 === 1)
      ? `<span class="tvb-var">${escapeHtml(part)}</span>`
      : escapeHtml(part))
    .join('')
})

const hasHead = computed(() =>
  !!props.filename || props.copy || !props.readonly
)

const copied = ref(false)
async function doCopy() {
  try {
    await navigator.clipboard.writeText(props.text)
    copied.value = true
    setTimeout(() => { copied.value = false }, 1200)
  } catch { /* clipboard blocked — ignore */ }
}

function onInput(e: Event) {
  emit('update:text', (e.target as HTMLTextAreaElement).value)
}
</script>

<template>
  <div data-ui="text-var-block" :class="$style.block">
    <div v-if="hasHead" :class="$style.head">
      <span v-if="filename" :class="$style.filename">{{ filename }}</span>
      <div :class="$style.spacer" />

      <button
        v-if="!readonly"
        type="button"
        :class="[$style.btn, editing && $style.btnOn]"
        @click="editing = !editing"
      >
        {{ editing ? 'done' : 'edit' }}
      </button>

      <button v-if="copy" type="button" :class="$style.btn" @click="doCopy">
        {{ copied ? 'copied' : 'copy' }}
      </button>
    </div>

    <pre v-if="!editing" :class="$style.pre"><span :class="$style.text" v-html="highlighted" /></pre>

    <!-- Edit mode: textarea overlaid on a highlighted pre. Identical font
         metrics (font, size, line-height, padding, white-space, tab-size) so
         the caret lines up with the colored glyphs in the pre. -->
    <div v-else :class="$style.editorWrap">
      <pre :class="$style.editorView" aria-hidden="true"><span v-html="highlighted" /> </pre>
      <textarea
        :class="$style.editorInput"
        :value="text"
        spellcheck="false"
        autocorrect="off"
        autocapitalize="off"
        @input="onInput"
      />
    </div>
  </div>
</template>

<style module>
.block {
  border: var(--border);
  border-radius: var(--radius);
  background: var(--color-bg-2, var(--color-bg));
  overflow: hidden;
}

.head {
  display: flex;
  align-items: center;
  gap: var(--space-2);
  padding: var(--space-2) var(--space-3);
  border-bottom: 1px solid var(--color-border-soft, var(--color-border));
  background: var(--color-surface);
}

.filename {
  font-family: var(--font-mono);
  font-size: var(--font-size-sm);
  color: var(--color-fg);
}

.spacer { flex: 1; }

.btn {
  font-family: var(--font-mono);
  font-size: var(--font-size-xs);
  color: var(--color-muted);
  background: transparent;
  border: var(--border);
  border-radius: var(--radius);
  padding: 2px var(--space-2);
  cursor: pointer;
  transition: color 0.12s, border-color 0.12s, background 0.12s;
}
.btn:hover {
  color: var(--color-fg);
  border-color: var(--color-border-hi, var(--color-border));
}
.btnOn {
  color: var(--color-accent);
  border-color: var(--color-accent-edge, var(--color-accent));
  background: var(--color-accent-soft, transparent);
}

.pre {
  margin: 0;
  padding: var(--space-3) var(--space-4);
  overflow-x: auto;
  background: var(--color-bg-2, var(--color-bg));
  white-space: pre-wrap;
  word-break: break-word;
}

.text {
  font-family: var(--font-mono);
  font-size: var(--font-size-sm);
  line-height: 1.6;
  color: var(--color-text-dim, var(--color-fg));
  background: transparent;
  display: block;
}

/* Var chips. Same lookup the Badge component uses for color tokens. */
.text :global(.tvb-var),
.editorView :global(.tvb-var) {
  display: inline;
  padding: 0 4px;
  margin: 0 1px;
  border-radius: var(--radius);
  background: var(--color-accent-soft, var(--color-surface));
  color: var(--color-accent);
  border: 1px solid var(--color-accent-edge, var(--color-accent));
  font-weight: 600;
}

.editorWrap {
  position: relative;
  background: var(--color-bg-2, var(--color-bg));
}

.editorView,
.editorInput {
  margin: 0;
  padding: var(--space-3) var(--space-4);
  font-family: var(--font-mono);
  font-size: var(--font-size-sm);
  font-weight: 400;
  font-style: normal;
  line-height: 1.6;
  letter-spacing: 0;
  word-spacing: 0;
  tab-size: 2;
  white-space: pre-wrap;
  word-break: break-word;
  border: 0;
  box-sizing: border-box;
}

.editorView {
  display: block;
  pointer-events: none;
  color: var(--color-text-dim, var(--color-fg));
  background: transparent;
  min-height: calc(1.6em * 3);
}

.editorInput {
  position: absolute;
  inset: 0;
  width: 100%;
  height: 100%;
  background: transparent;
  color: transparent;
  caret-color: var(--color-fg);
  resize: none;
  outline: 0;
  overflow: hidden;
}
.editorInput:focus {
  outline: 2px solid var(--color-accent);
  outline-offset: -2px;
}
.editorInput::selection {
  background: var(--color-accent-soft, oklch(0.80 0.13 var(--accent-hue, 220) / 0.35));
  color: var(--color-fg);
}
.editorInput::-moz-selection {
  background: var(--color-accent-soft, oklch(0.80 0.13 var(--accent-hue, 220) / 0.35));
  color: var(--color-fg);
}
</style>
