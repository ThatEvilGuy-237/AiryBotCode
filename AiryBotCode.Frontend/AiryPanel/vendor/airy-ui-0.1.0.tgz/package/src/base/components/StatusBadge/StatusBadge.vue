<script setup lang="ts">
/**
 * StatusBadge — coloured dot + label for a status string. Centralises the
 * status→colour mapping duplicated across Runs / Triggers / Models.
 *
 * @prop status - e.g. running | completed | failed | enabled | disabled
 * @prop label  - override the displayed text (defaults to status)
 * @prop map    - override the status→tone map
 *
 * Status: new
 */
import { computed } from 'vue'

type Tone = 'ok' | 'warn' | 'err' | 'run' | 'muted'

const props = defineProps<{
  status: string
  label?: string
  map?: Record<string, Tone>
}>()

const DEFAULT: Record<string, Tone> = {
  completed: 'ok', done: 'ok', success: 'ok', succeeded: 'ok', ok: 'ok',
  enabled: 'ok', active: 'ok', live: 'ok', online: 'ok',
  completedwitherrors: 'warn', warn: 'warn', degraded: 'warn',
  pending: 'muted', queued: 'muted', idle: 'muted', disabled: 'muted', inactive: 'muted', offline: 'muted', cancelled: 'muted',
  running: 'run', started: 'run', busy: 'run',
  failed: 'err', error: 'err', rejected: 'err',
}

const tone = computed<Tone>(() => (props.map ?? DEFAULT)[(props.status ?? '').toLowerCase()] ?? 'muted')
</script>

<template>
  <span data-ui="status-badge" :class="$style.wrap">
    <span :class="[$style.dot, $style[tone]]" />
    <span :class="$style.label">{{ label ?? status }}</span>
  </span>
</template>

<style module>
.wrap { display: inline-flex; align-items: center; gap: 6px; }
.dot { width: 8px; height: 8px; border-radius: 50%; background: var(--color-muted); flex-shrink: 0; }
.ok { background: var(--color-ok, #46c489); }
.warn { background: var(--color-warn, #e0b24a); }
.err { background: var(--color-danger, #d64b46); }
.run { background: var(--color-accent, #7c6af7); }
.muted { background: var(--color-muted); }
.label { font-family: var(--font-mono); font-size: var(--font-size-xs); color: var(--color-fg); }
</style>
