<script setup lang="ts">
import Icon from '../Icon/Icon.vue'
/**
 * Modal — centred dialog over a backdrop, teleported to <body>.
 * Slots: header, default (body), footer. Closes on Esc + backdrop (opt-out).
 * Keeps the whole modal contract through `useDialog`: focus moves in on open
 * (to the first element marked `data-autofocus`, else the panel) and back to
 * the opener on close, Tab wraps inside, page scroll is locked. The title names
 * the dialog (`aria-labelledby`).
 *
 * @prop open            - visibility (controlled)
 * @prop title           - convenience header text (or use #header)
 * @prop size            - sm | md | lg
 * @prop closeOnBackdrop - click outside to close (default true)
 * @prop closeOnEsc      - Esc to close (default true)
 * @prop closable        - show the header's close button (default true); set it
 *                         false with both close* props for a sheet that must be
 *                         finished, such as one-time secrets shown once
 * @event close          - user dismissed
 *
 * Status: new
 */
import { computed, ref, toRef, useId } from 'vue'
import { useDialog } from '../../composables/useDialog'

const props = withDefaults(defineProps<{
  open: boolean
  title?: string
  size?: 'sm' | 'md' | 'lg'
  closeOnBackdrop?: boolean
  closeOnEsc?: boolean
  closable?: boolean
}>(), { size: 'md', closeOnBackdrop: true, closeOnEsc: true, closable: true })

const emit = defineEmits<{ close: [] }>()

const panel = ref<HTMLElement | null>(null)
const titleId = useId()
const autofocus = computed(() => panel.value?.querySelector<HTMLElement>('[data-autofocus]') ?? null)
const { layer } = useDialog(toRef(props, 'open'), {
  container: panel,
  initialFocus: autofocus,
  onClose: () => { if (props.closeOnEsc) emit('close') },
})
</script>

<template>
  <Teleport to="body">
    <div v-if="open" :class="$style.overlay" :style="{ zIndex: 100 + layer }" @click.self="closeOnBackdrop && emit('close')">
      <div ref="panel" data-ui="modal" :class="[$style.panel, $style[size]]" role="dialog" aria-modal="true" tabindex="-1" :aria-labelledby="title || $slots.header ? titleId : undefined">
        <header v-if="title || $slots.header" :class="$style.head">
          <div :id="titleId" :class="$style.heading"><slot name="header"><span :class="$style.title">{{ title }}</span></slot></div>
          <button v-if="closable" type="button" :class="$style.close" aria-label="Close" @click="emit('close')"><Icon name="x" :size="16" /></button>
        </header>
        <div :class="$style.body"><slot /></div>
        <footer v-if="$slots.footer" :class="$style.foot"><slot name="footer" /></footer>
      </div>
    </div>
  </Teleport>
</template>

<style module>
.overlay { position: fixed; inset: 0; background: rgba(0,0,0,0.5); display: flex; align-items: center; justify-content: center; z-index: 100; padding: var(--space-4); }
.panel { width: 100%; background: var(--color-surface); border: var(--border); border-radius: var(--radius); display: flex; flex-direction: column; max-height: 90vh; box-shadow: 0 12px 40px rgba(0,0,0,0.35); }
.sm { max-width: 420px; } .md { max-width: 560px; } .lg { max-width: 820px; }
.head { display: flex; align-items: flex-start; gap: var(--space-2); padding: var(--space-3) var(--space-4); border-bottom: 1px solid var(--color-border-soft, var(--color-border)); }
.panel:focus { outline: none; }
.heading { flex: 1; min-width: 0; align-self: center; }
.title { display: block; font-weight: 600; min-width: 0; overflow-wrap: anywhere; }
.close { margin-left: auto; display: inline-flex; align-items: center; justify-content: center; background: none; border: 0; color: var(--color-muted); cursor: pointer; font-size: 20px; line-height: 1; width: var(--modal-close-size, 28px); height: var(--modal-close-size, 28px); border-radius: var(--radius); flex-shrink: 0; }
.close:focus-visible { outline: 2px solid var(--color-accent); outline-offset: 1px; }
.close:hover { color: var(--color-fg); background: var(--color-surface-hi, var(--color-bg)); }
.body { padding: var(--space-4); overflow: auto; }
.foot { display: flex; align-items: center; justify-content: flex-end; gap: var(--space-2); padding: var(--space-3) var(--space-4); border-top: 1px solid var(--color-border-soft, var(--color-border)); }
</style>
