<script setup lang="ts">
/**
 * Chart · area design
 * A single trend with volume under it — the flat low-alpha wash of its own colour,
 * never a gradient. `stacked` turns it into part-to-whole over time; nulls count as
 * zero while stacking, so the bands always add up to the total.
 *
 * @prop ctx    - plot context handed down by Chart.vue
 * @prop active - hovered/focused point index, or null
 *
 * Status: new | Consumers: Chart
 */
import { computed } from 'vue'
import { areaPath, fixed, linePath, markPath } from '../geometry'
import type { ChartPlotCtx } from '../types'

const props = defineProps<{ ctx: ChartPlotCtx, active: number | null }>()

defineEmits<{ active: [index: number | null], point: [index: number, seriesIndex: number] }>()

const MARK = 8

interface Point { x: number, y: number }

function bandPath(top: Point[], bottom: Point[]): string {
  if (!top.length) return ''
  let path = `M${fixed(top[0]!.x)} ${fixed(top[0]!.y)}`
  for (const point of top.slice(1)) path += `L${fixed(point.x)} ${fixed(point.y)}`
  for (const point of [...bottom].reverse()) path += `L${fixed(point.x)} ${fixed(point.y)}`
  return `${path}Z`
}

const drawn = computed(() => {
  const { scale, series, stacked } = props.ctx
  const running = Array.from({ length: scale.count }, () => 0)
  return series.map((entry) => {
    const activeValue = props.active === null ? null : entry.values[props.active] ?? null
    if (!stacked) {
      const points = entry.values.map((value, index) => (value === null ? null : { x: scale.x(index), y: scale.y(value) }))
      const present = points.filter((point): point is Point => point !== null)
      return {
        name: entry.name,
        color: entry.color,
        dash: entry.dash,
        shape: entry.shape,
        area: areaPath(points, scale.zeroY),
        line: linePath(points),
        lone: present.length === 1 ? present[0]! : null,
        activePoint: activeValue === null ? null : { x: scale.x(props.active!), y: scale.y(activeValue) },
      }
    }
    const top: Point[] = []
    const bottom: Point[] = []
    for (let index = 0; index < scale.count; index += 1) {
      const x = scale.x(index)
      bottom.push({ x, y: scale.y(running[index]!) })
      running[index] = running[index]! + Math.max(entry.values[index] ?? 0, 0)
      top.push({ x, y: scale.y(running[index]!) })
    }
    return {
      name: entry.name,
      color: entry.color,
      dash: entry.dash,
      shape: entry.shape,
      area: bandPath(top, bottom),
      line: linePath(top),
      lone: top.length === 1 ? top[0]! : null,
      activePoint: props.active === null ? null : top[props.active] ?? null,
    }
  })
})

function wash(color: string): string {
  return `color-mix(in oklab, ${color} calc(var(--hive-chart-wash, 0.14) * 100%), transparent)`
}
</script>

<template>
  <g :class="$style.marks">
    <g v-for="entry in drawn" :key="entry.name">
      <path v-if="entry.area" :d="entry.area" :fill="wash(entry.color)" :class="$style.fill" />
      <path
        v-if="entry.line"
        :class="$style.line"
        :d="entry.line"
        :stroke="entry.color"
        :stroke-dasharray="ctx.stacked ? undefined : (entry.dash || undefined)"
      />
      <line
        v-if="entry.lone && !ctx.stacked"
        :class="$style.line"
        :x1="entry.lone.x - 12"
        :x2="entry.lone.x + 12"
        :y1="entry.lone.y"
        :y2="entry.lone.y"
        :stroke="entry.color"
      />
      <path
        v-if="entry.activePoint"
        :class="$style.mark"
        :d="markPath(entry.shape, entry.activePoint.x, entry.activePoint.y, MARK + 3)"
        :fill="entry.color"
      />
    </g>
  </g>
</template>

<style module>
.fill { stroke: none; }
.line {
  fill: none;
  stroke-width: 2;
  stroke-linecap: round;
  stroke-linejoin: round;
}
.mark {
  stroke: var(--color-surface);
  stroke-width: 2.5;
  paint-order: stroke;
}

/* The one motion: the band wipes in from the left on mount. */
.marks { animation: rise 420ms ease-out both; }
@keyframes rise {
  from { clip-path: inset(0 100% 0 0); }
  to { clip-path: inset(0 -4% 0 0); }
}
@media (prefers-reduced-motion: reduce) {
  .marks { animation: none; }
}
</style>
