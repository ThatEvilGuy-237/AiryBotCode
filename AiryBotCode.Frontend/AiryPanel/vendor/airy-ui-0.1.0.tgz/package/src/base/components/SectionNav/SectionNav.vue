<script setup lang="ts">
/**
 * SectionNav
 * A strip of links between the sibling pages of one section (Settings: Account,
 * Users, Audit), under the page's top bar. It is navigation, not tabs: each item
 * is a real link to its own page and the current one carries
 * `aria-current="page"`; use `<Tabs>` only for panels that live on one page.
 * Give it only when there are two or more pages to move between, and hide it
 * where `<AppSidebar>` already lists the same pages, so each width has one way
 * to get there.
 *
 * The strip scrolls sideways when the labels do not fit, instead of wrapping.
 *
 * @prop label - accessible name of the <nav> landmark
 *
 * Slot: default - the `<SectionNavItem>`s
 *
 * Status: new | Consumers: evil-dash settings pages
 */
import { nextTick, onMounted, ref, watch } from 'vue'
import { useRoute } from 'vue-router'

withDefaults(defineProps<{ label?: string }>(), { label: 'Section' })
defineSlots<{ default?: () => unknown }>()

const nav = ref<HTMLElement | null>(null)
const route = useRoute()

function reveal() {
  const n = nav.value
  const el = n?.querySelector<HTMLElement>('[aria-current="page"]')
  if (!n || !el || n.scrollWidth <= n.clientWidth) return
  const left = el.offsetLeft - (n.clientWidth - el.offsetWidth) / 2
  n.scrollLeft = Math.max(0, Math.min(left, n.scrollWidth - n.clientWidth))
}

onMounted(() => nextTick(reveal))
watch(() => route.path, () => nextTick(reveal))
</script>

<template>
  <nav ref="nav" :class="$style.nav" :aria-label="label" data-ui="section-nav">
    <ul :class="$style.list"><slot /></ul>
  </nav>
</template>

<style module>
.nav {
  position: relative;
  border-bottom: 1px solid var(--color-border-soft, var(--color-border));
  overflow-x: auto;
  scrollbar-width: none;
}
.nav::-webkit-scrollbar { display: none; }
.list {
  display: flex;
  gap: var(--space-1);
  margin: 0;
  padding: 0 var(--space-2);
  list-style: none;
}
</style>
