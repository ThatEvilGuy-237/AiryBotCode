<script setup lang="ts">
/**
 * Badge
 * Tone chip. A hairline pill with a coloured status dot — the tone colours the
 * dot, never the whole chip. Content comes from the default slot.
 *
 * @prop tone    - neutral | accent | ok | warn | danger | muted (default 'neutral')
 * @prop outline - drop the surface fill, keep the hairline (transparent chip)
 * @prop variant - DEPRECATED. Legacy 4-state API kept as an alias so existing
 *                 consumers (PageHeader, Wraith/Spine/Chronos/Pocket) keep
 *                 working: active→accent, inactive→neutral, warning→warn,
 *                 danger→danger. Prefer `tone`. If both are set, `tone` wins.
 *
 * Status: stable | Consumers: PageHeader, ToolsPage, ToolboxesPage, portal
 */
import { computed } from 'vue'

type Tone = 'neutral' | 'accent' | 'ok' | 'warn' | 'danger' | 'muted'
type LegacyVariant = 'active' | 'inactive' | 'warning' | 'danger'

const props = defineProps<{
  tone?: Tone
  outline?: boolean
  variant?: LegacyVariant
}>()

const VARIANT_TONE: Record<LegacyVariant, Tone> = {
  active: 'accent',
  inactive: 'neutral',
  warning: 'warn',
  danger: 'danger',
}

const tone = computed<Tone>(() =>
  props.tone ?? (props.variant ? VARIANT_TONE[props.variant] : 'neutral'),
)
</script>

<template>
  <span data-ui="badge" :class="[$style.badge, $style[tone], outline && $style.outline]">
    <span :class="$style.dot" aria-hidden="true" />
    <slot />
  </span>
</template>

<style module>
.badge {
  display: inline-flex;
  align-items: center;
  gap: var(--space-2);
  max-width: 100%;
  padding: 1px var(--space-2);
  border: 1px solid var(--color-border);
  border-radius: 999px;
  background: var(--color-surface-mute, var(--color-surface));
  color: var(--color-text-dim, var(--color-fg));
  font-family: var(--badge-font, var(--font-mono));
  font-size: var(--badge-size, var(--font-size-xs));
  line-height: 1.6;
  letter-spacing: var(--badge-tracking, 0.04em);
  text-transform: var(--badge-case, uppercase);
  white-space: nowrap;
}

.dot {
  flex: none;
  width: 6px;
  height: 6px;
  border-radius: 50%;
  background: var(--color-muted);
}

/* The tone colours the dot; neutral keeps the default muted dot. */
.accent .dot { background: var(--color-accent); }
.ok .dot     { background: var(--color-ok); }
.warn .dot   { background: var(--color-warn); }
.danger .dot { background: var(--color-danger); }
.muted .dot  { background: var(--color-text-ghost, var(--color-muted)); }

.accent { color: var(--color-fg); border-color: var(--color-accent-edge, var(--color-border)); }
.danger { color: var(--color-fg); }
.muted  { color: var(--color-muted); }

.outline { background: transparent; }
</style>
