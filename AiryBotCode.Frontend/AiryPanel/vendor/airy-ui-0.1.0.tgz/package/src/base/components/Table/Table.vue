<script setup lang="ts">
import Icon from '../Icon/Icon.vue'
/**
 * Table
 * The Hive data table. Columns are declared as <TableColumn> children — there is
 * no `columns` array prop — and `data` stays plain row objects. Default layout is
 * fixed at 100% width with the columns auto-sharing the space, so most tables set
 * no widths at all. Cells are single-line and clip with an ellipsis.
 *
 * Cell data and headers are mono (headers as uppercase eyebrows), prose columns
 * are sans. Rows are separated by hairlines, never zebra fills, and the accent is
 * spent on exactly two things: the active sort column and the selected row's left bar.
 *
 * @prop data            - row objects to render (required)
 * @prop rowKey          - field that uniquely identifies a row (required). Sorting,
 *                         paging, selection and keyboard focus all hang off it
 * @prop label           - accessible name for the table
 * @prop density         - 'comfortable' (default) | 'compact' row padding
 * @prop loading         - swaps the body for a skeleton that holds the exact row height
 * @prop skeletonRows    - how many skeleton rows to draw (default: the page size, else 6)
 * @prop empty           - headline shown when there are no rows
 * @prop emptyHint       - mono `// …` line under that headline
 * @prop clickable       - rows get a pointer, a roving tabindex and Enter/Space
 * @prop selectable      - rows are selectable; v-model holds the selected rowKey value
 * @prop modelValue      - selected rowKey value (v-model), or null
 * @prop sort            - controlled sort (v-model:sort); omit to let Table own it
 * @prop defaultSort     - initial sort when uncontrolled
 * @prop scrollRows      - cap the body to this many rows; the rest scrolls under a pinned header
 * @prop scrollX         - content-size the columns and scroll sideways instead of fitting 100%
 * @prop colMin          - min width every column keeps in `scrollX` mode (default '7rem')
 * @prop paginated       - page the body and show the pager footer
 * @prop pageSize        - rows per page; defaults to the first pageSizeOptions entry
 * @prop pageSizeOptions - choices in the rows-per-page select
 * @prop page            - controlled page (v-model:page)
 * @prop total           - server-side row count. With `paginated`, Table stops slicing
 *                         and sorting locally and renders `data` as the current page
 *
 * @event row-click    - (row) any row click
 * @event sort-change  - (sort | null) sort cycled asc → desc → off
 * @event page-change  - ({ page, pageSize }) any pager interaction — the hook to fetch a page
 *
 * Slots:
 *   default - the <TableColumn> children
 *   empty   - replaces the whole empty state
 *   footer  - extra content in the footer, left of the pager
 *
 * Status: new | Consumers: catalog, portal-kit, memory portal
 */
import { computed, provide, ref, watch, watchEffect } from 'vue'
import Skeleton from '../Skeleton/Skeleton.vue'
import TableCell from './TableCell.vue'
import TableSlotCell from './TableSlotCell.vue'
import { HIVE_TABLE_REGISTRY } from './keys'
import type { TableAlign, TableColumnDef, TableRow, TableSort } from './types'

const props = withDefaults(defineProps<{
  data: TableRow[]
  rowKey: string
  label?: string
  density?: 'comfortable' | 'compact'
  loading?: boolean
  skeletonRows?: number
  empty?: string
  emptyHint?: string
  clickable?: boolean
  selectable?: boolean
  modelValue?: string | number | null
  sort?: TableSort | null
  defaultSort?: TableSort
  scrollRows?: number
  scrollX?: boolean
  colMin?: string
  paginated?: boolean
  pageSize?: number
  pageSizeOptions?: number[]
  page?: number
  total?: number
}>(), {
  rowKey: 'id',
  density: 'comfortable',
  loading: false,
  empty: 'No rows',
  emptyHint: 'nothing to show for this view',
  clickable: false,
  selectable: false,
  scrollX: false,
  colMin: '7rem',
  paginated: false,
  pageSizeOptions: () => [10, 25, 50, 100],
})

const emit = defineEmits<{
  'row-click': [row: TableRow]
  'sort-change': [sort: TableSort | null]
  'page-change': [change: { page: number, pageSize: number }]
  'update:modelValue': [key: string | number | null]
  'update:sort': [sort: TableSort | null]
  'update:page': [page: number]
  'update:pageSize': [size: number]
}>()

const SKELETON_WIDTHS = ['64%', '44%', '78%', '36%', '58%', '70%']

const order = ref<string[]>([])
const defs = ref<Record<string, TableColumnDef>>({})

provide(HIVE_TABLE_REGISTRY, {
  register(def: TableColumnDef) {
    if (!order.value.includes(def.field)) order.value = [...order.value, def.field]
    defs.value = { ...defs.value, [def.field]: def }
  },
  unregister(field: string) {
    const next = { ...defs.value }
    delete next[field]
    defs.value = next
  },
})

const columns = computed(() => order.value.map(field => defs.value[field]).filter(Boolean))

const interactive = computed(() => props.clickable || props.selectable)
const serverMode = computed(() => props.paginated && props.total !== undefined)

const internalSort = ref<TableSort | null>(props.defaultSort ?? null)
const activeSort = computed(() => (props.sort !== undefined ? props.sort : internalSort.value))

function alignOf(column: TableColumnDef): TableAlign {
  return column.align ?? (column.type === 'num' ? 'right' : 'left')
}

function headerOf(column: TableColumnDef): string {
  if (column.header != null) return column.header
  return column.action ? '' : column.field
}

function ariaSortOf(column: TableColumnDef): 'ascending' | 'descending' | 'none' | undefined {
  if (!column.sortable) return undefined
  if (activeSort.value?.field !== column.field) return 'none'
  return activeSort.value.direction === 'asc' ? 'ascending' : 'descending'
}

function toggleSort(column: TableColumnDef) {
  const current = activeSort.value
  let next: TableSort | null
  if (!current || current.field !== column.field) next = { field: column.field, direction: 'asc' }
  else if (current.direction === 'asc') next = { field: column.field, direction: 'desc' }
  else next = null
  if (props.sort === undefined) internalSort.value = next
  emit('update:sort', next)
  emit('sort-change', next)
  setPage(1, false)
}

function compareValues(a: unknown, b: unknown): number {
  if (a == null && b == null) return 0
  if (a == null) return 1
  if (b == null) return -1
  if (typeof a === 'number' && typeof b === 'number') return a - b
  if (typeof a === 'boolean' || typeof b === 'boolean') return Number(a) - Number(b)
  if (a instanceof Date || b instanceof Date) return new Date(a as Date).getTime() - new Date(b as Date).getTime()
  return String(a).localeCompare(String(b), undefined, { numeric: true, sensitivity: 'base' })
}

const sortedRows = computed(() => {
  const sort = activeSort.value
  if (!sort || serverMode.value) return props.data
  const column = columns.value.find(entry => entry.field === sort.field)
  const direction = sort.direction === 'asc' ? 1 : -1
  const rows = [...props.data]
  if (column?.compare) return rows.sort((a, b) => column.compare!(a, b) * direction)
  const keyOf = (row: TableRow) => (column?.sortValue ? column.sortValue(row) : row[sort.field])
  return rows.sort((a, b) => compareValues(keyOf(a), keyOf(b)) * direction)
})

const internalPage = ref(1)
const internalSize = ref(props.pageSize ?? props.pageSizeOptions[0] ?? 10)

watch(() => props.pageSize, size => { if (size) internalSize.value = size })

const totalRows = computed(() => (serverMode.value ? (props.total ?? 0) : sortedRows.value.length))
const pageCount = computed(() => Math.max(1, Math.ceil(totalRows.value / internalSize.value)))
const currentPage = computed(() => {
  const raw = props.page ?? internalPage.value
  return Math.min(Math.max(1, raw), pageCount.value)
})

const visibleRows = computed(() => {
  if (!props.paginated || serverMode.value) return sortedRows.value
  const start = (currentPage.value - 1) * internalSize.value
  return sortedRows.value.slice(start, start + internalSize.value)
})

const rangeFrom = computed(() => (totalRows.value === 0 ? 0 : (currentPage.value - 1) * internalSize.value + 1))
const rangeTo = computed(() => Math.min(currentPage.value * internalSize.value, totalRows.value))

function setPage(next: number, notify = true) {
  const clamped = Math.min(Math.max(1, next), pageCount.value)
  if (props.page === undefined) internalPage.value = clamped
  if (!notify) return
  emit('update:page', clamped)
  emit('page-change', { page: clamped, pageSize: internalSize.value })
}

function setSize(next: number) {
  internalSize.value = next
  emit('update:pageSize', next)
  if (props.page === undefined) internalPage.value = 1
  emit('update:page', 1)
  emit('page-change', { page: 1, pageSize: next })
}

const skeletonCount = computed(() => props.skeletonRows ?? (props.paginated ? Math.min(internalSize.value, 10) : 6))

function keyOf(row: TableRow): string {
  return String(row[props.rowKey])
}

const focusedKey = ref<string | null>(null)

function tabIndexOf(row: TableRow, index: number): number | undefined {
  if (!interactive.value) return undefined
  const target = focusedKey.value ?? (props.modelValue != null ? String(props.modelValue) : null)
  if (target !== null) return keyOf(row) === target ? 0 : -1
  return index === 0 ? 0 : -1
}

function isSelected(row: TableRow): boolean {
  return props.selectable && props.modelValue != null && keyOf(row) === String(props.modelValue)
}

function activate(row: TableRow) {
  if (props.selectable) {
    const key = row[props.rowKey] as string | number
    emit('update:modelValue', String(props.modelValue) === String(key) ? null : key)
  }
  emit('row-click', row)
}

function onRowKeydown(event: KeyboardEvent, row: TableRow) {
  const element = event.currentTarget as HTMLElement
  const parent = element.parentElement
  if (!parent) return
  let target: Element | null = null
  if (event.key === 'ArrowDown') target = element.nextElementSibling
  else if (event.key === 'ArrowUp') target = element.previousElementSibling
  else if (event.key === 'Home') target = parent.firstElementChild
  else if (event.key === 'End') target = parent.lastElementChild
  else if (event.key === 'Enter' || event.key === ' ') {
    event.preventDefault()
    activate(row)
    return
  }
  if (!target) return
  event.preventDefault()
  ;(target as HTMLElement).focus()
}

const dev = Boolean((import.meta as ImportMeta & { env?: { DEV?: boolean } }).env?.DEV)

watchEffect(() => {
  if (!dev) return
  const seen = new Set<string>()
  for (const row of props.data) {
    const key = keyOf(row)
    if (key === 'undefined') {
      console.warn(`[hive/Table] a row has no "${props.rowKey}" value — row-key must be a field present on every row.`)
      return
    }
    if (seen.has(key)) {
      console.warn(`[hive/Table] duplicate row-key "${key}" — sorting, paging and selection need unique keys.`)
      return
    }
    seen.add(key)
  }
})

watchEffect(() => {
  if (!dev) return
  const all = columns.value
  if (all.some((column, index) => column.action && index !== all.length - 1)) {
    console.warn('[hive/Table] an action column is pinned right and must be declared last.')
  }
})

const viewportStyle = computed(() => ({
  maxHeight: props.scrollRows ? `calc(${props.scrollRows} * var(--hive-table-row-h) + var(--hive-table-row-h))` : undefined,
}))
</script>

<template>
  <div data-ui="table"
    :class="[$style.wrap, $style[density], scrollX && $style.wrapX]"
    :style="{ '--hive-table-col-min': colMin }"
    :aria-busy="loading || undefined"
  >
    <div :class="$style.registry"><slot /></div>

    <div :class="[$style.viewport, (scrollRows || scrollX) && $style.pinned]" :style="viewportStyle">
      <table :class="$style.table" :aria-label="label">
        <colgroup>
          <col v-for="column in columns" :key="column.field" :style="{ width: column.action ? (column.width ?? '7rem') : column.width }" />
        </colgroup>

        <thead :class="$style.thead">
          <tr>
            <th
              v-for="column in columns"
              :key="column.field"
              scope="col"
              :class="[$style.th, column.action && $style.sticky, alignOf(column) === 'right' && $style.thRight, activeSort?.field === column.field && $style.thActive]"
              :style="{ textAlign: alignOf(column), minWidth: column.minWidth }"
              :aria-sort="ariaSortOf(column)"
            >
              <button
                v-if="column.sortable"
                type="button"
                :class="[$style.sortBtn, activeSort?.field === column.field && $style.sortActive]"
                @click="toggleSort(column)"
              >
                <span :class="$style.label">{{ headerOf(column) }}</span>
                <span
                  :class="[$style.caret, activeSort?.field === column.field && activeSort.direction === 'asc' && $style.caretUp]"
                  aria-hidden="true"
                ><Icon name="chevron-down" :size="12" /></span>
              </button>
              <span v-else :class="$style.label">{{ headerOf(column) }}</span>
            </th>
          </tr>
        </thead>

        <tbody v-if="loading" :class="$style.tbody" aria-hidden="true">
          <tr v-for="n in skeletonCount" :key="`skeleton-${n}`" :class="$style.tr">
            <td v-for="(column, index) in columns" :key="column.field" :class="[$style.td, column.action && $style.sticky]">
              <span :class="$style.skeletonCell">
                <Skeleton
                  variant="block"
                  height="9px"
                  radius="3px"
                  :width="SKELETON_WIDTHS[(index + n) % SKELETON_WIDTHS.length]"
                />
              </span>
            </td>
          </tr>
        </tbody>

        <tbody v-else-if="!visibleRows.length" :class="$style.tbody">
          <tr>
            <td :colspan="Math.max(columns.length, 1)" :class="[$style.td, $style.emptyCell]">
              <slot name="empty">
                <div :class="$style.empty">
                  <div :class="$style.emptyTitle">{{ empty }}</div>
                  <div :class="$style.emptyHint">// {{ emptyHint }}</div>
                </div>
              </slot>
            </td>
          </tr>
        </tbody>

        <tbody v-else :class="$style.tbody">
          <tr
            v-for="(row, index) in visibleRows"
            :key="keyOf(row)"
            :class="[$style.tr, interactive && $style.trInteractive, isSelected(row) && $style.trSelected]"
            :tabindex="tabIndexOf(row, index)"
            :aria-selected="selectable ? isSelected(row) : undefined"
            @click="activate(row)"
            @focusin="focusedKey = keyOf(row)"
            @keydown="interactive && onRowKeydown($event, row)"
          >
            <td
              v-for="column in columns"
              :key="column.field"
              :class="[$style.td, column.action && [$style.sticky, $style.actionCell], column.cell && $style.slotCell]"
              :style="{ textAlign: alignOf(column), minWidth: column.minWidth }"
              @click="column.cell && $event.stopPropagation()"
            >
              <TableSlotCell
                v-if="column.cell"
                :render="column.cell"
                :row="row"
                :value="row[column.field]"
                :index="index"
              />
              <TableCell v-else :column="column" :row="row" />
            </td>
          </tr>
        </tbody>
      </table>
    </div>

    <div v-if="loading" :class="$style.srOnly" role="status">Loading rows</div>

    <div v-if="paginated || $slots.footer" :class="$style.footer">
      <div :class="$style.footerNote">
        <slot name="footer">
          <span v-if="paginated">// {{ rangeFrom }}–{{ rangeTo }} of {{ totalRows }}</span>
        </slot>
      </div>

      <div v-if="paginated" :class="$style.pager">
        <label :class="$style.sizeLabel">
          rows
          <select
            :class="$style.size"
            :value="internalSize"
            @change="setSize(Number(($event.target as HTMLSelectElement).value))"
          >
            <option v-for="option in pageSizeOptions" :key="option" :value="option">{{ option }}</option>
          </select>
        </label>

        <span :class="$style.pageOf">{{ currentPage }} / {{ pageCount }}</span>

        <button
          type="button"
          :class="$style.pageBtn"
          :disabled="currentPage <= 1"
          aria-label="Previous page"
          @click="setPage(currentPage - 1)"
        >‹</button>
        <button
          type="button"
          :class="$style.pageBtn"
          :disabled="currentPage >= pageCount"
          aria-label="Next page"
          @click="setPage(currentPage + 1)"
        >›</button>
      </div>
    </div>
  </div>
</template>

<style module>
.wrap {
  --hive-table-pad-y: var(--space-3);
  --hive-table-pad-x: var(--space-4);
  --hive-table-line: 1.55;
  --hive-table-row-h: calc(var(--font-size-sm) * var(--hive-table-line) + 2 * var(--hive-table-pad-y) + 1px);
  width: 100%;
  min-width: 0;
  border: 1px solid var(--color-border);
  border-radius: var(--r-3, var(--radius));
  background: var(--color-surface);
  overflow: hidden;
}
.compact {
  --hive-table-pad-y: var(--space-2);
  --hive-table-pad-x: var(--space-3);
}
.registry { display: none; }

.viewport { overflow: visible; }
.pinned { overflow: auto; }
.wrapX .viewport { overflow: auto; }

.table {
  width: 100%;
  table-layout: fixed;
  border-collapse: collapse;
  font-size: var(--font-size-sm);
  line-height: var(--hive-table-line);
}
.wrapX .table {
  table-layout: auto;
  width: max-content;
  min-width: 100%;
}
.wrapX .th,
.wrapX .td {
  min-width: var(--hive-table-col-min);
}
.wrapX .sticky { min-width: 0; }

/* Header — mono eyebrows on the second surface step. */
.thead { background: var(--color-bg-2, var(--color-bg)); }
.pinned .th { position: sticky; top: 0; z-index: 2; background: var(--color-bg-2, var(--color-bg)); }
.pinned .th.sticky { z-index: 3; }

.th {
  padding: var(--hive-table-pad-y) var(--hive-table-pad-x);
  box-sizing: border-box;
  text-align: left;
  font-family: var(--font-mono);
  font-size: var(--font-size-xs);
  font-weight: 400;
  letter-spacing: 0.08em;
  text-transform: uppercase;
  color: var(--color-text-ghost, var(--color-muted));
  border-bottom: 1px solid var(--color-border);
  overflow: hidden;
}
.thActive { color: var(--color-accent); }

.label {
  display: block;
  overflow: hidden;
  text-overflow: ellipsis;
  white-space: nowrap;
  min-width: 0;
}

.sortBtn {
  display: inline-flex;
  align-items: center;
  gap: var(--space-1);
  max-width: 100%;
  margin: 0;
  padding: 0;
  border: 0;
  background: none;
  font: inherit;
  letter-spacing: inherit;
  text-transform: inherit;
  color: inherit;
  cursor: pointer;
}
.thRight .sortBtn { flex-direction: row-reverse; }
.sortBtn:hover { color: var(--color-fg); }
.sortBtn:focus-visible {
  outline: 2px solid var(--color-accent);
  outline-offset: 2px;
  border-radius: var(--r-1, 4px);
}

/* The one motion: the caret flips between asc and desc. */
.caret {
  flex: none;
  opacity: 0.35;
  transition: transform 120ms ease, opacity 120ms ease;
}
.sortActive .caret { opacity: 1; }
.caretUp { transform: rotate(180deg); }
@media (prefers-reduced-motion: reduce) {
  .caret { transition: none; }
}

.td {
  padding: var(--hive-table-pad-y) var(--hive-table-pad-x);
  box-sizing: border-box;
  border-bottom: 1px solid var(--color-border-soft, var(--color-border));
  color: var(--color-fg);
  overflow: hidden;
  white-space: nowrap;
  vertical-align: middle;
}
.tbody .tr:last-child .td { border-bottom: 0; }
.slotCell,
.actionCell {
  overflow: visible;
  white-space: nowrap;
  padding-top: var(--space-1);
  padding-bottom: var(--space-1);
}

.tr { background: var(--color-surface); }
.tr:hover .td { background: var(--color-surface-hi, var(--color-surface)); }
.trInteractive { cursor: pointer; }
.trInteractive:focus-visible {
  outline: 2px solid var(--color-accent);
  outline-offset: -2px;
}

/* Selection = accent left bar, never a fill. */
.trSelected .td:first-child { box-shadow: inset 2px 0 0 var(--color-accent); }
.trSelected .td { background: var(--color-surface-hi, var(--color-surface)); }

/* Sticky action column. */
.sticky {
  position: sticky;
  right: 0;
  background: var(--color-surface);
  box-shadow: -1px 0 0 var(--color-border);
}
.thead .sticky { background: var(--color-bg-2, var(--color-bg)); }
.tr:hover .sticky,
.trSelected .sticky { background: var(--color-surface-hi, var(--color-surface)); }

/* Skeleton — same box height as a real cell, so nothing jumps on load. */
.skeletonCell {
  display: flex;
  align-items: center;
  height: calc(1em * var(--hive-table-line));
}

.emptyCell { border-bottom: 0; white-space: normal; }
.empty {
  display: flex;
  flex-direction: column;
  align-items: center;
  gap: var(--space-1);
  padding: var(--space-6) var(--space-4);
  text-align: center;
}
.emptyTitle {
  font-family: var(--font-family);
  font-size: var(--font-size-base);
  color: var(--color-text-dim, var(--color-fg));
}
.emptyHint {
  font-family: var(--font-mono);
  font-size: var(--font-size-xs);
  color: var(--color-text-ghost, var(--color-muted));
}

.footer {
  display: flex;
  align-items: center;
  justify-content: space-between;
  gap: var(--space-3);
  padding: var(--space-2) var(--hive-table-pad-x);
  border-top: 1px solid var(--color-border);
  background: var(--color-bg-2, var(--color-bg));
}
.footerNote {
  font-family: var(--font-mono);
  font-size: var(--font-size-xs);
  color: var(--color-muted);
  min-width: 0;
}
.pager {
  display: inline-flex;
  align-items: center;
  gap: var(--space-2);
}
.sizeLabel {
  display: inline-flex;
  align-items: center;
  gap: var(--space-1);
  font-family: var(--font-mono);
  font-size: var(--font-size-xs);
  color: var(--color-text-ghost, var(--color-muted));
}
.size {
  appearance: none;
  padding: 2px var(--space-2);
  border: 1px solid var(--color-border);
  border-radius: var(--r-1, 4px);
  background: var(--color-surface-mute, var(--color-surface));
  color: var(--color-fg);
  font-family: var(--font-mono);
  font-size: var(--font-size-xs);
  cursor: pointer;
}
.size:focus-visible,
.pageBtn:focus-visible {
  outline: 2px solid var(--color-accent);
  outline-offset: 2px;
}
.pageOf {
  font-family: var(--font-mono);
  font-size: var(--font-size-xs);
  color: var(--color-muted);
  font-variant-numeric: tabular-nums;
}
.pageBtn {
  display: inline-flex;
  align-items: center;
  justify-content: center;
  width: 24px;
  height: 24px;
  padding: 0;
  border: 1px solid var(--color-border);
  border-radius: var(--r-1, 4px);
  background: var(--color-surface-mute, var(--color-surface));
  color: var(--color-text-dim, var(--color-fg));
  font-family: var(--font-mono);
  font-size: var(--font-size-sm);
  line-height: 1;
  cursor: pointer;
}
.pageBtn:hover:not(:disabled) {
  border-color: var(--color-border-hi, var(--color-border));
  color: var(--color-fg);
}
.pageBtn:disabled { opacity: 0.35; cursor: default; }

.srOnly {
  position: absolute;
  width: 1px;
  height: 1px;
  overflow: hidden;
  clip-path: inset(50%);
  white-space: nowrap;
}
</style>
