/**
 * Shared types for <Table> / <TableColumn>.
 *
 * Status: new | Consumers: Table, TableColumn, TableCell, portal-kit
 */
import type { VNodeChild } from 'vue'

export type TableRow = Record<string, unknown>

export type TableAlign = 'left' | 'center' | 'right'

export type TableCellType = 'text' | 'prose' | 'num' | 'date' | 'tag' | 'role'

export type TableTone = 'neutral' | 'accent' | 'ok' | 'warn' | 'danger' | 'plan'

export type TableToneInput =
  | TableTone
  | 'success'
  | 'brand'
  | 'warning'
  | 'error'
  | 'fail'
  | 'failed'
  | 'info'
  | 'active'
  | 'inactive'

export type TableSortDir = 'asc' | 'desc'

export interface TableSort {
  field: string
  direction: TableSortDir
}

export interface TablePageChange {
  page: number
  pageSize: number
}

export interface TableCellContext {
  row: TableRow
  value: unknown
  index: number
}

export interface TableColumnDef {
  field: string
  header?: string
  type?: TableCellType
  align?: TableAlign
  width?: string
  minWidth?: string
  sortable?: boolean
  action?: boolean
  tones?: Record<string, TableToneInput>
  format?: (value: unknown, row: TableRow) => string
  sortValue?: (row: TableRow) => unknown
  compare?: (a: TableRow, b: TableRow) => number
  cell?: (context: TableCellContext) => VNodeChild
}

export interface TableRegistry {
  register: (def: TableColumnDef) => void
  unregister: (field: string) => void
}
