<script setup lang="ts">
/**
 * Button
 * Action trigger.
 *
 * @prop variant  - solid (primary) | outline (secondary) | ghost (low-emphasis) | danger (destructive)
 * @prop size     - sm | md | lg
 * @prop disabled - disables interaction
 * @prop loading  - shows an inline spinner + disables (in-flight action)
 * @prop type     - native button type
 * @prop href     - renders a link with the same look (full page navigation)
 * @emits click   - MouseEvent, fires on press (not when disabled/loading)
 *
 * Status: stable | Consumers: ToolsPage, ToolboxesPage, portal (via PortalButton)
 */
withDefaults(defineProps<{
  variant?: 'solid' | 'outline' | 'ghost' | 'danger'
  size?: 'sm' | 'md' | 'lg'
  disabled?: boolean
  loading?: boolean
  type?: 'button' | 'submit'
  href?: string
}>(), { variant: 'solid', size: 'md', disabled: false, loading: false, type: 'button' })

defineEmits<{ click: [MouseEvent] }>()
</script>

<template>
  <a
    v-if="href"
    data-ui="button"
    :href="href"
    :class="[$style.btn, $style[variant], $style[size]]"
    @click="$emit('click', $event)"
  >
    <slot />
  </a>
  <button
    v-else
    data-ui="button"
    :type="type"
    :disabled="disabled || loading"
    :class="[$style.btn, $style[variant], $style[size], { [$style.isLoading]: loading }]"
    @click="$emit('click', $event)"
  >
    <span v-if="loading" :class="$style.spinner" aria-hidden="true" />
    <slot />
  </button>
</template>

<style module>
.btn {
  display: inline-flex;
  align-items: center;
  justify-content: center;
  gap: var(--space-2);
  border-radius: var(--radius);
  cursor: pointer;
  font-family: var(--font-family);
  font-weight: 500;
  white-space: nowrap;
  letter-spacing: 0.01em;
  transition: opacity 0.1s, background 0.1s, color 0.1s, border-color 0.1s, box-shadow 0.1s, transform 0.06s;
  flex-shrink: 0;
  text-decoration: none;
}
.btn:active:not(:disabled) { transform: translateY(0.5px); }

.btn:focus-visible {
  outline: 2px solid var(--color-accent);
  outline-offset: 2px;
}

.btn:disabled {
  opacity: 0.35;
  cursor: not-allowed;
}
/* When loading we keep it readable (spinner + label), not ghosted out. */
.isLoading:disabled { opacity: 0.8; cursor: progress; }

/* Sizes — fixed height so buttons are always consistent */
.sm {
  height: var(--button-h-sm, 28px);
  padding: 0 var(--space-3);
  font-size: var(--font-size-sm);
}

.md {
  height: var(--button-h-md, 36px);
  padding: 0 var(--space-4);
  font-size: var(--font-size-base);
}

.lg {
  height: var(--button-h-lg, 44px);
  padding: 0 var(--space-5, 20px);
  font-size: var(--font-size-lg, 15px);
  border-radius: calc(var(--radius) + 2px);
}

/* Variants */
.solid {
  background: var(--color-accent-mute, var(--color-accent, var(--color-fg)));
  color: var(--color-on-accent, var(--color-fg));
  border: 1px solid var(--color-accent-edge, var(--color-accent, var(--color-fg)));
}
.solid:hover:not(:disabled) {
  background: var(--color-accent, var(--color-fg));
}
.solid:disabled {
  opacity: var(--button-solid-disabled-opacity, 0.35);
  background: var(--button-solid-disabled-bg, var(--color-accent-mute, var(--color-accent, var(--color-fg))));
  color: var(--button-solid-disabled-fg, var(--color-on-accent, var(--color-fg)));
  border-color: var(--button-solid-disabled-edge, var(--color-accent-edge, var(--color-accent, var(--color-fg))));
}

.outline {
  background: var(--color-surface);
  color: var(--color-fg);
  border: var(--border);
}
.outline:hover:not(:disabled) {
  background: var(--color-surface-hi, var(--color-surface));
  border-color: var(--color-border-hi, var(--color-border));
}

.ghost {
  background: transparent;
  color: var(--color-text-dim, var(--color-muted));
  border: 1px solid transparent;
}
.ghost:hover:not(:disabled) {
  color: var(--color-fg);
  background: var(--color-surface-mute, var(--color-surface));
}

/* Danger — destructive intent. Reads as an outline at rest so it never shouts,
   then fills on hover to confirm the weight of the action (matches ConfirmDialog). */
.danger {
  background: transparent;
  color: var(--color-danger);
  border: 1px solid var(--color-danger);
}
.danger:hover:not(:disabled) {
  background: var(--color-danger);
  color: var(--color-fg);
}
.danger:focus-visible { outline-color: var(--color-danger); }

/* Inline spinner (currentColor, so it matches the button text) */
.spinner {
  width: 1em; height: 1em;
  box-sizing: border-box;
  border: 2px solid currentColor;
  border-top-color: transparent;
  border-radius: 50%;
  opacity: 0.9;
  animation: btnspin 0.6s linear infinite;
}
@keyframes btnspin { to { transform: rotate(360deg); } }
@media (prefers-reduced-motion: reduce) { .spinner { animation-duration: 1.4s; } }
</style>
