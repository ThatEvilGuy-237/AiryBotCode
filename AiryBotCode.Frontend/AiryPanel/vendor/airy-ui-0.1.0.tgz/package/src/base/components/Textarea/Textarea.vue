<script setup lang="ts">
/**
 * Textarea
 * Multiline text input with optional label. Companion to TextField — same
 * surface, same focus treatment, just a textarea instead of an input.
 *
 * @prop modelValue  - controlled value (use v-model)
 * @prop label       - visible label above textarea
 * @prop placeholder - placeholder text
 * @prop rows        - initial row count (default 4). The textarea is also
 *                     vertically resizable by the user; horizontal resize is off.
 * @prop mono        - render the textarea body in the mono font (use for
 *                     prompts, code-like content, anything data-shaped).
 *
 * Status: new | Consumers: NodeConfigPanel in Neural-Spine UI
 */
withDefaults(defineProps<{
  modelValue: string
  label?: string
  placeholder?: string
  rows?: number
  mono?: boolean
}>(), { rows: 4, mono: false })

defineEmits<{ 'update:modelValue': [value: string] }>()
</script>

<template>
  <div data-ui="textarea" :class="$style.wrapper">
    <label v-if="label" :class="$style.label">{{ label }}</label>
    <textarea
      :class="[$style.input, mono && $style.mono]"
      :value="modelValue"
      :placeholder="placeholder"
      :rows="rows"
      @input="$emit('update:modelValue', ($event.target as HTMLTextAreaElement).value)"
    />
  </div>
</template>

<style module>
.wrapper { display: flex; flex-direction: column; gap: var(--space-1); }
.label { font-size: var(--font-size-sm); color: var(--color-muted); }
.input {
  border: var(--border);
  border-radius: var(--radius);
  padding: var(--space-2) var(--space-3);
  font-size: var(--font-size-base);
  background: var(--color-surface-mute, var(--color-bg));
  color: var(--color-fg);
  width: 100%;
  font-family: var(--font-family);
  line-height: 1.5;
  resize: vertical;
  min-height: calc(var(--font-size-base) * 1.5 * 3); /* ~3 lines */
}
.input.mono {
  font-family: var(--font-mono);
  font-size: var(--font-size-sm);
}
.input:focus {
  outline: 2px solid var(--color-accent, var(--color-fg));
  outline-offset: 1px;
  border-color: var(--color-accent, var(--color-border));
}
</style>
