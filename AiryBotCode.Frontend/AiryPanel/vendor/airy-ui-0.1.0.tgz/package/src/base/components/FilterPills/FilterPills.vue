<script setup lang="ts">
/**
 * FilterPills
 * Inline pill-shaped filter selector. Single-select. Use with v-model.
 *
 * @prop modelValue - currently selected value
 * @prop items      - { value, label, count? }[]
 *
 * @event update:modelValue - value: string (the picked filter)
 *
 * Status: stable | Consumers: Patterns
 */
export interface FilterItem { value: string; label: string; count?: number | string }

defineProps<{
  modelValue: string
  items: FilterItem[]
}>()

defineEmits<{ 'update:modelValue': [value: string] }>()
</script>

<template>
  <div data-ui="filter-pills" :class="$style.pills">
    <button
      v-for="item in items"
      :key="item.value"
      type="button"
      :class="[$style.pill, modelValue === item.value && $style.on]"
      @click="$emit('update:modelValue', item.value)"
    >
      {{ item.label }}
      <span v-if="item.count !== undefined" :class="$style.count">{{ item.count }}</span>
    </button>
  </div>
</template>

<style module>
.pills {
  display: flex;
  flex-wrap: wrap;
  gap: var(--space-2);
}
.pill {
  display: inline-flex;
  align-items: center;
  gap: var(--space-2);
  height: 30px;
  padding: 0 var(--space-3);
  border: var(--border);
  border-radius: 999px;
  background: var(--color-surface);
  color: var(--color-text-dim, var(--color-muted));
  font-family: var(--font-family);
  font-size: var(--font-size-sm);
  text-transform: capitalize;
  cursor: pointer;
  transition: color 0.12s, background 0.12s, border-color 0.12s;
}
.pill:hover {
  color: var(--color-fg);
  background: var(--color-surface-hi, var(--color-surface));
}
.on {
  color: var(--color-accent);
  border-color: var(--color-accent-edge, var(--color-accent));
  background: var(--color-surface);
  box-shadow: inset 0 0 0 1px var(--color-accent-soft, transparent);
}
.count {
  font-family: var(--font-mono);
  font-size: var(--font-size-xs);
  padding: 1px 6px;
  min-width: 18px;
  text-align: center;
  border: 1px solid var(--color-border-soft, var(--color-border));
  border-radius: 999px;
  color: var(--color-muted);
}
.on .count {
  color: var(--color-accent);
  border-color: var(--color-accent-edge, var(--color-accent));
}
</style>
