import {
  // actions
  Plus, Search, X, Check, Pencil, Trash2, Copy, RefreshCw, Settings, Filter, Download,
  Ellipsis, Menu, Send, Play, Pause, ExternalLink,
  // navigation
  ChevronRight, ChevronDown, ChevronLeft, ChevronUp, ArrowRight, ArrowUpRight,
  // site kit — long-form pages
  Star, Dices, Columns2,
  // hive domain
  Brain, Database, Wrench, Eye, Image, Zap, Network, Share2, KeyRound,
  FileText, Hash, Bot, Cpu, MessageSquare, Clock, History,
  // status
  CircleCheck, TriangleAlert, CircleX, Info, CircleAlert, LoaderCircle,
  // portal kit — dashboard chrome (navigation, auth, entities, files)
  Archive, ArrowLeft, ArrowUpToLine, Banknote, Building2, CalendarClock,
  CheckCheck, Clipboard, Coffee, Coins, Combine, DoorClosed, DoorOpen, Flag,
  FolderOpen, FolderTree, GitFork, Globe, Hand, Hotel, House, Inbox, LayoutGrid,
  LibraryBig, Link, LocateFixed, Lock, LogIn, LogOut, Map as MapIcon, Maximize,
  Minimize, Minimize2, Minus, Moon, MoonStar, PackageCheck, PackageSearch,
  PencilLine, Plug, RotateCcw, Save, Scale, Scissors, ScrollText, Settings2,
  Shield, ShieldCheck, Sparkles, Sun, SunMoon, Undo2, UserMinus, UserPlus, Users,
  WandSparkles,
} from 'lucide-vue-next'

// Curated icon vocabulary for the Hive. Deliberate, not exhaustive: lucide ships
// ~1500 icons; exposing them all by string lookup would break tree-shaking and
// give no autocomplete. Each entry here is an explicit import (so only what we
// use is bundled) and a stable public name. Need a new one? Add a line.
// Public name (kebab) -> lucide component.
export const ICONS = {
  // actions
  'plus': Plus, 'search': Search, 'close': X, 'check': Check, 'edit': Pencil,
  'trash': Trash2, 'copy': Copy, 'refresh': RefreshCw, 'settings': Settings,
  'filter': Filter, 'more': Ellipsis, 'menu': Menu, 'send': Send,
  'play': Play, 'pause': Pause, 'external': ExternalLink,
  // navigation
  'chevron-right': ChevronRight, 'chevron-down': ChevronDown,
  'chevron-left': ChevronLeft, 'chevron-up': ChevronUp, 'arrow-right': ArrowRight,
  'arrow-up-right': ArrowUpRight,
  // site kit — long-form pages
  'star': Star, 'dice': Dices, 'columns': Columns2,
  // hive domain
  'brain': Brain, 'database': Database, 'wrench': Wrench, 'eye': Eye,
  'image': Image, 'bolt': Zap, 'network': Network, 'share': Share2, 'key': KeyRound,
  'file': FileText, 'hash': Hash, 'bot': Bot, 'cpu': Cpu, 'chat': MessageSquare,
  'clock': Clock, 'history': History,
  // status
  'ok': CircleCheck, 'warn': TriangleAlert, 'error': CircleX,
  'info': Info, 'alert': CircleAlert, 'loader': LoaderCircle,
  // portal kit — the dashboard's icon names (lucide kebab)
  'archive': Archive, 'arrow-left': ArrowLeft, 'arrow-up-to-line': ArrowUpToLine,
  'banknote': Banknote, 'building-2': Building2, 'calendar-clock': CalendarClock,
  'check-check': CheckCheck, 'clipboard': Clipboard, 'coffee': Coffee,
  'coins': Coins, 'combine': Combine, 'door-closed': DoorClosed,
  'door-open': DoorOpen, 'external-link': ExternalLink, 'flag': Flag,
  'folder-open': FolderOpen, 'folder-tree': FolderTree, 'git-fork': GitFork,
  'globe': Globe, 'hand': Hand, 'home': House, 'hotel': Hotel, 'inbox': Inbox,
  'key-round': KeyRound, 'layout-grid': LayoutGrid, 'library-big': LibraryBig,
  'link': Link, 'loader-circle': LoaderCircle, 'locate-fixed': LocateFixed,
  'lock': Lock, 'log-in': LogIn, 'log-out': LogOut, 'map': MapIcon,
  'maximize': Maximize, 'minimize': Minimize, 'minimize-2': Minimize2,
  'minus': Minus, 'moon': Moon, 'moon-star': MoonStar,
  'package-check': PackageCheck, 'package-search': PackageSearch,
  'pencil': Pencil, 'pencil-line': PencilLine, 'plug': Plug,
  'download': Download, 'refresh-cw': RefreshCw, 'rotate-ccw': RotateCcw, 'save': Save, 'scale': Scale,
  'scissors': Scissors, 'scroll-text': ScrollText, 'settings-2': Settings2,
  'share-2': Share2, 'shield': Shield, 'shield-check': ShieldCheck,
  'sparkles': Sparkles, 'sun': Sun, 'sun-moon': SunMoon,
  'trash-2': Trash2, 'triangle-alert': TriangleAlert, 'undo-2': Undo2,
  'user-minus': UserMinus, 'user-plus': UserPlus, 'users': Users,
  'wand-sparkles': WandSparkles, 'x': X,
}

export type IconName = keyof typeof ICONS

// The full, listable set of valid names — render it, type against it, validate it.
export const iconNames = Object.keys(ICONS) as IconName[]
