<script setup lang="ts">
import Icon from '../Icon/Icon.vue'
/**
 * Select — styled single-select dropdown (native under the hood). v-model.
 *
 * @prop modelValue / options ({ label, value, disabled? }[]) / placeholder / disabled / size
 *
 * Status: new
 */
export interface SelectOption { label: string; value: string; disabled?: boolean }

withDefaults(defineProps<{
  modelValue: string
  options: SelectOption[]
  placeholder?: string
  disabled?: boolean
  size?: 'sm' | 'md'
}>(), { size: 'md', disabled: false })

const emit = defineEmits<{ 'update:modelValue': [v: string] }>()
</script>

<template>
  <div data-ui="select" :class="[$style.wrap, $style[size]]">
    <select
      :class="$style.select"
      :value="modelValue"
      :disabled="disabled"
      @change="emit('update:modelValue', ($event.target as HTMLSelectElement).value)"
    >
      <option v-if="placeholder" value="" disabled>{{ placeholder }}</option>
      <option v-for="o in options" :key="o.value" :value="o.value" :disabled="o.disabled">{{ o.label }}</option>
    </select>
    <Icon name="chevron-down" :size="14" :class="$style.arrow" />
  </div>
</template>

<style module>
.wrap { position: relative; display: inline-flex; width: 100%; }
.select { appearance: none; width: 100%; background: var(--color-surface-mute, var(--color-bg)); color: var(--color-fg); border: 1px solid var(--color-border); border-radius: var(--radius); padding: 0 28px 0 var(--space-3); font-family: var(--font-family); }
.sm .select { height: var(--select-h-sm, 28px); font-size: var(--font-size-sm); }
.md .select { height: var(--select-h-md, 36px); font-size: var(--font-size-base); }
.select:disabled { opacity: 0.5; cursor: not-allowed; }
.select:focus { outline: none; border-color: var(--color-accent, var(--color-border)); }
.select:focus-visible { outline: 2px solid var(--color-accent, var(--color-fg)); outline-offset: 1px; }
.arrow { position: absolute; right: 10px; top: 50%; transform: translateY(-50%); pointer-events: none; color: var(--color-muted); }
</style>
