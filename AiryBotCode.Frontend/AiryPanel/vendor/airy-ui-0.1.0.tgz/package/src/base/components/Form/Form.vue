<script setup lang="ts">
/**
 * Form
 * The submit coordinator. `Field` owns one control's label, hint, error and
 * a11y; `Form` owns everything that happens *around* the whole set: one submit
 * on Enter, a busy state that cannot double-fire, dirty tracking against a
 * baseline, the changed-keys diff, the error summary, and the footer.
 *
 * It computes no validation rules on purpose — see FormPage for the reasoning.
 * What it does own is *when* an error may be shown (`submitted`), *whether* a
 * submit may proceed (any `aria-invalid` control blocks it), and *where* the
 * user goes next (first invalid control gets focus, the summary links to the
 * rest). Rules stay next to the API contract that enforces them.
 *
 * Give it `action` and it runs the whole in-flight dance: busy, double-submit
 * guard, the error line, the saved note, and re-baselining the model so `dirty`
 * goes quiet again. Give it nothing and it is still a correct `<form>`: listen
 * to `@submit` and drive `busy` / `error` yourself.
 *
 * @prop action       - async submit handler. Receives { changes, dirty, submitted }.
 *                      Throwing renders the message; resolving shows `saved`.
 * @prop model        - reactive object to dirty-track. `changes` is the shallow
 *                      diff of its own keys against the baseline.
 * @prop rebaseOn     - re-take the baseline whenever this value changes — pass the
 *                      fetched payload so a form filled after load starts clean.
 * @prop busy         - external busy state, OR-ed with the in-flight one.
 * @prop error        - external error message, shown above the footer.
 * @prop saved        - note shown after a successful `action`. `false` for silence.
 * @prop savedFor     - ms the saved note stays. 0 keeps it until the next submit.
 * @prop errorMessage - map a thrown value to a message. Defaults to the
 *                      `data.error / statusMessage / message` chain.
 * @prop blockInvalid - refuse to submit while any control is invalid. Default true.
 * @prop summary      - show the error summary after a blocked submit. Default true.
 * @prop summaryTitle - override the summary's mono `//` headline.
 * @prop submitOnEnter- allow implicit submission from a single-line control. Default true.
 * @prop lock         - while busy, make the body inert and disable every submit
 *                      button, restoring focus afterwards. Default true.
 * @prop divided      - hairline between every direct child of the body.
 * @prop note         - mono `// …` caption in the footer.
 * @prop dirtyNote    - caption used instead of `note` while dirty. `false` to disable.
 * @prop sticky       - pin the footer to the bottom of the scroll container.
 * @prop stack        - let the footer collapse to a column when narrow.
 * @prop loading      - render a layout-keeping skeleton instead of the body.
 * @prop loadingRows  - skeleton field count. Default 3.
 *
 * @slot default     - the fields. Slot props: { busy, dirty, submitted, changes,
 *                     invalid, submit, reset }.
 * @slot footer      - footer actions, laid out by `ButtonBar footer`. Same slot props.
 * @slot footerApart - held-away footer action (the destructive one).
 *
 * Status: new | Consumers: portal settings / accounts / login / setup
 */
import { computed, nextTick, onBeforeUnmount, onMounted, onUpdated, provide, ref, shallowRef, useSlots, watch } from 'vue'
import ButtonBar from '../ButtonBar/ButtonBar.vue'
import Skeleton from '../Skeleton/Skeleton.vue'
import { FORM_KEY, type FormFieldHandle, type FormInvalidField } from './keys'

export interface FormSubmitContext {
  /** Own keys of `model` that differ from the baseline. Empty without `model`. */
  changes: Record<string, unknown>
  dirty: boolean
  submitted: boolean
}

const props = withDefaults(defineProps<{
  action?: (ctx: FormSubmitContext) => unknown
  model?: Record<string, any>
  rebaseOn?: unknown
  busy?: boolean
  error?: string
  saved?: string | false
  savedFor?: number
  errorMessage?: (err: unknown) => string
  blockInvalid?: boolean
  summary?: boolean
  summaryTitle?: string
  submitOnEnter?: boolean
  lock?: boolean
  divided?: boolean
  note?: string
  dirtyNote?: string | false
  sticky?: boolean
  stack?: boolean
  loading?: boolean
  loadingRows?: number
}>(), {
  busy: false,
  error: '',
  saved: 'Saved.',
  savedFor: 4000,
  blockInvalid: true,
  summary: true,
  submitOnEnter: true,
  lock: true,
  divided: false,
  dirtyNote: 'unsaved changes',
  sticky: false,
  stack: false,
  loading: false,
  loadingRows: 3,
})

const emit = defineEmits<{
  submit: [ctx: FormSubmitContext]
  invalid: [fields: FormInvalidField[]]
  error: [err: unknown]
  success: []
  reset: []
  'update:dirty': [dirty: boolean]
}>()

const slots = useSlots()

const root = ref<HTMLFormElement>()
const running = ref(false)
const submitted = ref(false)
const failure = ref('')
const savedShown = ref(false)
const invalidFields = shallowRef<FormInvalidField[]>([])
const handles = shallowRef<FormFieldHandle[]>([])

const busy = computed(() => props.busy || running.value)
const locked = computed(() => props.lock && busy.value)
const errorText = computed(() => props.error || failure.value)
const savedText = computed(() => (savedShown.value && props.saved !== false ? props.saved : ''))

const baseline = ref<Record<string, string>>({})

function encode(value: unknown): string {
  try {
    const json = JSON.stringify(value)
    return json === undefined ? '\u0000undefined' : json
  }
  catch {
    return String(value)
  }
}

function rebase() {
  const model = props.model
  const next: Record<string, string> = {}
  if (model) for (const key of Object.keys(model)) next[key] = encode(model[key])
  baseline.value = next
}

const tracking = computed(() => !!props.model)

const changes = computed<Record<string, unknown>>(() => {
  const model = props.model
  const out: Record<string, unknown> = {}
  if (!model) return out
  for (const key of Object.keys(model)) {
    if (encode(model[key]) !== baseline.value[key]) out[key] = model[key]
  }
  return out
})

const dirty = computed(() => Object.keys(changes.value).length > 0)

const footNote = computed(() => {
  if (tracking.value && dirty.value && props.dirtyNote !== false) return props.dirtyNote
  return props.note
})

const summaryTitle = computed(() => {
  if (props.summaryTitle) return props.summaryTitle
  const n = invalidFields.value.length
  return `${n} field${n === 1 ? '' : 's'} need${n === 1 ? 's' : ''} attention — nothing was sent`
})

const FOCUSABLE = [
  'input:not([type="hidden"]):not([disabled])',
  'select:not([disabled])',
  'textarea:not([disabled])',
  'button:not([disabled])',
  '[contenteditable="true"]',
  '[tabindex]:not([tabindex="-1"])',
].join(',')

function esc(id: string): string {
  if (typeof CSS !== 'undefined' && typeof CSS.escape === 'function') return CSS.escape(id)
  return id.replace(/["\\]/g, '\\$&')
}

function textOf(node: Element | null | undefined): string {
  return (node?.textContent ?? '').replace(/\s+/g, ' ').trim()
}

function focusEl(el: HTMLElement | null) {
  if (!el) return
  const target = el.matches(FOCUSABLE) ? el : el.querySelector<HTMLElement>(FOCUSABLE)
  target?.focus()
  target?.scrollIntoView?.({ block: 'nearest' })
}

function labelOf(el: HTMLElement): string {
  const id = el.id
  const native = (el as HTMLInputElement).labels?.[0]
  const byFor = id ? root.value?.querySelector(`label[for="${esc(id)}"]`) : null
  const byId = id ? document.getElementById(`${id}-label`) : null
  const labelledBy = el.getAttribute('aria-labelledby')
  const byAria = labelledBy ? document.getElementById(labelledBy.split(/\s+/)[0]) : null
  const text = textOf(native ?? byFor ?? byId ?? byAria).replace(/\s*required$/i, '').trim()
  if (text) return text
  return el.getAttribute('aria-label') || (el as HTMLInputElement).placeholder || id || 'This field'
}

function messageOf(el: HTMLElement): string {
  const ids = (el.getAttribute('aria-describedby') ?? '').split(/\s+/).filter(Boolean)
  for (const id of ids) {
    const node = document.getElementById(id)
    if (node && (node.getAttribute('role') === 'alert' || id.endsWith('-error'))) {
      const text = textOf(node)
      if (text) return text
    }
  }
  return textOf(el.querySelector('[role="alert"]'))
}

function collectInvalid(): FormInvalidField[] {
  const form = root.value
  if (!form) return []

  const found: Array<{ el: HTMLElement, field: FormInvalidField }> = []
  const claimed = new Set<HTMLElement>()

  for (const handle of handles.value) {
    if (!handle.invalid.value) continue
    const el = handle.id ? form.querySelector<HTMLElement>(`#${esc(handle.id)}`) : null
    if (el) claimed.add(el)
    found.push({
      el: el ?? form,
      field: {
        id: handle.id,
        label: handle.label ?? (el ? labelOf(el) : handle.id),
        message: handle.message?.value ?? (el ? messageOf(el) : ''),
        focus: () => (handle.focus ? handle.focus() : focusEl(el)),
      },
    })
  }

  const marked = Array.from(form.querySelectorAll<HTMLElement>('[aria-invalid="true"]'))
  for (const el of marked) {
    if (claimed.has(el)) continue
    if (marked.some(other => other !== el && el.contains(other))) continue
    found.push({
      el,
      field: { id: el.id, label: labelOf(el), message: messageOf(el), focus: () => focusEl(el) },
    })
  }

  found.sort((a, b) =>
    a.el === b.el ? 0 : (a.el.compareDocumentPosition(b.el) & Node.DOCUMENT_POSITION_FOLLOWING ? -1 : 1))

  return found.map(entry => entry.field)
}

let savedTimer: ReturnType<typeof setTimeout> | undefined

async function submit() {
  if (busy.value) return
  submitted.value = true
  failure.value = ''
  savedShown.value = false
  clearTimeout(savedTimer)

  await nextTick()

  const bad = props.blockInvalid ? collectInvalid() : []
  invalidFields.value = bad
  if (bad.length) {
    emit('invalid', bad)
    bad[0].focus()
    return
  }

  const ctx: FormSubmitContext = { changes: { ...changes.value }, dirty: dirty.value, submitted: true }
  emit('submit', ctx)
  if (!props.action) return

  running.value = true
  try {
    await props.action(ctx)
    rebase()
    savedShown.value = true
    emit('success')
    if (props.savedFor > 0) savedTimer = setTimeout(() => { savedShown.value = false }, props.savedFor)
  }
  catch (err) {
    failure.value = (props.errorMessage ?? defaultMessage)(err)
    emit('error', err)
  }
  finally {
    running.value = false
  }
}

function defaultMessage(err: unknown): string {
  const e = err as any
  return e?.data?.error ?? e?.data?.statusMessage ?? e?.data?.message
    ?? e?.statusMessage ?? e?.message ?? 'That did not go through.'
}

function reset() {
  const model = props.model
  if (model) {
    for (const key of Object.keys(baseline.value)) {
      const raw = baseline.value[key]
      if (raw === '\u0000undefined') { model[key] = undefined; continue }
      try { model[key] = JSON.parse(raw) }
      catch { /* leave a value we could not encode alone */ }
    }
  }
  submitted.value = false
  invalidFields.value = []
  failure.value = ''
  savedShown.value = false
  clearTimeout(savedTimer)
  emit('reset')
}

function onKeydown(event: KeyboardEvent) {
  if (event.key !== 'Enter' || props.submitOnEnter || event.defaultPrevented) return
  const target = event.target as HTMLElement | null
  if (!target || target.tagName === 'TEXTAREA' || target.isContentEditable) return
  if (target.tagName === 'BUTTON' || (target as HTMLInputElement).type === 'submit') return
  event.preventDefault()
}

let recheck: ReturnType<typeof setTimeout> | undefined
function onInput() {
  if (!invalidFields.value.length) return
  clearTimeout(recheck)
  recheck = setTimeout(() => { invalidFields.value = collectInvalid() }, 60)
}

const held = new Set<HTMLButtonElement>()

function sync() {
  const form = root.value
  if (!form) return

  for (const button of Array.from(form.querySelectorAll<HTMLButtonElement>('button'))) {
    if (button.hasAttribute('data-form-submit')) {
      if (button.type !== 'submit') button.type = 'submit'
      continue
    }
    if (!button.hasAttribute('type')) button.type = 'button'
  }

  if (locked.value) {
    for (const button of Array.from(form.querySelectorAll<HTMLButtonElement>('button[type="submit"]'))) {
      if (!button.disabled) { button.disabled = true; held.add(button) }
    }
    return
  }
  for (const button of held) button.disabled = false
  held.clear()
}

let parked: HTMLElement | null = null

watch(locked, async (on) => {
  if (on) { parked = document.activeElement as HTMLElement | null; return }
  const el = parked
  parked = null
  await nextTick()
  sync()
  if (el && root.value?.contains(el) && typeof el.focus === 'function') el.focus()
})

watch(() => props.rebaseOn, async () => { await nextTick(); rebase() })
watch(dirty, value => emit('update:dirty', value))

onMounted(() => { rebase(); sync() })
onUpdated(sync)
onBeforeUnmount(() => { clearTimeout(savedTimer); clearTimeout(recheck) })

provide(FORM_KEY, {
  busy,
  submitted,
  dirty,
  register: handle => { handles.value = [...handles.value.filter(h => h.id !== handle.id), handle] },
  unregister: id => { handles.value = handles.value.filter(h => h.id !== id) },
  submit,
})

const state = computed(() => ({
  busy: busy.value,
  dirty: dirty.value,
  submitted: submitted.value,
  changes: changes.value,
  invalid: invalidFields.value.length > 0,
  submit,
  reset,
}))

const hasFoot = computed(() => !!slots.footer || !!errorText.value || !!savedText.value)

defineExpose({ submit, reset, rebase, dirty, busy, changes })
</script>

<template>
  <form data-ui="form"
    ref="root"
    novalidate
    :class="$style.form"
    :aria-busy="busy || undefined"
    @submit.prevent="submit"
    @keydown="onKeydown"
    @input="onInput"
    @change="onInput"
  >
    <div v-if="summary && invalidFields.length" :class="$style.summary" role="alert">
      <p :class="$style.summaryHead">
        <span :class="$style.slashes" aria-hidden="true">//</span>
        <span>{{ summaryTitle }}</span>
      </p>
      <ul :class="$style.summaryList">
        <li v-for="field in invalidFields" :key="field.id || field.label">
          <button type="button" :class="$style.jump" @click="field.focus()">{{ field.label }}</button>
          <span v-if="field.message" :class="$style.jumpMsg">{{ field.message }}</span>
        </li>
      </ul>
    </div>

    <div v-if="loading" :class="$style.body" aria-hidden="true">
      <div v-for="row in loadingRows" :key="row" :class="$style.skel">
        <Skeleton variant="block" width="34%" height="13px" />
        <Skeleton variant="block" height="36px" />
      </div>
    </div>

    <div v-else :class="[$style.body, divided && $style.divided]" :inert="locked || undefined">
      <slot v-bind="state" />
    </div>

    <div v-if="hasFoot" :class="$style.foot">
      <p v-if="errorText" :class="$style.error" role="alert">{{ errorText }}</p>
      <p v-else-if="savedText" :class="$style.saved" role="status">{{ savedText }}</p>

      <ButtonBar v-if="$slots.footer" footer :sticky="sticky" :stack="stack" :note="footNote">
        <template v-if="$slots.footerApart" #apart>
          <slot name="footerApart" v-bind="state" />
        </template>
        <slot name="footer" v-bind="state" />
      </ButtonBar>
    </div>
  </form>
</template>

<style module>
.form {
  display: flex;
  flex-direction: column;
  gap: var(--space-4);
  min-width: 0;
}

.body {
  display: flex;
  flex-direction: column;
  gap: var(--space-4);
  min-width: 0;
}
.body[inert] { opacity: 0.55; }

/* Hairlines between rows, never cards. */
.divided > * + * {
  padding-top: var(--space-4);
  border-top: 1px solid var(--color-border-soft, var(--color-border));
}

/* Skeleton keeps the label + control rhythm so nothing jumps on arrival. */
.skel {
  display: flex;
  flex-direction: column;
  gap: var(--space-2);
}

/* Error summary — outlined, never a filled banner. */
.summary {
  padding: var(--space-3);
  border: 1px solid var(--color-danger);
  border-radius: var(--r-2, var(--radius));
  animation: form-reveal 120ms ease-out;
}
.summaryHead {
  display: flex;
  gap: var(--space-2);
  margin: 0;
  font-family: var(--font-mono);
  font-size: var(--font-size-xs);
  color: var(--color-danger);
}
.slashes { color: var(--color-text-ghost); flex-shrink: 0; }

.summaryList {
  display: flex;
  flex-direction: column;
  gap: var(--space-1);
  margin: var(--space-2) 0 0;
  padding: 0;
  list-style: none;
}
.summaryList li {
  display: flex;
  flex-wrap: wrap;
  align-items: baseline;
  gap: var(--space-2);
  min-width: 0;
}

.jump {
  padding: 0;
  border: 0;
  border-radius: var(--r-1, 4px);
  background: none;
  cursor: pointer;
  font-family: var(--font-family);
  font-size: var(--font-size-sm);
  font-weight: 500;
  color: var(--color-fg);
  text-decoration: underline;
  text-decoration-style: dotted;
  text-underline-offset: 3px;
}
.jump:hover { color: var(--color-accent); }
.jump:focus-visible {
  outline: 2px solid var(--color-accent);
  outline-offset: 2px;
}
.jumpMsg {
  font-family: var(--font-mono);
  font-size: var(--font-size-xs);
  color: var(--color-muted);
  min-width: 0;
}

/* Footer — the status line sits above ButtonBar's own chrome. */
.foot {
  display: flex;
  flex-direction: column;
  gap: var(--space-2);
  min-width: 0;
}

.error,
.saved {
  margin: 0;
  padding-left: var(--space-2);
  border-left: 1px solid var(--color-border);
  font-family: var(--font-mono);
  font-size: var(--font-size-xs);
  line-height: 1.5;
  animation: form-reveal 120ms ease-out;
}
.error { border-left-color: var(--color-danger); color: var(--color-danger); }
.saved { border-left-color: var(--color-ok); color: var(--color-muted); }

@keyframes form-reveal {
  from { opacity: 0; transform: translateY(-2px); }
  to   { opacity: 1; transform: none; }
}

@media (prefers-reduced-motion: reduce) {
  .summary, .error, .saved { animation: none; }
}
</style>
