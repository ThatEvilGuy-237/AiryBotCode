<script setup lang="ts">
/**
 * ToolRow
 * Single row for a tool: monospace name + optional description + actions slot.
 * Used in lists and inside expandable toolbox sections.
 *
 * @prop name        - tool name (rendered in mono)
 * @prop description - optional muted description
 * @prop dim         - render in a muted/inactive state
 *
 * Slot: actions — right-aligned content (Badge, Button, etc.)
 *
 * Status: stable | Consumers: ToolsPage, ToolboxesPage
 */
withDefaults(defineProps<{
  name: string
  description?: string
  dim?: boolean
}>(), { dim: false })
</script>

<template>
  <div data-ui="tool-row" :class="[$style.row, dim && $style.dim]">
    <div :class="$style.info">
      <span :class="$style.name">{{ name }}</span>
      <span v-if="description" :class="$style.desc">{{ description }}</span>
    </div>
    <div v-if="$slots.actions" :class="$style.actions">
      <slot name="actions" />
    </div>
  </div>
</template>

<style module>
.row {
  display: flex;
  align-items: center;
  justify-content: space-between;
  gap: var(--space-4);
  padding: var(--space-2) 0;
}

.info {
  display: flex;
  align-items: baseline;
  gap: var(--space-3);
  min-width: 0;
}

.name {
  font-family: var(--font-mono);
  font-size: var(--font-size-sm);
  font-weight: 600;
  flex-shrink: 0;
}

.desc {
  font-size: var(--font-size-sm);
  color: var(--color-muted);
  overflow: hidden;
  text-overflow: ellipsis;
  white-space: nowrap;
}

.actions { display: flex; gap: var(--space-2); flex-shrink: 0; }

.dim .name { color: var(--color-muted); font-weight: 500; }
.dim .desc { opacity: 0.7; }
</style>
