<script setup lang="ts">
/**
 * Card
 * Bordered container with optional head and foot regions.
 * Renders a hairline divider between any two adjacent regions automatically.
 *
 * @prop bordered - 1px border + radius around the card (default true)
 * @prop stack    - lay the body out as a gapped vertical column: children get
 *                  `var(--space-3)` spacing and the body switches to the roomier
 *                  uniform `var(--space-4)` padding (default false). Additive —
 *                  the plain body is unchanged when off.
 *
 * Slots:
 *   head    - row at the top (title, status chip, actions)
 *   default - body content
 *   foot    - actions row at the bottom
 *
 * Status: stable | Consumers: Patterns, PortalCard
 */
withDefaults(defineProps<{ bordered?: boolean; stack?: boolean }>(), { bordered: true, stack: false })
</script>

<template>
  <div data-ui="card" :class="[$style.card, bordered && $style.bordered]">
    <div v-if="$slots.head" :class="$style.head"><slot name="head" /></div>
    <hr   v-if="$slots.head && $slots.default" :class="$style.divider" />
    <div v-if="$slots.default" :class="[$style.body, stack && $style.stack]"><slot /></div>
    <hr   v-if="$slots.default && $slots.foot" :class="$style.divider" />
    <div v-if="$slots.foot" :class="$style.foot"><slot name="foot" /></div>
  </div>
</template>

<style module>
.card {
  display: flex;
  flex-direction: column;
  background: var(--color-surface);
}
.bordered {
  border: var(--border);
  border-radius: var(--radius);
}
.head {
  display: flex;
  align-items: center;
  gap: var(--space-3);
  padding: var(--space-3) var(--space-4);
}
.body {
  padding: var(--space-3) var(--space-4);
  color: var(--color-text-dim, var(--color-muted));
  font-size: var(--font-size-sm);
  line-height: 1.55;
}
.stack {
  display: flex;
  flex-direction: column;
  gap: var(--space-3);
  padding: var(--space-4);
  /* A stack holds mixed content (typed components + loose prose); don't force the
     compact body type scale on it, so wrapped prose keeps the ambient size. */
  font-size: inherit;
  line-height: inherit;
}
.foot {
  display: flex;
  align-items: center;
  gap: var(--space-2);
  padding: var(--space-3) var(--space-4);
}
.divider {
  border: 0;
  border-top: 1px solid var(--color-border-soft, var(--color-border));
  margin: 0;
}
</style>
