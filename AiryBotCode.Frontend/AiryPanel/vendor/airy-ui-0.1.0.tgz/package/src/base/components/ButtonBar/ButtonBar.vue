<script setup lang="ts">
/**
 * ButtonBar
 * The row every Hive action group sits in. It encodes the decisions that get
 * got wrong by hand: the primary action is the LAST child and the bar defaults
 * to `align="end"`, so the primary lands bottom-right on every surface; a
 * destructive action goes in the `apart` slot so it can never end up adjacent
 * to the confirming one; the bar wraps instead of overflowing; and `footer`
 * gives the hairline-and-`--color-bg-2` chrome that dialogs would otherwise
 * each re-invent.
 *
 * Presentational only — it does not know what a button is beyond laying it out.
 *
 * @prop align   - 'start' | 'end' | 'between'. Default 'end' (primary right).
 * @prop gap     - 'sm' | 'md' | 'lg' spacing between actions.
 * @prop wrap    - allow the bar to wrap onto a second line. Default true.
 * @prop footer  - footer chrome: hairline top border, --color-bg-2, padding,
 *                 full width. For a Modal/Drawer/form action bar.
 * @prop sticky  - pin the bar to the bottom of the nearest scroll container.
 *                 Implies `footer` chrome, but the chrome only fades in while
 *                 there is still content scrolled under the bar.
 * @prop stack   - below `stackAt` px, collapse to a full-width column with the
 *                 primary on top and the `apart` action at the bottom.
 * @prop stackAt - width in px at which `stack` kicks in. Default 340.
 * @prop note    - mono `// …` caption pinned opposite the actions.
 *
 * Slots: default (the action group), apart (one action held away from the
 * group — the destructive slot).
 *
 * Status: new | Consumers: portal (plugin, accounts, spaces, search)
 */
import { computed, onBeforeUnmount, onMounted, ref, useSlots } from 'vue'

export type ButtonBarAlign = 'start' | 'end' | 'between'
export type ButtonBarGap = 'sm' | 'md' | 'lg'

const props = withDefaults(defineProps<{
  align?: ButtonBarAlign
  gap?: ButtonBarGap
  wrap?: boolean
  footer?: boolean
  sticky?: boolean
  stack?: boolean
  stackAt?: number
  note?: string
}>(), {
  align: 'end',
  gap: 'sm',
  wrap: true,
  footer: false,
  sticky: false,
  stack: false,
  stackAt: 340,
})

const slots = useSlots()
const el = ref<HTMLElement | null>(null)
const docked = ref(true)
const narrow = ref(false)

const hasLead = computed(() => !!slots.apart || !!props.note)
const leadFirst = computed(() => hasLead.value && props.align !== 'start')
const leadLast = computed(() => hasLead.value && props.align === 'start')
const chrome = computed(() => props.footer || props.sticky)
const gapClass = computed(() => ({ sm: 'gapSm', md: 'gapMd', lg: 'gapLg' } as const)[props.gap])

let scroller: HTMLElement | null = null
let observer: ResizeObserver | null = null

function findScroller(node: HTMLElement | null): HTMLElement | null {
  let cur = node?.parentElement ?? null
  while (cur) {
    const overflow = getComputedStyle(cur).overflowY
    if (overflow === 'auto' || overflow === 'scroll') return cur
    cur = cur.parentElement
  }
  return null
}

function measure() {
  if (props.stack && el.value) narrow.value = el.value.clientWidth < props.stackAt
  if (props.sticky && scroller) {
    docked.value = scroller.scrollHeight - scroller.clientHeight - scroller.scrollTop > 1
  }
}

onMounted(() => {
  if (props.sticky) scroller = findScroller(el.value)
  scroller?.addEventListener('scroll', measure, { passive: true })
  if (typeof ResizeObserver !== 'undefined') {
    observer = new ResizeObserver(measure)
    if (el.value) observer.observe(el.value)
    if (scroller) observer.observe(scroller)
  }
  measure()
})

onBeforeUnmount(() => {
  scroller?.removeEventListener('scroll', measure)
  observer?.disconnect()
  scroller = null
})
</script>

<template>
  <div data-ui="button-bar"
    ref="el"
    role="group"
    :class="[
      $style.bar,
      $style[align],
      $style[gapClass],
      wrap && $style.wrap,
      chrome && $style.chrome,
      sticky && $style.sticky,
      sticky && docked && $style.docked,
      narrow && $style.narrow,
    ]"
  >
    <div v-if="leadFirst" :class="[$style.lead, $style.leadFirst]">
      <slot name="apart" />
      <span v-if="note" :class="$style.note">// {{ note }}</span>
    </div>

    <slot />

    <div v-if="leadLast" :class="[$style.lead, $style.leadLast]">
      <slot name="apart" />
      <span v-if="note" :class="$style.note">// {{ note }}</span>
    </div>
  </div>
</template>

<style module>
.bar {
  display: flex;
  align-items: center;
  min-width: 0;
}
.wrap { flex-wrap: wrap; }

.gapSm { gap: var(--space-2); }
.gapMd { gap: var(--space-3); }
.gapLg { gap: var(--space-4); }

.start   { justify-content: flex-start; }
.end     { justify-content: flex-end; }
.between { justify-content: space-between; }

/* The held-away region: destructive action and/or the // note. */
.lead {
  display: flex;
  align-items: center;
  gap: inherit;
  min-width: 0;
}
.leadFirst { margin-inline-end: auto; }
.leadLast  { margin-inline-start: auto; }

.note {
  font-family: var(--font-mono);
  font-size: var(--font-size-xs);
  color: var(--color-muted);
  white-space: nowrap;
  overflow: hidden;
  text-overflow: ellipsis;
}

/* Footer chrome — hairline over --color-bg-2, no shadow. */
.chrome {
  box-sizing: border-box;
  width: 100%;
  padding: var(--space-3) var(--space-4);
  border-top: 1px solid var(--color-border-soft, var(--color-border));
  background: var(--color-bg-2, var(--color-bg));
}

.sticky {
  position: sticky;
  bottom: 0;
  z-index: 2;
  border-top-color: transparent;
  background: transparent;
  transition: background-color 120ms ease, border-top-color 120ms ease;
}
.sticky.docked {
  border-top-color: var(--color-border-soft, var(--color-border));
  background: var(--color-bg-2, var(--color-bg));
}

/* Narrow: full-width column, primary (last child) on top. */
.narrow {
  flex-direction: column-reverse;
  align-items: stretch;
  flex-wrap: nowrap;
}
.narrow .lead {
  margin: 0;
  flex-direction: column;
  align-items: stretch;
}
.narrow .note { text-align: center; }

@media (prefers-reduced-motion: reduce) {
  .sticky { transition: none; }
}
</style>
