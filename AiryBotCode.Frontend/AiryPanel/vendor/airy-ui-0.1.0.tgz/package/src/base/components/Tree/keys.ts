/**
 * Tree — the injection contract between the root and its branch rows.
 *
 * The root owns every piece of state: selection, expansion, the flattened
 * visible order, the roving focus target and the lazy-load cache. `TreeBranch`
 * is a thin renderer that reads from here, so nested rows never disagree.
 */
import type { ComputedRef, InjectionKey } from 'vue'
import type { TreeKey, TreeLoadState, TreeNode } from './types'

export interface TreeContext {
  selectedKey: ComputedRef<TreeKey | null>
  /** The single row that is tabbable at any moment (roving tabindex). */
  tabKey: ComputedRef<TreeKey | null>
  /** Ancestor keys of the selection — their indent hairline runs accent. */
  spine: ComputedRef<Set<TreeKey>>
  /** True when any rendered node carries an icon, so labels stay aligned. */
  anyIcon: ComputedRef<boolean>
  dense: ComputedRef<boolean>
  childrenOf: (node: TreeNode) => TreeNode[]
  expandable: (node: TreeNode) => boolean
  isExpanded: (key: TreeKey) => boolean
  loadStateOf: (key: TreeKey) => TreeLoadState
  select: (node: TreeNode) => void
  toggle: (node: TreeNode) => void
  onKeydown: (event: KeyboardEvent, node: TreeNode) => void
  registerRow: (key: TreeKey, el: HTMLElement) => void
  unregisterRow: (key: TreeKey) => void
  setActive: (key: TreeKey) => void
}

export const TREE_CTX: InjectionKey<TreeContext> = Symbol('hive:tree')
