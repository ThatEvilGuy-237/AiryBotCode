<script setup lang="ts">
/**
 * PageHeader
 * Page title row with an optional breadcrumb trail above it, a count badge on
 * the right of the title, a muted subtitle, an actions slot on the far right,
 * and an indeterminate loading line anchored to its bottom edge.
 *
 * @prop title       - main heading text
 * @prop subtitle    - optional muted second line
 * @prop count       - optional number shown in a Badge next to the title
 * @prop breadcrumbs - optional trail; items with `to` link, the last is plain text
 * @prop loading     - toggles a 2px indeterminate accent line on the bottom edge
 *
 * Status: stable | Consumers: ToolsPage, ToolboxesPage, memory portal
 */
import Badge from '../Badge/Badge.vue'
import LoadingBar from '../LoadingBar/LoadingBar.vue'

export interface PageHeaderCrumb {
  label: string
  to?: string
}

const props = withDefaults(defineProps<{
  title: string
  subtitle?: string
  count?: number | string
  breadcrumbs?: PageHeaderCrumb[]
  loading?: boolean
}>(), {
  breadcrumbs: () => [],
  loading: false,
})

defineSlots<{ actions?: () => unknown }>()
</script>

<template>
  <div data-ui="page-header" :class="$style.wrap">
    <nav v-if="props.breadcrumbs.length" :class="$style.crumbs" aria-label="Breadcrumb">
      <ol :class="$style.crumbList">
        <li
          v-for="(crumb, i) in props.breadcrumbs"
          :key="i"
          :class="$style.crumbItem"
        >
          <svg
            v-if="i > 0"
            :class="$style.sep"
            viewBox="0 0 16 16"
            width="12"
            height="12"
            aria-hidden="true"
            focusable="false"
          >
            <path d="M6 3l5 5-5 5" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round" />
          </svg>
          <RouterLink
            v-if="crumb.to && i < props.breadcrumbs.length - 1"
            :to="crumb.to"
            :class="$style.crumbLink"
          >{{ crumb.label }}</RouterLink>
          <span
            v-else
            :class="$style.crumbCurrent"
            :aria-current="i === props.breadcrumbs.length - 1 ? 'page' : undefined"
          >{{ crumb.label }}</span>
        </li>
      </ol>
    </nav>

    <div :class="$style.header">
      <div :class="$style.titleBlock">
        <div :class="$style.titleRow">
          <h1 :class="$style.title">{{ title }}</h1>
          <Badge v-if="count !== undefined" variant="inactive">{{ count }}</Badge>
        </div>
        <p v-if="subtitle" :class="$style.subtitle">{{ subtitle }}</p>
      </div>
      <div v-if="$slots.actions" :class="$style.actions">
        <slot name="actions" />
      </div>
    </div>

    <LoadingBar :active="props.loading" anchor="bottom" label="Loading page" />
  </div>
</template>

<style module>
.wrap {
  position: relative;
  display: flex;
  flex-direction: column;
  gap: var(--space-3);
  padding-bottom: var(--space-4);
  border-bottom: var(--border);
}

.crumbs { font-family: var(--font-mono); font-size: var(--font-size-sm); }

.crumbList {
  display: flex;
  flex-wrap: wrap;
  align-items: center;
  gap: var(--space-1);
  margin: 0;
  padding: 0;
  list-style: none;
}

.crumbItem { display: inline-flex; align-items: center; gap: var(--space-1); }

.sep { color: var(--color-text-ghost, var(--color-muted)); flex-shrink: 0; }

.crumbLink {
  color: var(--color-muted);
  text-decoration: none;
  border-radius: var(--radius-sm, var(--radius));
  transition: color 0.12s ease;
}
.crumbLink:hover { color: var(--color-accent); }
.crumbLink:focus-visible {
  outline: 2px solid var(--color-accent);
  outline-offset: 2px;
}

.crumbCurrent { color: var(--color-fg); }

.header {
  display: flex;
  align-items: flex-start;
  justify-content: space-between;
  gap: var(--space-4);
}

.titleBlock { display: flex; flex-direction: column; gap: var(--space-1); }
.titleRow   { display: flex; align-items: center; gap: var(--space-3); }

.title    { font-size: var(--font-size-xl); font-weight: 700; letter-spacing: -0.02em; }
.subtitle { font-size: var(--font-size-sm); color: var(--color-muted); }

.actions { display: flex; gap: var(--space-2); flex-shrink: 0; }

/* Mobile: a row that puts the title and its actions side by side runs the
   actions off the edge on a phone — stack them and let the actions wrap. */
@media (max-width: 768px) {
  .header {
    flex-direction: var(--page-header-narrow-direction, column);
    flex-wrap: var(--page-header-narrow-wrap, nowrap);
    align-items: var(--page-header-narrow-align, stretch);
    gap: var(--space-3);
  }
  .actions { flex-wrap: wrap; flex-shrink: 1; min-width: 0; }
}
</style>
