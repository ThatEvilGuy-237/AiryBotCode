<script setup lang="ts">
/**
 * Checkbox
 * Labeled checkbox input.
 *
 * @prop modelValue - controlled checked state (use v-model)
 * @prop label      - visible label text
 * @prop disabled   - disables interaction
 *
 * Status: stable | Consumers: (available for future use)
 */
defineProps<{
  modelValue: boolean
  label: string
  disabled?: boolean
}>()

defineEmits<{ 'update:modelValue': [value: boolean] }>()
</script>

<template>
  <label data-ui="checkbox" :class="[$style.label, disabled && $style.disabled]">
    <input
      type="checkbox"
      :class="$style.input"
      :checked="modelValue"
      :disabled="disabled"
      @change="$emit('update:modelValue', ($event.target as HTMLInputElement).checked)"
    />
    {{ label }}
  </label>
</template>

<style module>
.label {
  display: inline-flex;
  align-items: center;
  gap: var(--space-2);
  cursor: pointer;
  font-size: var(--checkbox-font-size, var(--font-size-base));
  min-height: var(--checkbox-min-height, auto);
  font-family: var(--font-family);
}
.disabled { opacity: 0.4; cursor: not-allowed; }
.input {
  width: var(--checkbox-size, 14px);
  height: var(--checkbox-size, 14px);
  accent-color: var(--color-accent, var(--color-fg));
  cursor: inherit;
  flex-shrink: 0;
}
</style>
