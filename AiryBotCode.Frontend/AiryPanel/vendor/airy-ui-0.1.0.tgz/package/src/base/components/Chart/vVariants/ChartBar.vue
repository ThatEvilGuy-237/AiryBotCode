<script setup lang="ts">
/**
 * Chart · bar design
 * Columns for counts per category — per-space concepts, runs per operation. Capped
 * at `barWidth` so a wide band keeps its air, 4px rounded at the data end and square
 * on the baseline, separated by a 2px surface gap instead of a stroke. `stacked`
 * stacks the series; grouped is the default.
 *
 * A single series with a handful of bands labels its own caps — direct labels before
 * gridlines. More series, or narrow bands, and the labels drop to the hover readout
 * and the table rather than collide.
 *
 * @prop ctx    - plot context handed down by Chart.vue
 * @prop active - hovered/focused band index, or null
 *
 * Status: new | Consumers: Chart
 */
import { computed } from 'vue'
import { columnPath } from '../geometry'
import type { ChartPlotCtx } from '../types'

const props = defineProps<{ ctx: ChartPlotCtx, active: number | null }>()

defineEmits<{ active: [index: number | null], point: [index: number, seriesIndex: number] }>()

const GAP = 2
const RADIUS = 4

interface Bar {
  key: string
  index: number
  path: string
  color: string
  quiet: boolean
  cap: { x: number, y: number, text: string } | null
}

const bars = computed<Bar[]>(() => {
  const { scale, series, stacked, barWidth, sparkline } = props.ctx
  const out: Bar[] = []
  if (!scale.count || !series.length) return out
  const band = scale.band
  const single = series.length === 1
  const widest = single ? Math.max(0, ...series[0]!.values.map((v) => (v === null || v === undefined ? 0 : props.ctx.fmt(v).length))) : 0
  const showCaps = single && !sparkline && scale.count <= 8 && band >= 30 && widest * 7 + 8 <= band

  if (stacked || single) {
    const width = Math.max(Math.min(barWidth, Math.max(band - 8, band * 0.7)), Math.min(4, band))
    for (let index = 0; index < scale.count; index += 1) {
      let running = 0
      const topSeries = series.reduce((found, entry, position) => ((entry.values[index] ?? 0) > 0 ? position : found), -1)
      series.forEach((entry, position) => {
        const value = single ? (entry.values[index] ?? null) : Math.max(entry.values[index] ?? 0, 0)
        if (value === null || (stacked && value === 0)) return
        const base = stacked ? scale.y(running) - (running > 0 ? GAP : 0) : scale.zeroY
        const top = stacked ? scale.y(running + value) : scale.y(value)
        running += stacked ? value : 0
        out.push({
          key: `${position}-${index}`,
          index,
          color: entry.color,
          quiet: entry.quiet,
          path: columnPath(scale.x(index) - width / 2, width, top, base, !stacked || position === topSeries ? RADIUS : 0),
          cap: showCaps ? { x: scale.x(index), y: Math.min(top, base) - 6, text: props.ctx.fmt(value) } : null,
        })
      })
    }
    return out
  }

  const groupWidth = Math.max(Math.min(band - 8, barWidth * series.length + GAP * (series.length - 1)), series.length)
  const width = Math.max((groupWidth - GAP * (series.length - 1)) / series.length, 1)
  for (let index = 0; index < scale.count; index += 1) {
    const start = scale.x(index) - groupWidth / 2
    series.forEach((entry, position) => {
      const value = entry.values[index] ?? null
      if (value === null) return
      out.push({
        key: `${position}-${index}`,
        index,
        color: entry.color,
        quiet: entry.quiet,
        path: columnPath(start + position * (width + GAP), width, scale.y(value), scale.zeroY, RADIUS),
        cap: null,
      })
    })
  }
  return out
})
</script>

<template>
  <g :class="$style.marks">
    <path
      v-for="bar in bars"
      :key="bar.key"
      :class="[$style.bar, bar.quiet && $style.quiet, active !== null && active !== bar.index && $style.recede]"
      :d="bar.path"
      :fill="bar.color"
    />
    <text
      v-for="bar in bars.filter(entry => entry.cap)"
      :key="`cap-${bar.key}`"
      :class="$style.cap"
      :x="bar.cap!.x"
      :y="bar.cap!.y"
      text-anchor="middle"
    >{{ bar.cap!.text }}</text>
  </g>
</template>

<style module>
.bar {
  stroke: none;
  transition: opacity 120ms ease;
}
.quiet { opacity: 0.4; }
.recede { opacity: 0.45; }
.cap {
  font-family: var(--font-mono);
  font-size: var(--font-size-xs);
  font-variant-numeric: tabular-nums;
  fill: var(--color-text-dim, var(--color-fg));
}

/* The one motion: the columns rise off the baseline on mount. */
.marks { animation: grow 380ms ease-out both; }
@keyframes grow {
  from { clip-path: inset(100% 0 0 0); }
  to { clip-path: inset(-8% 0 0 0); }
}
@media (prefers-reduced-motion: reduce) {
  .marks { animation: none; }
  .bar { transition: none; }
}
</style>
