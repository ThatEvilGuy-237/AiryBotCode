<script setup lang="ts">
/**
 * Markdown
 * Inline markdown renderer for prose — chat bubbles, conversation content,
 * docs blurbs. Does NOT render a card or border of its own; whatever parent
 * you drop it into (Card body, panel, list item) provides the container.
 *
 * Renders headings, lists, blockquote, inline + fenced code, tables, links.
 * Fenced code uses the shared highlight.js setup, so accent swaps re-color
 * keywords/strings/numbers automatically (same theme as <CodeBlock>).
 *
 * @prop content - the markdown content string
 *
 * Trust note: content passes through `marked` and is rendered via v-html.
 * For untrusted input (3rd-party content), sanitize at the call site
 * (e.g. with DOMPurify) before passing it in.
 *
 * Status: stable | Consumers: chat surfaces, docs prose
 */
import { computed } from 'vue'
import { Marked } from 'marked'
import hljs from '../_internal/hljs'

import '../CodeBlock/code-theme.css'
import './markdown-theme.css'

const props = defineProps<{ content: string }>()

// Isolated marked instance — does not mutate the global `marked` singleton,
// so other code can import marked with its own config without interference.
const md = new Marked({ gfm: true, breaks: false })
md.use({
  renderer: {
    code(token: { text: string; lang?: string }) {
      const text = token.text
      // Allow-list: marked passes the fence info string straight through, so a
      // crafted fence like ```"><script>... could break out of the data-lang
      // attribute. Strip to [a-z0-9_-] before interpolating into HTML.
      const lang = (token.lang || '').replace(/[^a-z0-9_-]/gi, '')
      const detected = lang && hljs.getLanguage(lang) ? lang : ''
      const html = detected
        ? hljs.highlight(text, { language: detected, ignoreIllegals: true }).value
        : hljs.highlightAuto(text).value
      const langAttr = detected ? ` data-lang="${detected}"` : ''
      const label = detected || 'text'
      // Wrap with a bar (language label + copy). Copy is wired via click
      // delegation below, reading the <pre>'s text — works with v-html.
      return `<div class="md-code"><div class="md-code-bar"><span class="md-lang">${label}</span>`
        + `<button type="button" class="md-copy" aria-label="Copy code">Copy</button></div>`
        + `<pre${langAttr}><code class="hljs">${html}</code></pre></div>`
    },
  },
})

const html = computed(() => md.parse(props.content) as string)

// Delegated copy: one listener on the container handles every code block,
// including ones added when `content` changes (v-html re-render).
async function onClick(e: MouseEvent) {
  const btn = (e.target as HTMLElement).closest('.md-copy') as HTMLElement | null
  if (!btn) return
  const code = btn.closest('.md-code')?.querySelector('code')
  if (!code) return
  try {
    await navigator.clipboard.writeText(code.textContent ?? '')
    const prev = btn.textContent
    btn.textContent = 'Copied'
    btn.classList.add('ok')
    setTimeout(() => { btn.textContent = prev; btn.classList.remove('ok') }, 1200)
  } catch { /* clipboard blocked — ignore */ }
}
</script>

<template>
  <div data-ui="markdown" class="hive-md" v-html="html" @click="onClick" />
</template>
