<script setup lang="ts">
/**
 * FormSection
 * A titled group of fields inside a <Form>. It is a real `<fieldset>` with a
 * real `<legend>`, so the group name is announced with every control in it —
 * and so `disabled` disables the whole group with one attribute instead of
 * threading a flag through every field.
 *
 * Sections are separated by a hairline, not stacked into cards: consecutive
 * sections draw their own top rule, so a long form reads as one surface with
 * seams rather than a pile of boxes.
 *
 * @prop title       - the group name (sans, section-title size).
 * @prop description - the mono `// …` sub-line under the title.
 * @prop step        - small mono ordinal before the title ("01", "A").
 * @prop hideTitle   - keep the legend for screen readers, drop it visually.
 * @prop disabled    - disable every control in the group (native fieldset).
 * @prop divided     - hairline between every direct child of the section body.
 *
 * @slot default     - the fields.
 * @slot title       - replaces the title text.
 * @slot description - replaces the description text (the `//` prefix stays).
 * @slot aside       - right side of the title row, e.g. a Badge or a count.
 *
 * Status: new | Consumers: portal settings / accounts
 */
withDefaults(defineProps<{
  title?: string
  description?: string
  step?: string | number
  hideTitle?: boolean
  disabled?: boolean
  divided?: boolean
}>(), {
  hideTitle: false,
  disabled: false,
  divided: false,
})

const slots = defineSlots<{
  default?: () => any
  title?: () => any
  description?: () => any
  aside?: () => any
}>()
</script>

<template>
  <fieldset :class="[$style.section, disabled && $style.off]" :disabled="disabled || undefined">
    <legend v-if="title || slots.title" :class="[$style.legend, hideTitle && $style.offscreen]">
      <span v-if="step != null" :class="$style.step">{{ step }}</span>
      <span :class="$style.title"><slot name="title">{{ title }}</slot></span>
      <span v-if="slots.aside" :class="$style.aside"><slot name="aside" /></span>
    </legend>

    <p v-if="description || slots.description" :class="$style.desc">
      <span :class="$style.slashes" aria-hidden="true">//</span>
      <span><slot name="description">{{ description }}</slot></span>
    </p>

    <div :class="[$style.body, divided && $style.divided]">
      <slot />
    </div>
  </fieldset>
</template>

<style module>
.section {
  display: block;
  min-width: 0;
  margin: 0;
  padding: 0;
  border: 0;
}

/* The seam between sections — a hairline, never a card edge. */
.section + .section {
  margin-top: var(--space-4);
  padding-top: var(--space-4);
  border-top: 1px solid var(--color-border-soft, var(--color-border));
}

.legend {
  width: 100%;
  padding: 0;
  font-family: var(--font-family);
  font-size: var(--font-size-lg);
  font-weight: 500;
  line-height: 1.3;
  color: var(--color-fg);
}

/* Mono ordinal — data font next to a prose title does the work a color would. */
.step {
  margin-right: var(--space-2);
  font-family: var(--font-mono);
  font-size: var(--font-size-xs);
  letter-spacing: 0.08em;
  color: var(--color-text-ghost);
  vertical-align: 0.15em;
}

.title { vertical-align: baseline; }

.aside {
  float: right;
  display: inline-flex;
  align-items: center;
  gap: var(--space-2);
  font-family: var(--font-mono);
  font-size: var(--font-size-xs);
  color: var(--color-muted);
}

/* The house `//` engineer line. */
.desc {
  display: flex;
  gap: var(--space-2);
  margin: var(--space-1) 0 0;
  font-family: var(--font-mono);
  font-size: var(--font-size-xs);
  line-height: 1.5;
  color: var(--color-muted);
}
.slashes { color: var(--color-text-ghost); flex-shrink: 0; }

.body {
  display: flex;
  flex-direction: column;
  gap: var(--space-4);
  min-width: 0;
  margin-top: var(--space-4);
}

.divided > * + * {
  padding-top: var(--space-4);
  border-top: 1px solid var(--color-border-soft, var(--color-border));
}

.off .legend,
.off .desc { opacity: 0.5; }

.offscreen {
  position: absolute;
  width: 1px;
  height: 1px;
  margin: 0;
  padding: 0;
  overflow: hidden;
  white-space: nowrap;
  clip-path: inset(50%);
}
</style>
