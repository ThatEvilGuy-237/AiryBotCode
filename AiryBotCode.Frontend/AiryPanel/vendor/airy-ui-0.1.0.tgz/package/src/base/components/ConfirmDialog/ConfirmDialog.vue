<script setup lang="ts">
/**
 * ConfirmDialog — yes/no confirmation built on Modal. Replaces native confirm().
 *
 * @prop open / title / message / confirmText / cancelText
 * @prop danger - render the confirm action as destructive (red)
 * @event confirm / cancel
 *
 * Status: new
 */
import Modal from '../Modal/Modal.vue'

withDefaults(defineProps<{
  open: boolean
  title?: string
  message?: string
  confirmText?: string
  cancelText?: string
  danger?: boolean
}>(), { title: 'Are you sure?', confirmText: 'Confirm', cancelText: 'Cancel', danger: false })

const emit = defineEmits<{ confirm: []; cancel: [] }>()
</script>

<template>
  <Modal data-ui="confirm-dialog" :open="open" :title="title" size="sm" @close="emit('cancel')">
    <p :class="$style.msg"><slot>{{ message }}</slot></p>
    <template #footer>
      <button type="button" :class="$style.cancel" @click="emit('cancel')">{{ cancelText }}</button>
      <button type="button" :class="[$style.confirm, danger && $style.danger]" @click="emit('confirm')">{{ confirmText }}</button>
    </template>
  </Modal>
</template>

<style module>
.msg { font-size: var(--font-size-sm); color: var(--color-text-dim, var(--color-fg)); line-height: 1.5; margin: 0; }
.cancel, .confirm { height: 30px; padding: 0 14px; border-radius: var(--radius); cursor: pointer; font-family: var(--font-family); font-size: var(--font-size-sm); border: var(--border); }
.cancel { background: var(--color-surface); color: var(--color-fg); }
.cancel:hover { background: var(--color-surface-hi, var(--color-bg)); }
.confirm { background: var(--color-accent-mute, var(--color-accent, var(--color-fg))); color: var(--color-fg); border-color: var(--color-accent, var(--color-fg)); }
.danger { background: var(--color-danger, #d64b46); border-color: var(--color-danger, #d64b46); color: #fff; }
</style>
