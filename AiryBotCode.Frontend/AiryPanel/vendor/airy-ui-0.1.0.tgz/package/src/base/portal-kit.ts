import {
  defineComponent,
  h,
  type PropType,
} from 'vue'
import HiveField from './components/Field/Field.vue'
import HiveText from './components/Text/Text.vue'
import HiveNumberField from './components/NumberField/NumberField.vue'
import './portal-kit.css'

export { default as Alert } from './components/Alert/Alert.vue'
export { default as ButtonBar } from './components/ButtonBar/ButtonBar.vue'
export { default as Tree } from './components/Tree/Tree.vue'
export { default as MultiSelect } from './components/MultiSelect/MultiSelect.vue'
export { default as RadioGroup } from './components/RadioGroup/RadioGroup.vue'
export { default as Chart } from './components/Chart/Chart.vue'
export type { ChartSeries, ChartTone, ChartHover, ChartPointEvent } from './components/Chart/types'
export { default as TraceRow } from './components/TraceRow/TraceRow.vue'
export { default as LoadingBar } from './components/LoadingBar/LoadingBar.vue'
export { default as Toaster } from './components/ToastHost/ToastHost.vue'
export { default as DescriptionList } from './components/KeyValueList/KeyValueList.vue'
export { default as TabStrip } from './components/Tabs/Tabs.vue'
export { default as Drawer } from './components/Drawer/Drawer.vue'
export { default as Markdown } from './components/Markdown/Markdown.vue'
export { default as Stat } from './components/Stat/Stat.vue'
export { default as StatStrip } from './components/StatStrip/StatStrip.vue'
export { default as StatGroup } from './components/StatStrip/StatStrip.vue'
export { default as Autocomplete } from './components/Autocomplete/Autocomplete.vue'
export type { AutocompleteOption, AutocompleteCommit } from './components/Autocomplete/Autocomplete.vue'
export { default as InfoTerm } from './components/InfoTerm/InfoTerm.vue'
export { defineGlossary, glossaryEntry, hasGlossaryEntry, glossaryEntries } from './components/InfoTerm/glossary'
export type { GlossaryEntry } from './components/InfoTerm/glossary'
export { formatTraceDuration } from './components/TraceRow/trace'
export { default as Table } from './components/Table/Table.vue'
export { default as TableColumn } from './components/Table/TableColumn.vue'
export type { TreeNode, TreeKey, TreeExpandedMap } from './components/Tree/types'
export { default as Badge } from './portal/PortalBadge.vue'
export { default as Button } from './portal/PortalButton.vue'
export { default as Card } from './portal/PortalCard.vue'
export { default as EmptyState } from './portal/PortalEmptyState.vue'
export { default as PageHeader } from './portal/PortalPageHeader.vue'
export { default as Switch } from './portal/PortalSwitch.vue'
export { default as AppSidebar } from './components/AppSidebar/AppSidebar.vue'
export { default as SidebarSection } from './components/AppSidebar/SidebarSection.vue'
export { default as SidebarItem } from './components/AppSidebar/SidebarItem.vue'
export type { SidebarFoldMap, SidebarBadge } from './components/AppSidebar/types'
export { default as BottomNav } from './components/BottomNav/BottomNav.vue'
export { default as BottomNavItem } from './components/BottomNav/BottomNavItem.vue'
export { default as SectionNav } from './components/SectionNav/SectionNav.vue'
export { default as SectionNavItem } from './components/SectionNav/SectionNavItem.vue'
export { default as DatePicker } from './components/DatePicker/DatePicker.vue'
export { default as Form } from './components/Form/Form.vue'
export { default as FormSection } from './components/Form/FormSection.vue'
export { default as FormRow } from './components/Form/FormRow.vue'
export type { FormSubmitContext } from './components/Form/Form.vue'



export const Field = defineComponent({
  name: 'Field',
  inheritAttrs: false,
  props: {
    modelValue: { type: [String, Number], default: '' }, label: String, hint: String,
    error: String, required: Boolean, hideLabel: Boolean,
    type: { type: String, default: 'text' }, placeholder: String, disabled: Boolean,
  },
  emits: ['update:modelValue'],
  setup(props, { attrs, emit, slots }) {
    return () => h(HiveField, {
      label: props.label, hint: props.hint, error: props.error,
      required: props.required, disabled: props.disabled, hideLabel: props.hideLabel,
    }, {
      default: slots.default ?? (({ id, describedBy, invalid }: { id: string; describedBy?: string; invalid: boolean }) => h('input', {
        ...attrs, id, 'aria-describedby': describedBy, 'aria-invalid': invalid || undefined,
        class: ['hpk-field__input', attrs.class], type: props.type,
        value: props.modelValue, placeholder: props.placeholder, disabled: props.disabled,
        onInput: (e: Event) => {
          const v = (e.target as HTMLInputElement).value
          emit('update:modelValue', props.type === 'number' && v !== '' ? Number(v) : v)
        },
      })),
    })
  },
})

export const NumberField = defineComponent({
  name: 'NumberField',
  props: {
    modelValue: { type: Number as unknown as PropType<number | null>, default: null },
    label: String, hint: String, unit: String,
    min: Number, max: Number, step: Number, precision: Number,
    disabled: Boolean,
  },
  emits: ['update:modelValue'],
  setup: (props, { emit }) => () => h(HiveField, { label: props.label, hint: props.hint, disabled: props.disabled }, {
    default: () => h(HiveNumberField, {
      modelValue: props.modelValue, unit: props.unit,
      min: props.min, max: props.max, step: props.step, precision: props.precision,
      allowEmpty: false, disabled: props.disabled,
      'onUpdate:modelValue': (v: number | null) => emit('update:modelValue', v),
    }),
  }),
})

export const Text = defineComponent({
  name: 'Text',
  props: { type: { type: String, default: 'body' }, color: String },
  setup: (props, { slots }) => () => h(HiveText, {
    variant: props.type === 'label' ? 'eyebrow' : 'body',
    as: props.type === 'heading' ? 'h3' : undefined,
    size: props.type === 'small' ? 'sm' : props.type === 'heading' ? 'lg' : undefined,
    tone: props.color === 'muted' ? 'muted'
      : props.color === 'dim' ? 'dim'
      : props.color === 'danger' ? 'danger'
      : 'default',
  }, slots),
})

