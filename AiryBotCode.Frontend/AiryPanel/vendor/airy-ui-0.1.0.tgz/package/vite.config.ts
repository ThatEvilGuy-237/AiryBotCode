import { defineConfig, Plugin } from 'vite'
import vue from '@vitejs/plugin-vue'
import dts from 'vite-plugin-dts'
import { resolve } from 'path'
import { copyFileSync, mkdirSync } from 'fs'

function copyStylesheets(): Plugin {
  return {
    name: 'copy-stylesheets',
    closeBundle() {
      const out = resolve(__dirname, 'dist')
      mkdirSync(out, { recursive: true })
      for (const f of ['theme.css', 'reset.css', 'site-tokens.css']) {
        copyFileSync(resolve(__dirname, 'src/base', f), resolve(out, f))
      }
      copyFileSync(resolve(__dirname, 'src/airy/tokens.css'), resolve(out, 'tokens.css'))
      copyFileSync(resolve(__dirname, 'src/airy/fonts.css'), resolve(out, 'fonts.css'))
    },
  }
}

export default defineConfig({
  plugins: [
    vue(),
    dts({ include: ['src'], rollupTypes: true, tsconfigPath: './tsconfig.json' }),
    copyStylesheets(),
  ],
  resolve: {
    alias: [
      { find: /^@evil-ui\/base\/site$/, replacement: resolve(__dirname, 'src/base/site-kit.ts') },
      { find: /^@evil-ui\/base\/portal$/, replacement: resolve(__dirname, 'src/base/portal-kit.ts') },
      { find: /^@evil-ui\/base\/flow$/, replacement: resolve(__dirname, 'src/base/flow-kit.ts') },
      { find: /^@evil-ui\/base$/, replacement: resolve(__dirname, 'src/base/index.ts') },
    ],
  },
  build: {
    outDir: 'dist',
    emptyOutDir: true,
    lib: {
      entry: {
        index: resolve(__dirname, 'src/airy/index.ts'),
        site: resolve(__dirname, 'src/airy/site.ts'),
        portal: resolve(__dirname, 'src/airy/portal.ts'),
        flow: resolve(__dirname, 'src/airy/flow.ts'),
      },
      formats: ['es'],
      fileName: (_format, entryName) => `${entryName}.js`,
    },
    rollupOptions: { external: ['vue', 'vue-router'] },
    cssCodeSplit: false,
    minify: false,
  },
})
