# Airy UI

Airy's control panel: a dark navy sky, one sky-blue accent from the cloud logo, DM Sans for words and JetBrains Mono for Discord ids.

One package with everything: the shared base components, the Airy tokens and the
company's own components. No other UI dependency. Only `vue` (and `vue-router` for the navigation
components) must be installed in the consuming app.

## Install

```bash
npm install ./airy-ui-0.1.3.tgz
```

## Use

```ts
import { createApp } from 'vue'
import '@airy/ui/fonts.css'
import '@airy/ui/reset.css'
import '@airy/ui/theme.css'
import '@airy/ui/site-tokens.css'
import '@airy/ui/tokens.css'
import '@airy/ui/components.css'
```

```vue
<script setup lang="ts">
import { Button, Card, Badge } from '@airy/ui'
import { Section, TagList } from '@airy/ui/site'
</script>
```

`theme.css` holds the base defaults for every token and `site-tokens.css` the long-form layer on top of
it; `tokens.css` is the Airy identity and must come after both. Leave out `theme.css`
when the app must not load Google Fonts; `tokens.css` declares every name the components read.

## What is inside

- `dist/` the built package: `index` (platform kit + company components), `site` (long-form kit),
  `portal` (portal kit), `flow` (flow kit), the stylesheets and bundled type declarations. A content site
  that only uses the site kit imports `site.css` instead of `components.css` and ships no platform styles.
- `src/base/` the shared base source as exported, for reading and for patches.
- `src/airy/` the company layer: `tokens.css`, `overrides.css`, own components, the re-export index.
- `vite.config.ts` and `tsconfig.json`: the package rebuilds itself.

## Change it and rebuild

```bash
npm install
npm run build        # regenerates dist/ from src/
npm pack             # a fresh tarball to install elsewhere
```

Edit `src/airy/tokens.css` for colours, fonts and radii, `src/airy/overrides.css`
to reshape base components through their `data-ui` and `data-site` hooks, and add components under
`src/airy/components/`. Patches to `src/base/` work too, but they stay in this package.

Built from @evil-ui/base 0.1.0 and @evil-ui/airy 0.1.3.
