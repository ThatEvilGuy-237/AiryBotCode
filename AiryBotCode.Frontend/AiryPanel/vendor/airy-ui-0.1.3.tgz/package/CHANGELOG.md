# Airy UI changes

Since the last hand-over (base commit 0d26c22), up to a774a2d. Base 0.1.0, company package 0.1.3.

## Your layer (companies/airy)

- **package.json**
  - Airy 0.1.2: readable ghost text on navy, phone-sized buttons, fields and selects
- **src/overrides.css**
  - Airy 0.1.2: readable ghost text on navy, phone-sized buttons, fields and selects
- **src/tokens.css**
  - Airy 0.1.2: readable ghost text on navy, phone-sized buttons, fields and selects

1 commit(s) in range.
