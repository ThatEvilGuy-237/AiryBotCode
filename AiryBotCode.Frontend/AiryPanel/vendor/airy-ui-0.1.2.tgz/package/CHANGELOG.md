# Airy UI changes

Since the last hand-over (base commit 0d26c22), up to 0d26c22. Base 0.1.0, company package 0.1.2.

No changes to the base or to your layer in this range.
0 commit(s) in range.
